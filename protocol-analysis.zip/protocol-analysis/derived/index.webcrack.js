const __vite__mapDeps = (i, m = __vite__mapDeps, d = m.f ||= ["assets/es-CWfXW5jh.js", "assets/shared-CAKwAg2C.js", "assets/pt-1gauOvPm.js", "assets/fr-C5eMvhxr.js", "assets/it-C2pCPOTd.js", "assets/de-CkTXFfkZ.js", "assets/nl-iZ_6hecB.js", "assets/pl-C7_zAHkL.js", "assets/tr-Bud-ECdT.js", "assets/id-DSv3w2E0.js", "assets/vi-BtObyLa_.js", "assets/el-C5kf_mfQ.js", "assets/uk-CFZ4hBii.js", "assets/ru-BEX_fK9x.js", "assets/hi-kacvLFRn.js", "assets/ar-MCahGY6d.js", "assets/he-BTJlyhmU.js"]) => i.map(i => d[i]);
(function () {
  const t = document.createElement("link").relList;
  if (t && t.supports && t.supports("modulepreload")) {
    return;
  }
  for (const o of document.querySelectorAll("link[rel=\"modulepreload\"]")) {
    n(o);
  }
  new MutationObserver(o => {
    for (const a of o) {
      if (a.type === "childList") {
        for (const r of a.addedNodes) {
          if (r.tagName === "LINK" && r.rel === "modulepreload") {
            n(r);
          }
        }
      }
    }
  }).observe(document, {
    childList: true,
    subtree: true
  });
  function s(o) {
    const a = {};
    if (o.integrity) {
      a.integrity = o.integrity;
    }
    if (o.referrerPolicy) {
      a.referrerPolicy = o.referrerPolicy;
    }
    if (o.crossOrigin === "use-credentials") {
      a.credentials = "include";
    } else if (o.crossOrigin === "anonymous") {
      a.credentials = "omit";
    } else {
      a.credentials = "same-origin";
    }
    return a;
  }
  function n(o) {
    if (o.ep) {
      return;
    }
    o.ep = true;
    const a = s(o);
    fetch(o.href, a);
  }
})();
const h = "192.168.1.10";
const ce = "192.168.1.1";
const se = "198.51.100.7";
const ae = 14;
const re = 20;
const ie = 20;
const Yt = 22;
const W = 1460;
const x = e => `${e.toFixed(3)}s`;
const j = e => Math.max(60, ae + re + ie + e);
const kl = e => ae + re + ie + Yt + e;
const K = (...e) => e.reduce((t, s) => t + s.length + 2, 0);
const St = e => e >= 1024 ? `${(e / 1024).toFixed(1)} KB` : `${e} B`;
const rt = e => Math.ceil(e / W);
const it = (e, t = 1) => t > 1 ? St(e) : `${e} B`;
const l = (e, t, s, n, o, a, r = {}) => ({
  type: "packet",
  from: e,
  to: t,
  color: s,
  label: n,
  payload: o,
  row: a,
  ...r
});
function q(e, t, s, n) {
  return {
    a: e,
    b: s,
    ports: o => o === e ? {
      sport: t,
      dport: n
    } : {
      sport: n,
      dport: t
    }
  };
}
const P = (e, t, s, n, o = {}) => ({
  tcp: {
    ...e.ports(t),
    flags: s,
    data: n,
    ...o
  }
});
const Mt = 12;
function he({
  from: e = "client",
  to: t = "web",
  src: s = h,
  dst: n,
  sport: o,
  dport: a,
  t: r,
  quick: i = true,
  linux: c = false
}) {
  const d = (T, m, w, k, A, N) => ({
    time: x(T),
    src: m,
    dst: w,
    proto: "TCP",
    info: k,
    len: `${A} B`,
    wire: N
  });
  const p = T => i ? [] : T;
  const u = q(s, o, n, a);
  const y = c ? Mt : 0;
  return [l(e, t, "green", "SYN", p(["seq=0"]), d(r[0], s, n, `${o} → ${a} [SYN] Seq=0`, c ? 74 : 66, P(u, s, "S")), {
    quick: i
  }), l(t, e, "green", "SYN-ACK", p(["seq=0 ack=1"]), d(r[1], n, s, `${a} → ${o} [SYN, ACK] Seq=0 Ack=1`, c ? 74 : 66, P(u, n, "SA")), {
    quick: i
  }), l(e, t, "green", "ACK", p(["seq=1 ack=1"]), d(r[2], s, n, `${o} → ${a} [ACK] Seq=1 Ack=1`, j(y), P(u, s, "A")), {
    quick: i
  })];
}
const Wi = 2862;
const fa = e => ({
  tls: [{
    type: "handshake",
    legacy: true,
    length: 512,
    hello: {
      type: 1,
      name: "Client Hello",
      note: "What this client supports. Its exact contents vary from client to client; this is an example.",
      fields: [["Server name (SNI)", e], ["Versions offered", "TLS 1.3, TLS 1.2"], ["Key share", "X25519"], ["Padding", "up to 512 bytes"]]
    }
  }]
});
const Vi = (e = "X25519", t = 122) => ({
  tls: [{
    type: "handshake",
    length: t,
    hello: {
      type: 2,
      name: "Server Hello",
      note: "The server’s choices and its key share.",
      fields: [["Version", "TLS 1.3"], ["Cipher suite", "TLS_AES_128_GCM_SHA256"], ["Key share", e]]
    }
  }, {
    type: "ccs",
    length: 1
  }, {
    type: "appdata",
    length: 2724,
    inner: {
      what: "Encrypted Extensions, Certificate (the chain), Certificate Verify (the signature), Finished"
    }
  }]
});
const Pl = {
  tls: [{
    type: "ccs",
    length: 1
  }, {
    type: "appdata",
    length: 53,
    inner: {
      what: "Finished: a check value over the whole handshake"
    }
  }]
};
const Mr = (e, t) => ({
  tls: [{
    type: "appdata",
    length: K(...e) + 17,
    inner: {
      what: t,
      text: e
    }
  }]
});
const R0 = (e, t) => ({
  tls: [{
    type: "appdata",
    length: e + 17,
    inner: {
      what: t
    }
  }]
});
function mo({
  from: e = "client",
  to: t = "web",
  src: s = h,
  dst: n,
  sni: o,
  sport: a,
  dport: r,
  t: i,
  linux: c = false
}) {
  const d = (T, m, w, k, A, N) => ({
    time: x(T),
    src: m,
    dst: w,
    proto: "TLSv1.3",
    info: k,
    len: A,
    wire: N
  });
  const p = q(s, a, n, r);
  const u = c ? Mt : 0;
  const y = Wi + (ae + re + ie + u) * 2;
  return [l(e, t, "teal", "CLIENT HELLO", [], d(i[0], s, n, `Client Hello (SNI=${o})`, `${517 + ae + re + ie + u} B`, P(p, s, "PA", fa(o))), {
    quick: true
  }), l(t, e, "teal", "SERVER HELLO", [], d(i[1], n, s, "Server Hello + encrypted handshake, 2 segments", St(y), P(p, n, "PA", Vi())), {
    quick: true
  }), l(e, t, "teal", "FINISHED", [], d(i[2], s, n, "Change Cipher Spec, Finished (encrypted)", `${64 + ae + re + ie + u} B`, P(p, s, "PA", Pl)), {
    quick: true
  })];
}
const ti = "8.8.8.8";
const _o = "203.0.113.10";
const pp = ["GET / HTTP/1.1", "Host: www.example.com", "Connection: keep-alive", "Upgrade-Insecure-Requests: 1", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7", "Accept-Encoding: gzip, deflate", "Accept-Language: en-US,en;q=0.9", ""];
const N0 = K(...pp);
const Fs = 12500;
const up = ["HTTP/1.1 200 OK", "Date: Sat, 31 Oct 2026 09:41:00 GMT", "Content-Type: text/html; charset=utf-8", `Content-Length: ${Fs}`, "Connection: keep-alive", ""];
const fp = K(...up) + Fs;
const Sc = q(h, 52344, _o, 80);
const Tc = {
  id: 15642,
  rd: true,
  q: ["www.example.com", "A"]
};
const bc = (e, t) => ({
  udp: e === h ? {
    sport: 59321,
    dport: 53,
    data: {
      dns: t
    }
  } : {
    sport: 53,
    dport: 59321,
    data: {
      dns: t
    }
  }
});
const ln = rt(fp);
const D0 = fp + ln * (ae + re + ie);
const vc = 0.094;
const O0 = {
  id: "http",
  name: "HTTP",
  title: "Web Communication",
  layer: 7,
  nodes: ["client", "router", "dns", "internet", "web"],
  latency: {
    "client-dns": 0.012,
    "client-web": 0.017
  },
  legend: [["blue", "DNS"], ["green", "TCP"], ["amber", "Request"], ["violet", "Response"], [null, "Data ACKs not shown"]],
  overview: {
    full: "Hypertext Transfer Protocol",
    description: "HTTP is the protocol of the web: a client asks for a resource, such as an HTML page, and the server answers with a status code, headers and usually a body. Every exchange is one request and one response, written as readable text in HTTP/1.1.",
    facts: [["Layer", "Application (Layer 7)"], ["Default Port", "80 (HTTPS: 443)"], ["Transport", "TCP"], ["Data Format", "Text (headers + optional body)"], ["Common Methods", "GET, POST, PUT, DELETE, HEAD"], ["Defined In", "RFC 9110, RFC 9112"]]
  },
  outro: {
    title: "Page delivered",
    desc: "One request, one response",
    text: "In under a tenth of a second the laptop looked up an address, opened a TCP connection and exchanged one HTTP request and response, all of it readable by anyone on the path. Press REPLAY to watch it again.",
    facts: [["Round trips", "3 (DNS, TCP, HTTP)"], ["Total time", `${vc.toFixed(3)} s`], ["Page size", St(Fs)], ["Response", `Sent as ${ln} TCP segments`]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Client Request",
    desc: "Browser prepares the request",
    detail: "You open http://www.example.com. The browser will send a GET request, but packets travel to IP addresses, not names, so first it needs the server’s address. (Browsers now try https:// first; this is the plain version.)",
    facts: [["URL", "http://www.example.com/"], ["Method", "GET"], ["Next hop", "Router 192.168.1.1"]],
    events: [{
      type: "type-url",
      text: "www.example.com"
    }, {
      type: "show",
      nodes: ["router"],
      frame: "local"
    }]
  }, {
    title: "DNS Resolution",
    desc: "Finds the server’s IP address",
    detail: "The laptop asks the DNS server it was given by DHCP, 8.8.8.8, for the address of www.example.com. The query goes over UDP port 53 and the answer is an A record with the IPv4 address. (On a network with IPv6 it would also ask for an AAAA record.)",
    facts: [["Resolver", "8.8.8.8 (had it cached)"], ["Transport", "UDP, port 53"], ["Answer", "A 203.0.113.10"]],
    events: [{
      type: "show",
      nodes: ["internet", "dns"],
      frame: "lookup"
    }, l("client", "dns", "blue", "DNS QUERY", ["A? www.example.com"], {
      time: x(0),
      src: h,
      dst: ti,
      proto: "DNS",
      info: "Standard query A www.example.com",
      len: "75 B",
      wire: bc(h, Tc)
    }), l("dns", "client", "blue", "DNS REPLY", ["A 203.0.113.10"], {
      time: x(0.012),
      src: ti,
      dst: h,
      proto: "DNS",
      info: "Standard query response A 203.0.113.10",
      len: "91 B",
      wire: bc(ti, {
        ...Tc,
        response: true,
        ra: true,
        an: [["www.example.com", "A", 1745, "203.0.113.10"]],
        exampleTtl: true
      })
    })]
  }, {
    title: "TCP Connection",
    desc: "Establishes a reliable link",
    detail: "HTTP runs on top of TCP. Before any page data moves, the laptop and the server open a connection to port 80 with a three-way handshake: SYN, SYN-ACK, ACK.",
    facts: [["Server port", "80"], ["Client port", "52344 (ephemeral)"], ["Handshake", "SYN → SYN-ACK → ACK"]],
    events: [{
      type: "show",
      nodes: ["web"],
      frame: "full"
    }, ...he({
      dst: _o,
      sport: 52344,
      dport: 80,
      t: [0.024, 0.041, 0.058],
      quick: false
    })]
  }, {
    title: "HTTP Exchange",
    desc: "Request and response messages",
    detail: `The browser sends a GET request with a Host header. The server answers 200 OK with the HTML in the body: ${St(Fs)}, too big for one packet, so TCP splits it into ${ln} segments of up to ${W} bytes (drawn here as one).`,
    facts: [["Status", "200 OK"], ["Body", `text/html, ${St(Fs)}`], ["Sent as", `${ln} TCP segments`]],
    events: [l("client", "web", "amber", "GET /", ["GET / HTTP/1.1", "Host: www.example.com"], {
      time: x(0.058),
      src: h,
      dst: _o,
      proto: "HTTP",
      info: "GET / HTTP/1.1",
      len: `${j(N0)} B`,
      wire: P(Sc, h, "PA", {
        text: pp
      })
    }), l("web", "client", "violet", "200 OK", ["HTTP/1.1 200 OK", `${St(Fs)} in ${ln} segments`], {
      time: x(0.076),
      src: _o,
      dst: h,
      proto: "HTTP",
      info: `HTTP/1.1 200 OK (text/html), ${ln} segments`,
      len: it(D0, ln),
      wire: P(Sc, _o, "PA", {
        http: {
          lines: up,
          body: Fs,
          what: "the HTML page"
        }
      })
    })]
  }, {
    title: "Page Rendering",
    desc: "Browser displays the content",
    detail: "The browser parses the HTML and paints the page. Linked CSS, images and scripts would each start more requests just like this one, reusing the open connection where they can.",
    facts: [["Document", `text/html, ${St(Fs)}`], ["Connection", "Kept open for reuse"], ["Total time", `${vc.toFixed(3)} s`]],
    events: [{
      type: "camera",
      frame: "client"
    }, {
      type: "render"
    }]
  }]
};
const si = "8.8.8.8";
const Bt = "203.0.113.10";
const ni = {
  locked: true
};
const Al = ["GET / HTTP/1.1", "Host: www.example.com", "Connection: keep-alive", "sec-ch-ua: \"Chromium\";v=\"142\", \"Google Chrome\";v=\"142\", \"Not_A Brand\";v=\"99\"", "sec-ch-ua-mobile: ?0", "sec-ch-ua-platform: \"Windows\"", "Upgrade-Insecure-Requests: 1", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7", "Sec-Fetch-Site: none", "Sec-Fetch-Mode: navigate", "Sec-Fetch-User: ?1", "Sec-Fetch-Dest: document", "Accept-Encoding: gzip, deflate, br, zstd", "Accept-Language: en-US,en;q=0.9", ""];
const Yi = K(...Al) + Yt;
const ma = 12500;
const El = ["HTTP/1.1 200 OK", "Date: Sat, 31 Oct 2026 09:41:00 GMT", "Content-Type: text/html; charset=utf-8", `Content-Length: ${ma}`, "Connection: keep-alive", "Strict-Transport-Security: max-age=31536000", ""];
const qr = K(...El) + ma + Yt;
const ra = rt(qr);
const ji = qr + ra * (ae + re + ie);
const xl = (217 + Yt) * 2;
const kc = 0.13;
const mp = {
  tls: [{
    type: "handshake",
    legacy: true,
    length: 1845,
    hello: {
      type: 1,
      name: "Client Hello",
      note: "Everything the browser supports. Browsers vary a few details from one connection to the next.",
      fields: [["Server name (SNI)", "www.example.com"], ["Versions offered", "TLS 1.3, TLS 1.2"], ["Key shares", "X25519MLKEM768 (1,216 bytes), X25519"], ["App protocols (ALPN)", "h2, http/1.1"]]
    }
  }]
};
const zi = {
  tls: [{
    type: "handshake",
    length: 1210,
    hello: {
      type: 2,
      name: "Server Hello",
      note: "The server’s choices and its half of the hybrid key exchange.",
      fields: [["Version", "TLS 1.3"], ["Cipher suite", "TLS_AES_128_GCM_SHA256"], ["Key share", "X25519MLKEM768 (1,120 bytes)"]]
    }
  }, {
    type: "ccs",
    length: 1
  }, {
    type: "appdata",
    length: 2724,
    inner: {
      what: "Encrypted Extensions (ALPN: http/1.1), Certificate (the chain), Certificate Verify (the signature), Finished"
    }
  }]
};
const Qi = {
  type: "appdata",
  length: xl / 2 - 5,
  inner: {
    what: "New Session Ticket: lets a later visit resume"
  }
};
const An = q(h, 52411, Bt, 443);
const Pc = {
  id: 31810,
  rd: true,
  q: ["www.example.com", "A"]
};
const Ac = (e, t) => ({
  udp: e === h ? {
    sport: 61744,
    dport: 53,
    data: {
      dns: t
    }
  } : {
    sport: 53,
    dport: 61744,
    data: {
      dns: t
    }
  }
});
const ut = {
  REQUEST: Yi,
  RESPONSE: qr,
  SEGMENTS: ra,
  RESPONSE_FRAMES: ji,
  TICKETS: xl,
  REQUEST_LINES: Al,
  RESPONSE_LINES: El,
  BODY: ma,
  TICKET: Qi
};
const M0 = {
  id: "https",
  name: "HTTPS",
  title: "Secure Web",
  layer: 7,
  nodes: ["client", "router", "dns", "internet", "web"],
  latency: {
    "client-dns": 0.012,
    "client-web": 0.017
  },
  legend: [["blue", "DNS"], ["green", "TCP"], ["teal", "TLS handshake"], ["amber", "HTTP request"], ["violet", "HTTP response"], [null, "Data ACKs not shown"]],
  overview: {
    full: "HTTP Secure",
    description: "HTTPS is HTTP sent through an encrypted TLS connection. TLS proves the server is who it claims to be with a certificate, agrees on fresh encryption keys, and then protects every request and response from being read or changed on the way.",
    facts: [["Layer", "Application (HTTP over TLS)"], ["Default Port", "443"], ["Transport", "TCP"], ["Security", "TLS 1.3 (1.2 still common)"], ["Proves", "Server identity (certificate)"], ["Defined In", "RFC 9110, RFC 8446"]]
  },
  outro: {
    title: "Secure page delivered",
    desc: "Encrypted, except the lookup",
    text: "The browser looked up the address in plain DNS, opened a TCP connection, checked the server’s certificate and agreed on keys in one round trip. Every HTTP byte after that travelled encrypted. Press REPLAY to watch it again.",
    facts: [["Round trips", "4 (DNS, TCP, TLS, HTTP)"], ["Total time", `${kc.toFixed(3)} s`], ["Cipher", "TLS_AES_128_GCM_SHA256"], ["Still visible", "IPs, server name, sizes"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Secure Request",
    desc: "Browser asks for https://",
    detail: "You type https://www.example.com. The “s” tells the browser to protect the connection with TLS, on port 443 by default. Before it can connect at all, it still has to find the server’s IP address.",
    facts: [["URL", "https://www.example.com/"], ["Port", "443"], ["Next hop", "Router 192.168.1.1"]],
    events: [{
      type: "type-url",
      text: "https://www.example.com",
      secure: true
    }, {
      type: "show",
      nodes: ["router"],
      frame: "local"
    }]
  }, {
    title: "DNS Lookup",
    desc: "Same lookup as HTTP, not encrypted",
    detail: "The lookup is exactly the same as for plain HTTP: a query to 8.8.8.8 over UDP port 53. It is not encrypted, so anyone on the path can see which name you asked for, unless the browser uses DNS over HTTPS.",
    facts: [["Resolver", "8.8.8.8 (had it cached)"], ["Encrypted", "No (plain DNS)"], ["Answer", "A 203.0.113.10"]],
    events: [{
      type: "show",
      nodes: ["internet", "dns"],
      frame: "lookup"
    }, l("client", "dns", "blue", "DNS QUERY", ["A? www.example.com"], {
      time: x(0),
      src: h,
      dst: si,
      proto: "DNS",
      info: "Standard query A www.example.com",
      len: "75 B",
      wire: Ac(h, Pc)
    }), l("dns", "client", "blue", "DNS REPLY", ["A 203.0.113.10"], {
      time: x(0.012),
      src: si,
      dst: h,
      proto: "DNS",
      info: "Standard query response A 203.0.113.10",
      len: "91 B",
      wire: Ac(si, {
        ...Pc,
        response: true,
        ra: true,
        an: [["www.example.com", "A", 1722, "203.0.113.10"]],
        exampleTtl: true
      })
    })]
  }, {
    title: "TCP Handshake",
    desc: "Opens a connection to port 443",
    detail: "TLS rides on TCP, so the same three-way handshake comes first, this time to port 443. Nothing is encrypted yet.",
    facts: [["Server port", "443"], ["Client port", "52411 (ephemeral)"], ["Handshake", "SYN → SYN-ACK → ACK"]],
    events: [{
      type: "show",
      nodes: ["web"],
      frame: "full"
    }, ...he({
      dst: Bt,
      sport: 52411,
      dport: 443,
      t: [0.024, 0.041, 0.058],
      quick: false
    })]
  }, {
    title: "TLS Handshake",
    desc: "Agrees on keys, checks the certificate",
    detail: "The browser offers ciphers and key shares, including a post-quantum hybrid. The server picks it and sends its own share, then its certificate, already encrypted. The browser checks it against authorities it trusts.",
    facts: [["Version", "TLS 1.3"], ["Key exchange", "X25519MLKEM768 (hybrid)"], ["Server name", "Sent in clear (SNI)"]],
    events: [l("client", "web", "teal", "CLIENT HELLO", ["TLS 1.3, SNI www.example.com", "key shares: hybrid + x25519"], {
      time: x(0.058),
      src: h,
      dst: Bt,
      proto: "TLSv1.3",
      info: "Client Hello (SNI=www.example.com), 2 segments",
      len: "1.9 KB",
      wire: P(An, h, "PA", mp)
    }), l("web", "client", "teal", "SERVER HELLO", ["cipher: AES_128_GCM_SHA256", "then encrypted: cert, Finished"], {
      time: x(0.076),
      src: Bt,
      dst: h,
      proto: "TLSv1.3",
      info: "Server Hello + encrypted handshake, 3 segments",
      len: "4.0 KB",
      wire: P(An, Bt, "PA", zi)
    }), {
      type: "note",
      at: "client",
      text: "CERTIFICATE VALID",
      tone: "green"
    }, l("client", "web", "teal", "FINISHED", ["handshake complete (encrypted)"], {
      time: x(0.094),
      src: h,
      dst: Bt,
      proto: "TLSv1.3",
      info: "Change Cipher Spec, Finished (encrypted)",
      len: "118 B",
      wire: P(An, h, "PA", Pl)
    })]
  }, {
    title: "Encrypted Exchange",
    desc: "HTTP inside TLS records",
    detail: "The GET and 200 OK are the same HTTP messages as before, sealed in TLS records that look like random “application data” on the wire. The server also hands over two session tickets, so a later visit can skip part of the handshake.",
    facts: [["Inside", "GET / and 200 OK"], ["Tickets", "2, for faster reconnects"], ["Still visible", "IPs, server name, sizes"]],
    events: [l("client", "web", "amber", "APP DATA", ["inside: GET / HTTP/1.1", "outside: encrypted bytes"], {
      time: x(0.094),
      src: h,
      dst: Bt,
      proto: "TLSv1.3",
      info: "Application Data (HTTP request)",
      len: it(Yi + ae + re + ie),
      wire: P(An, h, "PA", {
        tls: [{
          type: "appdata",
          length: Yi - 5,
          inner: {
            what: "The HTTP request",
            text: Al
          }
        }]
      })
    }, ni), l("web", "client", "violet", "TICKETS", [], {
      time: x(0.111),
      src: Bt,
      dst: h,
      proto: "TLSv1.3",
      info: "New Session Ticket ×2 (encrypted)",
      len: it(xl + ae + re + ie),
      wire: P(An, Bt, "PA", {
        tls: [Qi, Qi]
      })
    }, {
      ...ni,
      quick: true
    }), l("web", "client", "violet", "APP DATA", ["inside: HTTP/1.1 200 OK", `outside: ${St(ji)}, ${ra} segments`], {
      time: x(0.112),
      src: Bt,
      dst: h,
      proto: "TLSv1.3",
      info: `Application Data (HTTP response), ${ra} segments`,
      len: it(ji, ra),
      wire: P(An, Bt, "PA", {
        tls: [{
          type: "appdata",
          length: qr - 5,
          inner: {
            what: `The HTTP response, then the ${ma.toLocaleString("en-US")}-byte page`,
            text: El
          }
        }]
      })
    }, ni)]
  }, {
    title: "Page Rendering",
    desc: "Browser shows the padlock",
    detail: "The browser decrypts the response, paints the page and shows a padlock: the connection is private and the server proved its identity. The Strict-Transport-Security header tells it to use HTTPS for this site from now on.",
    facts: [["Document", `text/html, ${St(ma)}`], ["Remembers", "HTTPS only (HSTS), 1 year"], ["Total time", `${kc.toFixed(3)} s`]],
    events: [{
      type: "camera",
      frame: "client"
    }, {
      type: "render"
    }]
  }]
};
const ya = "203.0.113.10";
const wa = 49152;
const yp = ["GET / HTTP/1.1", "Host: www.example.com", "User-Agent: curl/8.9.1", "Accept: */*", ""];
const fe = K(...yp);
const Oe = W * 2;
const wp = q(h, wa, ya, 80);
const gp = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "TCP",
  info: n,
  len: `${o} B`,
  wire: a
});
const Ao = (e, t, s, n, o, a) => gp(e, h, ya, `${wa} → 80 ${t}`, s, P(wp, h, n, o, a));
const En = (e, t, s, n, o, a) => gp(e, ya, h, `80 → ${wa} ${t}`, s, P(wp, ya, n, o, a));
const oi = e => ({
  opaque: W,
  what: `the HTTP response, bytes ${e}–${e + W - 1}`,
  name: "HTTP"
});
const q0 = {
  id: "tcp",
  name: "TCP",
  title: "Reliable Delivery",
  layer: 4,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.017
  },
  legend: [["green", "Handshake and ACKs"], ["amber", "Data from laptop"], ["violet", "Data from server"], ["slate", "Closing (FIN)"]],
  overview: {
    full: "Transmission Control Protocol",
    description: "TCP turns the internet’s best-effort packet delivery into a reliable, ordered stream of bytes. It numbers every byte, acknowledges what arrives, resends what goes missing, and paces the sender so neither the other side nor the network is overwhelmed.",
    facts: [["Layer", "Transport (Layer 4)"], ["Connection", "Three-way handshake"], ["Reliability", "Sequence numbers + ACKs"], ["Recovery", "Retransmission"], ["Header", "20–60 bytes"], ["Defined In", "RFC 9293"]]
  },
  outro: {
    title: "Connection closed",
    desc: "Every byte accounted for",
    text: "TCP opened a connection, numbered and acknowledged every byte, spotted a gap and resent just the missing segment, then closed both directions cleanly. curl received every byte in order and never saw the loss. Press REPLAY to watch it again.",
    facts: [["Segments", "14 (1 lost, 1 resent)"], ["Bytes delivered", `${fe} up, ${Oe.toLocaleString("en-US")} down`], ["Loss found by", "Duplicate ACK + SACK"], ["Total time", "0.148 s"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Open Connection",
    desc: "Three-way handshake",
    detail: "curl already knows the server’s address. Before any data moves, both sides choose a starting sequence number and confirm it: SYN, SYN-ACK, ACK. The numbers here are relative; real ones start at a random value.",
    facts: [["Server", "203.0.113.10, port 80"], ["Client port", `${wa} (ephemeral)`], ["Flags", "SYN → SYN-ACK → ACK"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "full"
    }, ...he({
      dst: ya,
      sport: wa,
      dport: 80,
      t: [0, 0.017, 0.034],
      quick: false
    })]
  }, {
    title: "Send Data",
    desc: "Every byte is numbered",
    detail: `curl sends its ${fe}-byte HTTP request: bytes 1 to ${fe}. The server’s ACK number, ${fe + 1}, is the next byte it expects, which means everything before it has arrived.`,
    facts: [["Sent", `${fe} bytes (seq 1–${fe})`], ["ACK", `${fe + 1} = next byte expected`], ["Flags", "PSH, ACK"]],
    events: [l("client", "web", "amber", "DATA", [`seq=1  len=${fe}`, "GET / HTTP/1.1 …"], Ao(0.034, `[PSH, ACK] Seq=1 Ack=1 Len=${fe}`, j(fe), "PA", {
      text: yp,
      name: "HTTP"
    })), l("web", "client", "green", "ACK", [`ack=${fe + 1}`], En(0.051, `[ACK] Seq=1 Ack=${fe + 1}`, j(0), "A"))]
  }, {
    title: "Two Segments Back",
    desc: "One of them is lost",
    detail: `The server answers with ${Oe.toLocaleString("en-US")} bytes: two full segments of ${W.toLocaleString("en-US")} bytes, the most that fits in one packet here, sent back to back. The first is dropped somewhere on the internet; the second gets through.`,
    facts: [["Segment 1", `bytes 1–${W} (lost)`], ["Segment 2", `bytes ${W + 1}–${Oe}`], ["Segment size", `${W.toLocaleString("en-US")} bytes (MSS)`]],
    events: [{
      type: "stream",
      from: "web",
      to: "client",
      color: "violet",
      label: "2 SEGMENTS",
      payload: [`seq=1 and seq=${W + 1}`, "the first is lost"],
      packets: [l("web", "client", "violet", "DATA", [], En(0.052, `[ACK] Seq=1 Ack=${fe + 1} Len=${W}`, j(W), "A", oi(1)), {
        lost: true
      }), l("web", "client", "violet", "DATA", [], En(0.052, `[PSH, ACK] Seq=${W + 1} Ack=${fe + 1} Len=${W}`, j(W), "PA", oi(W + 1)))]
    }, {
      type: "note",
      at: "internet",
      text: "SEGMENT 1 LOST",
      tone: "amber"
    }]
  }, {
    title: "A Gap Is Noticed",
    desc: "Duplicate ACK with SACK",
    detail: `Bytes ${W + 1}–${Oe} arrive, but 1–${W} never did. An ACK can only count bytes received in order, so the laptop repeats ACK 1 at once and adds a SACK block saying it already holds ${W + 1}–${Oe}.`,
    facts: [["ACK", "1 (still waiting for byte 1)"], ["SACK", `holds bytes ${W + 1}–${Oe}`], ["Sent", "At once, not delayed"]],
    events: [l("client", "web", "green", "DUP ACK", ["ack=1", `sack: has ${W + 1}–${Oe}`], Ao(0.069, `[ACK] Seq=${fe + 1} Ack=1 SLE=${W + 1} SRE=${Oe + 1}`, 66, "A", undefined, {
      sack: true
    }))]
  }, {
    title: "Resend the Gap",
    desc: "Only the missing bytes",
    detail: "The SACK tells the server exactly what is missing, so it resends just segment 1, and the laptop acknowledges everything. Had no ACK come back at all, timers would have stepped in: a probe after about two round trips, then a retransmission timeout (at least 200 ms on Linux).",
    facts: [["Resent", `bytes 1–${W} only`], ["Next ACK", `${Oe + 1} (everything)`], ["curl saw", "Every byte, in order"]],
    events: [l("web", "client", "violet", "RESEND", ["seq=1  len=1460", "just the missing segment"], En(0.095, `[TCP Retransmission] Seq=1 Ack=${fe + 1} Len=${W}`, j(W), "A", oi(1), {
      seq: 1
    })), l("client", "web", "green", "ACK", [`ack=${Oe + 1}`], Ao(0.112, `[ACK] Seq=${fe + 1} Ack=${Oe + 1}`, j(0), "A"))]
  }, {
    title: "Close Connection",
    desc: "Each side says goodbye",
    detail: "curl is done, so it closes. Each direction closes on its own: the laptop sends FIN and the server acknowledges it, then the server sends its own FIN and the laptop acknowledges that. The laptop keeps the connection’s details for a while (TIME-WAIT).",
    facts: [["Closed by", "A FIN from each side"], ["Order", "FIN → ACK → FIN → ACK"], ["Then", "Laptop waits (TIME-WAIT)"]],
    events: [l("client", "web", "slate", "FIN", [`seq=${fe + 1}  ack=${Oe + 1}`], Ao(0.113, `[FIN, ACK] Seq=${fe + 1} Ack=${Oe + 1}`, j(0), "FA")), l("web", "client", "green", "ACK", [`ack=${fe + 2}`], En(0.13, `[ACK] Seq=${Oe + 1} Ack=${fe + 2}`, j(0), "A")), l("web", "client", "slate", "FIN", [`seq=${Oe + 1}  ack=${fe + 2}`], En(0.131, `[FIN, ACK] Seq=${Oe + 1} Ack=${fe + 2}`, j(0), "FA")), l("client", "web", "green", "ACK", [`ack=${Oe + 2}`], Ao(0.148, `[ACK] Seq=${fe + 2} Ack=${Oe + 2}`, j(0), "A"))]
  }]
};
const Cl = "192.168.1.10";
const Pr = "203.0.113.20";
const $l = (e, t, s, n, o, a, r = {}) => ({
  type: "packet",
  from: e,
  to: t,
  color: s,
  label: n,
  payload: o,
  row: a,
  ...r
});
const Ll = (e, t) => ({
  udp: {
    ...(t ? {
      sport: 50000,
      dport: 5004
    } : {
      sport: 5004,
      dport: 50000
    }),
    data: {
      rtp: {
        seq: (t ? 21737 : 4418) + e,
        ts: (t ? 2617440 : 913280) + (e - 1) * 960,
        ssrc: t ? 1590076113 : 460833806,
        pt: 111,
        marker: e === 1,
        audio: 80
      }
    }
  }
});
const js = (e, t, s) => $l("client", "web", "amber", `VOICE ${e}`, [], {
  time: t,
  src: Cl,
  dst: Pr,
  proto: "UDP",
  info: "50000 → 5004 Len=92",
  len: "134 B",
  wire: Ll(e, true)
}, s);
const ai = (e, t) => $l("web", "client", "violet", `REMOTE ${e}`, [], {
  time: t,
  src: Pr,
  dst: Cl,
  proto: "UDP",
  info: "5004 → 50000 Len=92",
  len: "134 B",
  wire: Ll(e, false)
});
const H0 = {
  id: "udp",
  name: "UDP",
  title: "Fast Datagrams",
  layer: 4,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.017
  },
  labels: {
    web: ["Media Server", Pr]
  },
  legend: [["amber", "Your voice"], ["violet", "Their voice"]],
  overview: {
    full: "User Datagram Protocol",
    description: "UDP sends data in independent packets called datagrams, with no connection, no acknowledgements and no resends. That keeps it fast and light: right for voice, video, games and DNS, where a late answer is worse than a missing one.",
    facts: [["Layer", "Transport (Layer 4)"], ["Connection", "None"], ["Reliability", "None (no ACKs, no resends)"], ["Ordering", "Not guaranteed"], ["Header", "8 bytes"], ["Defined In", "RFC 768"]]
  },
  outro: {
    title: "Call keeps flowing",
    desc: "Fast, simple, no guarantees",
    text: "Audio started with the very first packet, every datagram travelled on its own, and the one that was lost was simply gone: UDP never noticed. The app covered the gap and the call carried on. Press REPLAY to watch it again.",
    facts: [["Datagrams", "11 (1 lost, never resent)"], ["Setup time", "0 ms (no handshake)"], ["Header", "8 bytes (TCP: 20+)"], ["Shown", "The first 0.2 s of a call"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Send Right Away",
    desc: "No handshake, data goes first",
    detail: "A call app already knows the media server’s address and port from signing in. It doesn’t open a connection: the very first datagram already carries 20 ms of your voice, behind an 8-byte UDP header.",
    facts: [["Setup", "None"], ["Header", "8 bytes"], ["Ports", "50000 → 5004"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "full"
    }, $l("client", "web", "amber", "VOICE 1", ["UDP 50000 → 5004", "92 B of audio, no setup"], {
      time: "0.000s",
      src: Cl,
      dst: Pr,
      proto: "UDP",
      info: "50000 → 5004 Len=92",
      len: "134 B",
      wire: Ll(1, true)
    })]
  }, {
    title: "A Stream of Datagrams",
    desc: "One every 20 ms, each on its own",
    detail: "The app keeps sending a datagram every 20 ms. Each one stands alone, with its own header and no link to the others. UDP doesn’t number them, and nothing comes back to confirm they arrived.",
    facts: [["Rate", "1 datagram / 20 ms"], ["Numbering", "None in UDP itself"], ["Confirmation", "None (no ACKs)"]],
    events: [{
      type: "stream",
      from: "client",
      to: "web",
      color: "amber",
      label: "4 DATAGRAMS",
      payload: ["voice frames 2–5", "each with its own 8-byte header"],
      packets: [js(2, "0.020s"), js(3, "0.040s"), js(4, "0.060s"), js(5, "0.080s")]
    }]
  }, {
    title: "Lost on the Way",
    desc: "Nobody resends it",
    detail: "Frame 7 is dropped somewhere on the internet. The media server never asks for it, and UDP never tells the laptop: there are no acknowledgements to miss. The datagrams after it arrive as normal.",
    facts: [["Lost", "Voice frame 7"], ["Resent", "Never (no ACKs)"], ["Missing", "20 ms of audio"]],
    events: [{
      type: "stream",
      from: "client",
      to: "web",
      color: "amber",
      label: "3 DATAGRAMS",
      payload: ["voice frames 6–8", "frame 7 is lost"],
      packets: [js(6, "0.100s"), js(7, "0.120s", {
        lost: true
      }), js(8, "0.140s")]
    }, {
      type: "note",
      at: "web",
      text: "FRAME 7 LOST · NOT RESENT",
      tone: "amber"
    }]
  }, {
    title: "Replies Come Back",
    desc: "The other voice comes back",
    detail: "The other person’s voice arrives the same way, as separate datagrams sent to port 50000. They get back in because your router remembered the outgoing port when it translated your address (NAT).",
    facts: [["Ports", "5004 → 50000"], ["Direction", "Independent of ours"], ["Through NAT", "Router remembers the port"]],
    events: [{
      type: "stream",
      from: "web",
      to: "client",
      color: "violet",
      label: "3 DATAGRAMS",
      payload: ["the other person’s voice", "sent to port 50000"],
      packets: [ai(1, "0.150s"), ai(2, "0.170s"), ai(3, "0.190s")]
    }]
  }, {
    title: "The App Decides",
    desc: "Reliability is up to the app",
    detail: "The call app numbers its own frames (RTP does this), so it sees that frame 7 is missing and smooths over the 20 ms gap instead of waiting. Waiting for a resend would make the whole call lag.",
    facts: [["Ordering", "App’s job (e.g. RTP)"], ["Loss", "Hidden by the app"], ["Also on UDP", "DNS, games, QUIC"]],
    events: [{
      type: "note",
      at: "client",
      text: "APP COVERS THE 20 MS GAP",
      tone: "green"
    }]
  }]
};
const Us = "203.0.113.10";
const Ea = "00:00:5e:00:53:10";
const xa = "00:00:5e:00:53:01";
const Ec = q(h, 52344, Us, 443);
const xc = q(se, 40112, Us, 443);
const F0 = {
  id: "ip",
  name: "IP",
  title: "Addressing & Routing",
  layer: 3,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-router": 0.001,
    "router-web": 0.016
  },
  legend: [["slate", "ARP"], ["amber", "Outgoing packet"], ["violet", "Reply"]],
  overview: {
    full: "Internet Protocol",
    description: "IP gives every device an address and moves packets from network to network. Each router looks only at the destination address to choose the next hop. IP is best effort: it doesn’t promise delivery or order. TCP adds those on top.",
    facts: [["Layer", "Network (Layer 3)"], ["Address", "32 bits (IPv4), 128 (IPv6)"], ["Header", "20–60 bytes (IPv4)"], ["TTL", "Lowered by 1 at each router"], ["Delivery", "Best effort"], ["Defined In", "RFC 791, RFC 8200 (IPv6)"]]
  },
  outro: {
    title: "There and back",
    desc: "Twelve routers each way",
    text: "The laptop sent the packet to its router, which swapped in its public address. Twelve routers in all passed it along by destination address alone, and the reply found its way back the same way. Press REPLAY to watch it again.",
    facts: [["Routers", "12 each way (1 home + 11)"], ["TTL at server", "116 (sent with 128)"], ["Rewritten by NAT", "Source out, destination back"], ["Version", "IPv4 (IPv6 works alike)"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Local or Not?",
    desc: "Compare the address with the subnet",
    detail: "The laptop is 192.168.1.10 with a /24 mask, so its own network is 192.168.1.0 to 192.168.1.255. The server, 203.0.113.10, is outside that range, so the packet has to go to the default gateway: the home router.",
    facts: [["Laptop", "192.168.1.10/24"], ["Local range", "192.168.1.0 – .255"], ["Gateway", "192.168.1.1"]],
    events: [{
      type: "note",
      at: "client",
      text: "203.0.113.10 IS NOT LOCAL",
      tone: "amber"
    }, {
      type: "show",
      nodes: ["router"],
      frame: "local"
    }]
  }, {
    title: "Find the Router",
    desc: "ARP turns an IP into a MAC",
    detail: "On the local network, frames are delivered by MAC address. If the router’s MAC isn’t in the laptop’s ARP cache, it broadcasts “who has 192.168.1.1?” and the router answers with its MAC address.",
    facts: [["Asks", "Who has 192.168.1.1?"], ["Sent to", "Everyone (broadcast)"], ["Learns", "Router’s MAC address"]],
    events: [l("client", "router", "slate", "ARP REQUEST", ["who has 192.168.1.1?", "tell 192.168.1.10"], {
      time: x(0),
      src: Ea,
      dst: "Broadcast",
      proto: "ARP",
      info: "Who has 192.168.1.1? Tell 192.168.1.10",
      len: "60 B",
      wire: {
        arp: {
          op: 1,
          sender: [Ea, h],
          target: ["00:00:00:00:00:00", ce]
        }
      }
    }), l("router", "client", "slate", "ARP REPLY", ["192.168.1.1 is at", xa], {
      time: x(0.001),
      src: xa,
      dst: Ea,
      proto: "ARP",
      info: `192.168.1.1 is at ${xa}`,
      len: "60 B",
      wire: {
        arp: {
          op: 2,
          sender: [xa, ce],
          target: [Ea, h]
        }
      }
    })]
  }, {
    title: "Send the Packet",
    desc: "Addresses, TTL and protocol",
    detail: "The IP header carries the source and destination addresses, a TTL and the protocol inside. Here it holds a TCP SYN to port 443. Windows starts the TTL at 128 (Linux and macOS use 64).",
    facts: [["From → to", "192.168.1.10 → 203.0.113.10"], ["TTL", "128"], ["Protocol", "6 (TCP)"]],
    events: [l("client", "router", "amber", "IP PACKET", ["192.168.1.10 → 203.0.113.10", "TTL 128 · protocol TCP"], {
      time: x(0.002),
      src: h,
      dst: Us,
      proto: "TCP",
      info: "TTL 128 · 52344 → 443 [SYN]",
      len: "66 B",
      wire: P(Ec, h, "S")
    })]
  }, {
    title: "NAT, Then Hop by Hop",
    desc: "The router rewrites and forwards",
    detail: "The router swaps the private source for its public address 198.51.100.7 (and here port 52344 for 40112), notes the mapping, and lowers the TTL to 127. Then 11 routers on the internet each choose the next hop by destination and lower the TTL again.",
    facts: [["New source", "198.51.100.7:40112"], ["Leaves home", "TTL 127"], ["At the server", "TTL 116 (11 more hops)"]],
    events: [{
      type: "show",
      nodes: ["internet", "web"],
      frame: "full"
    }, l("router", "web", "amber", "IP PACKET", ["198.51.100.7 → 203.0.113.10", "TTL 127 · after NAT"], {
      time: x(0.003),
      src: se,
      dst: Us,
      proto: "TCP",
      info: "TTL 127 · 40112 → 443 [SYN] (after NAT)",
      len: "66 B",
      wire: {
        ...P(xc, se, "S", undefined, {
          seq: 0
        }),
        ttl: 127,
        ttlNote: "The laptop sent it with 128; the router took 1 when it passed it on.",
        natOf: -1,
        alias: [`${se}:40112`, `${h}:52344`]
      }
    }), {
      type: "note",
      at: "web",
      text: "ARRIVED WITH TTL 116",
      tone: "green"
    }]
  }, {
    title: "The Reply Comes Back",
    desc: "NAT translates it for the laptop",
    detail: "The server answers the address it saw, 198.51.100.7:40112. The router looks that up in its NAT table, rewrites the destination back to 192.168.1.10:52344 and passes it on. The reply started at TTL 64 and arrives with 52.",
    facts: [["Sent to", "198.51.100.7:40112"], ["Delivered to", "192.168.1.10:52344"], ["TTL", "64 → 52 (12 routers)"]],
    events: [l("web", "router", "violet", "REPLY", ["203.0.113.10 → 198.51.100.7", "TTL 64 · SYN-ACK"], {
      time: x(0.019),
      src: Us,
      dst: se,
      proto: "TCP",
      info: "TTL 64 · 443 → 40112 [SYN, ACK]",
      len: "66 B",
      wire: P(xc, Us, "SA")
    }), {
      type: "note",
      at: "router",
      text: "NAT: 40112 → 192.168.1.10",
      tone: "navy"
    }, l("router", "client", "violet", "REPLY", ["203.0.113.10 → 192.168.1.10", "TTL 52 · after NAT"], {
      time: x(0.035),
      src: Us,
      dst: h,
      proto: "TCP",
      info: "TTL 52 · 443 → 52344 [SYN, ACK] (after NAT)",
      len: "66 B",
      wire: {
        ...P(Ec, Us, "SA", undefined, {
          seq: 0
        }),
        natOf: -1
      }
    })]
  }]
};
const Cc = "192.168.1.10";
const bs = "8.8.8.8";
const $c = "198.41.0.4";
const Lc = "192.5.6.30";
const ri = "198.51.100.53";
const vs = (e, t, s, n, o, a) => ({
  type: "packet",
  from: e,
  to: t,
  color: s,
  label: n,
  payload: o,
  row: a
});
const ks = ["www.example.com", "A"];
const xn = {
  size: 1232
};
const ii = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m"].map(e => `${e}.gtld-servers.net`);
const U0 = ["192.5.6.30", "192.33.14.30", "192.26.92.30", "192.31.80.30", "192.12.94.30", "192.35.51.30", "192.42.93.30", "192.54.112.30", "192.43.172.30", "192.48.79.30", "192.52.178.30", "192.41.162.30", "192.55.83.30"];
const K0 = ["2001:503:a83e::2:30", "2001:503:231d::2:30", "2001:503:83eb::30", "2001:500:856e::30", "2001:502:1ca1::30", "2001:503:d414::30", "2001:503:eea3::30", "2001:502:8cc::30", "2001:503:39c1::30", "2001:502:7094::30", "2001:503:d2d::30", "2001:500:d937::30", "2001:501:b1f9::30"];
const Ca = (e, t) => ({
  udp: {
    sport: e,
    dport: 53,
    data: {
      dns: t
    }
  }
});
const $a = (e, t) => ({
  udp: {
    sport: 53,
    dport: e,
    data: {
      dns: t
    }
  }
});
const B0 = {
  id: "dns",
  name: "DNS",
  title: "Name Resolution",
  layer: 7,
  nodes: ["client", "router", "internet", "dns", "root", "tld", "auth"],
  latency: {
    "client-dns": 0.012,
    "dns-root": 0.005,
    "dns-tld": 0.01,
    "dns-auth": 0.02
  },
  legend: [["blue", "Query"], ["amber", "Referral"], ["green", "Answer"], [null, "DNSSEC not requested here"]],
  overview: {
    full: "Domain Name System",
    description: "DNS turns names like www.example.com into the IP addresses computers use to reach each other. No single server knows every name: the system is a hierarchy of servers, and answers are cached along the way so most lookups never have to go far.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "53, UDP (TCP if large)"], ["Turns", "Names into IP addresses"], ["Hierarchy", "Root → TLD → authoritative"], ["Caching", "For each record’s TTL"], ["Defined In", "RFC 1034, RFC 1035"]]
  },
  outro: {
    title: "Name resolved",
    desc: "And remembered for an hour",
    text: "Starting from an empty cache, the resolver walked from the root to .com to example.com’s own server, then answered the laptop. Until the TTL runs out, the next lookup for this name is answered straight from a cache. Press REPLAY to watch it again.",
    facts: [["Queries", "4 (laptop 1, resolver 3)"], ["Total time", "0.094 s"], ["Transport", "UDP, port 53"], ["Cached for", "3600 s (TTL)"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Ask the Resolver",
    desc: "The laptop hands the question off",
    detail: "The browser needs the IP address of www.example.com and neither it nor Windows has one cached. The laptop sends one question to the recursive resolver it was given, 8.8.8.8, and asks it to do the whole lookup (recursion desired).",
    facts: [["Question", "www.example.com, type A"], ["Asked", "8.8.8.8 (recursive)"], ["Flags", "RD (recursion desired)"]],
    events: [{
      type: "type-url",
      text: "www.example.com"
    }, {
      type: "show",
      nodes: ["router", "internet", "dns"],
      frame: "lookup"
    }, vs("client", "dns", "blue", "DNS QUERY", ["A? www.example.com", "flags: RD"], {
      time: "0.000s",
      src: Cc,
      dst: bs,
      proto: "DNS",
      info: "Standard query A www.example.com",
      len: "75 B",
      wire: Ca(54871, {
        id: 39486,
        rd: true,
        q: ks
      })
    })]
  }, {
    title: "Root Server",
    desc: "Points the way to .com",
    detail: "The resolver’s cache is empty (it has just started), so it begins at the top. A root server doesn’t know the address, but it knows which servers handle .com and replies with a referral. Many resolvers send it only “com”, not the full name.",
    facts: [["Server", "a.root-servers.net"], ["Root servers", "13 names, 1,000+ anycast sites"], ["Reply", "Referral (13 .com servers)"]],
    events: [{
      type: "note",
      at: "dns",
      text: "NOT IN CACHE",
      tone: "amber"
    }, {
      type: "show",
      nodes: ["root"],
      frame: "root"
    }, vs("dns", "root", "blue", "DNS QUERY", ["A? www.example.com"], {
      time: "0.012s",
      src: bs,
      dst: $c,
      proto: "DNS",
      info: "Standard query A www.example.com",
      len: "86 B",
      wire: Ca(38143, {
        id: 20935,
        q: ks,
        edns: xn
      })
    }), vs("root", "dns", "amber", "REFERRAL", ["no answer: ask .com", "com. NS a.gtld-servers.net …"], {
      time: "0.017s",
      src: $c,
      dst: bs,
      proto: "DNS",
      info: "Referral: com. NS ×13 (with glue)",
      len: "882 B",
      wire: $a(38143, {
        id: 20935,
        response: true,
        q: ks,
        edns: xn,
        ns: ii.map(e => ["com", "NS", 172800, e]),
        ar: [...ii.map((e, t) => [e, "A", 172800, U0[t]]), ...ii.map((e, t) => [e, "AAAA", 172800, K0[t]])]
      })
    })]
  }, {
    title: ".com TLD Server",
    desc: "Points the way to example.com",
    detail: "The resolver asks one of the .com servers. They don’t store addresses for every site either, but they know which name servers each .com domain uses, so this reply is another referral, with those servers’ addresses (glue) attached.",
    facts: [["Server", "a.gtld-servers.net"], ["Knows", "Name servers of .com domains"], ["Reply", "Referral + glue addresses"]],
    events: [{
      type: "show",
      nodes: ["tld"],
      frame: "tld"
    }, vs("dns", "tld", "blue", "DNS QUERY", ["A? www.example.com"], {
      time: "0.022s",
      src: bs,
      dst: Lc,
      proto: "DNS",
      info: "Standard query A www.example.com",
      len: "86 B",
      wire: Ca(41766, {
        id: 11152,
        q: ks,
        edns: xn
      })
    }), vs("tld", "dns", "amber", "REFERRAL", ["no answer: ask example.com", "example.com. NS ns1.example.com"], {
      time: "0.032s",
      src: Lc,
      dst: bs,
      proto: "DNS",
      info: "Referral: example.com. NS ×2 (with glue)",
      len: "154 B",
      wire: $a(41766, {
        id: 11152,
        response: true,
        q: ks,
        edns: xn,
        ns: [["example.com", "NS", 172800, "ns1.example.com"], ["example.com", "NS", 172800, "ns2.example.com"]],
        ar: [["ns1.example.com", "A", 172800, ri], ["ns2.example.com", "A", 172800, "198.51.100.54"]]
      })
    })]
  }, {
    title: "Authoritative Server",
    desc: "Gives the actual answer",
    detail: "Finally the resolver asks example.com’s own name server, which holds the domain’s records. It answers with the A record and marks the reply authoritative. The domain owner sets how long it may be cached: here, 3600 seconds.",
    facts: [["Server", "ns1.example.com"], ["Answer", "A 203.0.113.10"], ["Flags", "AA (authoritative), TTL 3600"]],
    events: [{
      type: "show",
      nodes: ["auth"],
      frame: "full"
    }, vs("dns", "auth", "blue", "DNS QUERY", ["A? www.example.com"], {
      time: "0.042s",
      src: bs,
      dst: ri,
      proto: "DNS",
      info: "Standard query A www.example.com",
      len: "86 B",
      wire: Ca(50911, {
        id: 58884,
        q: ks,
        edns: xn
      })
    }), vs("auth", "dns", "green", "ANSWER", ["www.example.com A 203.0.113.10", "TTL 3600 · flag AA"], {
      time: "0.062s",
      src: ri,
      dst: bs,
      proto: "DNS",
      info: "Response A 203.0.113.10 (authoritative)",
      len: "102 B",
      wire: $a(50911, {
        id: 58884,
        response: true,
        aa: true,
        q: ks,
        edns: xn,
        an: [["www.example.com", "A", 3600, "203.0.113.10"]]
      })
    })]
  }, {
    title: "Answer & Cache",
    desc: "The laptop gets its address",
    detail: "The resolver sends the answer back to the laptop and keeps a copy. For the next hour it can answer this name straight away, which is why the lookup in the HTTP lesson took only 24 ms. The laptop caches it too.",
    facts: [["Answer", "A 203.0.113.10"], ["Flags", "RD, RA (recursion available)"], ["Cached by", "Resolver and laptop"]],
    events: [vs("dns", "client", "green", "ANSWER", ["A 203.0.113.10 · TTL 3600", "flags: RD RA"], {
      time: "0.082s",
      src: bs,
      dst: Cc,
      proto: "DNS",
      info: "Standard query response A 203.0.113.10",
      len: "91 B",
      wire: $a(54871, {
        id: 39486,
        response: true,
        rd: true,
        ra: true,
        q: ks,
        an: [["www.example.com", "A", 3600, "203.0.113.10"]]
      })
    }), {
      type: "note",
      at: "dns",
      text: "CACHED · TTL 3600 S",
      tone: "green"
    }]
  }]
};
const Ps = "0x3903f326";
const La = "0x7a1c22e5";
const Cn = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "DHCP",
  info: n,
  len: `${o} B`,
  wire: a
});
const Eo = "alice-laptop";
const li = [1, 3, 6, 15, 31, 33, 43, 44, 46, 47, 119, 121, 249, 252];
const ci = e => ({
  udp: {
    sport: 68,
    dport: 67,
    data: {
      dhcp: {
        op: 1,
        ...e
      }
    }
  }
});
const di = e => ({
  udp: {
    sport: 67,
    dport: 68,
    data: {
      dhcp: {
        op: 2,
        ...e
      }
    }
  }
});
const hi = [[54, ce], [51, 86400], [58, 43200], [59, 75600], [1, "255.255.255.0"], [28, "192.168.1.255"], [3, ce], [6, "8.8.8.8"]];
const _0 = {
  id: "dhcp",
  name: "DHCP",
  title: "Getting an Address",
  layer: 7,
  nodes: ["client", "router"],
  latency: {
    "client-router": 0.001
  },
  labels: {
    client: ["Client", "No IP address"],
    router: ["Router", "192.168.1.1 · DHCP server"]
  },
  legend: [["amber", "From the laptop"], ["violet", "From the DHCP server"]],
  overview: {
    full: "Dynamic Host Configuration Protocol",
    description: "DHCP hands a device everything it needs to use a network: an IP address, the subnet mask, the router to send traffic through and the DNS servers to ask. Addresses are leased for a set time and renewed while the device stays on the network.",
    facts: [["Layer", "Application (Layer 7)"], ["Ports", "UDP 67 (server), 68 (client)"], ["Hands out", "IP, mask, gateway, DNS"], ["Exchange", "Discover, Offer, Request, Ack"], ["Lease", "Renewed at half its time"], ["Defined In", "RFC 2131, RFC 2132"]]
  },
  outro: {
    title: "On the network",
    desc: "Leased, and kept up to date",
    text: "Four messages took the laptop from no address to a working configuration, and halfway through the 24-hour lease it renewed it with a direct request to the router. Press REPLAY to watch it again.",
    facts: [["Messages", "4 to join, 2 per renewal"], ["Address", "192.168.1.10/24"], ["Lease", "24 h, renewed at 12 h"], ["Ports", "UDP 68 → 67"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "No Address Yet",
    desc: "The laptop joins the network",
    detail: "The laptop has just connected. It has a MAC address built in, but no IP address, no gateway and no DNS server, so it can’t talk to anything beyond its own network yet. It asks for them with DHCP.",
    facts: [["IP address", "None (uses 0.0.0.0)"], ["MAC address", "00:00:5e:00:53:10"], ["Needs", "IP, mask, gateway, DNS"]],
    events: [{
      type: "note",
      at: "client",
      text: "NO IP ADDRESS YET",
      tone: "amber"
    }, {
      type: "show",
      nodes: ["router"],
      frame: "local"
    }]
  }, {
    title: "Discover",
    desc: "Shout to the whole network",
    detail: "Without an address of its own, the laptop sends from 0.0.0.0 to the broadcast address 255.255.255.255, so every device on the local network receives it. Only DHCP servers answer.",
    facts: [["From", "0.0.0.0, UDP port 68"], ["To", "255.255.255.255, port 67"], ["Carries", "MAC, transaction ID"]],
    events: [l("client", "router", "amber", "DISCOVER", ["0.0.0.0 → 255.255.255.255", "any DHCP server out there?"], Cn(0, "0.0.0.0", "255.255.255.255", `DHCP Discover - Transaction ID ${Ps}`, 342, ci({
      xid: +Ps,
      options: [[53, 1], [61, "mac"], [12, Eo], [60, "MSFT 5.0"], [55, li]]
    })))]
  }, {
    title: "Offer",
    desc: "The router proposes an address",
    detail: "The router’s DHCP server picks a free address and offers it with the rest of the settings. The laptop can’t use an IP address yet, so the offer goes straight to its MAC address (some clients ask for a broadcast instead).",
    facts: [["Offered", "192.168.1.10/24"], ["Gateway, DNS", "192.168.1.1, 8.8.8.8"], ["Lease", "86,400 s (24 h)"]],
    events: [l("router", "client", "violet", "OFFER", ["offer: 192.168.1.10/24", "gateway, DNS, lease 24 h"], Cn(0.004, ce, h, `DHCP Offer - Transaction ID ${Ps}`, 342, di({
      xid: +Ps,
      yiaddr: h,
      options: [[53, 2], ...hi]
    })))]
  }, {
    title: "Request",
    desc: "Accept, out loud",
    detail: "The laptop asks for the offered address, naming the server it chose. It still broadcasts, so any other DHCP server that made an offer learns it wasn’t picked and can release its address.",
    facts: [["Requests", "192.168.1.10"], ["Chosen server", "192.168.1.1"], ["Sent to", "255.255.255.255"]],
    events: [l("client", "router", "amber", "REQUEST", ["I’ll take 192.168.1.10", "from server 192.168.1.1"], Cn(0.006, "0.0.0.0", "255.255.255.255", `DHCP Request - Transaction ID ${Ps}`, 364, ci({
      xid: +Ps,
      options: [[53, 3], [61, "mac"], [50, h], [54, ce], [12, Eo], [81, Eo], [60, "MSFT 5.0"], [55, li]]
    })))]
  }, {
    title: "Acknowledge",
    desc: "The address is the laptop’s",
    detail: "The server confirms, and the laptop configures its address, mask, gateway and DNS server. Many systems first check with ARP that no other device is already using the address.",
    facts: [["Address", "192.168.1.10/24"], ["Gateway", "192.168.1.1"], ["DNS server", "8.8.8.8"]],
    events: [l("router", "client", "violet", "ACK", ["192.168.1.10 is yours", "for 24 hours"], Cn(0.009, ce, h, `DHCP ACK - Transaction ID ${Ps}`, 342, di({
      xid: +Ps,
      yiaddr: h,
      options: [[53, 5], ...hi]
    }))), {
      type: "label",
      at: "client",
      label: ["Client", h]
    }, {
      type: "note",
      at: "client",
      text: "192.168.1.10/24 · 24 H LEASE",
      tone: "green"
    }]
  }, {
    title: "Renew",
    desc: "Halfway through the lease",
    detail: "Twelve hours later, half the lease has passed. The laptop now has an address, so it asks the router directly to extend the lease, and the router resets it to 24 hours. If the router didn’t answer, it would broadcast at 87.5%.",
    facts: [["When", "50% of lease (T1 = 12 h)"], ["Sent to", "The router (unicast)"], ["If unanswered", "Broadcast at 87.5% (T2)"]],
    events: [l("client", "router", "amber", "REQUEST", ["renew 192.168.1.10", "sent straight to 192.168.1.1"], Cn(43200, h, ce, `DHCP Request - Transaction ID ${La}`, 352, ci({
      xid: +La,
      ciaddr: h,
      options: [[53, 3], [61, "mac"], [12, Eo], [81, Eo], [60, "MSFT 5.0"], [55, li]]
    }))), l("router", "client", "violet", "ACK", ["lease renewed", "another 24 hours"], Cn(43200.003, ce, h, `DHCP ACK - Transaction ID ${La}`, 342, di({
      xid: +La,
      ciaddr: h,
      yiaddr: h,
      options: [[53, 5], ...hi]
    })))]
  }]
};
const As = "203.0.113.10";
const G0 = "198.51.100.1";
const is = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "ICMP",
  info: n,
  len: o,
  wire: a
});
const W0 = "abcdefghijklmnopqrstuvwabcdefghi";
const $n = (e, t, s) => ({
  icmp: {
    type: e,
    code: 0,
    id: 1,
    seq: t,
    data: W0
  },
  ...(s ? {
    ttl: s
  } : {})
});
const pi = (e, t, s, n = "all") => ({
  icmp: {
    type: e,
    code: t,
    quote: -1,
    ttl: s,
    quoteBytes: n
  }
});
const V0 = {
  id: "icmp",
  name: "ICMP",
  title: "Network Diagnostics",
  layer: 3,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-router": 0.001,
    "client-internet": 0.005,
    "client-web": 0.017
  },
  legend: [["amber", "Ping / probe"], ["green", "Echo reply"], ["slate", "Error report"]],
  overview: {
    full: "Internet Control Message Protocol",
    description: "ICMP is how the network reports back: a router says a packet’s time ran out, a server says nothing is listening on a port. Tools like ping and traceroute are built from these messages. It travels inside IP but carries no application data.",
    facts: [["Layer", "Network (Layer 3)"], ["Carried in", "IP (protocol 1)"], ["Messages", "A type and a code"], ["Tools", "ping, tracert / traceroute"], ["Often", "Filtered by firewalls"], ["Defined In", "RFC 792 (IPv6: RFC 4443)"]]
  },
  outro: {
    title: "The network answered",
    desc: "Replies, expiries and errors",
    text: "An echo request measured the round trip, packets with a small TTL made each router on the path identify itself, and a closed port was reported straight back. Press REPLAY to watch it again.",
    facts: [["Round trip", "34 ms"], ["Path", "12 routers, server at hop 13"], ["Types used", "8, 0, 11 and 3"], ["Reply TTL", "52 (64 − 12 routers)"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Ping",
    desc: "Echo request",
    detail: "“ping -n 1 203.0.113.10” sends one ICMP echo request (plain ping sends four, a second apart): type 8, code 0, with an identifier, a sequence number and 32 bytes of filler. The server’s system answers by itself, no application needed.",
    facts: [["Type, code", "8, 0 (echo request)"], ["Data", "32 bytes (Windows)"], ["TTL", "128"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "full"
    }, l("client", "web", "amber", "ECHO REQUEST", ["type 8 · seq 1", "32 bytes of data"], is(0, h, As, "Echo (ping) request id=0x0001, seq=1, ttl=128", "74 B", $n(8, 1)))]
  }, {
    title: "Echo Reply",
    desc: "Round-trip time",
    detail: "The server sends back an echo reply, type 0, with the same identifier, sequence number and data. Ping prints the time it took and the TTL the reply arrived with: “bytes=32 time=34ms TTL=52”.",
    facts: [["Type, code", "0, 0 (echo reply)"], ["Round trip", "34 ms"], ["TTL on arrival", "52 (64 − 12 routers)"]],
    events: [l("web", "client", "green", "ECHO REPLY", ["type 0 · seq 1", "same 32 bytes back"], is(0.017, As, h, "Echo (ping) reply id=0x0001, seq=1, ttl=52", "74 B", $n(0, 1))), {
      type: "note",
      at: "client",
      text: "TIME=34MS TTL=52",
      tone: "green"
    }]
  }, {
    title: "TTL 1",
    desc: "The first router answers",
    detail: "“ping -n 1 -i 1” sends the same request with a TTL of 1. The home router lowers it to 0, so it must drop the packet, and it sends back a Time Exceeded message from its own address: “Reply from 192.168.1.1: TTL expired in transit.”",
    facts: [["Sent with", "TTL 1"], ["Dropped by", "Router 192.168.1.1"], ["Type, code", "11, 0 (time exceeded)"]],
    events: [l("client", "router", "amber", "TTL 1", ["echo request", "expires at the first router"], is(1, h, As, "Echo (ping) request id=0x0001, seq=2, ttl=1", "74 B", $n(8, 2, 1))), l("router", "client", "slate", "TIME EXCEEDED", ["type 11 · from 192.168.1.1", "quotes the dropped header"], is(1.001, ce, h, "Time-to-live exceeded (in transit)", "102 B", pi(11, 0, 1)))]
  }, {
    title: "TTL 2",
    desc: "The next router answers",
    detail: "With “-i 2”, the home router lowers the TTL to 1 and forwards it. The first router at the internet provider lowers it to 0 and reports back from 198.51.100.1. The home router translates the report back to the laptop like any reply.",
    facts: [["Sent with", "TTL 2"], ["Dropped by", "ISP router 198.51.100.1"], ["Type, code", "11, 0 (time exceeded)"]],
    events: [l("client", "internet", "amber", "TTL 2", ["echo request", "expires at the second router"], is(2, h, As, "Echo (ping) request id=0x0001, seq=3, ttl=2", "74 B", $n(8, 3, 2))), {
      type: "note",
      at: "internet",
      text: "HOP 2 · 198.51.100.1",
      tone: "navy"
    }, l("internet", "client", "slate", "TIME EXCEEDED", ["type 11 · from 198.51.100.1", "quotes the dropped header"], is(2.005, G0, h, "Time-to-live exceeded (in transit)", "70 B", pi(11, 0, 1, 8)))]
  }, {
    title: "That’s Traceroute",
    desc: "TTL 1, 2, 3 … until it arrives",
    detail: "tracert automates this: it raises the TTL by one each time, sends three probes per hop and lists who reports back. Hops 3 to 12 work the same way, and with TTL 13 the request finally reaches the server, which replies normally.",
    facts: [["Hops", "12 routers, then the server"], ["Per hop", "3 probes"], ["On Linux", "traceroute sends UDP"]],
    events: [l("client", "web", "amber", "TTL 13", ["echo request", "enough hops to arrive"], is(3, h, As, "Echo (ping) request id=0x0001, seq=4, ttl=13", "74 B", $n(8, 4, 13))), l("web", "client", "green", "ECHO REPLY", ["the server itself answers", "end of the route"], is(3.017, As, h, "Echo (ping) reply id=0x0001, seq=4, ttl=52", "74 B", $n(0, 4)))]
  }, {
    title: "Unreachable",
    desc: "Nothing listening on that port",
    detail: "An app sends a UDP datagram to port 9999, where nothing is listening. The server can’t deliver it, so it replies with Destination Unreachable, code 3 (port unreachable), quoting the start of the datagram. Many firewalls drop such packets silently instead.",
    facts: [["Type, code", "3, 3 (port unreachable)"], ["Other codes", "0 net, 1 host, 4 too big"], ["Firewalls", "Often silent instead"]],
    events: [l("client", "web", "amber", "UDP", ["to port 9999", "nothing listening there"], {
      time: x(4),
      src: h,
      dst: As,
      proto: "UDP",
      info: "52500 → 9999 Len=18",
      len: "60 B",
      wire: {
        udp: {
          sport: 52500,
          dport: 9999,
          data: {
            ascii: "hello, anyone here",
            name: "App data",
            note: "What the app sent; nothing on the server is listening for it."
          }
        }
      }
    }), l("web", "client", "slate", "UNREACHABLE", ["type 3 · code 3", "port unreachable"], is(4.017, As, h, "Destination unreachable (Port unreachable)", "88 B", pi(3, 3, 116)))]
  }]
};
const X = "203.0.113.25";
const Ia = "8.8.8.8";
const Ye = "198.51.100.25";
const Y0 = q(h, 52900, X, 465);
const j0 = q(X, 41522, Ye, 25);
function xe(e, t, s, n, o, a = true) {
  const r = t === Ye || s === Ye;
  const i = r ? j0 : Y0;
  const c = o.message ? o.message + z0 : K(...o);
  const d = o.message ? `${o.what}, then a line holding only “.”` : "SMTP";
  const p = a ? o.message ? R0(c, d) : Mr(o, d) : {
    text: o,
    name: "SMTP"
  };
  return {
    time: x(e),
    src: t,
    dst: s,
    proto: a ? "SMTP (TLS)" : "SMTP",
    info: n,
    len: `${(a ? kl(c) : j(c)) + (r ? Mt : 0)} B`,
    wire: P(i, t, "PA", p)
  };
}
const Ra = {
  sport: 44210,
  edns: {
    size: 1232
  }
};
const Na = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "DNS",
  info: n,
  len: `${o} B`,
  wire: {
    udp: t === X ? {
      sport: Ra.sport,
      dport: 53,
      data: {
        dns: {
          rd: true,
          edns: Ra.edns,
          ...a
        }
      }
    } : {
      sport: 53,
      dport: Ra.sport,
      data: {
        dns: {
          response: true,
          rd: true,
          ra: true,
          edns: Ra.edns,
          exampleTtl: true,
          ...a
        }
      }
    }
  }
});
const Je = {
  locked: true
};
const ui = 316;
const Go = 1316;
const z0 = K(".");
const Q0 = ["220 smtp.example.com ESMTP Postfix"];
const X0 = ["EHLO alice-laptop"];
const Z0 = ["250-smtp.example.com", "250-PIPELINING", "250-SIZE 52428800", "250-AUTH PLAIN LOGIN", "250-ENHANCEDSTATUSCODES", "250-8BITMIME", "250 SMTPUTF8"];
const J0 = ["AUTH PLAIN AGFsaWNlAHNlY3JldA=="];
const ef = ["235 2.7.0 Authentication successful"];
const tf = ["MAIL FROM:<alice@example.com>", "RCPT TO:<bob@example.org>", "DATA"];
const Ic = ["250 2.1.0 Ok", "250 2.1.5 Ok", "354 End data with <CR><LF>.<CR><LF>"];
const sf = ["250 2.0.0 Ok: queued as 4A1F2C3D9E"];
const nf = ["220 mx.example.org ESMTP Postfix"];
const Rc = ["EHLO smtp.example.com"];
const Sp = ["250-mx.example.org", "250-PIPELINING", "250-SIZE 52428800", "250-STARTTLS", "250-ENHANCEDSTATUSCODES", "250-8BITMIME", "250 SMTPUTF8"];
const of = ["STARTTLS"];
const af = ["220 2.0.0 Ready to start TLS"];
const rf = Sp.filter(e => e !== "250-STARTTLS");
const lf = [`MAIL FROM:<alice@example.com> SIZE=${Go}`, "RCPT TO:<bob@example.org>", "DATA"];
const cf = ["250 2.0.0 Ok: queued as 7B3E9F01A2"];
const df = {
  id: "smtp",
  name: "SMTP",
  title: "Sending Email",
  layer: 7,
  nodes: ["client", "router", "internet", "dns", "web", "mx"],
  latency: {
    "client-web": 0.015,
    "web-dns": 0.005,
    "web-mx": 0.02
  },
  lifelines: ["client", "web", "dns", "mx"],
  labels: {
    web: ["smtp.example.com", X],
    mx: ["mx.example.org", Ye]
  },
  legend: [["green", "TCP"], ["teal", "TLS handshake"], ["amber", "SMTP command"], ["violet", "SMTP reply"], ["blue", "DNS"]],
  overview: {
    full: "Simple Mail Transfer Protocol",
    description: "SMTP moves email: from your mail app to your provider’s server, and from that server to the recipient’s. It is a conversation of short text commands, each answered with a three-digit reply code. Reading mail is a different job, done with IMAP or POP3.",
    facts: [["Layer", "Application (Layer 7)"], ["Ports", "465/587 submit, 25 relay"], ["Transport", "TCP, usually with TLS"], ["Commands", "EHLO, MAIL, RCPT, DATA"], ["Replies", "2xx ok, 3xx go on, 4/5xx error"], ["Defined In", "RFC 5321, RFC 6409"]]
  },
  outro: {
    title: "Mail delivered",
    desc: "Two hops, one message",
    text: "Alice’s app handed the message to her provider over an encrypted, logged-in connection. The provider found Bob’s mail server in DNS and relayed it there, upgrading that link to TLS. It now waits in Bob’s mailbox until he reads it with IMAP or POP3.",
    facts: [["Hops", "Laptop → provider → Bob’s"], ["Submission", "Port 465, TLS, login"], ["Relay", "Port 25, STARTTLS"], ["Checks at Bob’s", "SPF, DKIM, DMARC"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Connect Securely",
    desc: "Port 465, TLS from the start",
    detail: "Alice presses Send. Her mail app connects to her provider’s submission server, smtp.example.com, on port 465. On this port TLS starts immediately, so the whole SMTP conversation, including her password, is encrypted.",
    facts: [["Server", "smtp.example.com:465"], ["Security", "TLS from the start"], ["Then", "SMTP inside TLS"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      dst: X,
      sport: 52900,
      dport: 465,
      t: [0, 0.015, 0.03]
    }), ...mo({
      dst: X,
      sni: "smtp.example.com",
      sport: 52900,
      dport: 465,
      t: [0.03, 0.045, 0.062]
    })]
  }, {
    title: "Greeting & Login",
    desc: "EHLO, then AUTH",
    detail: "The server greets with code 220. The app says EHLO and the server lists what it supports, including AUTH. The app logs in with AUTH PLAIN (user name and password, base64-encoded) and gets 235: authenticated.",
    facts: [["Greeting", "220 … ESMTP"], ["Capabilities", "AUTH, PIPELINING, SIZE …"], ["Login result", "235 2.7.0"]],
    events: [l("web", "client", "violet", "220", ["220 smtp.example.com ESMTP"], xe(0.077, X, h, "220 smtp.example.com ESMTP Postfix", Q0), Je), l("client", "web", "amber", "EHLO", ["EHLO alice-laptop"], xe(0.092, h, X, "EHLO alice-laptop", X0), Je), l("web", "client", "violet", "250", ["250-PIPELINING", "250-AUTH PLAIN LOGIN …"], xe(0.107, X, h, "250 capabilities (PIPELINING, SIZE, AUTH …)", Z0), Je), l("client", "web", "amber", "AUTH", ["AUTH PLAIN AGFsaWNlAHNl…", "user and password, base64"], xe(0.122, h, X, "AUTH PLAIN (credentials)", J0), Je), l("web", "client", "violet", "235", ["235 2.7.0 Authentication", "successful"], xe(0.137, X, h, "235 2.7.0 Authentication successful", ef), Je)]
  }, {
    title: "Send the Message",
    desc: "Envelope, then content",
    detail: "MAIL FROM and RCPT TO are the envelope: sender and recipient. PIPELINING lets all three commands share one packet. After 354 comes the message, ended by a line holding just a dot.",
    facts: [["Envelope", "alice@ → bob@example.org"], ["Content ends", "A line with only “.”"], ["Result", "250 Ok: queued"]],
    events: [l("client", "web", "amber", "MAIL · RCPT · DATA", ["MAIL FROM:<alice@example.com>", "RCPT TO:<bob@example.org>", "DATA"], xe(0.152, h, X, "MAIL FROM, RCPT TO, DATA (pipelined)", tf), Je), l("web", "client", "violet", "250 · 250 · 354", ["250 2.1.0 Ok · 250 2.1.5 Ok", "354 End data with", "<CR><LF>.<CR><LF>"], xe(0.167, X, h, "250 Ok, 250 Ok, 354 End data with <CR><LF>.<CR><LF>", Ic), Je), l("client", "web", "amber", "MESSAGE", ["Subject: Lunch on Friday?", "… message …", "."], xe(0.182, h, X, `Message (${ui} bytes), then “.”`, {
      message: ui,
      what: `Alice’s message (${ui} bytes)`
    }), Je), l("web", "client", "violet", "250 QUEUED", ["250 2.0.0 Ok: queued", "as 4A1F2C3D9E"], xe(0.2, X, h, "250 2.0.0 Ok: queued as 4A1F2C3D9E", sf), Je)]
  }, {
    title: "Find Bob’s Server",
    desc: "An MX lookup in DNS",
    detail: "Alice’s provider now has to deliver to example.org. It asks DNS for that domain’s MX record, which names the server that accepts its mail, then looks up that server’s address.",
    facts: [["MX record", "10 mx.example.org"], ["Address", "A 198.51.100.25"], ["Asked by", "Alice’s provider"]],
    events: [{
      type: "show",
      nodes: ["dns"],
      frame: "mailhost"
    }, l("web", "dns", "blue", "DNS QUERY", ["MX? example.org"], Na(0.205, X, Ia, "Standard query MX example.org", 82, {
      id: 28165,
      q: ["example.org", "MX"]
    })), l("dns", "web", "blue", "DNS REPLY", ["example.org MX 10", "mx.example.org"], Na(0.21, Ia, X, "Standard query response MX 10 mx.example.org", 101, {
      id: 28165,
      q: ["example.org", "MX"],
      an: [["example.org", "MX", 3600, [10, "mx.example.org"]]]
    })), l("web", "dns", "blue", "DNS QUERY", ["A? mx.example.org"], Na(0.215, X, Ia, "Standard query A mx.example.org", 85, {
      id: 8146,
      q: ["mx.example.org", "A"]
    })), l("dns", "web", "blue", "DNS REPLY", ["mx.example.org", "A 198.51.100.25"], Na(0.22, Ia, X, "Standard query response A 198.51.100.25", 101, {
      id: 8146,
      q: ["mx.example.org", "A"],
      an: [["mx.example.org", "A", 3600, "198.51.100.25"]]
    }))]
  }, {
    title: "Server to Server",
    desc: "Port 25, upgraded with STARTTLS",
    detail: "The provider connects to mx.example.org on port 25. This conversation starts in plain text: the greeting and EHLO reply advertise STARTTLS, the provider asks for it, gets 220 and both sides switch to TLS.",
    facts: [["Server", "mx.example.org:25"], ["Starts as", "Plain text"], ["Upgrade", "STARTTLS → 220 → TLS"]],
    events: [{
      type: "show",
      nodes: ["mx"],
      frame: "full"
    }, ...he({
      from: "web",
      to: "mx",
      src: X,
      dst: Ye,
      sport: 41522,
      dport: 25,
      t: [0.225, 0.245, 0.265],
      linux: true
    }), l("mx", "web", "violet", "220", ["220 mx.example.org ESMTP"], xe(0.285, Ye, X, "220 mx.example.org ESMTP Postfix", nf, false)), l("web", "mx", "amber", "EHLO", ["EHLO smtp.example.com"], xe(0.305, X, Ye, "EHLO smtp.example.com", Rc, false)), l("mx", "web", "violet", "250", ["250-PIPELINING", "250-STARTTLS …"], xe(0.325, Ye, X, "250 capabilities (PIPELINING, STARTTLS …)", Sp, false)), l("web", "mx", "amber", "STARTTLS", ["STARTTLS"], xe(0.345, X, Ye, "STARTTLS", of, false)), l("mx", "web", "violet", "220", ["220 2.0.0 Ready to", "start TLS"], xe(0.365, Ye, X, "220 2.0.0 Ready to start TLS", af, false)), ...mo({
      from: "web",
      to: "mx",
      src: X,
      dst: Ye,
      sni: "mx.example.org",
      sport: 41522,
      dport: 25,
      t: [0.385, 0.405, 0.427],
      linux: true
    })]
  }, {
    title: "Deliver",
    desc: "The same transaction again",
    detail: "With TLS on, the provider repeats EHLO, then the envelope and the message, now with a DKIM signature and a Received header added. Bob’s server checks SPF, DKIM and DMARC and accepts it.",
    facts: [["Login needed", "No (server to server)"], ["Message", "1,316 bytes (signed)"], ["Result", "250 Ok: queued"]],
    events: [l("web", "mx", "amber", "EHLO", ["EHLO smtp.example.com"], xe(0.427, X, Ye, "EHLO smtp.example.com", Rc), Je), l("mx", "web", "violet", "250", ["250-PIPELINING", "250-SIZE …"], xe(0.447, Ye, X, "250 capabilities (PIPELINING, SIZE …)", rf), Je), l("web", "mx", "amber", "MAIL · RCPT · DATA", ["MAIL FROM:<alice@example.com>", "RCPT TO:<bob@example.org>", "DATA"], xe(0.467, X, Ye, `MAIL FROM (SIZE=${Go}), RCPT TO, DATA`, lf), Je), l("mx", "web", "violet", "250 · 250 · 354", ["250 2.1.0 Ok · 250 2.1.5 Ok", "354 End data with", "<CR><LF>.<CR><LF>"], xe(0.487, Ye, X, "250 Ok, 250 Ok, 354 End data with <CR><LF>.<CR><LF>", Ic), Je), l("web", "mx", "amber", "MESSAGE", ["DKIM-Signature: …", "… message …", "."], xe(0.507, X, Ye, `Message (${Go.toLocaleString("en-US")} bytes), then “.”`, {
      message: Go,
      what: `The signed message (${Go.toLocaleString("en-US")} bytes)`
    }), Je), l("mx", "web", "violet", "250 QUEUED", ["250 2.0.0 Ok: queued", "as 7B3E9F01A2"], xe(0.538, Ye, X, "250 2.0.0 Ok: queued as 7B3E9F01A2", cf), Je), {
      type: "note",
      at: "mx",
      text: "IN BOB’S MAILBOX",
      tone: "green"
    }]
  }]
};
const $e = "198.51.100.110";
const Tp = q(h, 53010, $e, 995);
const ct = (...e) => e;
const dt = (e, t, s, n, o) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "POP (TLS)",
  info: n,
  len: `${kl(K(...o))} B`,
  wire: P(Tp, t, "PA", Mr(o, "POP3"))
});
const et = {
  locked: true
};
const ia = K("+OK 1904 octets") + 1904 + K(".") + Yt;
const hf = ia + rt(ia) * (ae + re + ie);
const pf = {
  id: "pop3",
  name: "POP3",
  title: "Downloading Email",
  layer: 7,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.015
  },
  labels: {
    web: ["pop.example.org", $e]
  },
  legend: [["green", "TCP"], ["teal", "TLS handshake"], ["amber", "POP3 command"], ["violet", "POP3 reply"], [null, "Data ACKs not shown"]],
  overview: {
    full: "Post Office Protocol, version 3",
    description: "POP3 lets a mail app download messages from a mailbox on a server. It was designed for one device that fetches mail and then removes it from the server. Commands are short words, and every reply starts with +OK or -ERR.",
    facts: [["Layer", "Application (Layer 7)"], ["Ports", "995 (TLS), 110 (STLS)"], ["Transport", "TCP"], ["Model", "Download, then delete"], ["Replies", "+OK or -ERR"], ["Defined In", "RFC 1939"]]
  },
  outro: {
    title: "Mail downloaded",
    desc: "And gone from the server",
    text: "Bob’s app logged in, saw two messages, downloaded the first and deleted it, which the server carried out at QUIT. That message now lives only on this laptop, which is why POP3 suits one device and IMAP suits several.",
    facts: [["Messages", "2 waiting, 1 downloaded"], ["Deleted", "At QUIT (UPDATE state)"], ["Port", "995, TLS from the start"], ["Best for", "A single device"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Connect Securely",
    desc: "Port 995, TLS from the start",
    detail: "Bob’s mail app connects to pop.example.org on port 995, where TLS starts right away. Inside it, the server greets with +OK. (On port 110 the session starts in plain text and is upgraded with the STLS command.)",
    facts: [["Server", "pop.example.org:995"], ["Security", "TLS from the start"], ["Greeting", "+OK Dovecot ready."]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      dst: $e,
      sport: 53010,
      dport: 995,
      t: [0, 0.015, 0.03]
    }), ...mo({
      dst: $e,
      sni: "pop.example.org",
      sport: 53010,
      dport: 995,
      t: [0.03, 0.045, 0.062]
    }), l("web", "client", "violet", "+OK", ["+OK Dovecot ready."], dt(0.077, $e, h, "+OK Dovecot ready.", ct("+OK Dovecot ready.")), et)]
  }, {
    title: "Log In",
    desc: "USER, then PASS",
    detail: "The app sends the user name with USER and the password with PASS. Each command gets its own +OK. Because the session is inside TLS, the password isn’t readable on the way.",
    facts: [["Commands", "USER bob, PASS ••••"], ["Replies", "+OK, +OK Logged in."], ["Protected by", "TLS"]],
    events: [l("client", "web", "amber", "USER", ["USER bob"], dt(0.092, h, $e, "USER bob", ct("USER bob")), et), l("web", "client", "violet", "+OK", ["+OK"], dt(0.107, $e, h, "+OK", ct("+OK")), et), l("client", "web", "amber", "PASS", ["PASS ••••••"], dt(0.122, h, $e, "PASS (password)", ct("PASS secret")), et), l("web", "client", "violet", "+OK", ["+OK Logged in."], dt(0.137, $e, h, "+OK Logged in.", ct("+OK Logged in.")), et)]
  }, {
    title: "Check the Mailbox",
    desc: "STAT and LIST",
    detail: "STAT returns the number of messages and their total size: 2 messages, 5120 bytes. LIST gives each message’s number and size, ending with a line holding just a dot.",
    facts: [["STAT", "+OK 2 5120"], ["Message 1", "1904 bytes"], ["Message 2", "3216 bytes"]],
    events: [l("client", "web", "amber", "STAT", ["STAT"], dt(0.152, h, $e, "STAT", ct("STAT")), et), l("web", "client", "violet", "+OK", ["+OK 2 5120"], dt(0.167, $e, h, "+OK 2 5120", ct("+OK 2 5120")), et), l("client", "web", "amber", "LIST", ["LIST"], dt(0.182, h, $e, "LIST", ct("LIST")), et), l("web", "client", "violet", "+OK", ["+OK 2 messages:", "1 1904 · 2 3216 · ."], dt(0.197, $e, h, "+OK 2 messages: 1 1904, 2 3216", ct("+OK 2 messages:", "1 1904", "2 3216", ".")), et)]
  }, {
    title: "Download",
    desc: "RETR 1",
    detail: "RETR 1 asks for the first message. The server answers +OK with its size, then the message and a closing dot: 1904 bytes plus the reply line, two TCP segments.",
    facts: [["Command", "RETR 1"], ["Reply", "+OK 1904 octets"], ["Sent as", "2 TCP segments"]],
    events: [l("client", "web", "amber", "RETR 1", ["RETR 1"], dt(0.212, h, $e, "RETR 1", ct("RETR 1")), et), l("web", "client", "violet", "MESSAGE", ["+OK 1904 octets", "… message …", "."], {
      time: x(0.227),
      src: $e,
      dst: h,
      proto: "POP (TLS)",
      info: `+OK 1904 octets, message, “.” (${rt(ia)} segments)`,
      len: it(hf, rt(ia)),
      wire: P(Tp, $e, "PA", {
        tls: [{
          type: "appdata",
          length: ia - 5,
          inner: {
            what: "+OK 1904 octets, the 1,904-byte message, then a line holding only “.”"
          }
        }]
      })
    }, et)]
  }, {
    title: "Delete & Quit",
    desc: "Deleted only at QUIT",
    detail: "DELE 1 only marks the message. The server removes it when the app says QUIT: if the connection dropped before that, nothing would be deleted. Many apps offer “leave a copy on the server”, which skips DELE.",
    facts: [["DELE 1", "Marks message 1"], ["Removed", "At QUIT"], ["Option", "Leave a copy on server"]],
    events: [l("client", "web", "amber", "DELE 1", ["DELE 1"], dt(0.242, h, $e, "DELE 1", ct("DELE 1")), et), l("web", "client", "violet", "+OK", ["+OK Marked to be deleted."], dt(0.257, $e, h, "+OK Marked to be deleted.", ct("+OK Marked to be deleted.")), et), l("client", "web", "amber", "QUIT", ["QUIT"], dt(0.272, h, $e, "QUIT", ct("QUIT")), et), l("web", "client", "violet", "+OK", ["+OK Logging out,", "messages deleted."], dt(0.287, $e, h, "+OK Logging out, messages deleted.", ct("+OK Logging out, messages deleted.")), et), {
      type: "note",
      at: "web",
      text: "MESSAGE 1 DELETED",
      tone: "amber"
    }]
  }]
};
const We = "198.51.100.143";
const bp = q(h, 53140, We, 993);
const Gt = (...e) => e;
const Ht = (e, t, s, n, o) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "IMAP (TLS)",
  info: n,
  len: `${kl(K(...o))} B`,
  wire: P(bp, t, "PA", Mr(o, "IMAP"))
});
const Ct = {
  locked: true
};
const uf = Gt("* OK [CAPABILITY IMAP4rev1 IDLE LITERAL+ AUTH=PLAIN] Service ready");
const ff = Gt("a1 LOGIN bob secret");
const mf = Gt("a1 OK LOGIN completed");
const yf = Gt("a2 SELECT INBOX");
const wf = Gt("* FLAGS (\\Answered \\Flagged \\Deleted \\Seen \\Draft)", "* OK [PERMANENTFLAGS (\\Answered \\Flagged \\Deleted \\Seen \\Draft \\*)] Flags permitted", "* 2 EXISTS", "* 0 RECENT", "* OK [UNSEEN 2] Message 2 is first unseen", "* OK [UIDVALIDITY 1700000000] UIDs valid", "* OK [UIDNEXT 3] Predicted next UID", "a2 OK [READ-WRITE] SELECT completed");
const gf = Gt("a3 FETCH 2 BODY[]");
const la = K("* 2 FETCH (FLAGS (\\Seen) BODY[] {3216}") + 3216 + K(")", "a3 OK FETCH completed") + Yt;
const Sf = la + rt(la) * (ae + re + ie);
const Tf = {
  id: "imap",
  name: "IMAP",
  title: "Mail in Sync",
  layer: 7,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.015
  },
  labels: {
    web: ["imap.example.org", We]
  },
  legend: [["green", "TCP"], ["teal", "TLS handshake"], ["amber", "IMAP command"], ["violet", "IMAP response"], [null, "Data ACKs not shown"]],
  overview: {
    full: "Internet Message Access Protocol",
    description: "IMAP lets mail apps work with a mailbox that stays on the server. Folders, read and flagged marks and deletions are kept there, so a phone, a laptop and webmail all see the same mailbox. The server can also tell an app about new mail as it arrives.",
    facts: [["Layer", "Application (Layer 7)"], ["Ports", "993 (TLS), 143 (STARTTLS)"], ["Transport", "TCP"], ["Model", "Mail stays on the server"], ["Syncs", "Folders and flags"], ["Defined In", "RFC 9051, RFC 3501"]]
  },
  outro: {
    title: "Mailbox in sync",
    desc: "Read once, read everywhere",
    text: "Bob’s app opened his inbox, read a message, which marked it \\Seen on the server for all his devices, and then waited with IDLE until the server announced new mail. Nothing was deleted: the server still holds everything.",
    facts: [["Messages", "2, then 3 (new mail)"], ["Read mark", "\\Seen, stored on server"], ["New mail", "Pushed during IDLE"], ["Port", "993, TLS from the start"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Connect Securely",
    desc: "Port 993, TLS from the start",
    detail: "Bob’s app connects to imap.example.org on port 993, where TLS starts right away. The server greets with an untagged “* OK” line that also lists its capabilities, such as IDLE.",
    facts: [["Server", "imap.example.org:993"], ["Security", "TLS from the start"], ["Greeting", "* OK [CAPABILITY …]"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      dst: We,
      sport: 53140,
      dport: 993,
      t: [0, 0.015, 0.03]
    }), ...mo({
      dst: We,
      sni: "imap.example.org",
      sport: 53140,
      dport: 993,
      t: [0.03, 0.045, 0.062]
    }), l("web", "client", "violet", "* OK", ["* OK [CAPABILITY IMAP4rev1", "IDLE …] Service ready"], Ht(0.077, We, h, "* OK [CAPABILITY …] Service ready", uf), Ct)]
  }, {
    title: "Log In",
    desc: "Commands carry tags",
    detail: "Every command starts with a tag the app chooses, like a1, and the server ends its answer with the same tag. That way several commands can be in flight and each reply is matched up. Lines starting with * are untagged data.",
    facts: [["Command", "a1 LOGIN bob ••••"], ["Reply", "a1 OK LOGIN completed"], ["Tags", "Match replies to commands"]],
    events: [l("client", "web", "amber", "a1 LOGIN", ["a1 LOGIN bob ••••••"], Ht(0.092, h, We, "a1 LOGIN (user and password)", ff), Ct), l("web", "client", "violet", "a1 OK", ["a1 OK LOGIN completed"], Ht(0.107, We, h, "a1 OK LOGIN completed", mf), Ct)]
  }, {
    title: "Open the Inbox",
    desc: "SELECT a folder",
    detail: "SELECT INBOX opens the folder. The server reports the message count, the flags it supports and the first unread message, then confirms the folder is open read-write.",
    facts: [["Messages", "* 2 EXISTS"], ["First unread", "Message 2"], ["Access", "[READ-WRITE]"]],
    events: [l("client", "web", "amber", "a2 SELECT", ["a2 SELECT INBOX"], Ht(0.122, h, We, "a2 SELECT INBOX", yf), Ct), l("web", "client", "violet", "a2 OK", ["* 2 EXISTS", "* OK [UNSEEN 2]", "a2 OK [READ-WRITE]"], Ht(0.137, We, h, "* 2 EXISTS … a2 OK [READ-WRITE] SELECT completed", wf), Ct)]
  }, {
    title: "Read a Message",
    desc: "FETCH, and the \\Seen flag",
    detail: "FETCH 2 BODY[] downloads message 2 (three TCP segments). That sets its \\Seen flag on the server, so it shows as read on Bob’s phone too, and the message stays there.",
    facts: [["Command", "a3 FETCH 2 BODY[]"], ["Flag set", "\\Seen (on the server)"], ["Sent as", "3 TCP segments"]],
    events: [l("client", "web", "amber", "a3 FETCH", ["a3 FETCH 2 BODY[]"], Ht(0.152, h, We, "a3 FETCH 2 BODY[]", gf), Ct), l("web", "client", "violet", "MESSAGE", ["* 2 FETCH (FLAGS (\\Seen)", "BODY[] {3216} …)", "a3 OK FETCH completed"], {
      time: x(0.167),
      src: We,
      dst: h,
      proto: "IMAP (TLS)",
      info: `* 2 FETCH (FLAGS (\\Seen) BODY[] …), ${rt(la)} segments`,
      len: it(Sf, rt(la)),
      wire: P(bp, We, "PA", {
        tls: [{
          type: "appdata",
          length: la - 5,
          inner: {
            what: "* 2 FETCH (FLAGS (\\Seen) BODY[] {3216}, the 3,216-byte message, then a3 OK FETCH completed"
          }
        }]
      })
    }, Ct), {
      type: "note",
      at: "web",
      text: "STILL ON SERVER · \\SEEN",
      tone: "green"
    }]
  }, {
    title: "Wait for New Mail",
    desc: "IDLE: the server pushes",
    detail: "IDLE tells the server “let me know when something changes”. About 42 seconds later Alice’s message arrives and the server pushes “* 3 EXISTS” straight away. The app ends IDLE with DONE and can fetch the new mail.",
    facts: [["Command", "a4 IDLE"], ["Server says", "* 3 EXISTS (new mail)"], ["Ended by", "DONE"]],
    events: [l("client", "web", "amber", "a4 IDLE", ["a4 IDLE"], Ht(0.182, h, We, "a4 IDLE", Gt("a4 IDLE")), Ct), l("web", "client", "violet", "+ idling", ["+ idling"], Ht(0.197, We, h, "+ idling", Gt("+ idling")), Ct), {
      type: "note",
      at: "web",
      text: "NEW MAIL ARRIVED",
      tone: "navy"
    }, l("web", "client", "violet", "* 3 EXISTS", ["* 3 EXISTS", "* 1 RECENT"], Ht(42.515, We, h, "* 3 EXISTS, * 1 RECENT", Gt("* 3 EXISTS", "* 1 RECENT")), Ct), l("client", "web", "amber", "DONE", ["DONE"], Ht(42.53, h, We, "DONE", Gt("DONE")), Ct), l("web", "client", "violet", "a4 OK", ["a4 OK IDLE terminated"], Ht(42.545, We, h, "a4 OK IDLE terminated", Gt("a4 OK IDLE terminated")), Ct)]
  }]
};
const Dt = "203.0.113.21";
const cn = 4000;
const Sr = 50069;
const bf = q(h, 52800, Dt, 21);
const vp = q(h, 52801, Dt, Sr);
const Il = (e, t, s, n, o) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "FTP",
  info: n,
  len: `${j(K(o))} B`,
  wire: P(bf, t, "PA", {
    text: [o],
    name: "FTP"
  })
});
const Ln = (e, t) => l("client", "web", "amber", t.split(" ")[0], [t], Il(e, h, Dt, t, t));
const zs = (e, t, s, n) => l("web", "client", "violet", t, s, Il(e, Dt, h, n, n));
const un = [];
for (let e = cn; e > 0; e -= W) {
  un.push(Math.min(W, e));
}
const vf = (e, t) => {
  const s = 1 + t * W;
  return {
    time: x(0.225),
    src: Dt,
    dst: h,
    proto: "FTP-DATA",
    info: `FTP Data: ${e} bytes (Seq=${s})`,
    len: `${j(e)} B`,
    wire: P(vp, Dt, t === un.length - 1 ? "PA" : "A", {
      opaque: e,
      what: `report.pdf, bytes ${s}–${s + e - 1}`,
      name: "FTP data",
      note: "The file itself, unencrypted: anyone on the path could read it."
    })
  };
};
const kf = {
  id: "ftp",
  name: "FTP",
  title: "Transferring Files",
  layer: 7,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.015
  },
  labels: {
    web: ["ftp.example.com", Dt]
  },
  legend: [["green", "TCP"], ["amber", "FTP command"], ["violet", "FTP reply"], ["blue", "File data"], [null, "Data ACKs not shown"]],
  overview: {
    full: "File Transfer Protocol",
    description: "FTP moves files between a client and a server. It is unusual in using two TCP connections: one for commands and replies, and a fresh one for each file or listing. It dates from the early 1970s and sends everything, passwords included, as plain text.",
    facts: [["Layer", "Application (Layer 7)"], ["Ports", "21 control, data varies"], ["Connections", "Control + one per transfer"], ["Encryption", "None (plain text)"], ["Safer options", "SFTP, or FTPS (FTP + TLS)"], ["Defined In", "RFC 959"]]
  },
  outro: {
    title: "File downloaded",
    desc: "Two connections, no encryption",
    text: "Commands went over the control connection, the file over its own data connection, and closing that connection marked the end of the file. Anyone on the path could have read the password and the file, which is why SFTP or FTPS is used today.",
    facts: [["Connections", "2 (control + data)"], ["File", `${cn.toLocaleString("en-US")} bytes, ${un.length} segments`], ["Password", "Sent in plain text"], ["Use instead", "SFTP or FTPS"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Control Connection",
    desc: "Port 21, plain text",
    detail: "The FTP app opens a TCP connection to ftp.example.com on port 21. This control connection carries commands and replies for the whole session. The server greets with 220. Like SMTP, every reply starts with a three-digit code.",
    facts: [["Server", "ftp.example.com:21"], ["Greeting", "220 (vsFTPd 3.0.5)"], ["Encrypted", "No"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      dst: Dt,
      sport: 52800,
      dport: 21,
      t: [0, 0.015, 0.03]
    }), zs(0.045, "220", ["220 (vsFTPd 3.0.5)"], "220 (vsFTPd 3.0.5)")]
  }, {
    title: "Log In",
    desc: "USER and PASS, readable by anyone",
    detail: "The app sends USER, the server asks for the password with 331, and PASS sends it. Nothing is encrypted, so the user name and password cross every network on the way as readable text.",
    facts: [["Commands", "USER alice, PASS secret"], ["Result", "230 Login successful."], ["Visible to", "Anyone on the path"]],
    events: [Ln(0.06, "USER alice"), zs(0.075, "331", ["331 Please specify", "the password."], "331 Please specify the password."), Ln(0.09, "PASS secret"), {
      type: "note",
      at: "router",
      text: "PASSWORD IN PLAIN TEXT",
      tone: "amber"
    }, zs(0.105, "230", ["230 Login successful."], "230 Login successful.")]
  }, {
    title: "Passive Mode",
    desc: "The server names a data port",
    detail: "TYPE I asks for a byte-for-byte binary copy. PASV asks the server to open a port for the data connection. The reply encodes the address and port as six numbers: 195 × 256 + 149 = port 50069. The laptop connects out, which works through NAT.",
    facts: [["Reply", "227 (203,0,113,21,195,149)"], ["Data port", "195 × 256 + 149 = 50069"], ["Active mode", "Server dials in: NAT blocks"]],
    events: [Ln(0.12, "TYPE I"), zs(0.135, "200", ["200 Switching to", "Binary mode."], "200 Switching to Binary mode."), Ln(0.15, "PASV"), zs(0.165, "227", ["227 Entering Passive Mode", "(203,0,113,21,195,149)."], "227 Entering Passive Mode (203,0,113,21,195,149).")]
  }, {
    title: "Data Connection",
    desc: "A second TCP connection",
    detail: "The app opens a second TCP connection, to port 50069, and asks for the file on the control connection with RETR. The server answers 150 there and starts sending the file over the new connection.",
    facts: [["Data to", `ftp.example.com:${Sr}`], ["Command", "RETR report.pdf"], ["Reply", "150 Opening BINARY …"]],
    events: [...he({
      dst: Dt,
      sport: 52801,
      dport: Sr,
      t: [0.18, 0.195, 0.21]
    }), Ln(0.21, "RETR report.pdf"), l("web", "client", "violet", "150", ["150 Opening BINARY mode", "data connection …"], Il(0.225, Dt, h, "150 Opening BINARY mode data connection …", `150 Opening BINARY mode data connection for report.pdf (${cn} bytes).`))]
  }, {
    title: "The File Arrives",
    desc: "Closing the connection ends it",
    detail: `The ${cn.toLocaleString("en-US")} bytes arrive in ${un.length} TCP segments. FTP sends no length marker in the data itself: the server closes the data connection to mark the end of the file. Once the laptop has acknowledged everything, the server confirms with 226 on the control connection.`,
    facts: [["File", `report.pdf, ${cn.toLocaleString("en-US")} bytes`], ["Segments", un.join(" + ")], ["End of file", "Data connection closed"]],
    events: [{
      type: "stream",
      from: "web",
      to: "client",
      color: "blue",
      label: `${un.length} SEGMENTS`,
      payload: ["report.pdf", `${cn.toLocaleString("en-US")} bytes, readable by anyone`],
      packets: un.map((e, t) => l("web", "client", "blue", "DATA", [], vf(e, t)))
    }, l("web", "client", "green", "FIN", ["end of file:", "data connection closed"], {
      time: x(0.225),
      src: Dt,
      dst: h,
      proto: "TCP",
      info: `${Sr} → 52801 [FIN, ACK] Seq=${cn + 1} Ack=1`,
      len: `${j(0)} B`,
      wire: P(vp, Dt, "FA")
    }), zs(0.255, "226", ["226 Transfer complete."], "226 Transfer complete.")]
  }, {
    title: "Quit",
    desc: "Close the control connection",
    detail: "QUIT ends the session and the server says goodbye with 221. For anything sensitive, SFTP (a different protocol, run over SSH) or FTPS (FTP inside TLS) gives the same job encryption.",
    facts: [["Command", "QUIT"], ["Reply", "221 Goodbye."], ["Encrypted cousins", "SFTP, FTPS"]],
    events: [Ln(0.27, "QUIT"), zs(0.285, "221", ["221 Goodbye."], "221 Goodbye.")]
  }]
};
const gt = "203.0.113.22";
const kp = {
  locked: true
};
const Pp = e => {
  let t = 8 - e % 8;
  if (t < 4) {
    t += 8;
  }
  return t;
};
const Hr = e => 5 + e + Pp(5 + e);
const rs = e => 5 + e + Pp(1 + e) + 16;
const de = e => 4 + (typeof e == "number" ? e : e.length);
const In = e => de(e.join(","));
const Ap = e => e + rt(e) * (ae + re + ie);
const Ar = ["sntrup761x25519-sha512@openssh.com", "curve25519-sha256", "curve25519-sha256@libssh.org", "ecdh-sha2-nistp256", "ecdh-sha2-nistp384", "ecdh-sha2-nistp521", "diffie-hellman-group-exchange-sha256", "diffie-hellman-group16-sha512", "diffie-hellman-group18-sha512", "diffie-hellman-group14-sha256"];
const Ep = ["ssh-ed25519-cert-v01@openssh.com", "ecdsa-sha2-nistp256-cert-v01@openssh.com", "ecdsa-sha2-nistp384-cert-v01@openssh.com", "ecdsa-sha2-nistp521-cert-v01@openssh.com", "sk-ssh-ed25519-cert-v01@openssh.com", "sk-ecdsa-sha2-nistp256-cert-v01@openssh.com", "rsa-sha2-512-cert-v01@openssh.com", "rsa-sha2-256-cert-v01@openssh.com", "ssh-ed25519", "ecdsa-sha2-nistp256", "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp521", "sk-ssh-ed25519@openssh.com", "sk-ecdsa-sha2-nistp256@openssh.com", "rsa-sha2-512", "rsa-sha2-256"];
const xp = ["rsa-sha2-512", "rsa-sha2-256", "ecdsa-sha2-nistp256", "ssh-ed25519"];
const Cp = ["chacha20-poly1305@openssh.com", "aes128-ctr", "aes192-ctr", "aes256-ctr", "aes128-gcm@openssh.com", "aes256-gcm@openssh.com"];
const $p = ["umac-64-etm@openssh.com", "umac-128-etm@openssh.com", "hmac-sha2-256-etm@openssh.com", "hmac-sha2-512-etm@openssh.com", "hmac-sha1-etm@openssh.com", "umac-64@openssh.com", "umac-128@openssh.com", "hmac-sha2-256", "hmac-sha2-512", "hmac-sha1"];
const Lp = ["none", "zlib@openssh.com"];
const Ip = (e, t) => Hr(17 + In(e) + In(t) + In(Cp) * 2 + In($p) * 2 + In(Lp) * 2 + In([]) * 2 + 1 + 4);
const Nc = Ip([...Ar, "ext-info-c", "kex-strict-c-v00@openssh.com"], Ep);
const Pf = Ip([...Ar, "ext-info-s", "kex-strict-s-v00@openssh.com"], xp);
const yo = de("ssh-ed25519") + de(32);
const Rl = de("ssh-ed25519") + de(64);
const Af = Hr(1 + de(1190));
const Ef = Hr(1 + de(yo) + de(1071) + de(Rl));
const Dc = Hr(1);
const Nl = de("alice") + de("ssh-connection");
const Oc = rs(1 + de("ssh-userauth"));
const xf = rs(1 + Nl + de("none"));
const Cf = rs(1 + de("publickey,password") + 1);
const $f = rs(1 + Nl + de("publickey") + 1 + de("ssh-ed25519") + de(yo));
const Lf = rs(1 + de("ssh-ed25519") + de(yo));
const If = rs(1 + Nl + de("publickey-hostbound-v00@openssh.com") + 1 + de("ssh-ed25519") + de(yo) + de(yo) + de(Rl));
const Rf = rs(1);
const Nf = rs(1 + de("session") + 4 + 4 + 4);
const Df = rs(17);
const Rp = e => rs(5 + de(e));
const Es = Rp(1);
const Of = "]0;alice@server: ~[01;32malice@server[00m:[01;34m~[00m$ ";
const Np = `\r
\x1B[?2004l\r/home/alice\r
\x1B[?2004h${Of}`;
const Mf = Rp(Np.length);
const qf = q(h, 53210, gt, 22);
const ps = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "SSH",
  info: n,
  len: it(Ap(o), rt(o)),
  wire: P(qf, t, "PA", a)
});
const Dp = (e, t, s, n, o, a) => ps(e, t, s, `Encrypted (len=${o}): ${n}`, o, {
  ssh: {
    sealed: o,
    inside: a
  }
});
const ls = (e, t, s, n, o, a, r) => l("client", "web", "amber", t, s, Dp(e, h, gt, n, o, r), {
  ...kp,
  ...a
});
const cs = (e, t, s, n, o, a, r) => l("web", "client", "violet", t, s, Dp(e, gt, h, n, o, r), {
  ...kp,
  ...a
});
const Mc = e => ({
  text: [e],
  name: "SSH"
});
const qc = (e, t) => ({
  ssh: {
    msg: "kexinit",
    kex: e,
    hostkeys: t,
    ciphers: Cp,
    macs: $p,
    compression: Lp
  }
});
const xs = "SSH_MSG_CHANNEL_DATA (94), channel 0:";
const $t = {
  quick: true
};
const Hf = {
  id: "ssh",
  name: "SSH",
  title: "Secure Remote Login",
  layer: 7,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.015
  },
  labels: {
    web: ["server.example.com", gt]
  },
  legend: [["green", "TCP"], ["slate", "Plain setup"], ["teal", "Key exchange"], ["amber", "From laptop"], ["violet", "From server"], [null, "Some packets not shown"]],
  overview: {
    full: "Secure Shell",
    description: "SSH gives you an encrypted, authenticated connection to another computer, to run commands on it, copy files (SFTP, scp) or carry other connections. The server proves who it is with a host key; you prove who you are with a key pair or a password.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "22"], ["Transport", "TCP"], ["Server proves", "Host key (known_hosts)"], ["You prove", "Key pair or password"], ["Defined In", "RFC 4251 – 4254"]]
  },
  outro: {
    title: "Logged in securely",
    desc: "Encrypted from the key exchange on",
    text: "The two sides agreed on algorithms, built shared keys with a post-quantum hybrid exchange, and the server proved its identity with its host key. Alice proved hers by signing with a private key that never left the laptop, then typed a command, one packet per key.",
    facts: [["Key exchange", "sntrup761 + X25519"], ["Cipher", "ChaCha20-Poly1305"], ["Login", "Ed25519 key, no password"], ["Port", "22"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Say Hello",
    desc: "Versions, in plain text",
    detail: "Alice runs “ssh alice@server.example.com”. After the TCP handshake on port 22, each side sends one line of plain text naming the SSH protocol version (2.0) and its software. Everything else in SSH is binary.",
    facts: [["Laptop", "OpenSSH_for_Windows_9.5"], ["Server", "OpenSSH_9.6p1 Ubuntu"], ["Protocol", "SSH-2.0"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      dst: gt,
      sport: 53210,
      dport: 22,
      t: [0, 0.015, 0.03]
    }), l("client", "web", "slate", "VERSION", ["SSH-2.0-", "OpenSSH_for_Windows_9.5"], ps(0.03, h, gt, "Client: SSH-2.0-OpenSSH_for_Windows_9.5", K("SSH-2.0-OpenSSH_for_Windows_9.5"), Mc("SSH-2.0-OpenSSH_for_Windows_9.5"))), l("web", "client", "slate", "VERSION", ["SSH-2.0-OpenSSH_9.6p1", "Ubuntu-3ubuntu13.5"], ps(0.045, gt, h, "Server: SSH-2.0-OpenSSH_9.6p1 Ubuntu-3ubuntu13.5", K("SSH-2.0-OpenSSH_9.6p1 Ubuntu-3ubuntu13.5"), Mc("SSH-2.0-OpenSSH_9.6p1 Ubuntu-3ubuntu13.5")))]
  }, {
    title: "Agree on Algorithms",
    desc: "KEXINIT lists, first match wins",
    detail: "Each side sends a KEXINIT listing every algorithm it supports, in order of preference, for key exchange, host keys, encryption, integrity and compression. In each category the first algorithm on the laptop’s list that the server also supports is chosen.",
    facts: [["Key exchange", "sntrup761x25519-sha512"], ["Host key", "ssh-ed25519"], ["Cipher", "chacha20-poly1305"]],
    events: [l("web", "client", "slate", "KEXINIT", ["server’s algorithm lists", "in order of preference"], ps(0.045, gt, h, "Server: Key Exchange Init", Pf, qc([...Ar, "ext-info-s", "kex-strict-s-v00@openssh.com"], xp))), l("client", "web", "slate", "KEXINIT", ["laptop’s algorithm lists", "in order of preference"], ps(0.06, h, gt, `Client: Key Exchange Init, ${rt(Nc)} segments`, Nc, qc([...Ar, "ext-info-c", "kex-strict-c-v00@openssh.com"], Ep)))]
  }, {
    title: "Key Exchange",
    desc: "Shared keys, and a host key check",
    detail: "The laptop sends its half of a hybrid exchange: a Streamlined NTRU Prime key, chosen to resist future quantum computers, plus an X25519 key. The server answers with its half, its host key and a signature over the exchange. NEWKEYS switches encryption on.",
    facts: [["Hybrid", "sntrup761 + X25519"], ["Host key", "Matches known_hosts"], ["First visit", "ssh asks you to confirm"]],
    events: [l("client", "web", "teal", "KEX INIT", ["sntrup761 + X25519", "public keys"], ps(0.06, h, gt, "Client: KEX_ECDH_INIT (sntrup761x25519 public keys)", Af, {
      ssh: {
        msg: "ecdh_init",
        q: 1190
      }
    })), l("web", "client", "teal", "KEX REPLY", ["its half, its host key", "and a signature"], ps(0.075, gt, h, "Server: KEX_ECDH_REPLY (host key, its half, signature)", Ef, {
      ssh: {
        msg: "ecdh_reply",
        ks: yo,
        q: 1071,
        sig: Rl
      }
    })), l("web", "client", "teal", "NEWKEYS", [], ps(0.075, gt, h, "Server: New Keys", Dc, {
      ssh: {
        msg: "newkeys"
      }
    }), $t), {
      type: "note",
      at: "client",
      text: "HOST KEY MATCHES KNOWN_HOSTS",
      tone: "green"
    }, l("client", "web", "teal", "NEWKEYS", [], ps(0.09, h, gt, "Client: New Keys", Dc, {
      ssh: {
        msg: "newkeys"
      }
    }), $t)]
  }, {
    title: "Log In with a Key",
    desc: "Sign, don’t send a secret",
    detail: "The server lists the login methods it accepts. The laptop offers Alice’s public key, and the server says it would accept it. The laptop then signs this session with the private key, which never leaves the laptop. The server checks the signature against authorized_keys.",
    facts: [["Methods", "publickey, password"], ["Key", "Ed25519, private stays here"], ["Checked with", "~/.ssh/authorized_keys"]],
    events: [ls(0.09, "SERVICE REQUEST", [], "service request, ssh-userauth", Oc, $t, "SSH_MSG_SERVICE_REQUEST (5): “ssh-userauth”"), cs(0.105, "SERVICE ACCEPT", [], "service accept", Oc, $t, "SSH_MSG_SERVICE_ACCEPT (6): “ssh-userauth”"), ls(0.12, "AUTH: NONE", [], "login with method none", xf, $t, "SSH_MSG_USERAUTH_REQUEST (50): user “alice”, service “ssh-connection”, method “none”"), cs(0.135, "AUTH FAILURE", [], "try publickey,password", Cf, $t, "SSH_MSG_USERAUTH_FAILURE (51): methods that can continue: “publickey,password”"), ls(0.15, "OFFER KEY", ["alice’s public key", "would you accept it?"], "offer public key", $f, {}, "SSH_MSG_USERAUTH_REQUEST (50): method “publickey”, no signature, the ssh-ed25519 public key"), cs(0.165, "PK OK", ["yes, that key", "is in authorized_keys"], "public key OK", Lf, {}, "SSH_MSG_USERAUTH_PK_OK (60): the same ssh-ed25519 key"), ls(0.18, "SIGNED", ["same key, plus a signature", "made with the private key"], "public key + signature", If, {}, "SSH_MSG_USERAUTH_REQUEST (50): method “publickey-hostbound-v00@openssh.com”, the key, the server’s host key and a signature"), cs(0.195, "SUCCESS", ["logged in"], "login success", Rf, {}, "SSH_MSG_USERAUTH_SUCCESS (52)")]
  }, {
    title: "Open a Session",
    desc: "Channels inside one connection",
    detail: "One SSH connection can carry many channels: a shell, file transfers, forwarded ports. The laptop opens a session channel, then asks for a terminal and a shell (not shown), and the server sends its welcome text and a prompt.",
    facts: [["Channel", "session"], ["Then asks for", "A terminal and a shell"], ["Also possible", "SFTP, port forwarding"]],
    events: [ls(0.21, "CHANNEL OPEN", ["open a channel:", "session"], "channel open: session", Nf, {}, "SSH_MSG_CHANNEL_OPEN (90): “session”, channel 0, window 2 MB, packets up to 32 KB"), cs(0.225, "CONFIRMED", ["channel open"], "channel open confirmed", Df, {}, "SSH_MSG_CHANNEL_OPEN_CONFIRMATION (91): channel 0 is open")]
  }, {
    title: "Type a Command",
    desc: "Every key is a packet",
    detail: "Alice types pwd. Each key goes out at once in its own encrypted packet, and the server sends the character back to be shown (the echo). Since 9.5, OpenSSH sends keys on a 20 ms beat and adds decoy packets, so typing rhythm is harder to read from the timing.",
    facts: [["Per key", `1 packet, ${Ap(Es)} bytes`], ["Echo", "Sent back by the server"], ["Timing", "20 ms beat plus decoys"]],
    events: [ls(2, "“p”", [], "keystroke", Es, $t, `${xs} 1 byte, “p”`), cs(2.015, "ECHO", [], "echo", Es, $t, `${xs} 1 byte, “p”, sent back to be shown`), ls(2.14, "“w”", [], "keystroke", Es, $t, `${xs} 1 byte, “w”`), cs(2.155, "ECHO", [], "echo", Es, $t, `${xs} 1 byte, “w”, sent back to be shown`), ls(2.26, "“d”", [], "keystroke", Es, $t, `${xs} 1 byte, “d”`), cs(2.275, "ECHO", [], "echo", Es, $t, `${xs} 1 byte, “d”, sent back to be shown`), ls(2.42, "ENTER", ["Enter key"], "keystroke (Enter)", Es, {}, `${xs} 1 byte, a carriage return (Enter)`), cs(2.435, "OUTPUT", ["/home/alice", "alice@server:~$"], "output and a new prompt", Mf, {}, `${xs} ${Np.length} bytes: a new line, the shell’s terminal codes, “/home/alice”, and the coloured prompt`), {
      type: "note",
      at: "client",
      text: "EACH KEY IS ITS OWN PACKET",
      tone: "navy"
    }]
  }]
};
const Re = "203.0.113.10";
const Rn = {
  locked: true
};
const xo = ae + re + ie;
const Ff = 1215;
const Uf = 6;
const Kf = 2729;
const Bf = Ff + Uf + Kf;
const Ss = [];
for (let e = Bf; e > 0; e -= W) {
  Ss.push(Math.min(W, e));
}
const Hc = 2 + Yt;
const Qt = (e, t, s, n, o, a = "TLSv1.3") => ({
  time: x(e),
  src: t,
  dst: s,
  proto: a,
  info: n,
  len: o
});
const Xt = q(h, 52411, Re, 443);
const Zt = (e, t) => ({
  ...e,
  wire: t
});
const Fc = Ss.map((e, t) => Ss.slice(0, t).reduce((s, n) => s + n, 0));
const _f = {
  id: "tls",
  name: "TLS/SSL",
  title: "Encryption",
  layer: 6,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.017
  },
  labels: {
    web: ["www.example.com", Re]
  },
  legend: [["green", "TCP"], ["teal", "TLS handshake"], ["amber", "From browser"], ["violet", "From server"], [null, "Data ACKs not shown"]],
  overview: {
    full: "Transport Layer Security",
    description: "TLS puts a secure channel on top of TCP. It proves the server’s identity with a certificate, agrees on fresh keys, then encrypts and authenticates everything sent. HTTPS, secure email and many other protocols run inside it. SSL was the name of its predecessor.",
    facts: [["Sits", "Between TCP and the app"], ["OSI layer", "Often placed at 6"], ["Current", "TLS 1.3 (RFC 8446)"], ["Retired", "SSL 2 and 3, TLS 1.0 and 1.1"], ["Proves", "Server identity (certificate)"], ["Port", "The app’s own (443, 993 …)"]]
  },
  outro: {
    title: "Secure from start to finish",
    desc: "One round trip to set up",
    text: "One round trip agreed on a version, a cipher and a post-quantum hybrid key. The certificate chain proved who the server was, and every byte after the Server Hello was encrypted and authenticated, right up to the close_notify. Press REPLAY to watch it again.",
    facts: [["Version", "TLS 1.3"], ["Cipher", "TLS_AES_128_GCM_SHA256"], ["Key exchange", "X25519MLKEM768"], ["Setup", "1 round trip"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Client Hello",
    desc: "Everything the browser supports",
    detail: "After the TCP handshake the browser lists what it can do: TLS versions, cipher suites, and key shares for the groups it expects, including the post-quantum hybrid X25519MLKEM768. It also names the site (SNI) and the protocols it speaks (ALPN).",
    facts: [["Versions", "TLS 1.3, TLS 1.2"], ["Key shares", "X25519MLKEM768, X25519"], ["SNI, ALPN", "www.example.com; h2, http/1.1"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      dst: Re,
      sport: 52411,
      dport: 443,
      t: [0, 0.017, 0.034]
    }), l("client", "web", "teal", "CLIENT HELLO", ["versions, ciphers, key shares", "SNI www.example.com"], Zt(Qt(0.034, h, Re, "Client Hello (SNI=www.example.com), 2 segments", "1.9 KB"), P(Xt, h, "PA", mp)))]
  }, {
    title: "Server Hello",
    desc: "Choices made, keys computed",
    detail: "The server picks TLS 1.3, the cipher suite and the hybrid group, and sends its own key share. From the two shares both sides compute the same secret without it ever crossing the network. Everything after this message is encrypted.",
    facts: [["Cipher", "TLS_AES_128_GCM_SHA256"], ["Group", "X25519MLKEM768"], ["From here on", "Encrypted"]],
    events: [l("web", "client", "teal", "SERVER HELLO", ["TLS 1.3, AES_128_GCM", "its key share"], Zt(Qt(0.052, Re, h, "Server Hello, Change Cipher Spec (+ encrypted)", `${Ss[0] + xo} B`), P(Xt, Re, "A", {
      ...zi,
      take: [0, Ss[0]]
    }))), {
      type: "note",
      at: "client",
      text: "SHARED SECRET COMPUTED",
      tone: "teal"
    }]
  }, {
    title: "Certificate",
    desc: "Who the server is, proven",
    detail: "Now encrypted, the flight continues: the chosen protocol (http/1.1), the certificate chain, a signature made with the certificate’s private key, and Finished.",
    facts: [["Chain", "Site → intermediate → root"], ["Signature", "Proves the private key"], ["Checked", "Name, dates, trusted root"]],
    events: [{
      type: "stream",
      from: "web",
      to: "client",
      color: "teal",
      label: `${Ss.length - 1} SEGMENTS`,
      locked: true,
      payload: ["encrypted: http/1.1, certificates,", "signature, Finished"],
      packets: Ss.slice(1).map((e, t) => l("web", "client", "teal", "ENCRYPTED", [], Zt(Qt(0.052, Re, h, t === Ss.length - 2 ? "Encrypted handshake (certificate, verify, Finished)" : "Encrypted handshake (continued)", `${e + xo} B`), P(Xt, Re, t === Ss.length - 2 ? "PA" : "A", {
        ...zi,
        take: [Fc[t + 1], Fc[t + 1] + e]
      })), Rn))
    }, {
      type: "note",
      at: "client",
      text: "CHAIN LEADS TO A TRUSTED ROOT",
      tone: "green"
    }]
  }, {
    title: "Finished",
    desc: "One round trip, then data",
    detail: "The browser sends its own Finished: a check value over everything both sides said, keyed with the new secret, so any tampering with the hellos would show. TLS 1.3 needs one round trip before data flows; TLS 1.2 needed two.",
    facts: [["Round trips", "1 (TLS 1.2: 2)"], ["Covers", "The whole handshake"], ["Change Cipher Spec", "For old middleboxes"]],
    events: [l("client", "web", "teal", "FINISHED", ["check value over", "the whole handshake"], Zt(Qt(0.07, h, Re, "Change Cipher Spec, Finished (encrypted)", "118 B"), P(Xt, h, "PA", Pl)), Rn)]
  }, {
    title: "Encrypted Data",
    desc: "Records, tags and tickets",
    detail: "HTTP now travels in encrypted records, each with a 16-byte tag that exposes any change. The server also sends two session tickets: next time the browser can resume with one and skip the certificate.",
    facts: [["Per record", `${Yt} bytes of overhead`], ["Tickets", "2, for resuming later"], ["Visible", "IPs, SNI, sizes, timing"]],
    events: [l("client", "web", "amber", "APP DATA", ["inside: GET / HTTP/1.1"], Zt(Qt(0.07, h, Re, "Application Data (HTTP request)", it(ut.REQUEST + xo)), P(Xt, h, "PA", {
      tls: [{
        type: "appdata",
        length: ut.REQUEST - 5,
        inner: {
          what: "The HTTP request",
          text: ut.REQUEST_LINES
        }
      }]
    })), Rn), l("web", "client", "violet", "TICKETS", ["2 session tickets", "for resuming later"], Zt(Qt(0.087, Re, h, "New Session Ticket ×2 (encrypted)", it(ut.TICKETS + xo)), P(Xt, Re, "PA", {
      tls: [ut.TICKET, ut.TICKET]
    })), Rn), l("web", "client", "violet", "APP DATA", ["inside: HTTP/1.1 200 OK", `${ut.SEGMENTS} segments`], Zt(Qt(0.088, Re, h, `Application Data (HTTP response), ${ut.SEGMENTS} segments`, it(ut.RESPONSE_FRAMES, ut.SEGMENTS)), P(Xt, Re, "PA", {
      tls: [{
        type: "appdata",
        length: ut.RESPONSE - 5,
        inner: {
          what: `The HTTP response, then the ${ut.BODY.toLocaleString("en-US")}-byte page`,
          text: ut.RESPONSE_LINES
        }
      }]
    })), Rn)]
  }, {
    title: "Closing",
    desc: "close_notify, then TCP",
    detail: "After 75 idle seconds the server closes the connection. It first sends a close_notify alert, encrypted like everything else, so the browser knows the data ended on purpose and wasn’t cut short by an attacker. Then TCP closes as usual.",
    facts: [["Alert", "close_notify"], ["Why", "Shows nothing was cut off"], ["Then", "TCP FIN from both sides"]],
    events: [l("web", "client", "violet", "CLOSE_NOTIFY", ["alert: close_notify", "encrypted"], Zt(Qt(75.088, Re, h, "Application Data (inside: close_notify alert)", `${Hc + xo} B`), P(Xt, Re, "PA", {
      tls: [{
        type: "appdata",
        length: Hc - 5,
        inner: {
          what: "Alert: close_notify (the data ends here, on purpose)"
        }
      }]
    })), Rn), l("web", "client", "green", "FIN", [], Zt(Qt(75.088, Re, h, "443 → 52411 [FIN, ACK]", "60 B", "TCP"), P(Xt, Re, "FA")), {
      quick: true
    }), l("client", "web", "green", "FIN", [], Zt(Qt(75.105, h, Re, "52411 → 443 [FIN, ACK]", "60 B", "TCP"), P(Xt, h, "FA")), {
      quick: true
    })]
  }]
};
const Rt = "203.0.113.10";
const Xi = q(h, 52360, Rt, 80);
const Uc = ["GET /chat HTTP/1.1", "Host: www.example.com", "Connection: Upgrade", "Pragma: no-cache", "Cache-Control: no-cache", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36", "Upgrade: websocket", "Origin: http://www.example.com", "Sec-WebSocket-Version: 13", "Accept-Encoding: gzip, deflate", "Accept-Language: en-US,en;q=0.9", "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==", "Sec-WebSocket-Extensions: permessage-deflate; client_max_window_bits", ""];
const Kc = ["HTTP/1.1 101 Switching Protocols", "Upgrade: websocket", "Connection: Upgrade", "Sec-WebSocket-Accept: s3pPLMBiTxaQ9kYGzzhZRbK+xOo=", ""];
const Gf = (e, t) => j(2 + (t ? 4 : 0) + e);
const Da = "bob: hi there";
const Nn = (e, t, s, n, o, a, r) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "WebSocket",
  info: n,
  len: `${Gf(o, a)} B`,
  wire: P(Xi, t, "PA", {
    ws: r
  })
});
const Wf = {
  id: "websocket",
  name: "WebSocket",
  title: "Live Updates",
  layer: 7,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.017
  },
  labels: {
    web: ["www.example.com", Rt]
  },
  legend: [["green", "TCP"], ["amber", "From the browser"], ["violet", "From the server"]],
  overview: {
    full: "The WebSocket Protocol",
    description: "A WebSocket keeps one connection open between a web page and a server, so either side can send a message at any moment: chat, live scores, games, shared documents. It starts as an ordinary HTTP request asking to upgrade; after that, messages travel in small frames with a header of just a few bytes.",
    facts: [["Layer", "Application (Layer 7)"], ["Ports", "80 (ws://), 443 (wss://)"], ["Starts as", "An HTTP request (Upgrade)"], ["Then", "Frames both ways, any time"], ["Frame header", "2–14 bytes"], ["Defined In", "RFC 6455"]]
  },
  outro: {
    title: "Connection closed",
    desc: "One request, then messages",
    text: "One HTTP request turned an ordinary TCP connection into a two-way channel. After that every message cost a few bytes of header, and the server could send whenever it had something to say. Press REPLAY to watch it again.",
    facts: [["Handshake", "GET with Upgrade, then 101"], ["Smallest frame", "2 bytes (a ping)"], ["Server push", "Any time, unasked"], ["Real sites", "wss:// (inside TLS)"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "TCP Connection",
    desc: "TCP to the server, as for HTTP",
    detail: "The chat page is already open, loaded from www.example.com. Its script calls new WebSocket(\"ws://www.example.com/chat\"), and the browser starts with an ordinary TCP connection to port 80. (Real sites use wss://, the same thing inside TLS; plain ws:// lets you read every byte.)",
    facts: [["URL", "ws://www.example.com/chat"], ["Port", "80"], ["Transport", "TCP"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      dst: Rt,
      sport: 52360,
      dport: 80,
      t: [0, 0.017, 0.034]
    })]
  }, {
    title: "Ask to Upgrade",
    desc: "An HTTP request with Upgrade: websocket",
    detail: "The browser sends an HTTP GET with Upgrade: websocket and Connection: Upgrade. Sec-WebSocket-Key is 16 random bytes written in base64, which the server has to answer correctly. The browser also offers to compress messages (permessage-deflate).",
    facts: [["Request", "GET /chat"], ["Asks for", "Upgrade: websocket"], ["Key", "16 random bytes, base64"]],
    events: [l("client", "web", "amber", "UPGRADE", ["GET /chat HTTP/1.1", "Upgrade: websocket"], {
      time: x(0.034),
      src: h,
      dst: Rt,
      proto: "HTTP",
      info: "GET /chat HTTP/1.1",
      len: `${j(K(...Uc))} B`,
      wire: P(Xi, h, "PA", {
        text: Uc,
        name: "HTTP"
      })
    })]
  }, {
    title: "Switch Protocols",
    desc: "101: from now on, WebSocket",
    detail: "The server answers 101 Switching Protocols. Its Sec-WebSocket-Accept is the key with a fixed string added, hashed with SHA-1 and written in base64: proof that it understood the request. It didn’t take up compression, so messages go as plain text. HTTP is finished on this connection; from now on both sides send WebSocket frames.",
    facts: [["Status", "101 Switching Protocols"], ["Accept", "SHA-1 of the key + a fixed string"], ["Compression", "Offered, not taken"]],
    events: [l("web", "client", "violet", "101", ["101 Switching Protocols", "Upgrade: websocket"], {
      time: x(0.052),
      src: Rt,
      dst: h,
      proto: "HTTP",
      info: "HTTP/1.1 101 Switching Protocols",
      len: `${j(K(...Kc))} B`,
      wire: P(Xi, Rt, "PA", {
        text: Kc,
        name: "HTTP"
      })
    }), {
      type: "note",
      at: "client",
      text: "NOW A WEBSOCKET",
      tone: "green"
    }]
  }, {
    title: "Live Updates",
    desc: "Small frames, from either side",
    detail: "You send \"Hello\": a 2-byte header, a 4-byte masking key and the 5 masked bytes, 11 bytes in all instead of a whole HTTP request. Seconds later the server pushes Bob’s message without being asked: the connection is still open, so it can. Frames from the browser are always masked; frames from the server never are.",
    facts: [["You send", "\"Hello\" (11 bytes)"], ["Server pushes", `"${Da}"`], ["Masked", "From the browser only"]],
    events: [l("client", "web", "amber", "TEXT", ["\"Hello\"", "masked"], Nn(2.4, h, Rt, "WebSocket Text [FIN] [MASKED]", 5, true, {
      op: 1,
      text: "Hello",
      mask: [55, 250, 33, 61]
    })), l("web", "client", "violet", "TEXT", [`"${Da}"`, "unasked"], Nn(6.81, Rt, h, "WebSocket Text [FIN]", Da.length, false, {
      op: 1,
      text: Da
    }))]
  }, {
    title: "Keeping It Alive",
    desc: "Ping and pong",
    detail: "After half a minute with nothing to say, the server sends a ping, so routers and firewalls on the way don’t forget the quiet connection. The browser answers with a pong on its own; the page’s script never sees either.",
    facts: [["Ping", "Opcode 9, from either side"], ["Pong", "Opcode 10, by itself"], ["How often", "Up to the server (30 s)"]],
    events: [l("web", "client", "violet", "PING", [], Nn(36.81, Rt, h, "WebSocket Ping [FIN]", 0, false, {
      op: 9
    })), l("client", "web", "amber", "PONG", [], Nn(36.827, h, Rt, "WebSocket Pong [FIN] [MASKED]", 0, true, {
      op: 10,
      mask: [92, 30, 144, 114]
    }))]
  }, {
    title: "Closing",
    desc: "A close frame each way",
    detail: "When you leave the chat, the page’s script closes the WebSocket with status 1000 (normal closure): the browser sends a close frame and the server answers with its own. Then the server closes the TCP connection. (Simply closing the tab would send 1001, going away.)",
    facts: [["Opcode", "8 (close)"], ["Status", "1000 (normal closure)"], ["Then", "TCP closes"]],
    events: [l("client", "web", "amber", "CLOSE", ["1000 normal closure"], Nn(40, h, Rt, "WebSocket Connection Close [FIN] [MASKED]", 2, true, {
      op: 8,
      code: 1000,
      mask: [163, 75, 7, 217]
    })), l("web", "client", "violet", "CLOSE", ["1000 normal closure"], Nn(40.018, Rt, h, "WebSocket Connection Close [FIN]", 2, false, {
      op: 8,
      code: 1000
    }))]
  }]
};
const so = "00:00:5e:00:53:10";
const Wo = "00:00:5e:00:53:01";
const Ft = "HomeNet";
const Vf = 279;
const Yf = 134;
const jf = 267;
const Bc = 30;
const zf = 155;
const Qf = 200;
const Oa = e => 133 + e;
const Xf = 328;
const _c = 8 + Xf;
const Op = (e, t, s, n, o, a, r) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: n,
  info: o,
  len: `${a} B`,
  wire: {
    wifi: r
  }
});
const Dn = (e, t, s, n, o) => Op(e, Wo, t, o.kind === "eapol" ? "EAPOL" : "802.11", s, n, {
  from: "ap",
  ...o
});
const On = (e, t, s, n, o) => Op(e, so, t, o.kind === "eapol" ? "EAPOL" : "802.11", s, n, {
  from: "sta",
  ...o
});
const Zf = {
  id: "wifi",
  name: "Wi-Fi",
  title: "Joining a Network",
  layer: 2,
  nodes: ["client", "router"],
  latency: {
    "client-router": 0.001
  },
  labels: {
    client: ["Client", "MAC …:53:10"],
    router: ["Access Point", `"${Ft}"`]
  },
  legend: [["violet", "From the access point"], ["amber", "From the laptop"], ["teal", "4-way handshake"]],
  overview: {
    full: "Wi-Fi (802.11) with WPA2",
    description: "Wi-Fi carries a network over radio. Before a device can send anything, it has to find the network, join it and prove it knows the password. With WPA2-Personal that proof is the 4-way handshake: four short messages that turn the password into fresh encryption keys, without the password ever going over the air.",
    facts: [["Layer", "Data Link (Layer 2)"], ["Standard", "IEEE 802.11"], ["Security", "WPA2: CCMP (AES)"], ["Joining", "Probe, authenticate, associate"], ["Keys from", "The 4-way handshake"], ["Defined In", "IEEE 802.11-2020"]]
  },
  outro: {
    title: "Connected",
    desc: "Eleven frames to a secure link",
    text: "The laptop found the network, joined it with two formalities and proved it knew the password in a four-message handshake, without ever sending it. Everything after that was encrypted with keys made for this connection alone. Press REPLAY to watch it again.",
    facts: [["Frames to join", "11"], ["Password sent", "Never"], ["Session keys", "New every time"], ["Next", "DHCP, for an IP address"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Find the Network",
    desc: "A beacon, then a probe",
    detail: "About ten times a second the router’s Wi-Fi sends a beacon: here is \"HomeNet\", protected with WPA2, on channel 36. The laptop could simply wait to hear one; to be quicker it also asks out loud with a probe request, and the access point answers with a probe response.",
    facts: [["Network", `"${Ft}"`], ["Channel", "36 (5 GHz)"], ["Security", "WPA2-Personal (password)"]],
    events: [{
      type: "show",
      nodes: ["router"],
      frame: "local"
    }, l("router", "client", "violet", "BEACON", [`SSID "${Ft}"`, "WPA2 · channel 36"], Dn(0, "Broadcast", `Beacon, SSID "${Ft}"`, Vf, {
      kind: "beacon",
      seq: 1520,
      ssid: Ft,
      akm: 2,
      ts: 81234567890,
      other: 196
    })), l("client", "router", "amber", "PROBE", ["any networks here?"], On(0.035, "Broadcast", "Probe Request, any SSID", Yf, {
      kind: "probe-req",
      seq: 210,
      other: 98
    })), l("router", "client", "violet", "PROBE RESPONSE", [`SSID "${Ft}"`, "WPA2-Personal"], Dn(0.036, so, `Probe Response, SSID "${Ft}"`, jf, {
      kind: "probe-resp",
      seq: 1521,
      duration: 44,
      ssid: Ft,
      akm: 2,
      ts: 81234603910,
      other: 190
    }))]
  }, {
    title: "Join the Network",
    desc: "Two formalities: hello, then join",
    detail: "Open System authentication lets anyone this far: no password yet. Then the laptop asks to associate, repeating the security it chose (CCMP, with a password), and the access point gives it association ID 1. The laptop is connected, but the only thing it may send is the handshake that comes next.",
    facts: [["Authentication", "Open System (no password)"], ["Association ID", "1"], ["Allowed so far", "The 4-way handshake"]],
    events: [l("client", "router", "amber", "AUTH", ["Open System"], On(0.05, Wo, "Authentication (Open System), 1 of 2", Bc, {
      kind: "auth",
      seq: 211,
      duration: 44,
      alg: 0,
      trans: 1
    }), {
      quick: true
    }), l("router", "client", "violet", "AUTH", ["success"], Dn(0.051, so, "Authentication (Open System), 2 of 2", Bc, {
      kind: "auth",
      seq: 1522,
      duration: 44,
      alg: 0,
      trans: 2
    }), {
      quick: true
    }), l("client", "router", "amber", "ASSOCIATE", [`join "${Ft}"`, "CCMP, password"], On(0.052, Wo, `Association Request, SSID "${Ft}"`, zf, {
      kind: "assoc-req",
      seq: 212,
      duration: 44,
      ssid: Ft,
      akm: 2,
      other: 86
    })), l("router", "client", "violet", "ASSOCIATED", ["association ID 1"], Dn(0.054, so, "Association Response, AID 1", Qf, {
      kind: "assoc-resp",
      seq: 1523,
      duration: 44,
      other: 160
    }))]
  }, {
    title: "Messages 1 and 2",
    desc: "The 4-way handshake: nonces",
    detail: "Both sides already hold the same key, worked out from the password and the network’s name (the PMK); it never goes over the air. The access point sends a random number, the ANonce. The laptop sends its own, the SNonce, with a check value (MIC). From the PMK, the two nonces and both MAC addresses, each side now works out the same session keys.",
    facts: [["Shared key", "PMK, from the password"], ["Exchanged", "Two random nonces"], ["Worked out", "Session keys (PTK)"]],
    events: [l("router", "client", "teal", "MESSAGE 1", ["ANonce"], Dn(0.06, so, "Key (Message 1 of 4)", Oa(0), {
      kind: "eapol",
      seq: 1524,
      duration: 44,
      msg: 1
    })), l("client", "router", "teal", "MESSAGE 2", ["SNonce + MIC"], On(0.063, Wo, "Key (Message 2 of 4)", Oa(22), {
      kind: "eapol",
      seq: 213,
      duration: 44,
      msg: 2
    }))]
  }, {
    title: "Messages 3 and 4",
    desc: "The 4-way handshake: keys",
    detail: "Message 3 shows the access point has the same keys (its MIC checks out) and brings the group key (GTK) for broadcasts, encrypted. Message 4 says the laptop is ready, and both ends start encrypting.",
    facts: [["Group key", "GTK, sent encrypted"], ["Install", "Both ends at once"], ["Cipher", "CCMP (AES-128)"]],
    events: [l("router", "client", "teal", "MESSAGE 3", ["group key, encrypted", "MIC"], Dn(0.065, so, "Key (Message 3 of 4)", Oa(56), {
      kind: "eapol",
      seq: 1525,
      duration: 44,
      msg: 3,
      keyData: 56
    })), l("client", "router", "teal", "MESSAGE 4", ["keys installed"], On(0.066, Wo, "Key (Message 4 of 4)", Oa(0), {
      kind: "eapol",
      seq: 214,
      duration: 44,
      msg: 4
    }))]
  }, {
    title: "Encrypted Now",
    desc: "And what a listener could still do",
    detail: "Every data frame is encrypted now, like this first one carrying a DHCP Discover: anyone nearby sees only the MAC addresses and the size. But someone who recorded the four handshake messages can try password guesses at home, as fast as their computer allows: a guess is right when it gives the same MIC. A long, random password makes that hopeless; WPA3 removes the weakness.",
    facts: [["Others see", "MAC addresses, sizes, timing"], ["Weak point", "Offline password guessing"], ["Defence", "A long password, or WPA3"]],
    events: [l("client", "router", "amber", "DATA", ["DHCP Discover inside"], On(0.08, "Broadcast", "QoS Data (encrypted)", 34 + _c + 8, {
      kind: "data",
      seq: 215,
      duration: 44,
      tid: 0,
      dst: "ff:ff:ff:ff:ff:ff",
      pn: 1,
      sealed: _c,
      inner: ["LLC/SNAP: an IPv4 packet", "DHCP Discover, 0.0.0.0 → 255.255.255.255"]
    }), {
      locked: true
    }), {
      type: "note",
      at: "client",
      text: "ENCRYPTED FROM HERE ON",
      tone: "green"
    }]
  }]
};
const no = "00:00:5e:00:53:10";
const Mp = "00:00:5e:00:53:01";
const Qs = "HomeNet";
const Jf = 279;
const Gc = 128;
const Wc = 64;
const e1 = 155;
const t1 = 200;
const Ma = e => 133 + e;
const qp = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: a.kind === "eapol" ? "EAPOL" : "802.11",
  info: n,
  len: `${o} B`,
  wire: {
    wifi: a
  }
});
const Mn = (e, t, s, n, o) => qp(e, Mp, t, s, n, {
  from: "ap",
  duration: 44,
  ...o
});
const Co = (e, t, s, n) => qp(e, no, Mp, t, s, {
  from: "sta",
  duration: 44,
  ...n
});
const s1 = {
  id: "wpa3",
  name: "WPA3",
  title: "Safer Wi-Fi",
  layer: 2,
  nodes: ["client", "router"],
  latency: {
    "client-router": 0.001
  },
  labels: {
    client: ["Client", "MAC …:53:10"],
    router: ["Access Point", `"${Qs}"`]
  },
  legend: [["violet", "From the access point"], ["amber", "From the laptop"], ["teal", "4-way handshake"]],
  overview: {
    full: "Wi-Fi Protected Access 3",
    description: "WPA3 is the current Wi-Fi security standard. Its Personal mode keeps the simple shared password but changes how it is checked: SAE, a password exchange that no recording can attack offline, gives every connection a fresh key. It also makes protected management frames compulsory.",
    facts: [["Layer", "Data Link (Layer 2)"], ["Password check", "SAE (Dragonfly)"], ["Then", "The 4-way handshake"], ["Required", "Protected management frames"], ["Since", "2018"], ["Defined In", "IEEE 802.11-2020, RFC 7664"]]
  },
  outro: {
    title: "Connected with WPA3",
    desc: "Same password, better protocol",
    text: "The laptop and the access point proved to each other that they know the password without giving anyone a way to test guesses offline, then made fresh keys exactly as WPA2 does. Press REPLAY to watch it again.",
    facts: [["SAE frames", "4 (commit, confirm)"], ["Handshake", "4 EAPOL-Key frames"], ["Offline guessing", "Not possible"], ["Forged disconnects", "Ignored"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "A WPA3 Network",
    desc: "The beacon asks for SAE",
    detail: "The beacon looks like WPA2’s with two changes in its RSN element: the key management is SAE instead of PSK, and protected management frames are required. Everyone still uses one shared password.",
    facts: [["Key management", "SAE"], ["Management frames", "Protected (required)"], ["Password", "Still one for everyone"]],
    events: [{
      type: "show",
      nodes: ["router"],
      frame: "local"
    }, l("router", "client", "violet", "BEACON", [`SSID "${Qs}"`, "WPA3 (SAE)"], Mn(0, "Broadcast", `Beacon, SSID "${Qs}"`, Jf, {
      kind: "beacon",
      duration: 0,
      seq: 2040,
      ssid: Qs,
      akm: 8,
      ts: 92418866310,
      other: 196
    }))]
  }, {
    title: "SAE Commit",
    desc: "Each side commits to the password",
    detail: "Instead of Open System authentication, the two sides run SAE, a password exchange between equals. Each picks a random secret and sends a scalar and an element worked out from that secret and the password. The password is the same on both sides, the secrets are not, so every connection ends up with a new key.",
    facts: [["Group", "19 (256-bit curve)"], ["Each sends", "A scalar and an element"], ["Replaces", "Open System authentication"]],
    events: [l("client", "router", "amber", "COMMIT", ["scalar + element"], Co(0.04, "Authentication (SAE), Commit", Gc, {
      kind: "auth",
      seq: 330,
      alg: 3,
      trans: 1,
      sae: "Commit"
    })), l("router", "client", "violet", "COMMIT", ["scalar + element"], Mn(0.043, no, "Authentication (SAE), Commit", Gc, {
      kind: "auth",
      seq: 2041,
      alg: 3,
      trans: 1,
      sae: "Commit"
    }))]
  }, {
    title: "SAE Confirm",
    desc: "Proof, without the password",
    detail: "Each side now works out the shared key and sends a confirm, a value only someone with the right password could produce. Recording all four SAE frames doesn’t let an attacker test guesses at home: every guess takes a live exchange with the access point, which can slow them down or shut them out.",
    facts: [["Result", "A new key (PMK) each time"], ["Guessing", "Live only, never offline"], ["Password leaks", "Past traffic stays safe"]],
    events: [l("client", "router", "amber", "CONFIRM", ["proof of the key"], Co(0.046, "Authentication (SAE), Confirm", Wc, {
      kind: "auth",
      seq: 331,
      alg: 3,
      trans: 2,
      sae: "Confirm"
    })), l("router", "client", "violet", "CONFIRM", ["proof of the key"], Mn(0.048, no, "Authentication (SAE), Confirm", Wc, {
      kind: "auth",
      seq: 2042,
      alg: 3,
      trans: 2,
      sae: "Confirm"
    }))]
  }, {
    title: "Join, Handshake",
    desc: "Then the 4-way handshake, as in WPA2",
    detail: "Association works as before, repeating the choice of SAE. The 4-way handshake that follows is WPA2’s, starting from the key SAE just made, except that message 3 also brings the IGTK, a key that signs broadcast management frames.",
    facts: [["Association ID", "1"], ["Message 3 adds", "IGTK"], ["Cipher", "CCMP (AES)"]],
    events: [l("client", "router", "amber", "ASSOCIATE", [`join "${Qs}"`, "SAE"], Co(0.05, `Association Request, SSID "${Qs}"`, e1, {
      kind: "assoc-req",
      seq: 332,
      ssid: Qs,
      akm: 8,
      other: 86
    }), {
      quick: true
    }), l("router", "client", "violet", "ASSOCIATED", ["association ID 1"], Mn(0.052, no, "Association Response, AID 1", t1, {
      kind: "assoc-resp",
      seq: 2043,
      other: 160
    }), {
      quick: true
    }), l("router", "client", "teal", "MESSAGE 1", [], Mn(0.055, no, "Key (Message 1 of 4)", Ma(0), {
      kind: "eapol",
      seq: 2044,
      msg: 1,
      sae: true
    }), {
      quick: true
    }), l("client", "router", "teal", "MESSAGE 2", [], Co(0.058, "Key (Message 2 of 4)", Ma(22), {
      kind: "eapol",
      seq: 333,
      msg: 2,
      sae: true
    }), {
      quick: true
    }), l("router", "client", "teal", "MESSAGE 3", [], Mn(0.06, no, "Key (Message 3 of 4)", Ma(88), {
      kind: "eapol",
      seq: 2045,
      msg: 3,
      sae: true,
      keyData: 88
    }), {
      quick: true
    }), l("client", "router", "teal", "MESSAGE 4", [], Co(0.061, "Key (Message 4 of 4)", Ma(0), {
      kind: "eapol",
      seq: 334,
      msg: 4,
      sae: true
    }), {
      quick: true
    })]
  }, {
    title: "Why It’s Safer",
    desc: "Forged disconnects stop working",
    detail: "With WPA2, anyone in range could forge a “disconnect” frame and knock a device off the network, often to record its handshake when it joined again. WPA3 requires protected management frames, so forged disconnects are ignored. Many routers also offer a transition mode that lets WPA2 devices join too; those devices keep WPA2’s weaknesses.",
    facts: [["Protected", "Disconnects, other management"], ["WPA2/3 mode", "WPA2 devices stay at risk"], ["Stronger still", "WPA3-Enterprise (192-bit)"]],
    events: [{
      type: "note",
      at: "client",
      text: "MANAGEMENT FRAMES PROTECTED",
      tone: "green"
    }]
  }]
};
const je = "203.0.113.30";
const Hp = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36";
const Fp = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7";
const qa = ["GET /connecttest.txt HTTP/1.1", "Connection: Close", "User-Agent: Microsoft NCSI", "Host: www.msftconnecttest.com", ""];
const Vc = ["HTTP/1.1 302 Found", "Location: http://192.168.1.1/login", "Content-Length: 0", "Connection: close", ""];
const Yc = ["GET /login HTTP/1.1", "Host: 192.168.1.1", "Connection: keep-alive", "Upgrade-Insecure-Requests: 1", `User-Agent: ${Hp}`, Fp, "Accept-Encoding: gzip, deflate", "Accept-Language: en-US,en;q=0.9", ""];
const Er = 2400;
const Up = ["HTTP/1.1 200 OK", "Content-Type: text/html; charset=utf-8", `Content-Length: ${Er}`, "Connection: keep-alive", ""];
const Ha = K(...Up) + Er;
const Vo = "terms=accepted";
const jc = ["POST /login HTTP/1.1", "Host: 192.168.1.1", "Connection: keep-alive", `Content-Length: ${Vo.length}`, "Content-Type: application/x-www-form-urlencoded", "Origin: http://192.168.1.1", "Referer: http://192.168.1.1/login", `User-Agent: ${Hp}`, Fp, "Accept-Encoding: gzip, deflate", "Accept-Language: en-US,en;q=0.9", ""];
const zc = ["HTTP/1.1 302 Found", "Location: http://www.msftconnecttest.com/redirect", "Content-Length: 0", "Connection: keep-alive", ""];
const Yo = "Microsoft Connect Test";
const Qc = ["HTTP/1.1 200 OK", "Content-Type: text/plain", `Content-Length: ${Yo.length}`, "Connection: close", "Cache-Control: max-age=30, must-revalidate", ""];
const $o = q(h, 52410, je, 80);
const Fa = q(h, 52411, ce, 80);
const Xc = q(h, 52412, je, 80);
const Zc = {
  ttl: 64,
  ttlNote: "Sent with 64 and not lowered at all: it came from the router next door, not from a server 12 routers away."
};
const fi = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "TCP",
  info: n,
  len: `${o} B`,
  wire: a
});
const Kp = {
  id: 32289,
  rd: true,
  q: ["www.msftconnecttest.com", "A"]
};
const n1 = {
  ...Kp,
  response: true,
  ra: true,
  an: [["www.msftconnecttest.com", "A", 46, je]],
  exampleTtl: true
};
const Jc = (e, t, s, n, o) => ({
  time: x(e),
  src: t,
  dst: t === h ? ce : h,
  proto: "DNS",
  info: n,
  len: `${o} B`,
  wire: {
    udp: t === h ? {
      sport: 58133,
      dport: 53,
      data: {
        dns: s
      }
    } : {
      sport: 53,
      dport: 58133,
      data: {
        dns: s
      }
    }
  }
});
const Cs = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "HTTP",
  info: n,
  len: o,
  wire: a
});
const o1 = {
  id: "portal",
  name: "Captive Portal",
  title: "Sign-In",
  layer: 7,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-router": 0.002,
    "client-web": 0.02
  },
  labels: {
    router: ["Hotel Router", "192.168.1.1 · captive portal"],
    web: ["msftconnecttest.com", je]
  },
  legend: [["green", "TCP"], ["amber", "From the laptop"], ["violet", "From the router"], ["blue", "From the test server"]],
  overview: {
    full: "Wi-Fi login pages",
    description: "Hotels, cafés, airports and trains often put a login page in front of their Wi-Fi. Until you accept the terms (or pay), the router lets nothing out to the internet. It catches your device’s first plain HTTP request and answers it with a redirect to its own page; your device notices because a test page it knows comes back wrong.",
    facts: [["Where", "Hotels, cafés, airports"], ["How", "Catches plain HTTP requests"], ["Noticed by", "Your system’s test page"], ["Logging in", "Lets your MAC address through"], ["Newer way", "DHCP option 114 (RFC 8910)"], ["Described In", "RFC 8952"]]
  },
  outro: {
    title: "Online",
    desc: "Noticed, logged in, let through",
    text: "Windows asked a test page for an answer it knows and got a redirect instead, so it knew a portal was in the way and opened the login page. Once the terms were accepted, the router let the laptop through, and the same check came back right. Press REPLAY to watch it again.",
    facts: [["Noticed by", "A plain HTTP test page"], ["Faked by", "The router (TTL 64)"], ["Let through", "The laptop’s MAC address"], ["Open Wi-Fi", "Use HTTPS, or a VPN"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Joined, Offline",
    desc: "An address, but no way out",
    detail: "The laptop has joined the hotel’s Wi-Fi, which has no password, and got an address from the router by DHCP. The router answers the laptop itself and passes on its DNS lookups, but drops anything else bound for the internet until the guest has logged in. (An open network also means anyone nearby can read whatever isn’t protected by HTTPS.)",
    facts: [["Address", "192.168.1.10 (by DHCP)"], ["Wi-Fi password", "None (open network)"], ["Internet", "Blocked until you log in"]],
    events: [{
      type: "show",
      nodes: ["router"],
      frame: "local"
    }, {
      type: "note",
      at: "client",
      text: "CONNECTED, NO INTERNET YET",
      tone: "amber"
    }]
  }, {
    title: "Internet Check",
    desc: "Windows checks a test page",
    detail: "After joining any network, Windows looks up www.msftconnecttest.com (the router passes the lookup on) and asks it for /connecttest.txt over plain HTTP; the right answer is the text \"Microsoft Connect Test\". The router catches the connection and answers the handshake itself, in the test server’s name. The laptop can’t tell yet.",
    facts: [["Test page", "msftconnecttest.com/connecttest.txt"], ["Expected", "\"Microsoft Connect Test\""], ["Answered by", "The router, posing as the server"]],
    events: [l("client", "router", "amber", "DNS QUERY", ["A? www.msftconnecttest.com"], Jc(0, h, Kp, "Standard query A www.msftconnecttest.com", 83), {
      quick: true
    }), l("router", "client", "violet", "DNS REPLY", [`A ${je}`], Jc(0.026, ce, n1, `Standard query response A ${je}`, 99), {
      quick: true
    }), l("client", "router", "green", "SYN", ["to 203.0.113.30:80"], fi(0.03, h, je, "52410 → 80 [SYN] Seq=0", 66, P($o, h, "S")), {
      quick: true
    }), l("router", "client", "green", "SYN-ACK", ["from \"203.0.113.30\""], fi(0.032, je, h, "80 → 52410 [SYN, ACK] Seq=0 Ack=1", 66, {
      ...P($o, je, "SA"),
      ...Zc
    }), {
      quick: true
    }), l("client", "router", "green", "ACK", [], fi(0.034, h, je, "52410 → 80 [ACK] Seq=1 Ack=1", 60, P($o, h, "A")), {
      quick: true
    }), l("client", "router", "amber", "GET", ["/connecttest.txt", "User-Agent: Microsoft NCSI"], Cs(0.034, h, je, "GET /connecttest.txt HTTP/1.1", `${j(K(...qa))} B`, P($o, h, "PA", {
      text: qa,
      name: "HTTP"
    })))]
  }, {
    title: "Redirected",
    desc: "The wrong answer gives it away",
    detail: "Instead of the test text, the \"server\" answers 302 Found, pointing to the router’s login page. Its TTL is 64, not lowered at all, because it came straight from the router. Windows sees the wrong answer, marks the network as needing action and opens the browser, whose first request the router redirects the same way, to its login page. This only works with plain HTTP: the router can’t fake an HTTPS page without a certificate error.",
    facts: [["Answer", "302 → 192.168.1.1/login"], ["Give-away", "TTL 64, from one hop away"], ["Why HTTP", "HTTPS can’t be faked"]],
    events: [l("router", "client", "violet", "302 FOUND", ["Location: 192.168.1.1/login"], Cs(0.037, je, h, "HTTP/1.1 302 Found", `${j(K(...Vc))} B`, {
      ...P($o, je, "PA", {
        text: Vc,
        name: "HTTP"
      }),
      ...Zc
    })), {
      type: "note",
      at: "client",
      text: "ACTION NEEDED",
      tone: "amber"
    }]
  }, {
    title: "The Login Page",
    desc: "Served by the router itself",
    detail: "The browser opens http://192.168.1.1/login, a page the router serves itself: the hotel’s name, the terms of use and an Accept button. This connection really does go to the router.",
    facts: [["Page", "http://192.168.1.1/login"], ["Served by", "The router"], ["Size", `${Er.toLocaleString("en-US")} bytes of HTML`]],
    events: [...he({
      to: "router",
      dst: ce,
      sport: 52411,
      dport: 80,
      t: [1.5, 1.502, 1.504]
    }), l("client", "router", "amber", "GET", ["/login"], Cs(1.504, h, ce, "GET /login HTTP/1.1", `${j(K(...Yc))} B`, P(Fa, h, "PA", {
      text: Yc,
      name: "HTTP"
    }))), l("router", "client", "violet", "200 OK", ["the login page"], Cs(1.507, ce, h, `HTTP/1.1 200 OK (text/html), ${rt(Ha)} segments`, it(Ha + rt(Ha) * (ae + re + ie), rt(Ha)), P(Fa, ce, "PA", {
      http: {
        lines: Up,
        body: Er,
        what: "the login page"
      }
    })))]
  }, {
    title: "Accept the Terms",
    desc: "The router lets the laptop out",
    detail: "Clicking Accept posts a small form back to the router. It adds the laptop’s MAC address to the list of devices allowed out, often for the length of the stay, and redirects the browser on its way.",
    facts: [["Form", Vo], ["Router allows", "The laptop’s MAC address"], ["Then", "302 to where you were going"]],
    events: [l("client", "router", "amber", "POST", ["/login", Vo], Cs(9.2, h, ce, "POST /login HTTP/1.1 (application/x-www-form-urlencoded)", `${j(K(...jc) + Vo.length)} B`, P(Fa, h, "PA", {
      text: jc,
      body: Vo,
      name: "HTTP"
    }))), l("router", "client", "violet", "302 FOUND", ["you’re online"], Cs(9.203, ce, h, "HTTP/1.1 302 Found", `${j(K(...zc))} B`, P(Fa, ce, "PA", {
      text: zc,
      name: "HTTP"
    }))), {
      type: "note",
      at: "router",
      text: "MAC ADDRESS ALLOWED",
      tone: "green"
    }]
  }, {
    title: "Online",
    desc: "The same check, now real",
    detail: "Windows checks again. This time the router lets the connection through to the real test server, twelve routers away (its replies arrive with TTL 52), and the answer is the expected text. The network is marked as connected to the internet.",
    facts: [["Answer", `"${Yo}"`], ["Reply TTL", "52 (64 − 12 routers)"], ["Status", "Connected to the internet"]],
    events: [{
      type: "show",
      nodes: ["internet", "web"],
      frame: "path"
    }, ...he({
      dst: je,
      sport: 52412,
      dport: 80,
      t: [9.3, 9.32, 9.34]
    }), l("client", "web", "amber", "GET", ["/connecttest.txt"], Cs(9.34, h, je, "GET /connecttest.txt HTTP/1.1", `${j(K(...qa))} B`, P(Xc, h, "PA", {
      text: qa,
      name: "HTTP"
    }))), l("web", "client", "blue", "200 OK", [`"${Yo}"`], Cs(9.361, je, h, "HTTP/1.1 200 OK (text/plain)", `${j(K(...Qc) + Yo.length)} B`, P(Xc, je, "PA", {
      text: Qc,
      body: Yo,
      name: "HTTP"
    }))), {
      type: "note",
      at: "client",
      text: "ONLINE",
      tone: "green"
    }]
  }]
};
const Ae = "192.0.2.80";
const ms = "203.0.113.10";
const Dl = "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36";
const Bp = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7";
const _p = "Via: 1.1 proxy.example.net (squid/6.10)";
const ed = ["GET http://www.example.com/ HTTP/1.1", "Host: www.example.com", "Proxy-Connection: keep-alive", "Upgrade-Insecure-Requests: 1", Dl, Bp, "Accept-Encoding: gzip, deflate", "Accept-Language: en-US,en;q=0.9", ""];
const td = ["GET / HTTP/1.1", "Host: www.example.com", "Upgrade-Insecure-Requests: 1", Dl, Bp, "Accept-Encoding: gzip, deflate", "Accept-Language: en-US,en;q=0.9", _p, "X-Forwarded-For: 198.51.100.7", "Connection: keep-alive", ""];
const wo = 12500;
const Gp = ["HTTP/1.1 200 OK", "Date: Sat, 31 Oct 2026 09:41:00 GMT", "Content-Type: text/html; charset=utf-8", `Content-Length: ${wo}`, "Connection: keep-alive", ""];
const Wp = ["HTTP/1.1 200 OK", "Date: Sat, 31 Oct 2026 09:41:00 GMT", "Content-Type: text/html; charset=utf-8", `Content-Length: ${wo}`, "X-Cache: MISS from proxy.example.net", _p, "Connection: keep-alive", ""];
const sd = ["CONNECT www.example.com:443 HTTP/1.1", "Host: www.example.com:443", "Proxy-Connection: keep-alive", Dl, ""];
const nd = ["HTTP/1.1 200 Connection established", ""];
const a1 = W - Mt;
const Vp = (e, t) => {
  const s = Math.ceil(e / (t ? a1 : W));
  return {
    count: s,
    len: it(e + s * (ae + re + ie + (t ? Mt : 0)), s)
  };
};
const mi = Vp(K(...Gp) + wo, true);
const yi = Vp(K(...Wp) + wo, false);
const Lo = q(h, 52370, Ae, 8080);
const od = q(Ae, 40210, ms, 80);
const r1 = q(Ae, 40214, ms, 443);
const $s = (e, t, s, n, o, a, r) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: n,
  info: o,
  len: typeof a == "number" ? `${a} B` : a,
  wire: r
});
const i1 = {
  id: "proxy",
  name: "HTTP Proxy",
  title: "Via a Proxy",
  layer: 7,
  nodes: ["client", "router", "internet", "relay", "web"],
  latency: {
    "client-relay": 0.01,
    "relay-web": 0.008
  },
  labels: {
    relay: ["Proxy", `${Ae}:8080`],
    web: ["www.example.com", ms]
  },
  legend: [["green", "TCP"], ["amber", "Request"], ["violet", "Response"], ["teal", "TLS, through the tunnel"]],
  overview: {
    full: "Forward proxy, and CONNECT for HTTPS",
    description: "A forward proxy fetches web pages on your behalf. Companies and schools use one to filter sites, keep copies of popular pages and log what goes out; the sites you visit see the proxy, not you. Plain HTTP passes through it in the clear. For HTTPS the browser asks the proxy for a tunnel, and the encrypted connection runs through it unread.",
    facts: [["Layer", "Application (Layer 7)"], ["Common ports", "8080, 3128"], ["http:// pages", "Fetched by the proxy"], ["https:// pages", "Tunnelled with CONNECT"], ["Used for", "Filtering, caching, logging"], ["Defined In", "RFC 9110 (CONNECT: §9.3.6)"]]
  },
  outro: {
    title: "Two ways through",
    desc: "Fetched for you, or tunnelled",
    text: "For the plain page, the proxy did the work: it read the request, fetched the page on its own connection and could have kept, changed or refused it. For HTTPS it only opened a tunnel and copied encrypted bytes, knowing nothing but the site’s name. Press REPLAY to watch it again.",
    facts: [["Server sees", "The proxy (192.0.2.80)"], ["Plain HTTP", "The proxy reads it all"], ["HTTPS", "Name and sizes only"], ["DNS for the site", "Done by the proxy"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Proxy Settings",
    desc: "The browser sends everything there",
    detail: "The browser is set to send everything through a proxy at 192.0.2.80, port 8080, as many companies and schools require. You open http://www.example.com. The browser doesn’t look up www.example.com itself: it connects to the proxy and leaves the rest to it.",
    facts: [["Proxy", `${Ae}:8080`], ["DNS for the site", "Left to the proxy"], ["URL", "http://www.example.com/"]],
    events: [{
      type: "type-url",
      text: "www.example.com"
    }, {
      type: "show",
      nodes: ["router"],
      frame: "local"
    }]
  }, {
    title: "To the Proxy",
    desc: "TCP to port 8080",
    detail: "The laptop opens an ordinary TCP connection, not to the website, but to the proxy’s port 8080.",
    facts: [["To", `${Ae}, port 8080`], ["Not to", "www.example.com"], ["Handshake", "SYN → SYN-ACK → ACK"]],
    events: [{
      type: "show",
      nodes: ["internet", "relay"],
      frame: "relay"
    }, ...he({
      to: "relay",
      dst: Ae,
      sport: 52370,
      dport: 8080,
      t: [0, 0.01, 0.02]
    })]
  }, {
    title: "The Whole URL",
    desc: "GET http://www.example.com/",
    detail: "Sent to a proxy, the request line carries the whole address, not just the path: GET http://www.example.com/ HTTP/1.1. That is how the proxy knows where to go. Chrome adds Proxy-Connection: keep-alive, a header only proxies read.",
    facts: [["Request line", "GET http://www.example.com/"], ["To a server", "GET /"], ["Readable by", "The proxy (plain HTTP)"]],
    events: [l("client", "relay", "amber", "GET", ["GET http://www.example.com/", "to the proxy"], $s(0.02, h, Ae, "HTTP", "GET http://www.example.com/ HTTP/1.1", j(K(...ed)), P(Lo, h, "PA", {
      text: ed,
      name: "HTTP"
    })))]
  }, {
    title: "Proxy Fetches It",
    desc: "Its own connection to the server",
    detail: "The proxy looks up www.example.com itself (not shown) and opens its own connection to the server. Its request is the ordinary kind, GET /, with headers of its own: Via names the proxy, and X-Forwarded-For gives the address the request came from (the home router’s public address, since the laptop is behind NAT).",
    facts: [["Connection", "The proxy’s own"], ["Via", "1.1 proxy.example.net"], ["Forwarded for", "198.51.100.7"]],
    events: [{
      type: "show",
      nodes: ["web"],
      frame: "full"
    }, ...he({
      from: "relay",
      src: Ae,
      dst: ms,
      sport: 40210,
      dport: 80,
      t: [0.036, 0.044, 0.052],
      linux: true
    }), l("relay", "web", "amber", "GET", ["GET / HTTP/1.1", "Via, X-Forwarded-For"], $s(0.052, Ae, ms, "HTTP", "GET / HTTP/1.1", j(K(...td) + Mt), P(od, Ae, "PA", {
      text: td,
      name: "HTTP"
    })))]
  }, {
    title: "Page Passed On",
    desc: "The page, passed on",
    detail: "The server answers the proxy, and the proxy passes the page on to the laptop with a Via header of its own. It could keep a copy and give it to the next person who asks without troubling the server (X-Cache: MISS says it had none yet), and it can refuse sites that aren’t allowed.",
    facts: [["Server sees", "The proxy, not the laptop"], ["Cache", "MISS (first request)"], ["Proxy can", "Cache, filter, log, change"]],
    events: [l("web", "relay", "violet", "200 OK", ["HTTP/1.1 200 OK", `${mi.count} segments`], $s(0.061, ms, Ae, "HTTP", `HTTP/1.1 200 OK (text/html), ${mi.count} segments`, mi.len, P(od, ms, "PA", {
      http: {
        lines: Gp,
        body: wo,
        what: "the HTML page"
      }
    }))), l("relay", "client", "violet", "200 OK", ["Via: 1.1 proxy.example.net", `${yi.count} segments`], $s(0.071, Ae, h, "HTTP", `HTTP/1.1 200 OK (text/html), ${yi.count} segments`, yi.len, P(Lo, Ae, "PA", {
      http: {
        lines: Wp,
        body: wo,
        what: "the HTML page"
      }
    })))]
  }, {
    title: "HTTPS: CONNECT",
    desc: "CONNECT www.example.com:443",
    detail: "Now you open https://www.example.com. A proxy can’t fetch an HTTPS page for you without breaking its encryption, so the browser asks for a tunnel instead: CONNECT www.example.com:443. The proxy opens a TCP connection to port 443 and answers 200 Connection established.",
    facts: [["Request", "CONNECT www.example.com:443"], ["Proxy opens", "TCP to port 443"], ["Answer", "200 Connection established"]],
    events: [l("client", "relay", "amber", "CONNECT", ["www.example.com:443"], $s(3, h, Ae, "HTTP", "CONNECT www.example.com:443 HTTP/1.1", j(K(...sd)), P(Lo, h, "PA", {
      text: sd,
      name: "HTTP"
    }))), ...he({
      from: "relay",
      src: Ae,
      dst: ms,
      sport: 40214,
      dport: 443,
      t: [3.011, 3.019, 3.027],
      linux: true
    }), l("relay", "client", "violet", "200", ["Connection established"], $s(3.027, Ae, h, "HTTP", "HTTP/1.1 200 Connection established", j(K(...nd)), P(Lo, Ae, "PA", {
      text: nd,
      name: "HTTP"
    })))]
  }, {
    title: "In the Tunnel",
    desc: "The proxy copies, unread",
    detail: "From now on the proxy copies bytes both ways without reading them. The browser’s TLS Client Hello goes in on the laptop’s connection and comes out, byte for byte the same, on the proxy’s connection to the server. TLS runs from end to end, so the proxy learns the site’s name and the sizes, never the pages. (Some company proxies do open HTTPS, using a certificate authority installed on every company laptop; then they see everything.)",
    facts: [["Proxy sees", "Site name, sizes, timing"], ["Hidden from it", "Pages, passwords, cookies"], ["Encryption", "TLS, laptop to server"]],
    events: [l("client", "relay", "teal", "CLIENT HELLO", ["SNI www.example.com"], $s(3.037, h, Ae, "TLSv1.3", "Client Hello (SNI=www.example.com)", 517 + ae + re + ie, P(Lo, h, "PA", fa("www.example.com")))), l("relay", "web", "teal", "CLIENT HELLO", ["the same bytes"], $s(3.047, Ae, ms, "TLSv1.3", "Client Hello (SNI=www.example.com)", 517 + ae + re + ie + Mt, P(r1, Ae, "PA", fa("www.example.com")))), {
      type: "note",
      at: "relay",
      text: "COPIES BYTES, CAN’T READ THEM",
      tone: "navy"
    }]
  }]
};
const ot = "192.0.2.80";
const jo = "203.0.113.10";
const Ut = "www.example.com";
const Zi = q(h, 52380, ot, 1080);
const ad = q(ot, 40220, jo, 443);
const Ua = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "SOCKS5",
  info: n,
  len: `${j(o)} B`,
  wire: P(Zi, t, "PA", {
    socks: a
  })
});
const Ka = (e, t, s, n, o, a, r) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "TLSv1.3",
  info: n,
  len: o,
  wire: P(a, t, "PA", r)
});
const l1 = {
  id: "socks",
  name: "SOCKS5",
  title: "Any Connection",
  layer: 5,
  nodes: ["client", "router", "internet", "relay", "web"],
  latency: {
    "client-relay": 0.01,
    "relay-web": 0.008
  },
  labels: {
    relay: ["SOCKS Proxy", `${ot}:1080`],
    web: [Ut, jo]
  },
  legend: [["green", "TCP"], ["amber", "From the laptop"], ["violet", "From the proxy"], ["teal", "TLS, through the tunnel"]],
  overview: {
    full: "Socket Secure, version 5",
    description: "SOCKS is a general-purpose proxy. Where an HTTP proxy understands web requests, a SOCKS proxy simply opens a connection on your behalf and copies the bytes, whatever the protocol: web, email, games, SSH. Apps use it to reach a network through one gateway, or to hide their own address; ssh -D and Tor both offer one.",
    facts: [["Layer", "Session (Layer 5)"], ["Port", "1080"], ["Carries", "Any TCP, and UDP"], ["Logins", "None, or user and password"], ["Offered by", "ssh -D, Tor, proxy servers"], ["Defined In", "RFC 1928, RFC 1929"]]
  },
  outro: {
    title: "Tunnel open",
    desc: "A few bytes, then just copying",
    text: "Four tiny messages told the proxy where to connect; after that it only copied bytes. The website saw the proxy’s address, and because the laptop sent a name rather than an address, even the DNS lookup happened at the proxy. Press REPLAY to watch it again.",
    facts: [["Setup", "4 messages, 37 bytes"], ["Server sees", "The proxy (192.0.2.80)"], ["DNS lookup", "At the proxy"], ["Encryption", "Only the TLS inside"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "To the Proxy",
    desc: "TCP to port 1080",
    detail: "An app set to use a SOCKS proxy (a browser, a game launcher, or a tunnel made with ssh -D) opens a TCP connection to it, port 1080. SOCKS doesn’t care what will travel inside: it can carry any TCP connection.",
    facts: [["Proxy", `${ot}:1080`], ["Carries", "Any TCP connection"], ["Wants to reach", `https://${Ut}`]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "relay"],
      frame: "relay"
    }, ...he({
      to: "relay",
      dst: ot,
      sport: 52380,
      dport: 1080,
      t: [0, 0.01, 0.02]
    })]
  }, {
    title: "Greeting",
    desc: "Version 5, and how to log in",
    detail: "The laptop sends three bytes: version 5, one login method offered, and that method, 0: no login. The proxy answers with two: version 5, method 0. Had it chosen method 2, the app would next send a user name and password, in plain text.",
    facts: [["Laptop sends", "05 01 00 (3 bytes)"], ["Proxy answers", "05 00 (2 bytes)"], ["Login", "None needed here"]],
    events: [l("client", "relay", "amber", "GREETING", ["05 01 00", "no login, please"], Ua(0.02, h, ot, "Version 5, 1 method: no login", 3, {
      name: "greeting",
      methods: [0]
    })), l("relay", "client", "violet", "METHOD", ["05 00", "no login needed"], Ua(0.03, ot, h, "Version 5, method chosen: no login", 2, {
      name: "method chosen",
      method: 0
    }))]
  }, {
    title: "Where To?",
    desc: "Connect to www.example.com:443",
    detail: "The laptop asks the proxy to connect to www.example.com, port 443. It gives the name rather than an address, so the proxy does the DNS lookup and the laptop needs none. The proxy opens its own TCP connection to the server, then replies: succeeded, and the address and port it connected from.",
    facts: [["Command", "1 (CONNECT)"], ["Address", `${Ut} (a name)`], ["Reply", "Succeeded, from 192.0.2.80:40220"]],
    events: [l("client", "relay", "amber", "CONNECT", [`${Ut}:443`], Ua(0.04, h, ot, `Connect to ${Ut}:443`, 22, {
      name: "connect request",
      host: Ut,
      port: 443
    })), {
      type: "show",
      nodes: ["web"],
      frame: "full"
    }, ...he({
      from: "relay",
      src: ot,
      dst: jo,
      sport: 40220,
      dport: 443,
      t: [0.055, 0.063, 0.071],
      linux: true
    }), l("relay", "client", "violet", "SUCCEEDED", ["from 192.0.2.80:40220"], Ua(0.071, ot, h, "Succeeded, bound to 192.0.2.80:40220", 10, {
      name: "reply",
      reply: true,
      ip: ot,
      port: 40220
    }))]
  }, {
    title: "In the Tunnel",
    desc: "Copied both ways, unread",
    detail: "Now the proxy just copies. The app starts TLS with the server: its Client Hello goes in on the laptop’s connection and comes out unchanged on the proxy’s, and the server’s answer comes back the same way. The server only ever sees the proxy’s address; the proxy sees only encrypted bytes.",
    facts: [["Server sees", "The proxy’s address"], ["Proxy sees", "Encrypted bytes"], ["Same bytes", "On both connections"]],
    events: [l("client", "relay", "teal", "CLIENT HELLO", [`SNI ${Ut}`], Ka(0.081, h, ot, `Client Hello (SNI=${Ut})`, `${517 + ae + re + ie} B`, Zi, fa(Ut))), l("relay", "web", "teal", "CLIENT HELLO", ["unchanged"], Ka(0.091, ot, jo, `Client Hello (SNI=${Ut})`, `${517 + ae + re + ie + Mt} B`, ad, fa(Ut))), l("web", "relay", "teal", "SERVER HELLO", ["+ encrypted handshake"], Ka(0.1, jo, ot, "Server Hello + encrypted handshake, 2 segments", St(Wi + (ae + re + ie + Mt) * 2), ad, Vi())), l("relay", "client", "teal", "SERVER HELLO", ["unchanged"], Ka(0.108, ot, h, "Server Hello + encrypted handshake, 2 segments", St(Wi + (ae + re + ie) * 2), Zi, Vi()))]
  }]
};
const Hs = "203.0.113.10";
const zo = "10.0.0.10";
const dn = "10.0.0.20";
const Yp = "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36";
const jp = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7";
const rd = ["GET / HTTP/1.1", "Host: www.example.com", "Connection: keep-alive", Yp, jp, "Accept-Encoding: gzip, deflate, br, zstd", "Accept-Language: en-US,en;q=0.9", ""];
const id = ["GET / HTTP/1.1", "Host: www.example.com", "X-Forwarded-For: 198.51.100.7", "X-Forwarded-Proto: https", "Connection: keep-alive", Yp, jp, "Accept-Encoding: gzip, deflate, br, zstd", "Accept-Language: en-US,en;q=0.9", ""];
const ca = 12500;
const Ji = ["HTTP/1.1 200 OK", "Date: Sat, 31 Oct 2026 09:41:00 GMT", "Content-Type: text/html; charset=utf-8", `Content-Length: ${ca}`, "Connection: keep-alive", ""];
const Ol = K(...Ji) + ca;
const el = Ol + Yt;
const Ba = Math.ceil(Ol / (W - Mt));
const _a = Math.ceil(el / W);
const ld = q(h, 52390, Hs, 443);
const cd = q(zo, 45110, dn, 8080);
const Ga = (e, t, s, n, o, a, r) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: n,
  info: o,
  len: a,
  wire: r
});
const c1 = {
  id: "reverse",
  name: "Reverse Proxy",
  title: "Offloading",
  layer: 7,
  nodes: ["client", "router", "internet", "web", "app"],
  latency: {
    "client-web": 0.017,
    "web-app": 0.0005
  },
  labels: {
    web: ["Reverse Proxy", Hs],
    app: ["App Server", `${dn}:8080`]
  },
  legend: [["green", "TCP"], ["teal", "TLS"], ["amber", "Request"], ["violet", "Response"]],
  overview: {
    full: "TLS (SSL) offloading",
    description: "A reverse proxy stands in front of a website’s servers: visitors connect to it, and it passes their requests on to an app server behind it. It can spread the load over many servers, keep copies of pages and turn away attacks. Often it also does the TLS work, decrypting HTTPS at the edge so the servers behind it speak plain HTTP. That is SSL (or TLS) offloading.",
    facts: [["Layer", "Application (Layer 7)"], ["Visitors reach", "The proxy, never the app"], ["TLS ends", "At the proxy (offloading)"], ["Inside", "Plain HTTP (or TLS again)"], ["Adds", "X-Forwarded-For, -Proto"], ["For example", "nginx, HAProxy, cloud LBs"]]
  },
  outro: {
    title: "Served from the edge",
    desc: "Encrypted outside, plain inside",
    text: "The laptop saw one HTTPS website. Behind it, the reverse proxy decrypted the request, asked an app server in plain HTTP over the private network and encrypted the answer for the trip back. Press REPLAY to watch it again.",
    facts: [["TLS", "Laptop ↔ proxy only"], ["Inside", "Plain HTTP"], ["App learns visitor", "From X-Forwarded-For"], ["Certificate kept", "On the proxy"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "The Front Door",
    desc: "The proxy holds the certificate",
    detail: "The laptop opens https://www.example.com. The address DNS gives for the name belongs to the reverse proxy, which holds the site’s certificate and does the TLS handshake. Nothing tells the laptop there is another server behind it.",
    facts: [["Laptop connects to", `${Hs}:443`], ["Certificate", "On the reverse proxy"], ["Also called", "Load balancer, edge"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      dst: Hs,
      sport: 52390,
      dport: 443,
      t: [0, 0.017, 0.034]
    }), ...mo({
      dst: Hs,
      sni: "www.example.com",
      sport: 52390,
      dport: 443,
      t: [0.034, 0.052, 0.069]
    })]
  }, {
    title: "TLS Ends Here",
    desc: "Offloading: the proxy does the TLS work",
    detail: "The request arrives encrypted, and the reverse proxy decrypts it. That is the offloading: the TLS work is done here, once, instead of on every app server. Now the proxy can read the URL, headers and cookies, and pick a server by them.",
    facts: [["TLS ends", "At the reverse proxy"], ["Proxy can read", "URL, headers, cookies"], ["Then picks", "An app server"]],
    events: [l("client", "web", "amber", "APP DATA", ["inside: GET / HTTP/1.1"], Ga(0.069, h, Hs, "TLSv1.3", "Application Data (HTTP request)", `${ae + re + ie + K(...rd) + Yt} B`, P(ld, h, "PA", Mr(rd, "The HTTP request"))), {
      locked: true
    }), {
      type: "note",
      at: "web",
      text: "TLS ENDS HERE",
      tone: "amber"
    }]
  }, {
    title: "In the Clear",
    desc: "Passed on to the app server",
    detail: "The proxy passes the request on over the data centre’s private network, as plain HTTP to port 8080. It adds X-Forwarded-For, the visitor’s address, and X-Forwarded-Proto: https, how the visitor came in; otherwise the app would see only the proxy. Anyone able to watch this private network could read it all.",
    facts: [["To", `${dn}:8080`], ["Encrypted", "No"], ["Adds", "X-Forwarded-For, -Proto"]],
    events: [{
      type: "show",
      nodes: ["app"],
      frame: "backend"
    }, ...he({
      from: "web",
      to: "app",
      src: zo,
      dst: dn,
      sport: 45110,
      dport: 8080,
      t: [0.087, 0.088, 0.089],
      linux: true
    }), l("web", "app", "amber", "GET", ["GET / HTTP/1.1", "X-Forwarded-For: 198.51.100.7"], Ga(0.089, zo, dn, "HTTP", "GET / HTTP/1.1", `${ae + re + ie + Mt + K(...id)} B`, P(cd, zo, "PA", {
      text: id,
      name: "HTTP"
    })))]
  }, {
    title: "The App Answers",
    desc: "In plain HTTP too",
    detail: "The app server builds the page and answers the proxy, in plain HTTP: it never deals with TLS or certificates at all.",
    facts: [["Status", "200 OK"], ["Body", `text/html, ${ca.toLocaleString("en-US")} bytes`], ["Sent as", `${Ba} TCP segments`]],
    events: [l("app", "web", "violet", "200 OK", ["HTTP/1.1 200 OK", "readable inside"], Ga(0.093, dn, zo, "HTTP", `HTTP/1.1 200 OK (text/html), ${Ba} segments`, it(Ol + Ba * (ae + re + ie + Mt), Ba), P(cd, dn, "PA", {
      http: {
        lines: Ji,
        body: ca,
        what: "the HTML page"
      }
    })))]
  }, {
    title: "Encrypted Again",
    desc: "An ordinary HTTPS answer",
    detail: "The reverse proxy encrypts the answer in the TLS session it holds with the laptop and sends it on. From outside, it is an ordinary HTTPS site.",
    facts: [["Laptop sees", "One HTTPS server"], ["App servers", "Never handle TLS"], ["Certificates", "Renewed in one place"]],
    events: [{
      type: "camera",
      frame: "full"
    }, l("web", "client", "violet", "APP DATA", ["inside: HTTP/1.1 200 OK", `${_a} segments`], Ga(0.094, Hs, h, "TLSv1.3", `Application Data (HTTP response), ${_a} segments`, it(el + _a * (ae + re + ie), _a), P(ld, Hs, "PA", {
      tls: [{
        type: "appdata",
        length: el - 5,
        inner: {
          what: `The HTTP response, then the ${ca.toLocaleString("en-US")}-byte page`,
          text: Ji
        }
      }]
    })), {
      locked: true
    })]
  }, {
    title: "Three Options",
    desc: "Offload, re-encrypt or pass through",
    detail: "Offloading, as here, is simple and fast but leaves the inside traffic readable. Re-encrypting opens a second TLS connection from the proxy to the app server, so it stays encrypted inside too. Passing through forwards the TLS bytes without opening them: the certificate lives on the app servers, and the proxy can only choose a server by address and the name in the Client Hello, not by URL.",
    facts: [["Offload", "Plain HTTP inside"], ["Re-encrypt", "TLS inside as well"], ["Pass through", "Proxy can’t read it"]],
    events: [{
      type: "note",
      at: "app",
      text: "PLAIN HTTP INSIDE",
      tone: "amber"
    }]
  }]
};
const Ve = "192.0.2.51";
const Qo = "203.0.113.10";
const dd = 54016;
const wi = 2637977825;
const gi = 1328184339;
const qn = e => Math.ceil(e / 16) * 16 + 16;
const Wa = 52;
const Va = 52;
const Io = (e, t) => ({
  udp: e === h ? {
    sport: dd,
    dport: 51820,
    data: {
      wg: t
    }
  } : {
    sport: 51820,
    dport: dd,
    data: {
      wg: t
    }
  }
});
const Ro = e => 42 + e;
const No = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "WireGuard",
  info: n,
  len: `${o} B`,
  wire: a
});
const hd = q(Ve, 52344, Qo, 443);
const d1 = {
  id: "wireguard",
  name: "WireGuard",
  title: "A Modern VPN",
  layer: 3,
  nodes: ["client", "router", "internet", "relay", "web"],
  latency: {
    "client-relay": 0.015,
    "relay-web": 0.01
  },
  labels: {
    relay: ["VPN Server", Ve],
    web: ["www.example.com", Qo]
  },
  legend: [["teal", "WireGuard (encrypted)"], ["green", "TCP beyond the VPN"], ["slate", "Keepalive"]],
  overview: {
    full: "A modern VPN",
    description: "A VPN carries your traffic inside an encrypted tunnel to a VPN server, which sends it on to the internet. On a café’s Wi-Fi, others see only encrypted packets going to the VPN server; websites see the VPN server’s address instead of yours. WireGuard is a modern VPN: a small amount of code, one fixed set of modern algorithms and a handshake of two messages.",
    facts: [["Layer", "Network (Layer 3)"], ["Transport", "UDP (51820 by default)"], ["Handshake", "2 messages, 1 round trip"], ["Crypto", "Curve25519, ChaCha20-Poly1305"], ["Identity", "Public keys, like SSH"], ["Defined In", "The WireGuard whitepaper"]]
  },
  outro: {
    title: "Tunnel up",
    desc: "Encrypted to the VPN, plain beyond it",
    text: "Two handshake messages made the keys. After that every packet the laptop sent was sealed whole inside a UDP packet to the VPN server, and the website saw only the VPN server’s address. Beyond the VPN server traffic is no better protected than without one, so HTTPS still matters. Press REPLAY to watch it again.",
    facts: [["Others nearby see", `UDP to ${Ve}`], ["Websites see", "The VPN server"], ["Beyond the VPN", "Only HTTPS protects"], ["Overhead", "60 bytes + padding"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Set Up Once",
    desc: "Keys, not passwords",
    detail: "The laptop runs the WireGuard app with a short configuration: its own private key, the server’s public key and address (192.0.2.51, UDP port 51820), and AllowedIPs = 0.0.0.0/0, which means everything goes through the tunnel. Inside the tunnel the laptop’s address is 10.8.0.2.",
    facts: [["Server", `${Ve}:51820`], ["Inside address", "10.8.0.2"], ["Through the tunnel", "Everything (0.0.0.0/0)"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "relay"],
      frame: "relay"
    }, {
      type: "note",
      at: "client",
      text: "TUNNEL ADDRESS 10.8.0.2",
      tone: "navy"
    }]
  }, {
    title: "Handshake",
    desc: "Two messages, one round trip",
    detail: "When the laptop first has something to send, it starts a handshake: 148 bytes with a fresh public key, its own long-term key (encrypted, so only the server learns who is calling) and the time (encrypted, so a recording can’t be replayed). The server answers only keys it knows, here with 92 bytes. One round trip, and both sides have new session keys.",
    facts: [["Initiation", "148 bytes"], ["Response", "92 bytes"], ["Server answers", "Only keys it knows"]],
    events: [l("client", "relay", "teal", "INITIATION", ["148 bytes", "fresh key + identity"], No(0, h, Ve, "Handshake Initiation, sender=0x9d3c58e1", Ro(148), Io(h, {
      type: 1,
      sender: wi
    }))), l("relay", "client", "teal", "RESPONSE", ["92 bytes", "keys agreed"], No(0.016, Ve, h, "Handshake Response, sender=0x4f2a7c13, receiver=0x9d3c58e1", Ro(92), Io(Ve, {
      type: 2,
      sender: gi,
      receiver: wi
    })))]
  }, {
    title: "Into the Tunnel",
    desc: "A packet inside a packet",
    detail: "You open https://www.example.com; its address was looked up through the tunnel too (not shown). The first packet of the connection, a TCP SYN from 10.8.0.2 to the web server, is encrypted whole and sent inside a UDP packet to the VPN server. On the café’s Wi-Fi only the outer packet shows: from the laptop to 192.0.2.51, port 51820.",
    facts: [["Inside", "10.8.0.2 → 203.0.113.10:443"], ["Outside", `UDP to ${Ve}:51820`], ["Overhead", "60 bytes + padding"]],
    events: [l("client", "relay", "teal", "DATA", ["inside: TCP SYN to :443"], No(0.031, h, Ve, "Transport Data, receiver=0x4f2a7c13, counter=0", Ro(16 + qn(Wa)), Io(h, {
      type: 4,
      receiver: gi,
      counter: 0,
      sealed: qn(Wa),
      inner: ["IPv4 10.8.0.2 → 203.0.113.10", "TCP 52344 → 443 [SYN]", `then ${qn(Wa) - 16 - Wa} bytes of padding, and the tag`]
    })), {
      locked: true
    })]
  }, {
    title: "Out to the Web",
    desc: "Decrypted, then sent on",
    detail: "The VPN server decrypts the packet, swaps 10.8.0.2 for its own public address (NAT) and sends the SYN on, one hop older (TTL 127). The SYN offers a maximum segment of 1380 bytes, not 1460: the tunnel adds 60 bytes to every packet. The web server sees a visitor at 192.0.2.51 and answers there.",
    facts: [["Website sees", `${Ve} (the VPN)`], ["Your address", "Hidden from the site"], ["TTL", "127 (one hop, the VPN)"]],
    events: [{
      type: "show",
      nodes: ["web"],
      frame: "full"
    }, l("relay", "web", "green", "SYN", ["from 192.0.2.51"], {
      time: x(0.046),
      src: Ve,
      dst: Qo,
      proto: "TCP",
      info: "52344 → 443 [SYN] Seq=0",
      len: "66 B",
      wire: {
        ...P(hd, Ve, "S", undefined, {
          mss: 1380
        }),
        alias: [`${Ve}:52344`, "10.8.0.2:52344"],
        ttl: 127,
        ttlNote: "The laptop sent it with 128; the VPN server took 1 when it passed it on."
      }
    }), l("web", "relay", "green", "SYN-ACK", ["to 192.0.2.51"], {
      time: x(0.056),
      src: Qo,
      dst: Ve,
      proto: "TCP",
      info: "443 → 52344 [SYN, ACK] Seq=0 Ack=1",
      len: "66 B",
      wire: P(hd, Qo, "SA")
    })]
  }, {
    title: "The Way Back",
    desc: "Sealed again, for the laptop",
    detail: "The answer goes back the same way. The VPN server seals the SYN-ACK in a WireGuard packet for the laptop, which opens it and hands it to Windows as if it had come straight from the web server.",
    facts: [["Inside", "203.0.113.10 → 10.8.0.2"], ["Counter", "Each side counts its own"], ["Replays", "Thrown away"]],
    events: [l("relay", "client", "teal", "DATA", ["inside: TCP SYN-ACK"], No(0.066, Ve, h, "Transport Data, receiver=0x9d3c58e1, counter=0", Ro(16 + qn(Va)), Io(Ve, {
      type: 4,
      receiver: wi,
      counter: 0,
      sealed: qn(Va),
      inner: ["IPv4 203.0.113.10 → 10.8.0.2", "TCP 443 → 52344 [SYN, ACK]", `then ${qn(Va) - 16 - Va} bytes of padding, and the tag`]
    })), {
      locked: true
    })]
  }, {
    title: "Keeping It Open",
    desc: "A keepalive, and new keys",
    detail: "With nothing to send, a WireGuard tunnel goes quiet. Because the laptop is behind NAT, it is set to send an empty packet every 25 seconds (PersistentKeepalive), a keepalive of 32 bytes, so the router doesn’t forget the connection. Every two minutes a new handshake makes fresh keys, and if the laptop moves to another network, the tunnel simply carries on from its new address.",
    facts: [["Keepalive", "Every 25 s, 32 bytes"], ["New keys", "Every 2 minutes"], ["New network", "The tunnel carries on"]],
    events: [{
      type: "camera",
      frame: "relay"
    }, l("client", "relay", "slate", "KEEPALIVE", ["empty, 32 bytes"], No(25.031, h, Ve, "Keepalive, receiver=0x4f2a7c13, counter=1", Ro(32), Io(h, {
      type: 4,
      receiver: gi,
      counter: 1,
      sealed: 16
    })))]
  }]
};
const st = "192.0.2.51";
const Xo = "203.0.113.10";
const Ya = 9167668316052413000;
const Si = 3201509163735963600;
const pd = 3315722194;
const ud = 2336188945;
const fd = 200;
const md = 1184;
const yd = 1136;
const tl = e => Math.ceil((e + 2) / 4) * 4;
const wd = e => 16 + tl(e) + 16;
const gd = 52;
const Sd = 52;
const Hn = (e, t, s, n, o = {}) => ({
  udp: e === h ? {
    sport: t,
    dport: s,
    data: n,
    ...o
  } : {
    sport: s,
    dport: t,
    data: n,
    ...o
  }
});
const Fn = e => 42 + e;
const Un = (e, t, s, n, o, a, r) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: n,
  info: o,
  len: `${a} B`,
  wire: r
});
const Td = q(st, 52344, Xo, 443);
const h1 = {
  id: "ipsec",
  name: "IPsec",
  title: "IKEv2 and ESP",
  layer: 3,
  nodes: ["client", "router", "internet", "relay", "web"],
  latency: {
    "client-relay": 0.015,
    "relay-web": 0.01
  },
  labels: {
    relay: ["VPN Gateway", st],
    web: ["www.example.com", Xo]
  },
  legend: [["amber", "IKE"], ["teal", "ESP (encrypted)"], ["green", "TCP beyond the gateway"]],
  overview: {
    full: "IP Security",
    description: "IPsec protects IP packets themselves. IKEv2 sets things up: the two sides agree on algorithms, make keys and prove who they are with certificates or other credentials. Then ESP carries each packet encrypted inside another. IPsec links offices together and brings laptops into company networks, and it is built into most operating systems and firewalls.",
    facts: [["Layer", "Network (Layer 3)"], ["Setup", "IKEv2, UDP 500"], ["Behind NAT", "UDP 4500"], ["Data", "ESP (IP protocol 50)"], ["Identity", "Certificates, EAP, keys"], ["Defined In", "RFC 7296, RFC 4303"]]
  },
  outro: {
    title: "Tunnel up",
    desc: "IKE to set up, ESP to carry",
    text: "Four IKE messages agreed on algorithms, found the NAT, proved both identities and set up the tunnel. After that each packet travelled whole inside ESP, encrypted and checked, and wrapped in UDP to get through the home router. Press REPLAY to watch it again.",
    facts: [["IKE messages", "4 (2 exchanges)"], ["NAT traversal", "UDP 4500"], ["ESP", "One SPI each way"], ["Inside address", "10.8.0.2"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "IKE_SA_INIT",
    desc: "Agree on algorithms, swap keys",
    detail: "The VPN client opens with IKE on UDP port 500. Its first message proposes the algorithms (AES-GCM with 256-bit keys, SHA-256, Curve25519) and carries a public key and a random nonce; the gateway picks the proposal and sends its own key and nonce. Both now share a secret, but neither has proved who it is yet.",
    facts: [["Port", "UDP 500"], ["Proposed", "AES-GCM-256, Curve25519"], ["After this", "Shared keys, no identities"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "relay"],
      frame: "relay"
    }, l("client", "relay", "amber", "IKE_SA_INIT", ["proposal, key, nonce", "NAT detection"], Un(0, h, st, "ISAKMP", "IKE_SA_INIT MID=00 Initiator Request", Fn(fd), Hn(h, 500, 500, {
      ike: {
        exchange: 34,
        spiI: Ya
      }
    }))), l("relay", "client", "amber", "IKE_SA_INIT", ["chosen proposal, key, nonce"], Un(0.017, st, h, "ISAKMP", "IKE_SA_INIT MID=00 Responder Response", Fn(fd), Hn(h, 500, 500, {
      ike: {
        exchange: 34,
        response: true,
        spiI: Ya,
        spiR: Si
      }
    })))]
  }, {
    title: "A NAT in the Way",
    desc: "So everything moves to port 4500",
    detail: "Both messages also carried hashes of the address and port each side sent from. At the gateway they don’t match what arrived: the home router rewrote the laptop’s address on the way (NAT). ESP has no port numbers, so a NAT can’t pass it; both sides move to UDP port 4500 and wrap ESP in UDP from now on.",
    facts: [["Hashes of", "Address and port sent from"], ["Mismatch", "The router rewrote them"], ["Fix", "Everything over UDP 4500"]],
    events: [{
      type: "note",
      at: "router",
      text: "NAT DETECTED",
      tone: "amber"
    }]
  }, {
    title: "IKE_AUTH",
    desc: "Prove who you are, encrypted",
    detail: "Now encrypted, each side sends its identity, its certificate and a signature over everything said so far, so anyone in the middle would be caught. The laptop asks for an address inside the network and gets 10.8.0.2. The same exchange sets up the ESP tunnel itself, with its own keys and an SPI for each direction.",
    facts: [["Port", "UDP 4500 (NAT traversal)"], ["Proves", "Identity, by certificate"], ["Laptop gets", "10.8.0.2, and a DNS server"]],
    events: [l("client", "relay", "amber", "IKE_AUTH", ["identity, certificate", "signature"], Un(0.034, h, st, "ISAKMP", "IKE_AUTH MID=01 Initiator Request", Fn(4 + md), Hn(h, 4500, 4500, {
      ike: {
        exchange: 35,
        nonEsp: true,
        spiI: Ya,
        spiR: Si,
        first: 35,
        sealed: md - 56,
        inner: ["IDi, CERT, AUTH: who the laptop is, proven", "CP: asks for an inside address and DNS", "SA: what to use for ESP (AES-GCM)", "TSi, TSr: which traffic goes in the tunnel"]
      }
    })), {
      locked: true
    }), l("relay", "client", "amber", "IKE_AUTH", ["identity, certificate", "address 10.8.0.2"], Un(0.052, st, h, "ISAKMP", "IKE_AUTH MID=01 Responder Response", Fn(4 + yd), Hn(h, 4500, 4500, {
      ike: {
        exchange: 35,
        nonEsp: true,
        response: true,
        spiI: Ya,
        spiR: Si,
        first: 36,
        sealed: yd - 56,
        inner: ["IDr, CERT, AUTH: who the gateway is, proven", "CP: inside address 10.8.0.2, DNS 10.8.0.1", "SA: ESP with AES-GCM, and the SPIs", "TSi, TSr: everything (0.0.0.0/0)"]
      }
    })), {
      locked: true
    })]
  }, {
    title: "Into the Tunnel",
    desc: "The whole packet, encrypted",
    detail: "You open https://www.example.com, looked up through the tunnel at the DNS server the gateway gave (not shown). The SYN from 10.8.0.2 is encrypted whole into an ESP packet: an SPI that names the tunnel, a sequence number, then the encrypted packet and a check value, all inside UDP port 4500. Its UDP checksum is zero: ESP checks its own contents.",
    facts: [["SPI", "Names the tunnel"], ["Inside", "The whole IP packet"], ["Overhead", "62 bytes + padding"]],
    events: [l("client", "relay", "teal", "ESP", ["inside: TCP SYN to :443"], Un(0.07, h, st, "ESP", `ESP (SPI=0x${pd.toString(16)})`, Fn(wd(gd)), Hn(h, 4500, 4500, {
      esp: {
        spi: pd,
        seq: 1,
        sealed: tl(gd),
        inner: ["IPv4 10.8.0.2 → 203.0.113.10", "TCP 52344 → 443 [SYN]", "then padding, pad length and next header (4)"]
      }
    }, {
      noChecksum: true
    })), {
      locked: true
    })]
  }, {
    title: "Out and Back",
    desc: "Through the gateway and home again",
    detail: "The gateway decrypts the packet and sends the SYN on from its own address, one hop older. The answer comes back to the gateway and returns through the tunnel as another ESP packet, with the SPI for the laptop’s direction and its own sequence numbers.",
    facts: [["Website sees", `${st} (the gateway)`], ["Each direction", "Its own SPI and keys"], ["Replays", "Thrown away"]],
    events: [{
      type: "show",
      nodes: ["web"],
      frame: "full"
    }, l("relay", "web", "green", "SYN", [`from ${st}`], {
      time: x(0.085),
      src: st,
      dst: Xo,
      proto: "TCP",
      info: "52344 → 443 [SYN] Seq=0",
      len: "66 B",
      wire: {
        ...P(Td, st, "S", undefined, {
          mss: 1360
        }),
        alias: [`${st}:52344`, "10.8.0.2:52344"],
        ttl: 127,
        ttlNote: "The laptop sent it with 128; the gateway took 1 when it passed it on."
      }
    }), l("web", "relay", "green", "SYN-ACK", [`to ${st}`], {
      time: x(0.095),
      src: Xo,
      dst: st,
      proto: "TCP",
      info: "443 → 52344 [SYN, ACK] Seq=0 Ack=1",
      len: "66 B",
      wire: P(Td, Xo, "SA")
    }), l("relay", "client", "teal", "ESP", ["inside: TCP SYN-ACK"], Un(0.105, st, h, "ESP", `ESP (SPI=0x${ud.toString(16)})`, Fn(wd(Sd)), Hn(h, 4500, 4500, {
      esp: {
        spi: ud,
        seq: 1,
        sealed: tl(Sd),
        inner: ["IPv4 203.0.113.10 → 10.8.0.2", "TCP 443 → 52344 [SYN, ACK]", "then padding, pad length and next header (4)"]
      }
    }, {
      noChecksum: true
    })), {
      locked: true
    })]
  }, {
    title: "Which VPN?",
    desc: "IPsec or WireGuard",
    detail: "IPsec is older and very flexible: it negotiates its algorithms, takes many kinds of credentials and is built into Windows, macOS, iOS, Android and most firewalls, which makes it the usual way to join a company network or link two offices. WireGuard does less, with far less code and one fixed set of algorithms.",
    facts: [["Built into", "Windows, macOS, iOS, Android"], ["Also links", "Office to office"], ["Negotiates", "Its algorithms (WireGuard: no)"]],
    events: [{
      type: "camera",
      frame: "relay"
    }]
  }]
};
const sl = "203.0.113.10";
const zp = [91, 158, 65, 7, 194, 56, 175, 22];
const Qp = [138, 47, 96, 212, 19, 126, 149, 177];
const Xp = [62, 199, 82, 9, 248, 106, 33, 212];
const p1 = {
  initial: 27,
  handshake: 26
};
const u1 = 10;
const f1 = e => e.reduce((t, s) => t + (s.type === "1rtt" ? u1 : p1[s.type]) + s.sealed, 0);
const m1 = e => 42 + f1(e);
const Ls = (e, t, s, n) => {
  const o = t === "client" ? h : sl;
  return {
    time: x(e),
    src: o,
    dst: t === "client" ? sl : h,
    proto: "QUIC",
    info: s,
    len: `${m1(n)} B`,
    wire: {
      udp: t === "client" ? {
        sport: 59214,
        dport: 443,
        data: {
          quic: {
            packets: n
          }
        }
      } : {
        sport: 443,
        dport: 59214,
        data: {
          quic: {
            packets: n
          }
        }
      }
    }
  };
};
const go = (e, t, s, n, o = Xp) => ({
  type: e,
  pn: t,
  sealed: s,
  inner: n,
  dcid: o,
  scid: Qp
});
const da = (e, t, s, n) => ({
  type: e,
  pn: t,
  sealed: s,
  inner: n,
  dcid: Qp,
  scid: Xp
});
const y1 = [go("initial", 0, 1223, ["CRYPTO: Client Hello, bytes 1–1,203 of 1,880", "SNI www.example.com, ALPN h3, X25519MLKEM768 key share"], zp)];
const w1 = [go("initial", 1, 1223, ["CRYPTO: Client Hello, bytes 1,204–1,880", "PADDING, up to 1,250 bytes"], zp)];
const g1 = [da("initial", 0, 1235, ["ACK: packets 0–1 arrived", "CRYPTO: Server Hello, with its half of the key (1,120 bytes)"])];
const S1 = [[da("handshake", 0, 1324, ["CRYPTO: Encrypted Extensions, Certificate (start)"])], [da("handshake", 1, 1324, ["CRYPTO: Certificate (continued)"])], [da("handshake", 2, 204, ["CRYPTO: Certificate Verify, Finished"])]];
const T1 = [go("initial", 2, 1138, ["ACK: the server’s Initial arrived", "PADDING, up to 1,250 bytes"]), go("handshake", 0, 59, ["ACK: the Handshake packets arrived", "CRYPTO: Finished"])];
const b1 = [go("1rtt", 0, 340, ["STREAM 2: SETTINGS (the control stream)", "STREAM 0: HEADERS, GET / (QPACK-compressed)"])];
const v1 = [da("1rtt", 0, 1205, ["HANDSHAKE_DONE: the handshake is over", "STREAM 3: SETTINGS", "STREAM 0: HEADERS 200, then DATA: the page (1,000 bytes)"])];
const k1 = [go("1rtt", 1, 21, ["ACK: the response arrived"])];
const P1 = {
  id: "quic",
  name: "QUIC",
  title: "HTTP/3 over UDP",
  layer: 4,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.017
  },
  labels: {
    web: ["www.example.com", sl]
  },
  legend: [["teal", "Handshake"], ["amber", "Request"], ["violet", "Response"]],
  overview: {
    full: "HTTP/3 over QUIC",
    description: "QUIC is a newer transport that runs over UDP and has TLS 1.3 built in. Its first packets do the transport and the encryption handshakes together, so a page request can leave after one round trip. It carries many streams at once, so one lost packet doesn’t hold up the rest, and it survives a change of network. HTTP/3 is HTTP running over QUIC.",
    facts: [["Layer", "Transport (Layer 4)"], ["Runs over", "UDP, port 443"], ["Encryption", "TLS 1.3, always"], ["Handshake", "1 round trip (0 when returning)"], ["Streams", "Many, independent"], ["Defined In", "RFC 9000, RFC 9114"]]
  },
  outro: {
    title: "Page delivered",
    desc: "One round trip, then the request",
    text: "QUIC folded the transport and TLS handshakes into one round trip, so the request left 36 ms after the first packet; over TCP and TLS it would have waited twice as long. Everything after the first packets was encrypted, even most of each packet’s header. Press REPLAY to watch it again.",
    facts: [["Round trips", "1 before the request (TCP + TLS: 2)"], ["Datagrams", "10"], ["Transport", "UDP, port 443"], ["Lost packet", "Holds up one stream only"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Choosing HTTP/3",
    desc: "An earlier visit said it can",
    detail: "On an earlier visit the server answered with Alt-Svc: h3=\":443\", meaning it also speaks HTTP/3 on UDP port 443 (DNS can say the same in an HTTPS record). So this time the browser skips TCP and talks QUIC.",
    facts: [["Learned from", "Alt-Svc header, or DNS"], ["Transport", "QUIC over UDP 443"], ["Encryption", "TLS 1.3, built in"]],
    events: [{
      type: "type-url",
      text: "www.example.com",
      secure: true
    }, {
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }]
  }, {
    title: "Initial Packets",
    desc: "The Client Hello, straight away",
    detail: "There is no separate TCP handshake: the very first packets carry the TLS Client Hello. With its post-quantum key share it is 1,880 bytes, too big for one packet, so it fills two Initial packets. Each datagram is padded to at least 1,200 bytes; a server may send back only three times what it has received, so a forged sender address can’t turn it into an amplifier.",
    facts: [["Datagrams", "2 × 1,250 bytes"], ["Carries", "The TLS Client Hello"], ["Readable?", "Yes (Initial keys are public)"]],
    events: [l("client", "web", "teal", "INITIAL 1", ["Client Hello, part 1"], Ls(0, "client", "Initial, CRYPTO (Client Hello, part 1)", y1)), l("client", "web", "teal", "INITIAL 2", ["Client Hello, part 2", "padding"], Ls(0, "client", "Initial, CRYPTO (Client Hello, part 2), PADDING", w1), {
      quick: true
    })]
  }, {
    title: "Server Hello",
    desc: "Then the certificate, encrypted",
    detail: "The server answers with its Server Hello in an Initial packet. Both sides can now work out handshake keys, so the rest (the certificate, its signature and Finished) comes in Handshake packets that only the laptop can read. Four datagrams, well under three times what the laptop sent.",
    facts: [["Initial", "Server Hello"], ["Handshake", "Certificate, signature, Finished"], ["Server limit", "3× the bytes received"]],
    events: [l("web", "client", "teal", "INITIAL", ["Server Hello"], Ls(0.018, "server", "Initial, ACK, CRYPTO (Server Hello)", g1)), {
      type: "stream",
      from: "web",
      to: "client",
      color: "teal",
      label: "3 HANDSHAKE",
      locked: true,
      payload: ["certificate, Finished", "encrypted"],
      packets: S1.map((e, t) => l("web", "client", "teal", `HANDSHAKE ${t + 1}`, [], Ls(0.018, "server", `Handshake, CRYPTO (${["Certificate, part 1", "Certificate, part 2", "Certificate Verify, Finished"][t]})`, e)))
    }]
  }, {
    title: "Finished + GET",
    desc: "The request, one round trip in",
    detail: "The laptop checks the certificate and sends its Finished, and in the same moment its first HTTP/3 request in a 1-RTT packet: a HEADERS frame on stream 0, its headers compressed with QPACK. One round trip after the first packet, the request is on its way; TCP and TLS together would need two.",
    facts: [["Round trips", "1 (TCP + TLS: 2)"], ["Request", "HEADERS on stream 0"], ["Headers", "Compressed (QPACK)"]],
    events: [l("client", "web", "teal", "FINISHED", ["Initial + Handshake"], Ls(0.036, "client", "Initial, ACK, PADDING; Handshake, ACK, CRYPTO (Finished)", T1), {
      quick: true,
      locked: true
    }), l("client", "web", "amber", "GET /", ["HTTP/3, stream 0"], Ls(0.036, "client", "1-RTT, HTTP/3 HEADERS (GET /)", b1), {
      locked: true
    })]
  }, {
    title: "The Response",
    desc: "On its own stream",
    detail: "The server confirms the handshake is over (HANDSHAKE_DONE) and answers on stream 0: headers, then the page. Every request gets its own stream, so a lost packet holds up only the stream it belonged to. Over TCP one missing segment stalls everything behind it.",
    facts: [["HTTP/3", "Frames on QUIC streams"], ["Lost packet", "Holds up one stream"], ["Encrypted", "All but a few header bits"]],
    events: [l("web", "client", "violet", "200", ["HTTP/3, stream 0", "the page"], Ls(0.054, "server", "1-RTT, HANDSHAKE_DONE, HTTP/3 HEADERS (200), DATA", v1), {
      locked: true
    }), l("client", "web", "amber", "ACK", [], Ls(0.071, "client", "1-RTT, ACK", k1), {
      quick: true,
      locked: true
    }), {
      type: "render"
    }]
  }, {
    title: "New Network",
    desc: "Known by ID, not by address",
    detail: "A QUIC connection is known by its connection IDs, not by addresses and ports. If the laptop moves from Wi-Fi to a phone’s hotspot, its address changes but the connection carries on: the server checks the new path and continues. And on the next visit the browser can send its request in its very first packets (0-RTT).",
    facts: [["Known by", "Connection ID"], ["New address", "The connection carries on"], ["Next visit", "0-RTT: request at once"]],
    events: [{
      type: "note",
      at: "client",
      text: "SAME CONNECTION ON ANY NETWORK",
      tone: "navy"
    }]
  }]
};
const Ks = "00:00:5e:00:53:10";
const ao = "00:00:5e:00:53:01";
const Kt = "fe80::8d2e:4f61:a9b0:7c13";
const ja = "2001:db8:1234:5678::";
const Kn = "2001:db8:1234:5678:8d2e:4f61:a9b0:7c13";
const Xs = "fe80::1";
const Zs = "ff02::1:ffb0:7c13";
const Bn = e => 54 + e;
const za = 24;
const Qa = 8;
const _n = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "ICMPv6",
  info: n,
  len: `${o} B`,
  wire: {
    ipv6: a
  }
});
const Xa = e => ({
  ethSrc: Ks,
  ethDst: ao,
  ...e
});
const bd = e => ({
  ethSrc: ao,
  ethDst: Ks,
  ...e
});
const A1 = {
  id: "ipv6",
  name: "IPv6",
  title: "Address Setup",
  layer: 3,
  nodes: ["client", "router"],
  latency: {
    "client-router": 0.001
  },
  labels: {
    client: ["Client", "No IPv6 address"],
    router: ["Router", Xs]
  },
  legend: [["amber", "From the laptop"], ["violet", "From the router"]],
  overview: {
    full: "IPv6: SLAAC and neighbour discovery",
    description: "IPv6 addresses are 128 bits long, enough for every device to have its own. A device can usually set itself up with no DHCP server: it makes a link-local address, asks for a router, and builds its global address from the prefix the router advertises (SLAAC). Neighbour discovery, part of ICMPv6, finds MAC addresses and does the work ARP does for IPv4.",
    facts: [["Layer", "Network (Layer 3)"], ["Address", "128 bits"], ["Addresses", "SLAAC: no server needed"], ["Replaces ARP", "Neighbour discovery"], ["DHCPv6", "Optional"], ["Defined In", "RFC 8200, 4861, 4862"]]
  },
  outro: {
    title: "Two addresses, no DHCP",
    desc: "Made by the laptop itself",
    text: "The laptop made a link-local address and a global one, checked that nobody else had either, and learned its router, MTU and DNS server from a single advertisement. When packets came for it, neighbour discovery found its MAC address. Press REPLAY to watch it again.",
    facts: [["Link-local", Kt], ["Global", `${ja}/64 + its own ID`], ["Router, DNS", "From one advertisement"], ["Messages", "6, all ICMPv6"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Link-Local First",
    desc: "Made by the laptop itself",
    detail: "Every IPv6 interface gets a link-local address, usable only on its own network. The laptop makes one from fe80:: and a random-looking 64-bit interface ID. First it checks nobody already has it: a Neighbor Solicitation asking for that address, sent from :: because it can’t use the address yet. Nobody answers, so it’s the laptop’s.",
    facts: [["Address", Kt], ["Check", "Duplicate address detection"], ["Answer", "None: the address is free"]],
    events: [{
      type: "show",
      nodes: ["router"],
      frame: "local"
    }, l("client", "router", "amber", "IS IT TAKEN?", ["from ::", `target ${Kt}`], _n(0, "::", Zs, `Neighbor Solicitation for ${Kt}`, Bn(za), Xa({
      src: "::",
      dst: Zs,
      icmp: {
        type: 135,
        target: Kt,
        dad: true
      }
    }))), {
      type: "note",
      at: "client",
      text: "NO ANSWER: ADDRESS IS FREE",
      tone: "green"
    }, {
      type: "label",
      at: "client",
      label: ["Client", Kt]
    }]
  }, {
    title: "Any Routers?",
    desc: "A Router Solicitation",
    detail: "Link-local addresses can’t reach the internet. The laptop sends a Router Solicitation to ff02::2, the address every router on the network listens to, with its own MAC address attached.",
    facts: [["To", "ff02::2 (all routers)"], ["From", Kt], ["Includes", "The laptop’s MAC address"]],
    events: [l("client", "router", "amber", "ROUTERS?", ["to ff02::2"], _n(1.01, Kt, "ff02::2", `Router Solicitation from ${Ks}`, Bn(8 + Qa), Xa({
      src: Kt,
      dst: "ff02::2",
      icmp: {
        type: 133,
        options: [{
          type: 1,
          mac: Ks
        }]
      }
    })))]
  }, {
    title: "Router Answers",
    desc: "Prefix, MTU and DNS in one message",
    detail: "The router answers to ff02::1, every device on the network, with a Router Advertisement: use me as your way out for 30 minutes, here is my MAC address, the MTU is 1500, the network’s prefix is 2001:db8:1234:5678::/64 and you may make your own address in it, and ask 2001:4860:4860::8888 for DNS. Routers also send these on their own every few minutes.",
    facts: [["Prefix", `${ja}/64`], ["Make your own", "Yes (flag A)"], ["DNS server", "2001:4860:4860::8888"]],
    events: [l("router", "client", "violet", "ADVERTISEMENT", [`prefix ${ja}/64`, "MTU, DNS"], _n(1.012, Xs, "ff02::1", `Router Advertisement from ${ao}`, Bn(16 + Qa + 8 + 32 + 24), bd({
      src: Xs,
      dst: "ff02::1",
      icmp: {
        type: 134,
        options: [{
          type: 1,
          mac: ao
        }, {
          type: 5,
          mtu: 1500
        }, {
          type: 3,
          prefix: ja,
          valid: 86400,
          preferred: 14400
        }, {
          type: 25,
          dns: "2001:4860:4860::8888",
          lifetime: 3600
        }]
      }
    })))]
  }, {
    title: "A Global Address",
    desc: "Prefix + interface ID",
    detail: "The laptop joins the prefix and its interface ID into a global address, 2001:db8:1234:5678:8d2e:4f61:a9b0:7c13, and checks it the same way. Windows also makes a temporary address with a random ID that changes every day, used for outgoing connections so websites can’t follow one device by its address.",
    facts: [["Global", "…:5678:8d2e:4f61:a9b0:7c13"], ["Check", "Duplicate address detection"], ["Also made", "A temporary address"]],
    events: [l("client", "router", "amber", "IS IT TAKEN?", ["from ::", "target the global address"], _n(1.02, "::", Zs, `Neighbor Solicitation for ${Kn}`, Bn(za), Xa({
      src: "::",
      dst: Zs,
      icmp: {
        type: 135,
        target: Kn,
        dad: true
      }
    }))), {
      type: "note",
      at: "client",
      text: "NO ANSWER: ADDRESS IS FREE",
      tone: "green"
    }, {
      type: "label",
      at: "client",
      label: ["Client", "2001:db8:1234:5678:…"]
    }]
  }, {
    title: "Neighbour Lookup",
    desc: "Who has this address? (ARP’s job)",
    detail: "A reply from the internet arrives at the router for the laptop’s global address. To deliver it, the router needs the MAC address that goes with it: it sends a Neighbor Solicitation to the address’s solicited-node group, so only devices whose address ends the same way even look. The laptop answers with a Neighbor Advertisement carrying its MAC address.",
    facts: [["Asked to", `${Zs}`], ["Answer", `${Ks}`], ["Instead of", "ARP broadcasts to everyone"]],
    events: [l("router", "client", "violet", "WHO HAS?", ["the global address"], _n(2.5, Xs, Zs, `Neighbor Solicitation for ${Kn} from ${ao}`, Bn(za + Qa), bd({
      src: Xs,
      dst: Zs,
      icmp: {
        type: 135,
        target: Kn,
        options: [{
          type: 1,
          mac: ao
        }]
      }
    }))), l("client", "router", "amber", "IT’S ME", [`MAC ${Ks}`], _n(2.502, Kt, Xs, `Neighbor Advertisement ${Kn} (sol, ovr) is at ${Ks}`, Bn(za + Qa), Xa({
      src: Kt,
      dst: Xs,
      icmp: {
        type: 136,
        target: Kn,
        options: [{
          type: 2,
          mac: Ks
        }]
      }
    })))]
  }, {
    title: "Ready, No DHCP",
    desc: "And no NAT either",
    detail: "The laptop is on the internet with its own global address, and no NAT changes it on the way: the address a website sees is the laptop’s. The home router’s firewall still turns away connections nobody inside asked for. Networks that want to hand out addresses centrally can use DHCPv6 instead.",
    facts: [["NAT", "Not needed"], ["Incoming", "Blocked by the firewall"], ["DHCPv6", "Optional (flags M, O)"]],
    events: [{
      type: "note",
      at: "client",
      text: "ONLINE OVER IPv6",
      tone: "green"
    }]
  }]
};
const Ti = "203.0.113.123";
const Ta = Date.UTC(2026, 10, 7, 9, 41, 0) / 1000;
const Zp = 0.25;
const xr = Ta - Zp;
const Ml = Ta + 0.012;
const ql = Ta + 0.0121;
const Jp = Ta + 0.0241 - Zp;
const Do = e => `${(e * 1000).toFixed(1)} ms`;
const bi = (Ml - xr + (ql - Jp)) / 2;
const vd = Jp - xr - (ql - Ml);
const E1 = (e, t) => ({
  udp: {
    sport: 123,
    dport: 123,
    data: {
      ntp: t
    }
  }
});
const kd = (e, t, s, n, o) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "NTP",
  info: n,
  len: "90 B",
  wire: E1(t, o)
});
const x1 = {
  id: "ntp",
  name: "NTP",
  title: "Setting the Clock",
  layer: 7,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.012
  },
  labels: {
    web: ["time.windows.com", Ti]
  },
  legend: [["amber", "Request"], ["violet", "Answer"]],
  overview: {
    full: "Network Time Protocol",
    description: "Computer clocks drift by seconds a week, and a lot depends on them: certificates have dates, logins and payments expire, logs from different machines must line up. NTP sets a clock from a time server over the internet. One small request and answer carry four timestamps, enough to work out how far off the clock is and how long the network took.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "UDP 123"], ["Message", "48 bytes"], ["Timestamps", "4: T1 to T4"], ["Accuracy", "A few milliseconds online"], ["Defined In", "RFC 5905"]]
  },
  outro: {
    title: "Clock set",
    desc: "Four timestamps, one answer",
    text: "One request and one answer gave four timestamps. From them the laptop worked out that its clock was 0.25 s slow and that the network took 24 ms there and back, and it began easing its clock into line. Press REPLAY to watch it again.",
    facts: [["Offset", `${Do(bi)} (slow)`], ["Round trip", Do(vd)], ["Server", "Stratum 2"], ["Next check", "Minutes to days later"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Clocks Drift",
    desc: "The laptop’s clock is a little slow",
    detail: "A computer keeps time with a quartz crystal that runs a little fast or slow, so clocks drift apart by seconds a week. This laptop’s clock is a quarter of a second behind. Windows sets it from time.windows.com, whose address it has already looked up by DNS.",
    facts: [["Laptop clock", "0.25 s slow"], ["Time server", "time.windows.com"], ["Why it matters", "Certificates, logins, logs"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, {
      type: "note",
      at: "client",
      text: "CLOCK 0.250 s SLOW",
      tone: "amber"
    }]
  }, {
    title: "Ask for the Time",
    desc: "T1: when the request leaves",
    detail: "The laptop sends a 48-byte request to port 123. It writes in the time by its own clock as the request leaves: T1, 09:40:59.750. Everything else is empty.",
    facts: [["T1 (laptop)", "09:40:59.750000"], ["Mode", "3 (client)"], ["Size", "48 bytes"]],
    events: [l("client", "web", "amber", "REQUEST", ["T1 09:40:59.750"], kd(0, h, Ti, "NTP Version 3, client", {
      version: 3,
      transmit: xr
    }))]
  }, {
    title: "The Answer",
    desc: "T2 and T3 from the server, T4 on arrival",
    detail: "The server copies T1 back, adds T2, when the request arrived, and T3, when its answer leaves, both by its own accurate clock. When the answer arrives, the laptop notes T4 by its own clock. The server is stratum 2: it sets its clock from a stratum 1 server, which has a GPS receiver or an atomic clock.",
    facts: [["T2, T3", "09:41:00.012000, .012100"], ["T4 (laptop)", "09:40:59.774100"], ["Stratum", "2"]],
    events: [l("web", "client", "violet", "ANSWER", ["T2 09:41:00.012000", "T3 09:41:00.012100"], kd(0.012, Ti, h, "NTP Version 3, server", {
      version: 3,
      server: true,
      reference: Ta - 523.418,
      origin: xr,
      receive: Ml,
      transmit: ql
    }))]
  }, {
    title: "The Offset",
    desc: "Four times, two answers",
    detail: "The time on the network, there and back, is (T4 − T1) − (T3 − T2) = 24.0 ms. The offset assumes the trip takes as long each way: ((T2 − T1) + (T3 − T4)) / 2 = 250.0 ms. The laptop’s clock is a quarter of a second slow. An uneven route (slower one way than the other) would skew the result by up to half the difference.",
    facts: [["Round trip", `(T4 − T1) − (T3 − T2) = ${Do(vd)}`], ["Offset", `((T2 − T1) + (T3 − T4)) / 2 = ${Do(bi)}`], ["Assumes", "Equal time each way"]],
    events: [{
      type: "note",
      at: "client",
      text: `OFFSET +${Do(bi)}`,
      tone: "navy"
    }]
  }, {
    title: "Ease It In",
    desc: "No jumps backwards",
    detail: "A small error is not fixed in one jump: the clock is run slightly fast until it catches up, so time never stops or goes backwards for running programs. Only a big error is set straight away. As a clock settles, an NTP client asks less often, from every 64 seconds up to every 17 minutes or so; Windows on its own checks time.windows.com far less often, every several hours or less.",
    facts: [["Small offsets", "Eased in gradually"], ["Large offsets", "Set at once"], ["Asks again", "Less often as it settles"]],
    events: [{
      type: "note",
      at: "client",
      text: "CLOCK IN STEP",
      tone: "green"
    }]
  }]
};
const us = "8.8.8.8";
const eu = {
  id: 27196,
  rd: true,
  q: ["www.example.com", "A"]
};
const C1 = {
  ...eu,
  response: true,
  ra: true,
  an: [["www.example.com", "A", 1745, "203.0.113.10"]],
  exampleTtl: true
};
const Pd = (e, t) => ({
  udp: e === h ? {
    sport: 60412,
    dport: 53,
    data: {
      dns: t
    }
  } : {
    sport: 53,
    dport: 60412,
    data: {
      dns: t
    }
  }
});
const $1 = q(h, 52420, us, 443);
const L1 = "AAABAAABAAAAAAAAA3d3dwdleGFtcGxlA2NvbQAAAQAB";
const I1 = 143;
const R1 = 124;
const Ad = (e, t, s, n, o, a, r) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "TLSv1.3",
  info: n,
  len: `${ae + re + ie + Yt + o} B`,
  wire: P($1, t, "PA", {
    tls: [{
      type: "appdata",
      length: o + 17,
      inner: {
        what: a,
        text: r
      }
    }]
  })
});
const N1 = {
  id: "doh",
  name: "DNS over HTTPS",
  title: "Private",
  layer: 7,
  nodes: ["client", "router", "internet", "dns"],
  latency: {
    "client-dns": 0.012
  },
  labels: {
    dns: ["dns.google", us]
  },
  legend: [["blue", "Plain DNS"], ["green", "TCP"], ["teal", "TLS"], ["amber", "DNS inside HTTPS"]],
  overview: {
    full: "DNS queries inside HTTPS",
    description: "Ordinary DNS travels in the clear: anyone on the same Wi-Fi, and your internet provider, can read every name you look up and even change the answers. DNS over HTTPS (DoH) sends the same DNS messages inside an encrypted HTTPS connection to the resolver, so on the way they look like any other web traffic. Browsers and operating systems can turn it on.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "443 (HTTPS)"], ["Carries", "Ordinary DNS messages"], ["Hides", "Which names you look up"], ["Similar", "DNS over TLS (port 853)"], ["Defined In", "RFC 8484"]]
  },
  outro: {
    title: "Looked up in private",
    desc: "Same question, sealed",
    text: "The plain lookup could be read by anyone on the path. Over HTTPS the same DNS message was sealed inside TLS, readable only by the resolver. The resolver still sees every question, so the trust moves to it, and the site you then visit can still be seen by its address. Press REPLAY to watch it again.",
    facts: [["On the way", "Only “HTTPS to dns.google”"], ["The resolver", "Still sees every name"], ["Still visible", "The site’s address you then visit"], ["Answers", "Can’t be changed on the way"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Plain DNS",
    desc: "Readable by anyone on the way",
    detail: "This is the lookup from the other lessons: a UDP packet to port 53 asking for www.example.com, and the answer. Neither is encrypted, so everyone on the café’s Wi-Fi, and the internet provider, can see which names the laptop looks up, and could even answer with a false address.",
    facts: [["Transport", "UDP port 53"], ["Encrypted", "No"], ["Can be changed", "Yes, on the way"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "dns"],
      frame: "lookup"
    }, l("client", "dns", "blue", "DNS QUERY", ["A? www.example.com", "readable"], {
      time: x(0),
      src: h,
      dst: us,
      proto: "DNS",
      info: "Standard query A www.example.com",
      len: "75 B",
      wire: Pd(h, eu)
    }), l("dns", "client", "blue", "DNS REPLY", ["A 203.0.113.10", "readable"], {
      time: x(0.012),
      src: us,
      dst: h,
      proto: "DNS",
      info: "Standard query response A 203.0.113.10",
      len: "91 B",
      wire: Pd(us, C1)
    }), {
      type: "note",
      at: "router",
      text: "ANYONE HERE CAN READ IT",
      tone: "amber"
    }]
  }, {
    title: "An HTTPS Link",
    desc: "TCP and TLS to dns.google",
    detail: "With DNS over HTTPS on, the browser opens an HTTPS connection to the resolver instead: TCP to port 443 and a TLS handshake for dns.google. It keeps this connection open and sends every lookup down it.",
    facts: [["Resolver", "dns.google (8.8.8.8)"], ["Port", "443, like any website"], ["Kept open", "For every lookup"]],
    events: [...he({
      to: "dns",
      dst: us,
      sport: 52420,
      dport: 443,
      t: [1, 1.012, 1.024]
    }), ...mo({
      to: "dns",
      dst: us,
      sni: "dns.google",
      sport: 52420,
      dport: 443,
      t: [1.024, 1.036, 1.048]
    })]
  }, {
    title: "Sealed Question",
    desc: "A DNS message in an HTTP request",
    detail: "The question is the same DNS message as before. It goes in an HTTP/2 request, GET /dns-query?dns= followed by the message in base64url, asking for an answer in the type application/dns-message. Inside TLS, nobody on the way can read it.",
    facts: [["Request", "GET /dns-query?dns=…"], ["Format", "application/dns-message"], ["On the way", "Encrypted (TLS)"]],
    events: [l("client", "dns", "amber", "DoH QUERY", ["inside: GET /dns-query?dns=…"], Ad(1.048, h, us, "Application Data (HTTP/2: DNS query)", I1, "HTTP/2: the connection preface and settings, then the request", [`GET /dns-query?dns=${L1}`, "accept: application/dns-message"]), {
      locked: true
    })]
  }, {
    title: "Sealed Answer",
    desc: "The DNS answer in an HTTP response",
    detail: "The resolver answers 200 with a body of type application/dns-message: the same DNS answer as the plain lookup, A 203.0.113.10. Because it arrives through TLS from dns.google, nobody on the way could have changed it.",
    facts: [["Response", "200, application/dns-message"], ["Body", "The DNS answer (49 bytes)"], ["Tampering", "Impossible on the way"]],
    events: [l("dns", "client", "amber", "DoH ANSWER", ["inside: A 203.0.113.10"], Ad(1.061, us, h, "Application Data (HTTP/2: DNS answer)", R1, "HTTP/2: settings, the response headers, then the DNS answer", [":status: 200", "content-type: application/dns-message", "www.example.com A 203.0.113.10 (49-byte DNS message)"]), {
      locked: true
    })]
  }, {
    title: "What Still Shows",
    desc: "Hidden on the way, not from the resolver",
    detail: "On the way, the lookups now look like any HTTPS traffic to dns.google. But the resolver itself reads every question, so you are trusting it instead of whoever runs your network. And the site you then visit is still seen by its IP address, and by its name in the TLS Client Hello unless it supports Encrypted Client Hello. DNS over TLS does the same job on port 853.",
    facts: [["Resolver", "Sees every name"], ["Then visible", "The site’s IP, maybe its name"], ["Alternative", "DNS over TLS (port 853)"]],
    events: [{
      type: "note",
      at: "dns",
      text: "TRUST MOVES TO THE RESOLVER",
      tone: "navy"
    }]
  }]
};
const Nt = "8.8.8.8";
const Ed = "192.5.6.30";
const Za = "198.51.100.53";
const tu = 47362;
const nl = 61845;
const D1 = 19718;
const O1 = Date.UTC(2026, 9, 31) / 1000;
const M1 = Date.UTC(2026, 10, 21) / 1000;
const Hl = (e, t, s, n, o) => ({
  covered: e,
  labels: t,
  ttl: s,
  tag: n,
  signer: o,
  inception: O1,
  expiration: M1
});
const Fl = {
  size: 1232,
  do: true
};
const su = {
  id: 23521,
  rd: true,
  q: ["www.example.com", "A"]
};
const nu = {
  id: 12039,
  q: ["www.example.com", "A"],
  edns: Fl
};
const q1 = {
  ...nu,
  response: true,
  aa: true,
  an: [["www.example.com", "A", 3600, "203.0.113.10"], ["www.example.com", "RRSIG", 3600, Hl("A", 3, 3600, tu, "example.com")]]
};
const ou = {
  id: 37844,
  q: ["example.com", "DNSKEY"],
  edns: Fl
};
const H1 = {
  ...ou,
  response: true,
  aa: true,
  an: [["example.com", "DNSKEY", 3600, {
    flags: 256,
    tag: tu
  }], ["example.com", "DNSKEY", 3600, {
    flags: 257,
    tag: nl
  }], ["example.com", "RRSIG", 3600, Hl("DNSKEY", 2, 3600, nl, "example.com")]]
};
const au = {
  id: 19480,
  q: ["example.com", "DS"],
  edns: Fl
};
const F1 = {
  ...au,
  response: true,
  aa: true,
  an: [["example.com", "DS", 86400, {
    tag: nl
  }], ["example.com", "RRSIG", 86400, Hl("DS", 2, 86400, D1, "com")]]
};
const U1 = {
  ...su,
  response: true,
  ra: true,
  ad: true,
  an: [["www.example.com", "A", 3600, "203.0.113.10"]]
};
const vi = {
  [h]: 61302,
  [Nt]: 40519
};
const K1 = (e, t, s) => ({
  udp: {
    sport: e === Nt && t === h ? 53 : vi[e] ?? 53,
    dport: t === h ? vi[h] : t === Nt ? e === h ? 53 : vi[Nt] : 53,
    data: {
      dns: s
    }
  }
});
const Is = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t,
  dst: s,
  proto: "DNS",
  info: n,
  len: `${o} B`,
  wire: K1(t, s, a)
});
const B1 = {
  id: "dnssec",
  name: "DNSSEC",
  title: "Signed Answers",
  layer: 7,
  nodes: ["client", "router", "internet", "dns", "tld", "auth"],
  latency: {
    "client-dns": 0.012,
    "dns-tld": 0.015,
    "dns-auth": 0.02
  },
  legend: [["blue", "Question and answer"], ["amber", "To the name servers"], ["violet", "Signed answers"]],
  overview: {
    full: "DNS Security Extensions",
    description: "Plain DNS answers can be forged: whoever answers first, or sits in the middle, can send a false address. DNSSEC lets a resolver check that an answer really comes from the domain’s owner. Every set of records is signed; each zone’s key is vouched for by its parent, up to the root, whose key resolvers have built in. DNSSEC proves answers are genuine; it doesn’t hide them.",
    facts: [["Layer", "Application (Layer 7)"], ["Adds records", "RRSIG, DNSKEY, DS"], ["Checked by", "The resolver"], ["Trust anchor", "The root’s key (built in)"], ["Hides queries", "No (that’s DoH)"], ["Defined In", "RFC 4033, 4034, 4035"]]
  },
  outro: {
    title: "Answer checked",
    desc: "A chain of signatures to the root",
    text: "The resolver followed a chain: the address was signed by example.com’s key, that key by its key-signing key, which .com vouched for with a signed DS record, and .com’s key is vouched for by the root, whose key the resolver has built in. A forged answer would have broken the chain. Press REPLAY to watch it again.",
    facts: [["Signatures checked", "3 here (plus cached ones)"], ["Algorithm", "ECDSA P-256 (13)"], ["Laptop sees", "The AD flag"], ["Forged answer", "Fails the check"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Ask as Usual",
    desc: "The laptop’s question doesn’t change",
    detail: "The laptop asks its resolver for www.example.com as always. The checking happens at the resolver, which asks the name servers with the DNSSEC OK flag set: send the signatures too.",
    facts: [["Question", "www.example.com, type A"], ["Checking done by", "The resolver (8.8.8.8)"], ["Resolver sets", "DNSSEC OK"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "dns"],
      frame: "lookup"
    }, l("client", "dns", "blue", "DNS QUERY", ["A? www.example.com"], Is(0, h, Nt, "Standard query A www.example.com", 75, su))]
  }, {
    title: "Signed Answer",
    desc: "An RRSIG comes with the A record",
    detail: "The resolver already knows example.com’s name server from earlier lookups. That server sends the address with an RRSIG record: a signature over the A record, made with the zone’s private key. The RRSIG says which key signed it (key 47362, the zone-signing key) and when the signature expires. To check it the resolver needs that key.",
    facts: [["Answer", "A 203.0.113.10"], ["Signature", "RRSIG by key 47362"], ["Valid", "31 Oct to 21 Nov 2026"]],
    events: [{
      type: "show",
      nodes: ["tld", "auth"],
      frame: "full"
    }, l("dns", "auth", "amber", "A? + DO", ["www.example.com", "DNSSEC OK"], Is(0.013, Nt, Za, "Standard query A www.example.com OPT", 86, nu)), l("auth", "dns", "violet", "A + RRSIG", ["A 203.0.113.10", "signed by key 47362"], Is(0.033, Za, Nt, "Standard query response A 203.0.113.10 RRSIG", 209, q1))]
  }, {
    title: "The Zone’s Keys",
    desc: "DNSKEY records, signed too",
    detail: "The resolver asks for example.com’s keys. There are two: the zone-signing key (flags 256) that signed the A record, and the key-signing key (flags 257), which signs only the set of keys. With them the resolver checks both signatures. But who says these keys belong to example.com?",
    facts: [["ZSK", "47362, zone-signing (256)"], ["KSK", "61845, key-signing (257)"], ["Keys signed by", "The key-signing key"]],
    events: [l("dns", "auth", "amber", "DNSKEY?", ["example.com"], Is(0.054, Nt, Za, "Standard query DNSKEY example.com OPT", 82, ou)), l("auth", "dns", "violet", "DNSKEY + RRSIG", ["two keys", "signed by key 61845"], Is(0.074, Za, Nt, "Standard query response DNSKEY DNSKEY RRSIG", 349, H1))]
  }, {
    title: "Vouched by .com",
    desc: "The parent’s DS record",
    detail: "The parent zone answers that. The .com servers hold a DS record for example.com: a hash of its key-signing key, signed with .com’s own key. If the hash matches key 61845, the keys are example.com’s, as far as .com is concerned.",
    facts: [["DS", "Hash of key 61845"], ["Signed by", ".com (key 19718)"], ["Matches", "The key-signing key"]],
    events: [l("dns", "tld", "amber", "DS?", ["example.com"], Is(0.095, Nt, Ed, "Standard query DS example.com OPT", 82, au)), l("tld", "dns", "violet", "DS + RRSIG", ["hash of key 61845", "signed by .com"], Is(0.11, Ed, Nt, "Standard query response DS RRSIG", 229, F1))]
  }, {
    title: "Up to the Root",
    desc: "Where the chain ends",
    detail: "The same goes on above: .com’s keys are vouched for by a DS record in the root zone, signed by the root’s key, and that key is built into every validating resolver: the trust anchor. The resolver had those links cached, so the chain is complete: root → .com → example.com → the address.",
    facts: [[".com’s key", "Vouched for by the root"], ["Root’s key", "Built in (trust anchor)"], ["Chain", "Root → .com → example.com"]],
    events: [{
      type: "note",
      at: "dns",
      text: "CHAIN OF TRUST CHECKED",
      tone: "green"
    }]
  }, {
    title: "A Checked Answer",
    desc: "With the AD flag",
    detail: "The resolver answers the laptop with the address and the AD flag: authenticated data. Had any signature failed, the laptop would have got an error (SERVFAIL) instead of a forged address. DNSSEC doesn’t hide the question or the answer; for that there is DNS over HTTPS.",
    facts: [["Answer", "A 203.0.113.10"], ["Flag", "AD (authenticated data)"], ["Bad signature", "SERVFAIL, no address"]],
    events: [{
      type: "camera",
      frame: "lookup"
    }, l("dns", "client", "blue", "DNS REPLY", ["A 203.0.113.10", "AD: checked"], Is(0.126, Nt, h, "Standard query response A 203.0.113.10", 91, U1))]
  }]
};
const xd = "00:00:5e:00:53:10";
const Cd = "00:00:5e:00:53:01";
const Cr = "192.168.1.2";
const ol = "192.168.1.20";
const _1 = "Office";
const $r = "alex@example.org";
const $d = 50112;
const ft = (e, t, s, n, o, a = "EAP") => ({
  time: x(e),
  src: t === "ap" ? Cd : xd,
  dst: t === "ap" ? xd : Cd,
  proto: a,
  info: s,
  len: `${n} B`,
  wire: {
    wifi: {
      from: t,
      kind: "eapol",
      duration: 44,
      ...o
    }
  }
});
const Ja = e => 133 + e;
const G1 = [["User-Name", $r], ["NAS-IP-Address", Cr], ["Service-Type", 2], ["Called-Station-Id", `00-00-5E-00-53-01:${_1}`], ["Calling-Station-Id", "00-00-5E-00-53-10"], ["NAS-Port-Type", 19], ["Framed-MTU", 1400]];
const er = (e, t, s = true) => ({
  code: 1,
  id: e,
  attrs: [["Message-Authenticator"], ...G1, ...(s ? [["State"]] : []), ["EAP-Message", t]]
});
const ki = (e, t) => ({
  code: 11,
  id: e,
  attrs: [["Message-Authenticator"], ["EAP-Message", t], ["State"]]
});
const Rs = (e, t, s, n, o) => ({
  time: x(e),
  src: t === "ap" ? Cr : ol,
  dst: t === "ap" ? ol : Cr,
  proto: "RADIUS",
  info: s,
  len: `${n} B`,
  wire: {
    udp: t === "ap" ? {
      sport: $d,
      dport: 1812,
      data: {
        radius: o
      }
    } : {
      sport: 1812,
      dport: $d,
      data: {
        radius: o
      }
    }
  }
});
const W1 = {
  code: 1,
  id: 1,
  type: 1
};
const Ld = {
  code: 2,
  id: 1,
  type: 1,
  identity: $r
};
const Id = {
  code: 1,
  id: 2,
  type: 13,
  tls: {
    start: true
  }
};
const Rd = {
  code: 2,
  id: 2,
  type: 13,
  tls: {
    length: 213,
    what: ["Client Hello: TLS 1.3, the laptop’s key share"],
    note: "The same TLS records as over TCP, only carried in EAP."
  }
};
const Nd = {
  code: 1,
  id: 3,
  type: 13,
  tls: {
    length: 998,
    what: ["Server Hello: TLS 1.3, the server’s key share", "Encrypted: certificate for radius.example.org, a request for the laptop’s certificate, signature, Finished"]
  }
};
const Dd = {
  code: 2,
  id: 3,
  type: 13,
  tls: {
    length: 812,
    what: ["Encrypted: the laptop’s certificate (for alex@example.org), its signature, Finished"]
  }
};
const Od = {
  code: 1,
  id: 4,
  type: 13,
  tls: {
    length: 23,
    what: ["Encrypted: one 0 byte, the “commitment message”: no more handshake messages"]
  }
};
const Md = {
  code: 2,
  id: 4,
  type: 13,
  tls: {}
};
const ru = {
  code: 3,
  id: 4
};
const V1 = {
  code: 2,
  id: 84,
  attrs: [["Message-Authenticator"], ["Tunnel-Type", 13], ["Tunnel-Medium-Type", 6], ["Tunnel-Private-Group-Id", "20"], ["MS-MPPE-Recv-Key"], ["MS-MPPE-Send-Key"], ["EAP-Message", ru]]
};
const Y1 = {
  id: "radius",
  name: "RADIUS",
  title: "Wi-Fi Logins",
  layer: 2,
  nodes: ["client", "router", "lan"],
  seenOn: "Seen on the office network",
  latency: {
    "client-router": 0.001,
    "router-lan": 0.0005
  },
  labels: {
    client: ["Client", "MAC …:53:10"],
    router: ["Access Point", Cr],
    lan: ["RADIUS Server", ol]
  },
  legend: [["amber", "EAP over Wi-Fi"], ["violet", "RADIUS"], ["teal", "4-way handshake"]],
  overview: {
    full: "RADIUS and 802.1X (Enterprise Wi-Fi)",
    description: "At home everyone shares one Wi-Fi password. Offices, universities and eduroam use WPA2- or WPA3-Enterprise instead: each person or device logs in with its own account or certificate, checked by a RADIUS server. The access point knows no passwords. It passes the login, a series of EAP messages, between the laptop and the server, and lets the laptop in only when the server says yes.",
    facts: [["Layer", "Data Link (Layer 2)"], ["Standard", "IEEE 802.1X"], ["Login", "EAP (here EAP-TLS)"], ["Checked by", "RADIUS, UDP 1812"], ["Keys", "Different for every login"], ["Defined In", "RFC 2865, 3579, 5216"]]
  },
  outro: {
    title: "Let in",
    desc: "Its own login, its own keys",
    text: "The laptop proved who it was with its certificate. The RADIUS server checked it and told the access point to let it in, on VLAN 20, with a key for this login alone. The access point never saw a password: it only passed the messages on. Press REPLAY to watch it again.",
    facts: [["Login", "EAP-TLS (certificates)"], ["Messages", "17, then the 4-way handshake"], ["VLAN", "20 (staff)"], ["A user leaves", "Disable one account"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Who Are You?",
    desc: "The access point asks for an identity",
    detail: "The laptop has joined “Office”, a WPA2-Enterprise network, but until it has logged in the access point passes on nothing except login messages. It asks who the laptop is with an EAP Identity request, and the laptop answers alex@example.org. The access point knows no accounts: it will pass the answer on to the RADIUS server.",
    facts: [["Network", "“Office”, WPA2-Enterprise"], ["Identity", $r], ["Before login", "Only EAP gets through"]],
    events: [{
      type: "show",
      nodes: ["router", "lan"],
      frame: "office"
    }, l("router", "client", "amber", "IDENTITY?", ["EAP Identity request"], ft(0, "ap", "Request, Identity", 43, {
      seq: 1520,
      eap: W1
    })), l("client", "router", "amber", "IDENTITY", [$r], ft(0.004, "sta", "Response, Identity", 59, {
      seq: 210,
      eap: Ld
    }))]
  }, {
    title: "Ask RADIUS",
    desc: "The login goes to the server",
    detail: "The access point copies the EAP message into a RADIUS Access-Request and sends it to the RADIUS server on UDP port 1812, with the laptop’s MAC address and the network’s name. A secret that only the two of them share protects every packet. The server answers with an Access-Challenge: the next message for the laptop, which is “start EAP-TLS”.",
    facts: [["To", "RADIUS server, UDP 1812"], ["Protected by", "A shared secret"], ["Answer", "Access-Challenge"]],
    events: [l("router", "lan", "violet", "ACCESS-REQUEST", ["EAP: alex@example.org", "from the access point"], Rs(0.006, "ap", "Access-Request id=81", 190, er(81, Ld, false))), l("lan", "router", "violet", "CHALLENGE", ["EAP-TLS start"], Rs(0.008, "server", "Access-Challenge id=81", 106, ki(81, Id))), l("router", "client", "amber", "TLS START", ["EAP-TLS start"], ft(0.009, "ap", "Request, TLS EAP (EAP-TLS)", 44, {
      seq: 1521,
      eap: Id
    }), {
      quick: true
    })]
  }, {
    title: "TLS Inside EAP",
    desc: "The server proves who it is",
    detail: "The laptop and the server now run a TLS 1.3 handshake inside EAP; the access point repacks each message, EAPOL over the air and RADIUS on the wire. The server sends its certificate and asks for the laptop’s. The laptop checks that it was issued by the company’s own certificate authority to radius.example.org. That check is what stops a fake access point from catching the login.",
    facts: [["Handshake", "TLS 1.3, inside EAP"], ["Server proves", "Its certificate"], ["Laptop checks", "Issuer and name"]],
    events: [l("client", "router", "amber", "CLIENT HELLO", ["TLS inside EAP"], ft(0.012, "sta", "Response, TLS EAP: Client Hello", 261, {
      seq: 211,
      eap: Rd
    })), l("router", "lan", "violet", "ACCESS-REQUEST", ["Client Hello"], Rs(0.014, "ap", "Access-Request id=82: Client Hello", 410, er(82, Rd)), {
      quick: true
    }), l("lan", "router", "violet", "CHALLENGE", ["Server Hello", "certificate (encrypted)"], Rs(0.019, "server", "Access-Challenge id=82: Server Hello, certificate", 1114, ki(82, Nd))), l("router", "client", "amber", "SERVER HELLO", ["certificate (encrypted)"], ft(0.02, "ap", "Request, TLS EAP: Server Hello, encrypted handshake", 1046, {
      seq: 1522,
      eap: Nd
    }), {
      quick: true
    })]
  }, {
    title: "Laptop’s Proof",
    desc: "Its own certificate",
    detail: "The laptop answers with its own certificate, which the company issued for this user, and a signature made with its private key; the key never leaves the laptop. No password is involved. The server checks the certificate and the signature and looks up the account. Many networks, eduroam among them, use a password instead, sent inside the TLS tunnel (PEAP or EAP-TTLS).",
    facts: [["Laptop sends", "Its certificate, a signature"], ["Password", "None with EAP-TLS"], ["Or instead", "PEAP: a password in TLS"]],
    events: [l("client", "router", "amber", "CERTIFICATE", ["laptop’s certificate", "signature, Finished"], ft(0.048, "sta", "Response, TLS EAP: encrypted handshake", 860, {
      seq: 212,
      eap: Dd
    }), {
      locked: true
    }), l("router", "lan", "violet", "ACCESS-REQUEST", ["laptop’s certificate"], Rs(0.05, "ap", "Access-Request id=83: encrypted handshake", 1015, er(83, Dd)), {
      quick: true,
      locked: true
    })]
  }, {
    title: "Handshake Done",
    desc: "Nothing more to send",
    detail: "With TLS 1.3 the server then sends one tiny encrypted message, a single zero byte, to say the handshake is over, and the laptop answers with an empty EAP message. Both ends now hold the same 64 bytes of key material, worked out during the handshake. Nobody on the way has seen it, not even the access point.",
    facts: [["Server sends", "One encrypted 0 byte"], ["Laptop sends", "An empty EAP-TLS reply"], ["Both hold", "64 bytes of key material"]],
    events: [l("lan", "router", "violet", "CHALLENGE", ["handshake over"], Rs(0.056, "server", "Access-Challenge id=83", 133, ki(83, Od)), {
      quick: true,
      locked: true
    }), l("router", "client", "amber", "DONE", ["one encrypted byte"], ft(0.057, "ap", "Request, TLS EAP: Application Data", 71, {
      seq: 1523,
      eap: Od
    }), {
      locked: true
    }), l("client", "router", "amber", "EMPTY", ["nothing more"], ft(0.06, "sta", "Response, TLS EAP (EAP-TLS)", 44, {
      seq: 213,
      eap: Md
    }), {
      quick: true
    }), l("router", "lan", "violet", "ACCESS-REQUEST", ["empty EAP-TLS"], Rs(0.062, "ap", "Access-Request id=84", 193, er(84, Md)), {
      quick: true
    })]
  }, {
    title: "Access-Accept",
    desc: "And a key for the access point",
    detail: "The server answers Access-Accept. Inside are EAP Success for the laptop; the first 32 bytes of the key material for the access point, encrypted with the shared secret (MS-MPPE-Recv-Key); and VLAN 20, so this user lands on the staff network. The same access point could put another user on another VLAN.",
    facts: [["Answer", "Access-Accept"], ["AP gets", "The key (MS-MPPE-Recv-Key)"], ["VLAN", "20 (staff)"]],
    events: [l("lan", "router", "violet", "ACCESS-ACCEPT", ["EAP Success", "key, VLAN 20"], Rs(0.065, "server", "Access-Accept id=84", 218, V1)), l("router", "client", "amber", "SUCCESS", ["EAP Success"], ft(0.066, "ap", "Success", 42, {
      seq: 1524,
      eap: ru
    }))]
  }, {
    title: "4-Way Handshake",
    desc: "As at home, from a different key",
    detail: "The access point and the laptop now hold the same 32-byte key, the PMK. What follows is the 4-way handshake from the Wi-Fi lesson; only the PMK’s origin differs. At home it comes from the shared password, here from this one login, so every user gets different keys.",
    facts: [["PMK from", "This login"], ["At home", "From the shared password"], ["Then", "Encrypted data (CCMP)"]],
    events: [l("router", "client", "teal", "MESSAGE 1", ["ANonce"], ft(0.068, "ap", "Key (Message 1 of 4)", Ja(0), {
      seq: 1525,
      msg: 1
    }, "EAPOL"), {
      quick: true
    }), l("client", "router", "teal", "MESSAGE 2", ["SNonce + MIC"], ft(0.071, "sta", "Key (Message 2 of 4)", Ja(22), {
      seq: 214,
      msg: 2,
      akm: 1
    }, "EAPOL"), {
      quick: true
    }), l("router", "client", "teal", "MESSAGE 3", ["group key, MIC"], ft(0.073, "ap", "Key (Message 3 of 4)", Ja(56), {
      seq: 1526,
      msg: 3,
      keyData: 56
    }, "EAPOL"), {
      quick: true
    }), l("client", "router", "teal", "MESSAGE 4", ["keys installed"], ft(0.075, "sta", "Key (Message 4 of 4)", Ja(0), {
      seq: 215,
      msg: 4
    }, "EAPOL"), {
      quick: true
    })]
  }, {
    title: "Why Enterprise",
    desc: "One account per person",
    detail: "When someone leaves, their account is disabled and nobody else changes a password. Every login gets its own keys, so users can’t read each other’s traffic, and the RADIUS server records who connected and when. eduroam works the same way: a visitor’s login for user@their-university is passed from RADIUS server to RADIUS server until it reaches their own university.",
    facts: [["A user leaves", "Disable one account"], ["Keys", "Different for every user"], ["eduroam", "Login passed home"]],
    events: [{
      type: "note",
      at: "lan",
      text: "ONE ACCOUNT PER PERSON",
      tone: "navy"
    }]
  }]
};
const co = "192.168.1.20";
const tr = "\\\\nas\\Documents";
const ds = "report.pdf";
const Zo = 245760;
const Jo = 134422208708645;
const j1 = 10833;
const z1 = q(h, 50532, co, 445);
const mt = e => 58 + e;
const iu = 84 + Zo;
const Gn = Math.ceil(iu / 1460);
const lu = (e, t, s, n, o) => ({
  time: x(e),
  src: t,
  dst: t === h ? co : h,
  proto: "SMB2",
  info: s,
  len: typeof n == "number" ? `${n} B` : n,
  wire: P(z1, t, "PA", {
    smb: o
  })
});
const Js = (e, t, s, n) => lu(e, h, t, s, n);
const en = (e, t, s, n) => lu(e, co, t, s, {
  resp: true,
  ...n
});
const tn = {
  session: Jo,
  tree: j1,
  signed: true
};
const Q1 = {
  id: "smb",
  name: "SMB",
  title: "Shared Folders",
  layer: 7,
  nodes: ["client", "router", "lan"],
  latency: {
    "client-lan": 0.001
  },
  labels: {
    lan: ["nas (File Server)", co]
  },
  legend: [["green", "TCP"], ["amber", "Requests"], ["violet", "Responses"]],
  overview: {
    full: "Server Message Block (SMB 3)",
    description: "SMB is how Windows shares files and printers: \\\\server\\share in File Explorer, a mapped network drive, a NAS at home. macOS and Linux speak it too. Over one TCP connection to port 445 the client agrees on a version, logs in and connects to a share, then opens, reads, writes and closes files with numbered requests.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "TCP 445"], ["Version", "SMB 3.1.1"], ["Login", "NTLM or Kerberos"], ["Protection", "Signing, optional encryption"], ["Defined In", "MS-SMB2 (Microsoft)"]]
  },
  outro: {
    title: "File read",
    desc: "Seven requests, one connection",
    text: "Over one TCP connection the laptop agreed on SMB 3.1.1, logged in with NTLM without sending its password, connected to the share and read a 240 KB file with a single request. Every message after the login was signed. Press REPLAY to watch it again.",
    facts: [["Requests", "7 on one connection"], ["Login", "NTLMv2, no password sent"], ["File", `240 KB in ${Gn} segments`], ["Signed", "Every message after login"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Port 445",
    desc: "A TCP connection to the NAS",
    detail: "The laptop opens \\\\nas\\Documents, a shared folder on the NAS. It finds nas’s address with a local name lookup and opens a TCP connection to port 445. The packets pass through the home router to the NAS and never leave the home network.",
    facts: [["Server", `nas, ${co}`], ["Port", "TCP 445"], ["Stays", "On the home network"]],
    events: [{
      type: "show",
      nodes: ["router", "lan"],
      frame: "office"
    }, ...he({
      to: "lan",
      dst: co,
      sport: 50532,
      dport: 445,
      t: [0, 0.001, 0.002]
    })]
  }, {
    title: "Negotiate",
    desc: "Agree on a version",
    detail: "The laptop lists every SMB version it speaks, from 2.0.2 to 3.1.1, and says it requires signing. The NAS picks 3.1.1, the newest. Both sides keep a SHA-512 hash of everything exchanged from here until the login is done. It goes into the keys, so if anyone changed these messages on the way, to force an older version for instance, the login would fail.",
    facts: [["Offered", "2.0.2 to 3.1.1"], ["Chosen", "SMB 3.1.1"], ["Tamper check", "SHA-512 of the exchange"]],
    events: [l("client", "lan", "amber", "NEGOTIATE", ["SMB 2.0.2 … 3.1.1", "signing required"], Js(0.002, "Negotiate Protocol Request", mt(214), {
      cmd: 0,
      mid: 0,
      credits: 1
    })), l("lan", "client", "violet", "NEGOTIATE", ["SMB 3.1.1"], en(0.004, "Negotiate Protocol Response", mt(284), {
      cmd: 0,
      mid: 0,
      credits: 1
    }))]
  }, {
    title: "NTLM Challenge",
    desc: "The NAS sends a random number",
    detail: "A home NAS has no domain, so there is no Kerberos: the laptop logs in with NTLM. Its first SESSION_SETUP says it wants to log in, and the NAS answers “more processing required” with a challenge of 8 random bytes. It also gives this login a session ID.",
    facts: [["Login", "NTLMv2 (in a domain: Kerberos)"], ["Challenge", "8 random bytes"], ["Status", "More processing required"]],
    events: [l("client", "lan", "amber", "SESSION SETUP", ["NTLM: let me log in"], Js(0.006, "Session Setup Request, NTLMSSP_NEGOTIATE", mt(162), {
      cmd: 1,
      mid: 1,
      credits: 33,
      blob: [74, ["NTLMSSP NEGOTIATE: the NTLM options the laptop supports"]]
    })), l("lan", "client", "violet", "CHALLENGE", ["8 random bytes", "a session ID"], en(0.008, "Session Setup Response, NTLMSSP_CHALLENGE", mt(263), {
      cmd: 1,
      mid: 1,
      credits: 33,
      status: 3221225494,
      session: Jo,
      blob: [191, ["NTLMSSP CHALLENGE: an 8-byte random challenge", "The NAS’s names and its clock"]]
    }))]
  }, {
    title: "NTLM Response",
    desc: "Proof, not the password",
    detail: "The laptop answers with the user name, alex, and an NTLMv2 response: an HMAC of the challenge and a few other values, keyed with a hash of the password. The NAS has the same hash and works out the same value. The password itself never crosses the network, and both sides now have a session key to sign messages with.",
    facts: [["User", "alex"], ["Sends", "An HMAC of the challenge"], ["Password", "Never sent"]],
    events: [l("client", "lan", "amber", "SESSION SETUP", ["user alex", "NTLMv2 response"], Js(0.01, "Session Setup Request, NTLMSSP_AUTH, User: \\alex", mt(665), {
      cmd: 1,
      mid: 2,
      credits: 33,
      session: Jo,
      blob: [577, ["NTLMSSP AUTH: user alex, computer ALEX-PC", "NTLMv2 response: an HMAC of the challenge, keyed with a hash of the password", "A key for signing, encrypted"]]
    })), l("lan", "client", "violet", "LOGGED IN", ["STATUS_SUCCESS", "signed"], en(0.013, "Session Setup Response", mt(81), {
      cmd: 1,
      mid: 2,
      credits: 64,
      session: Jo,
      signed: true,
      blob: "done"
    }))]
  }, {
    title: "Connect a Share",
    desc: "\\\\nas\\Documents",
    detail: "TREE_CONNECT asks for the share by its full name, \\\\nas\\Documents. The answer gives it a tree ID and says what this user may do there. Every message is now signed: each carries a tag over the whole message, made with a key from the login, so a changed or forged message would be caught.",
    facts: [["Share", tr], ["Tree ID", "0x00002a51"], ["Every message", "Signed (AES-GMAC)"]],
    events: [l("client", "lan", "amber", "TREE CONNECT", [tr], Js(0.015, `Tree Connect Request Tree: ${tr}`, mt(102), {
      cmd: 3,
      mid: 3,
      credits: 64,
      session: Jo,
      signed: true,
      path: tr
    })), l("lan", "client", "violet", "TREE CONNECT", ["tree ID 0x2a51"], en(0.017, "Tree Connect Response", mt(80), {
      cmd: 3,
      mid: 3,
      credits: 64,
      ...tn
    }))]
  }, {
    title: "Open the File",
    desc: "With CREATE",
    detail: "SMB opens files with CREATE, which can also make new ones. This one opens report.pdf to read it, and fails if it doesn’t exist. The answer gives the file’s size and dates, and a file ID that the read and the close will use.",
    facts: [["File", ds], ["Size", "245,760 bytes"], ["Handle", "A 16-byte file ID"]],
    events: [l("client", "lan", "amber", "CREATE", [ds, "open to read"], Js(0.019, `Create Request File: ${ds}`, mt(140), {
      cmd: 5,
      mid: 4,
      credits: 64,
      ...tn,
      name: ds
    })), l("lan", "client", "violet", "CREATE", ["file ID", "245,760 bytes"], en(0.021, `Create Response File: ${ds}`, mt(152), {
      cmd: 5,
      mid: 4,
      credits: 64,
      ...tn,
      size: Zo
    }))]
  }, {
    title: "Read It",
    desc: "The whole file in one request",
    detail: `One READ asks for the whole file, 245,760 bytes from offset 0. It costs 4 credits, one for every 64 KB. The answer is 80 bytes of headers and then the file, in ${Gn} TCP segments. A bigger file is read with several requests, many on their way at once, as far as the credits allow.`,
    facts: [["Asks for", "245,760 bytes from 0"], ["Credits", "4 (one per 64 KB)"], ["Arrives in", `${Gn} TCP segments`]],
    events: [l("client", "lan", "amber", "READ", ["245,760 bytes", "from offset 0"], Js(0.023, `Read Request Len:${Zo} Off:0 File: ${ds}`, mt(113), {
      cmd: 8,
      mid: 5,
      credits: 64,
      charge: 4,
      ...tn,
      length: Zo
    })), l("lan", "client", "violet", "DATA", ["report.pdf", `${Gn} segments`], en(0.025, `Read Response, ${Gn} segments`, St(iu + Gn * 54), {
      cmd: 8,
      mid: 5,
      credits: 64,
      charge: 4,
      ...tn,
      length: Zo
    }))]
  }, {
    title: "Close the File",
    desc: "And keep 445 at home",
    detail: "CLOSE hands the file ID back; the connection stays open for the next file. SMB 3 can also encrypt every message with AES-GCM, for one share or a whole server. Here only signing protects the messages, so anyone on the network could read the file as it passed. Port 445 should never be reachable from the internet: the WannaCry worm (2017) spread through a flaw in the old SMB1.",
    facts: [["Encryption", "SMB 3: AES-GCM, optional"], ["SMB1", "Switched off: old, unsafe"], ["Port 445", "Never open to the internet"]],
    events: [l("client", "lan", "amber", "CLOSE", [ds], Js(0.03, `Close Request File: ${ds}`, mt(88), {
      cmd: 6,
      mid: 9,
      credits: 64,
      ...tn
    })), l("lan", "client", "violet", "CLOSE", ["done"], en(0.032, `Close Response File: ${ds}`, mt(124), {
      cmd: 6,
      mid: 9,
      credits: 64,
      ...tn
    })), {
      type: "note",
      at: "router",
      text: "KEEP PORT 445 OFF THE INTERNET",
      tone: "amber"
    }]
  }]
};
const ys = "192.168.1.20";
const X1 = q(h, 51874, ys, 502);
const Z1 = [[412, "tank level, 4.12 m"], [183, "temperature, 18.3 °C"], [1450, "pump speed, 1,450 rpm"], [450, "level setpoint, 4.50 m"]];
const Ns = e => 61 + e;
const Ds = (e, t, s, n, o) => ({
  time: x(e),
  src: t,
  dst: t === h ? ys : h,
  proto: "Modbus/TCP",
  info: s,
  len: `${n} B`,
  wire: P(X1, t, "PA", {
    modbus: o
  })
});
const J1 = {
  id: "modbus",
  name: "Modbus",
  title: "Talking to a PLC",
  layer: 7,
  nodes: ["client", "router", "lan"],
  seenOn: "Seen on the plant network",
  latency: {
    "client-lan": 0.001
  },
  labels: {
    router: ["Switch", "Plant network"],
    lan: ["PLC", ys]
  },
  legend: [["green", "TCP"], ["amber", "Requests"], ["violet", "Answers"]],
  overview: {
    full: "Modbus/TCP, for industrial control",
    description: "Modbus is one of the oldest and most widely used protocols in industrial control (OT, operational technology): PLCs, sensors, motor drives and meters in factories, water works and buildings speak it. A client reads and writes numbered registers and coils on a device. Modbus/TCP carries the same small messages over TCP port 502, with no login and no encryption.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "TCP 502"], ["Since", "1979, by Modicon"], ["Data", "16-bit registers, on/off coils"], ["Security", "None built in"], ["Defined In", "Modbus.org specifications"]]
  },
  outro: {
    title: "Pump running",
    desc: "Simple, and wide open",
    text: "The laptop read four registers, changed a setpoint and started a pump, each with a 12-byte request and a short answer. No message carried a password and none was encrypted: Modbus trusts whoever can reach it, so the network around it has to do the protecting. Press REPLAY to watch it again.",
    facts: [["Messages", "4 requests, 4 answers"], ["Biggest", "17 bytes (the read answer)"], ["Login", "None"], ["Protect with", "Separate networks"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Port 502",
    desc: "A TCP connection to the PLC",
    detail: "A PLC (programmable logic controller) runs a small pumping station: it reads the sensors and switches the pumps. An engineer’s laptop on the plant network talks to it in Modbus/TCP, so it opens a TCP connection to port 502. In Modbus terms the laptop is the client and the PLC the server.",
    facts: [["PLC", ys], ["Port", "TCP 502"], ["Roles", "Client asks, server answers"]],
    events: [{
      type: "show",
      nodes: ["router", "lan"],
      frame: "office"
    }, ...he({
      to: "lan",
      dst: ys,
      sport: 51874,
      dport: 502,
      t: [0, 0.001, 0.002]
    })]
  }, {
    title: "Read Registers",
    desc: "Function 3: four numbers",
    detail: "The laptop asks for 4 holding registers starting at address 0, with function code 3. The PLC answers with 8 bytes: four 16-bit numbers. What they mean (the tank level in centimetres, the temperature in tenths of a degree) is written only in the PLC’s documentation; the message carries no names and no units. An HMI screen sends reads like this every second or so.",
    facts: [["Function", "3, Read Holding Registers"], ["Asks for", "4 registers from 0"], ["Answer", "412, 183, 1450, 450"]],
    events: [l("client", "lan", "amber", "READ", ["function 3", "registers 0–3"], Ds(0.002, h, "Query: Trans: 1; Unit: 1, Func: 3: Read Holding Registers", Ns(5), {
      tid: 1,
      fn: 3,
      address: 0,
      count: 4
    })), l("lan", "client", "violet", "VALUES", ["412, 183, 1450, 450"], Ds(0.005, ys, "Response: Trans: 1; Unit: 1, Func: 3: Read Holding Registers", Ns(10), {
      tid: 1,
      fn: 3,
      resp: true,
      address: 0,
      registers: Z1
    }))]
  }, {
    title: "Write a Setpoint",
    desc: "Function 6: one register",
    detail: "The engineer raises the tank’s level setpoint from 4.50 m to 5.00 m: function 6, write single register, register 3, value 500. The PLC answers by repeating the request, which means done. From now on its program keeps the tank fuller.",
    facts: [["Function", "6, Write Single Register"], ["Register 3", "450 → 500"], ["Answer", "The request, repeated"]],
    events: [l("client", "lan", "amber", "WRITE", ["register 3 = 500"], Ds(3, h, "Query: Trans: 2; Unit: 1, Func: 6: Write Single Register", Ns(5), {
      tid: 2,
      fn: 6,
      address: 3,
      value: 500,
      what: "level setpoint",
      meaning: "5.00 m"
    })), l("lan", "client", "violet", "DONE", ["register 3 = 500"], Ds(3.002, ys, "Response: Trans: 2; Unit: 1, Func: 6: Write Single Register", Ns(5), {
      tid: 2,
      fn: 6,
      resp: true,
      address: 3,
      value: 500,
      what: "level setpoint",
      meaning: "5.00 m"
    }))]
  }, {
    title: "Start a Pump",
    desc: "Function 5: a coil",
    detail: "Coils are single on/off outputs. Function 5 writes one: coil 0, pump 2, value 0xFF00, which means on. The PLC switches the pump on and echoes the request. In a real plant the PLC’s own program usually decides this, with safety interlocks.",
    facts: [["Function", "5, Write Single Coil"], ["Coil 0", "Pump 2: on"], ["On", "0xFF00 (off: 0x0000)"]],
    events: [l("client", "lan", "amber", "COIL ON", ["coil 0: pump 2"], Ds(5, h, "Query: Trans: 3; Unit: 1, Func: 5: Write Single Coil", Ns(5), {
      tid: 3,
      fn: 5,
      address: 0,
      value: 1,
      what: "pump 2"
    })), l("lan", "client", "violet", "DONE", ["pump 2 on"], Ds(5.002, ys, "Response: Trans: 3; Unit: 1, Func: 5: Write Single Coil", Ns(5), {
      tid: 3,
      fn: 5,
      resp: true,
      address: 0,
      value: 1,
      what: "pump 2"
    })), {
      type: "note",
      at: "lan",
      text: "PUMP 2 RUNNING",
      tone: "green"
    }]
  }, {
    title: "An Exception",
    desc: "No such register",
    detail: "A request for registers that don’t exist, here 100 and 101, gets an exception: the function code with its top bit set (3 + 128 = 131) and exception code 2, illegal data address. Other codes say the function isn’t supported or the device is busy.",
    facts: [["Function", "131 (3 + 128)"], ["Exception", "2, Illegal Data Address"], ["Means", "No register there"]],
    events: [l("client", "lan", "amber", "READ", ["registers 100–101"], Ds(7, h, "Query: Trans: 4; Unit: 1, Func: 3: Read Holding Registers", Ns(5), {
      tid: 4,
      fn: 3,
      address: 100,
      count: 2
    })), l("lan", "client", "violet", "EXCEPTION", ["code 2: no such register"], Ds(7.002, ys, "Response: Trans: 4; Unit: 1, Func: 131: Exception: Illegal data address", Ns(2), {
      tid: 4,
      fn: 3,
      resp: true,
      exception: 2
    }))]
  }, {
    title: "No Security",
    desc: "Anyone who can reach it",
    detail: "Nothing in these messages says who sent them: Modbus, from 1979, has no login and no encryption, so any device that can reach port 502 can read the values and start the pump. Plants protect it with separate networks, firewalls between office and plant, lists of who may talk to each PLC, and monitoring. Modbus/TCP Security wraps the same messages in TLS, on port 802.",
    facts: [["Login", "None"], ["Encryption", "None"], ["Protect with", "Separate networks, TLS"]],
    events: [{
      type: "note",
      at: "lan",
      text: "NO LOGIN, NO ENCRYPTION",
      tone: "amber"
    }]
  }]
};
const sn = "203.0.113.10";
const tt = "203.0.113.0/24";
const _t = "192.0.2.5";
const wt = "192.0.2.4";
const al = "192.0.2.8";
const ea = "192.0.2.9";
const hn = q(_t, 50311, wt, 179);
const qd = q(ea, 179, al, 41622);
const em = {
  bytes: [1240, 1186],
  ts: true
};
const Os = e => 66 + e;
const Hd = 19;
const cu = (e, t, s, n, o, a, r, i, c, d = {}) => ({
  time: x(e),
  src: s,
  dst: n,
  proto: o,
  info: a,
  len: `${r} B`,
  wire: {
    ...P(t, s, i, c, d),
    ttl: 1
  }
});
const Ms = (e, t, s, n, o, a, r, i) => cu(e, t, s, n, "BGP", o, a, "PA", {
  bgp: r
}, i);
const Pi = (e, t, s, n, o, a) => cu(e, hn, t, s, "TCP", n, o, a);
const tm = {
  id: "bgp",
  name: "BGP",
  title: "Internet Routes",
  layer: 7,
  nodes: ["client", "router", "isp", "transit", "hosting", "app"],
  latency: {
    "isp-transit": 0.004,
    "transit-hosting": 0.006,
    "client-app": 0.017
  },
  labels: {
    app: ["www.example.com", sn]
  },
  legend: [["green", "TCP"], ["blue", "Session"], ["violet", "Routes"], ["amber", "The laptop’s packets"]],
  overview: {
    full: "Border Gateway Protocol",
    description: "The internet is a network of networks: tens of thousands of them, run by internet providers, clouds, universities and companies, each with its own AS number. BGP is how their border routers tell each other which addresses they can reach. Every router passes on what it learns with its own number added, so each network builds its own map of the paths to every address on the internet.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "TCP 179"], ["Between", "Networks (ASes)"], ["Table", "About a million IPv4 routes"], ["Path choice", "Policy, then shortest"], ["Defined In", "RFC 4271"]]
  },
  outro: {
    title: "Route learned",
    desc: "Announced, passed on, used",
    text: "The hosting network announced its addresses, the transit network passed them on with its own number added, and the ISP’s router used that path for the laptop’s packets. When the route was withdrawn, the news spread the same way. There is no central map: every network builds its own from what its neighbours say. Press REPLAY to watch it again.",
    facts: [["Messages", "OPEN, KEEPALIVE, UPDATE"], ["Path", "64510 64511"], ["Map", "Each network makes its own"], ["Protect with", "RPKI and filters"]]
  },
  start: {
    nodes: ["isp"],
    frame: "bgp"
  },
  steps: [{
    title: "Many Networks",
    desc: "Each with its own number",
    detail: "The internet is more than 75,000 separate networks, called autonomous systems (ASes): internet providers, clouds, universities, big companies, each with a number. Here are three: the laptop’s ISP (AS 64500), a transit network that carries others’ traffic (AS 64510), and the hosting network of www.example.com (AS 64511). BGP is how their routers tell each other where every address can be reached.",
    facts: [["Networks", "More than 75,000 ASes"], ["Here", "3 ASes, a router each"], ["Numbers", "64500, 64510, 64511"]],
    events: [{
      type: "show",
      nodes: ["transit", "hosting", "app"],
      frame: "bgp"
    }]
  }, {
    title: "Open a Session",
    desc: "TCP to port 179",
    detail: "BGP routers don’t discover each other: engineers at both ends set each other up as neighbours. The ISP’s router opens a TCP connection to the transit router on port 179. They are directly connected, so their packets go out with a TTL of 1: they can’t cross even one more router, so the session only works between direct neighbours.",
    facts: [["Port", "TCP 179"], ["Neighbours", "Set up by hand"], ["TTL", "1: the next router only"]],
    events: [l("isp", "transit", "green", "SYN", [], Pi(0, _t, wt, "50311 → 179 [SYN] Seq=0", 74, "S"), {
      quick: true
    }), l("transit", "isp", "green", "SYN-ACK", [], Pi(0.004, wt, _t, "179 → 50311 [SYN, ACK] Seq=0 Ack=1", 74, "SA"), {
      quick: true
    }), l("isp", "transit", "green", "ACK", [], Pi(0.008, _t, wt, "50311 → 179 [ACK] Seq=1 Ack=1", 66, "A"), {
      quick: true
    })]
  }, {
    title: "Say Hello",
    desc: "OPEN, then KEEPALIVE",
    detail: "Each router sends an OPEN: its AS number, a hold time of 180 seconds, its router ID and what it supports, such as 4-byte AS numbers. Each answers with a KEEPALIVE, and the session is established. From now on a KEEPALIVE goes every 60 seconds when there’s nothing else to send; after 180 silent seconds the session would be dropped.",
    facts: [["OPEN", "AS, hold time, ID"], ["Then", "KEEPALIVE: established"], ["Hold time", "180 s"]],
    events: [l("isp", "transit", "blue", "OPEN", ["AS 64500", "hold 180 s"], Ms(0.008, hn, _t, wt, "OPEN Message", Os(45), {
      type: 1,
      as: 64500,
      hold: 180,
      id: _t
    })), l("transit", "isp", "blue", "OPEN", ["AS 64510", "hold 180 s"], Ms(0.012, hn, wt, _t, "OPEN Message", Os(45), {
      type: 1,
      as: 64510,
      hold: 180,
      id: wt
    })), l("transit", "isp", "blue", "KEEPALIVE", [], Ms(0.012, hn, wt, _t, "KEEPALIVE Message", Os(Hd), {
      type: 4
    }), {
      quick: true
    }), l("isp", "transit", "blue", "KEEPALIVE", [], Ms(0.016, hn, _t, wt, "KEEPALIVE Message", Os(Hd), {
      type: 4
    }), {
      quick: true
    }), {
      type: "note",
      at: "isp",
      text: "SESSION ESTABLISHED",
      tone: "green"
    }]
  }, {
    title: "Announce a Route",
    desc: "The hosting network: “I have these”",
    detail: "The hosting network’s router announces 203.0.113.0/24, the 256 addresses that include www.example.com, to the transit network, which it pays to carry its traffic. The UPDATE says how to get there: AS_PATH 64511, only its own network so far, and NEXT_HOP, its own address on the link between them.",
    facts: [["Prefix", tt], ["AS_PATH", "64511"], ["Next hop", ea]],
    events: [l("hosting", "transit", "violet", "UPDATE", [tt, "path 64511"], Ms(0.03, qd, ea, al, `UPDATE Message: ${tt}`, Os(47), {
      type: 2,
      path: [64511],
      next: ea,
      nlri: [tt]
    }, {
      opened: em
    }))]
  }, {
    title: "Passed On",
    desc: "Each network adds its number",
    detail: "The transit router accepts the route and passes it to its other neighbours, the ISP among them, with its own number added to the front: AS_PATH 64510 64511, and itself as the next hop. The ISP’s router may hear of the same prefix from several neighbours. It picks one by its own policy first (routes through paying customers before others, say), then by the shortest AS path.",
    facts: [["AS_PATH", "64510 64511"], ["Next hop", wt], ["Best path", "Policy, then shortest"]],
    events: [l("transit", "isp", "violet", "UPDATE", [tt, "path 64510 64511"], Ms(0.037, hn, wt, _t, `UPDATE Message: ${tt}`, Os(51), {
      type: 2,
      path: [64510, 64511],
      next: wt,
      nlri: [tt]
    })), {
      type: "note",
      at: "isp",
      text: `ROUTE TO ${tt}`,
      tone: "navy"
    }]
  }, {
    title: "Follow the Route",
    desc: "Packets go where BGP said",
    detail: "When the laptop connects to www.example.com (its address found by DNS as usual), its packets reach the ISP, whose router now sends anything for 203.0.113.0/24 to the transit router, and the transit router sends it on to the hosting network. The answer comes back by whatever route the hosting network chose towards the laptop’s ISP: on the internet the way back is often different from the way there.",
    facts: [["To", sn], ["Path", "AS 64500 → 64510 → 64511"], ["Way back", "Chosen separately"]],
    events: [{
      type: "show",
      nodes: ["client", "router"],
      frame: "route"
    }, l("client", "app", "amber", "SYN", ["to 203.0.113.10"], {
      time: x(1),
      src: h,
      dst: sn,
      proto: "TCP",
      info: "52800 → 443 [SYN] Seq=0",
      len: "66 B",
      wire: P(q(h, 52800, sn, 443), h, "S")
    }), l("app", "client", "amber", "SYN-ACK", ["the way back"], {
      time: x(1.017),
      src: sn,
      dst: h,
      proto: "TCP",
      info: "443 → 52800 [SYN, ACK] Seq=0 Ack=1",
      len: "66 B",
      wire: P(q(h, 52800, sn, 443), sn, "SA")
    })]
  }, {
    title: "Withdrawn",
    desc: "Routes can be taken back",
    detail: "Later the hosting network takes the prefix back, as it would if a link failed: an UPDATE listing it under withdrawn routes. The transit router passes it on, and within seconds to minutes networks everywhere forget the path. A session that goes quiet past its hold time loses all its routes at once. In 2021 Facebook withdrew the routes to its own DNS servers and vanished from the internet for six hours.",
    facts: [["Withdrawn", tt], ["Spreads in", "Seconds to minutes"], ["Session lost", "All its routes go"]],
    events: [{
      type: "camera",
      frame: "bgp"
    }, l("hosting", "transit", "violet", "WITHDRAW", [tt], Ms(5, qd, ea, al, `UPDATE Message: withdrawn ${tt}`, Os(27), {
      type: 2,
      withdraw: [tt]
    })), l("transit", "isp", "violet", "WITHDRAW", [tt], Ms(5.007, hn, wt, _t, `UPDATE Message: withdrawn ${tt}`, Os(27), {
      type: 2,
      withdraw: [tt]
    }))]
  }, {
    title: "Trust Problems",
    desc: "BGP believes its neighbours",
    detail: "A router accepts what its neighbours announce. A network that announces addresses that aren’t its own, by mistake or on purpose, pulls their traffic towards it: in 2008 a Pakistani ISP took YouTube offline worldwide this way. With RPKI the holder of a prefix signs which AS may announce it, and routers that check drop any other. Filters on what each neighbour may announce do the rest.",
    facts: [["Risk", "Hijacks and leaks"], ["RPKI", "Signed: who may announce"], ["Also", "Filters per neighbour"]],
    events: [{
      type: "note",
      at: "transit",
      text: "CHECK WHO MAY ANNOUNCE",
      tone: "amber"
    }]
  }]
};
const ws = "203.0.113.10";
const Tr = "192.0.2.19";
const Fe = "198.51.100.200";
const du = 56143;
const Wn = 61022;
const rl = 49170;
const sr = q(h, 50918, ws, 443);
const Fd = q(Fe, 50731, ws, 443);
const sm = {
  bytes: [2817, 5934]
};
const nm = {
  bytes: [4410, 1934],
  ts: true
};
const om = (e, t) => 5 + e + (e > 125 ? 4 : 2) + (t ? 4 : 0) + 17;
const il = (e, t) => Math.ceil(e / (t ? 1448 : 1460));
const Ud = (e, t) => e + il(e, t) * (34 + (t ? 32 : 20));
const am = {
  join: ["{\"type\":\"join\",\"room\":\"42\"}"],
  peer: ["{\"type\":\"peer\",\"name\":\"Sam\"}"],
  offer: ["{\"type\":\"offer\",\"sdp\":\"v=0 …\"}", "m=audio: Opus; m=video: VP8, H.264, AV1 …", "a=fingerprint:sha-256 4F:2A:… (its DTLS certificate)", "a=ice-ufrag:Hk2w a=ice-pwd:…", "a=candidate: host 2b9c…e1.local, srflx 198.51.100.7 61022"],
  answer: ["{\"type\":\"answer\",\"sdp\":\"v=0 …\"}", "Chosen: Opus, VP8", "a=setup:active (Sam’s browser starts DTLS)", "a=fingerprint:sha-256 9C:71:… a=ice-ufrag:q7Rz", "a=candidate: srflx 198.51.100.200 49170, and others"]
};
const Vn = (e, t, s, n, o, a, r, i, c = {}) => {
  const d = om(a, r);
  const p = s === Fe || n === Fe;
  const u = {
    tls: [{
      type: "appdata",
      length: d - 5,
      inner: {
        what: "A WebSocket text message",
        text: am[i]
      }
    }]
  };
  const y = il(d, p) > 1;
  return {
    time: x(e),
    src: s,
    dst: n,
    proto: "TLSv1.3",
    info: y ? `${o}, ${il(d, p)} segments` : o,
    len: y ? St(Ud(d, p)) : `${Ud(d, p)} B`,
    wire: {
      ...P(t, s, "PA", u, c),
      ...(s === Fe ? {
        ttl: 63
      } : {})
    }
  };
};
const ro = (e, t, s, n, o, a, r) => {
  const i = {
    [h]: du,
    [Fe]: rl,
    [Tr]: 3478
  };
  return {
    time: x(e),
    src: t,
    dst: s,
    proto: n,
    info: o,
    len: `${a} B`,
    wire: {
      udp: {
        sport: i[t],
        dport: i[s],
        data: r
      },
      ...(t === Fe ? {
        ttl: 51
      } : {})
    }
  };
};
const nr = [[78, 33, 156, 7, 179, 90, 17, 232, 98, 13, 159, 52], [8, 123, 210, 69, 145, 60, 174, 96, 23, 245, 43, 201]];
const or = (e, t, s, n, o, a) => ro(e, t, t === h ? Fe : h, "DTLSv1.2", s, n, {
  dtls: {
    name: o,
    records: a
  }
});
const Kd = (e, t, s, n, o) => ro(e, t, t === h ? Fe : h, "SRTP", s, n, {
  srtp: o
});
const rm = {
  id: "webrtc",
  name: "WebRTC",
  title: "A Video Call",
  layer: 7,
  nodes: ["client", "router", "internet", "relay", "web", "remote", "peer"],
  latency: {
    "client-web": 0.017,
    "client-relay": 0.01,
    "web-peer": 0.02,
    "client-peer": 0.025
  },
  labels: {
    relay: ["STUN Server", Tr],
    web: ["call.example.com", ws],
    remote: ["Sam’s Router", Fe],
    peer: ["Sam’s Laptop", "192.168.0.23"]
  },
  legend: [["blue", "Signalling"], ["amber", "STUN and ICE"], ["teal", "DTLS"], ["violet", "Media"]],
  overview: {
    full: "Web Real-Time Communication",
    description: "WebRTC lets two browsers call each other, with audio, video and data going straight between them, not through a server. A server only introduces them: they swap descriptions of what they can send and where they can be reached (signalling), find a way through both home routers with ICE and STUN, encrypt with DTLS, and send the media over UDP as SRTP.",
    facts: [["Layer", "Application (Layer 7)"], ["Media over", "UDP (SRTP)"], ["Setup", "SDP, ICE, STUN, DTLS"], ["Encryption", "Always on"], ["Works in", "Every major browser"], ["Defined In", "W3C; RFC 8825 and others"]]
  },
  outro: {
    title: "On the call",
    desc: "Introduced by a server, then direct",
    text: "The signalling server passed the offer and the answer between the two browsers, a STUN server told the laptop its public address, and an ICE check found a way through both home routers. After a DTLS handshake, encrypted audio and video went straight from one laptop to the other. Press REPLAY to watch it again.",
    facts: [["Signalling", "Via call.example.com"], ["Media path", "Direct, through 2 NATs"], ["Encryption", "DTLS, then SRTP"], ["If blocked", "A TURN relay"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Join the Call",
    desc: "Through a signalling server",
    detail: "The laptop opens a call page on call.example.com, and the page keeps a WebSocket open to the server, inside TLS. It joins room 42, where Sam is already waiting. The server will pass messages between the two browsers. WebRTC doesn’t say how: every app does this signalling its own way.",
    facts: [["Signalling", "The app’s own server"], ["Here", "A WebSocket in TLS"], ["Room", "42, with Sam"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "relay", "web", "remote", "peer"],
      frame: "call"
    }, l("client", "web", "blue", "JOIN", ["room 42"], Vn(0, sr, h, ws, "Application Data (WebSocket: join)", 27, true, "join", {
      opened: sm
    }), {
      locked: true
    }), l("web", "client", "blue", "SAM IS HERE", ["peer: Sam"], Vn(0.018, sr, ws, h, "Application Data (WebSocket: peer)", 28, false, "peer"), {
      locked: true
    })]
  }, {
    title: "Public Address?",
    desc: "Ask a STUN server",
    detail: "Behind its home router the laptop knows only its private address, 192.168.1.10, which nobody on the internet can reach. So it asks a STUN server named in the call page’s settings, with one small UDP request. The answer says where the request seemed to come from, 198.51.100.7 port 61022: the router’s public address and the port its NAT opened for this conversation.",
    facts: [["STUN", "UDP 3478"], ["Private", `${h}:${du}`], ["Public", `${se}:${Wn}`]],
    events: [l("client", "relay", "amber", "BINDING?", ["what is my address?"], ro(0.04, h, Tr, "STUN", "Binding Request", 62, {
      stun: {
        type: 1,
        tid: nr[0]
      }
    })), l("relay", "client", "amber", "YOUR ADDRESS", [`${se}:${Wn}`], ro(0.05, Tr, h, "STUN", `Binding Success Response XOR-MAPPED-ADDRESS: ${se}:${Wn}`, 74, {
      stun: {
        type: 257,
        tid: nr[0],
        attrs: [["XOR-MAPPED-ADDRESS", `${se}:${Wn}`]]
      }
    }))]
  }, {
    title: "The Offer",
    desc: "An SDP description, via the server",
    detail: "The browser writes an offer in SDP: the media it wants to send (Opus audio; video in VP8, H.264 and others), the fingerprint of its DTLS certificate, its ICE user name and password, and its candidates, the addresses it might be reached at. Its private address is hidden behind a random .local name. The signalling server passes the offer on to Sam.",
    facts: [["Format", "SDP, in a JSON message"], ["Candidates", ".local name, 198.51.100.7"], ["Size", "About 4.7 KB"]],
    events: [l("client", "web", "blue", "OFFER", ["SDP: audio, video", "candidates"], Vn(0.07, sr, h, ws, "Application Data (WebSocket: offer)", 4738, true, "offer"), {
      locked: true
    }), l("web", "peer", "blue", "OFFER", ["to Sam"], Vn(0.088, Fd, ws, Fe, "Application Data (WebSocket: offer)", 4754, false, "offer", {
      opened: nm
    }), {
      locked: true
    })]
  }, {
    title: "The Answer",
    desc: "Sam’s browser replies",
    detail: "Sam accepts the call. Sam’s browser answers with SDP of its own: the codecs it picked from the offer, its certificate fingerprint, its ICE user name and password, and its candidates, including its public address, 198.51.100.200 port 49170, which it learned from a STUN server the same way. It also says it will start the encryption handshake. Now each browser knows where the other might be reached.",
    facts: [["Codecs", "Opus, VP8"], ["Sam’s address", `${Fe}:${rl}`], ["Starts DTLS", "Sam’s browser"]],
    events: [l("peer", "web", "blue", "ANSWER", ["SDP: Opus, VP8", "candidates"], Vn(2.4, Fd, Fe, ws, "Application Data (WebSocket: answer)", 2900, true, "answer"), {
      locked: true
    }), l("web", "client", "blue", "ANSWER", ["from Sam"], Vn(2.421, sr, ws, h, "Application Data (WebSocket: answer)", 2916, false, "answer"), {
      locked: true
    })]
  }, {
    title: "Punch Through",
    desc: "Checks straight to each other",
    detail: "Now the browsers try pairs of addresses with STUN checks sent straight to each other (ICE). Each check also opens a way back through the sender’s own router, so once both sides have sent one, checks get through both NATs. This one is answered: the direct path works. The laptop then repeats the check with USE-CANDIDATE, choosing this pair for the call.",
    facts: [["Checks", "STUN, peer to peer"], ["Protected by", "The ICE password"], ["Result", "A direct path"]],
    events: [l("client", "peer", "amber", "CHECK", [`to ${Fe}:${rl}`], ro(2.44, h, Fe, "STUN", "Binding Request user: q7Rz:Hk2w", 130, {
      stun: {
        type: 1,
        tid: nr[1],
        attrs: [["USERNAME", "q7Rz:Hk2w"], ["PRIORITY", 1853824767], ["ICE-CONTROLLING"], ["MESSAGE-INTEGRITY"], ["FINGERPRINT"]]
      }
    })), l("peer", "client", "amber", "IT WORKS", ["direct path"], ro(2.466, Fe, h, "STUN", `Binding Success Response XOR-MAPPED-ADDRESS: ${se}:${Wn}`, 106, {
      stun: {
        type: 257,
        tid: nr[1],
        peer: true,
        attrs: [["XOR-MAPPED-ADDRESS", `${se}:${Wn}`], ["MESSAGE-INTEGRITY"], ["FINGERPRINT"]]
      }
    })), {
      type: "note",
      at: "internet",
      text: "THROUGH BOTH ROUTERS",
      tone: "green"
    }]
  }, {
    title: "DTLS Handshake",
    desc: "Keys for the media",
    detail: "Over the same path the browsers run a DTLS handshake: TLS for UDP. Their certificates are self-signed, so each checks the other’s against the fingerprint in the SDP, which came through the signalling server inside TLS. The handshake also agrees the keys for SRTP, which encrypts the audio and video. WebRTC never sends media unencrypted.",
    facts: [["DTLS", "1.2, TLS over UDP"], ["Certificates", "Checked by fingerprint"], ["Gives", "The SRTP keys"]],
    events: [l("peer", "client", "teal", "CLIENT HELLO", [], or(2.47, Fe, "Client Hello", 218, "Client Hello", [{
      msg: 1,
      mseq: 0,
      epoch: 0,
      seq: 0,
      body: 151,
      what: ["Cipher suites: ECDHE-ECDSA with AES-GCM, and others", "use_srtp: the SRTP protection it supports"]
    }]), {
      quick: true
    }), l("client", "peer", "teal", "SERVER HELLO", ["certificate"], or(2.497, h, "Server Hello, Certificate, Key Exchange, Cert Request, Hello Done", 714, "Server Hello … Server Hello Done", [{
      msg: 2,
      mseq: 0,
      epoch: 0,
      seq: 0,
      body: 88,
      what: ["Chosen: ECDHE-ECDSA-AES128-GCM-SHA256", "use_srtp: SRTP_AEAD_AES_128_GCM"]
    }, {
      msg: 11,
      mseq: 1,
      epoch: 0,
      seq: 1,
      body: 322,
      what: ["A self-signed certificate the browser made; its fingerprint was in the offer"]
    }, {
      msg: 12,
      mseq: 2,
      epoch: 0,
      seq: 2,
      body: 111,
      what: ["Its half of an X25519 key exchange, signed"]
    }, {
      msg: 13,
      mseq: 3,
      epoch: 0,
      seq: 3,
      body: 26,
      what: ["Asks Sam’s browser for its certificate too"]
    }, {
      msg: 14,
      mseq: 4,
      epoch: 0,
      seq: 4,
      body: 0
    }]), {
      quick: true
    }), l("peer", "client", "teal", "CERTIFICATE", ["Finished"], or(2.53, Fe, "Certificate, Key Exchange, Cert Verify, Change Cipher Spec, Finished", 622, "Certificate … Finished", [{
      msg: 11,
      mseq: 1,
      epoch: 0,
      seq: 1,
      body: 322,
      what: ["Sam’s self-signed certificate; its fingerprint was in the answer"]
    }, {
      msg: 16,
      mseq: 2,
      epoch: 0,
      seq: 2,
      body: 33,
      what: ["Its half of the X25519 key exchange"]
    }, {
      msg: 15,
      mseq: 3,
      epoch: 0,
      seq: 3,
      body: 75,
      what: ["A signature that proves it holds the certificate’s key"]
    }, {
      ccs: true,
      epoch: 0,
      seq: 4
    }, {
      sealed: 48,
      epoch: 1,
      seq: 0
    }]), {
      quick: true
    }), l("client", "peer", "teal", "FINISHED", [], or(2.557, h, "Change Cipher Spec, Finished", 117, "Change Cipher Spec, Finished", [{
      ccs: true,
      epoch: 0,
      seq: 5
    }, {
      sealed: 48,
      epoch: 1,
      seq: 0
    }]), {
      quick: true,
      locked: true
    })]
  }, {
    title: "Media Flows",
    desc: "Audio and video, direct",
    detail: "Audio goes in an SRTP packet every 20 ms, and video as frames split over several packets. Each packet has a readable RTP header (sequence number, timestamp, stream ID) and encrypted media. None of it passes through call.example.com. Both browsers watch delay and loss and adjust the video quality to suit, and a data channel for chat or files can share the same path.",
    facts: [["Audio", "Opus, a packet per 20 ms"], ["Video", "VP8, adapts to the network"], ["Server sees", "None of it"]],
    events: [{
      type: "stream",
      from: "client",
      to: "peer",
      color: "violet",
      label: "AUDIO",
      locked: true,
      payload: ["Opus, every 20 ms"],
      packets: [0, 1, 2].map(e => l("client", "peer", "violet", "AUDIO", [], Kd(2.59 + e * 0.02, h, `PT=111, SSRC=0x5D2E81A4, Seq=${9021 + e}, Time=${416820 + e * 960}`, 144, {
        pt: 111,
        seq: 9021 + e,
        ts: 416820 + e * 960,
        ssrc: 1563328932,
        level: 38 + e,
        tw: 12 + e,
        media: 62
      })))
    }, {
      type: "stream",
      from: "peer",
      to: "client",
      color: "violet",
      label: "VIDEO",
      locked: true,
      payload: ["VP8, a frame in 3 packets"],
      packets: [0, 1, 2].map(e => l("peer", "client", "violet", "VIDEO", [], Kd(2.66 + e * 0.002, Fe, `PT=96, SSRC=0x1B7C3F90, Seq=${30117 + e}, Time=2286000${e === 2 ? ", Mark" : ""}`, e === 2 ? 812 : 1182, {
        video: true,
        pt: 96,
        marker: e === 2,
        seq: 30117 + e,
        ts: 2286000,
        ssrc: 461127568,
        sent: 2772752 + e,
        tw: 40 + e,
        media: e === 2 ? 730 : 1100
      })))
    }]
  }, {
    title: "Peer to Peer",
    desc: "And when it can’t be",
    detail: "The server helped the two browsers find each other, then stepped aside: the call goes straight between the two homes. When a network won’t let direct packets through (some company firewalls, some mobile networks), ICE falls back to a TURN server that relays the encrypted media without being able to read it. Group calls usually send media through a server too, called an SFU.",
    facts: [["Media path", "Laptop to laptop"], ["Fallback", "TURN relay (encrypted)"], ["Group calls", "Usually via an SFU"]],
    events: [{
      type: "note",
      at: "internet",
      text: "NO SERVER IN THE MIDDLE",
      tone: "navy"
    }]
  }]
};
const fs = "192.168.1.20";
const fn = "203.0.113.10";
const nn = "00:00:5e:00:53:10";
const on = "00:00:5e:00:53:20";
const im = "00:00:5e:00:53:01";
const Bd = q(h, 50532, fs, 445);
const lm = q(h, 52344, fn, 443);
const cm = q(se, 40112, fn, 443);
const Lt = e => `${e.toFixed(6)}s`;
const Oo = e => `Seen going into the switch, port ${e}`;
const dm = e => `Seen leaving the switch, port ${e}`;
const Yn = (e, t) => ({
  copyOf: -e,
  at: dm(t)
});
const hm = {
  id: "ethernet",
  name: "Ethernet",
  title: "Frames & Switches",
  layer: 2,
  nodes: ["client", "switch", "lan", "router", "isp"],
  links: ["client-switch", "switch-lan", "switch-router", "router-isp"],
  lifelines: ["client", "switch", "lan", "router", "isp"],
  latency: {
    "client-switch": 0.000001,
    "switch-lan": 0.000001,
    "switch-router": 0.000001,
    "router-isp": 0.002
  },
  labels: {
    client: ["Client", "MAC …:53:10"],
    lan: ["NAS", "MAC …:53:20"],
    router: ["Router", "MAC …:53:01"],
    isp: ["ISP Router", "MAC …:53:fe"]
  },
  legend: [["slate", "ARP"], ["green", "To the NAS"], ["amber", "To the internet"]],
  overview: {
    full: "Ethernet and Switches",
    description: "Ethernet carries almost every wired network, and Wi-Fi access points pass their traffic on to it. Every network card has a 48-bit MAC address. A frame says which card it is for and which card sent it, and a switch delivers it: it learns which port each address is behind from the frames it sees, and sends each frame only where it needs to go.",
    facts: [["Layer", "Data Link (Layer 2)"], ["Address", "48-bit MAC"], ["Header", "14 bytes, plus a 4-byte FCS"], ["Frame size", "64 to 1,518 bytes"], ["Speeds", "10 Mb/s to 800 Gb/s"], ["Defined In", "IEEE 802.3"]]
  },
  outro: {
    title: "Switched",
    desc: "Learned, flooded, forwarded",
    text: "The switch learned where the laptop and the NAS were from the frames they sent, flooded only the broadcast, and sent every other frame out of just the port it needed. MAC addresses carried each frame across one link; at the router the packet moved into a new frame. Press REPLAY to watch it again.",
    facts: [["Learned", "2 addresses, 2 ports"], ["Flooded", "Only the broadcast"], ["Frame", "14-byte header, 4-byte FCS"], ["Forgets after", "5 minutes unused"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Who Has the NAS?",
    desc: "A broadcast asks for a MAC address",
    detail: "The laptop wants to reach the NAS at 192.168.1.20. On a local network, frames are delivered by MAC address, and the laptop doesn’t know the NAS’s yet. So it sends an ARP request to ff:ff:ff:ff:ff:ff, the broadcast address, into port 1 of the switch.",
    facts: [["Looking for", fs], ["Sent to", "ff:ff:ff:ff:ff:ff (all)"], ["Into", "Switch port 1"]],
    events: [{
      type: "show",
      nodes: ["switch", "lan", "router"],
      frame: "switched"
    }, l("client", "switch", "slate", "ARP REQUEST", ["who has 192.168.1.20?", "to ff:ff:ff:ff:ff:ff"], {
      time: Lt(0),
      src: nn,
      dst: "Broadcast",
      proto: "ARP",
      info: "In port 1 · Who has 192.168.1.20? Tell 192.168.1.10",
      len: "60 B",
      wire: {
        arp: {
          op: 1,
          sender: [nn, h],
          target: ["00:00:00:00:00:00", fs]
        },
        at: Oo(1)
      }
    })]
  }, {
    title: "Learn, Then Flood",
    desc: "The switch notes where the laptop is",
    detail: "A switch reads each frame’s source address and notes it in its MAC table: 00:00:5e:00:53:10 is on port 1. A broadcast is for everyone, so it sends a copy out of every other port: to the NAS on port 2 and the router on port 8. Frames for unknown addresses are flooded too.",
    facts: [["Learned", "…:53:10 is on port 1"], ["Copies", "Out of every other port"], ["Unknown address", "Flooded the same way"]],
    events: [{
      type: "note",
      at: "switch",
      text: "…:53:10 IS ON PORT 1",
      tone: "navy"
    }, {
      type: "stream",
      from: "switch",
      to: "lan",
      color: "slate",
      label: "ARP REQUEST",
      payload: ["copies out of ports 2 and 8"],
      spacing: 0,
      packets: [l("switch", "lan", "slate", "ARP REQUEST", ["flooded: port 2"], {
        time: Lt(0.000005),
        src: nn,
        dst: "Broadcast",
        proto: "ARP",
        info: "Out port 2 (flooded) · Who has 192.168.1.20?",
        len: "60 B",
        wire: Yn(1, 2)
      }), l("switch", "router", "slate", "ARP REQUEST", ["flooded: port 8"], {
        time: Lt(0.000005),
        src: nn,
        dst: "Broadcast",
        proto: "ARP",
        info: "Out port 8 (flooded) · Who has 192.168.1.20?",
        len: "60 B",
        wire: Yn(2, 8)
      })]
    }]
  }, {
    title: "Only the NAS Answers",
    desc: "The reply goes to one port",
    detail: "Every device reads the request, but only the NAS has 192.168.1.20, so only it answers, straight to the laptop’s MAC; the router ignores it. The switch learns that 00:00:5e:00:53:20 is on port 2. It already knows where the laptop is, so the reply leaves by port 1 alone.",
    facts: [["Answer", "To the laptop only"], ["Learned", "…:53:20 is on port 2"], ["Out of", "Port 1"]],
    events: [l("lan", "switch", "slate", "ARP REPLY", ["192.168.1.20 is at", on], {
      time: Lt(0.000052),
      src: on,
      dst: nn,
      proto: "ARP",
      info: `In port 2 · 192.168.1.20 is at ${on}`,
      len: "60 B",
      wire: {
        arp: {
          op: 2,
          sender: [on, fs],
          target: [nn, h]
        },
        at: Oo(2)
      }
    }), {
      type: "note",
      at: "switch",
      text: "…:53:20 IS ON PORT 2",
      tone: "navy"
    }, l("switch", "client", "slate", "ARP REPLY", ["port 1 only"], {
      time: Lt(0.000057),
      src: on,
      dst: nn,
      proto: "ARP",
      info: `Out port 1 only · 192.168.1.20 is at ${on}`,
      len: "60 B",
      wire: Yn(1, 1)
    })]
  }, {
    title: "Port to Port",
    desc: "Frames go only where they must",
    detail: "The laptop connects to the NAS. Each frame starts with the NAS’s MAC, then its own, then a type: 0x0800, an IPv4 packet. After the packet, the card adds a 4-byte checksum. The switch looks up the destination and sends each frame out of port 2 only. The router never sees them.",
    facts: [["Header", "To, from, type: 14 bytes"], ["Checksum", "4 bytes, added by the card"], ["Router sees", "Nothing"]],
    events: [l("client", "switch", "green", "SYN", [`to ${on}`, "type 0x0800 (IPv4)"], {
      time: Lt(0.000231),
      src: h,
      dst: fs,
      proto: "TCP",
      info: "In port 1 · 50532 → 445 [SYN]",
      len: "66 B",
      wire: {
        ...P(Bd, h, "S"),
        at: Oo(1)
      }
    }), l("switch", "lan", "green", "SYN", ["out of port 2 only"], {
      time: Lt(0.000236),
      src: h,
      dst: fs,
      proto: "TCP",
      info: "Out port 2 · 50532 → 445 [SYN]",
      len: "66 B",
      wire: Yn(1, 2)
    }), l("lan", "switch", "green", "SYN-ACK", [], {
      time: Lt(0.000281),
      src: fs,
      dst: h,
      proto: "TCP",
      info: "In port 2 · 445 → 50532 [SYN, ACK]",
      len: "66 B",
      wire: {
        ...P(Bd, fs, "SA"),
        at: Oo(2)
      }
    }, {
      quick: true
    }), l("switch", "client", "green", "SYN-ACK", [], {
      time: Lt(0.000286),
      src: fs,
      dst: h,
      proto: "TCP",
      info: "Out port 1 · 445 → 50532 [SYN, ACK]",
      len: "66 B",
      wire: Yn(1, 1)
    }, {
      quick: true
    })]
  }, {
    title: "Off the Network",
    desc: "A frame for the router",
    detail: "Next the laptop opens a website at 203.0.113.10. That address isn’t on the local network, so the frame goes to the router: the router’s MAC, known from an earlier ARP, is the destination, while the packet inside still names 203.0.113.10. The switch sends it out of port 8.",
    facts: [["Frame to", "The router’s MAC"], ["Packet to", fn], ["Out of", "Port 8"]],
    events: [l("client", "switch", "amber", "SYN", [`to ${im}`, "IP packet to 203.0.113.10"], {
      time: Lt(0.004128),
      src: h,
      dst: fn,
      proto: "TCP",
      info: "In port 1 · 52344 → 443 [SYN] (frame to the router)",
      len: "66 B",
      wire: {
        ...P(lm, h, "S"),
        at: Oo(1)
      }
    }), l("switch", "router", "amber", "SYN", ["out of port 8"], {
      time: Lt(0.004133),
      src: h,
      dst: fn,
      proto: "TCP",
      info: "Out port 8 · 52344 → 443 [SYN]",
      len: "66 B",
      wire: Yn(1, 8)
    })]
  }, {
    title: "A New Frame",
    desc: "Every hop rewraps the packet",
    detail: "The router takes the packet out of the frame, lowers its TTL and swaps in its public address (NAT). Then it puts the packet in a new frame for its next link: its internet-side MAC as the source, the provider’s router as the destination. MAC addresses only ever cross one link.",
    facts: [["From", "The router’s internet port"], ["To", "The provider’s router"], ["Packet to", `Still ${fn}`]],
    events: [{
      type: "show",
      nodes: ["isp"],
      frame: "uplink"
    }, l("router", "isp", "amber", "NEW FRAME", ["from the router’s internet port", "IP still to 203.0.113.10"], {
      time: Lt(0.00419),
      src: se,
      dst: fn,
      proto: "TCP",
      info: "TTL 127 · 40112 → 443 [SYN] (new frame, after NAT)",
      len: "66 B",
      wire: {
        ...P(cm, se, "S", undefined, {
          seq: 0
        }),
        ttl: 127,
        ttlNote: "The laptop sent it with 128; the router took 1 when it passed it on.",
        natOf: -1,
        alias: [`${se}:40112`, `${h}:52344`]
      }
    })]
  }]
};
const _d = "00:00:5e:00:53:02";
const Gd = "00:00:5e:00:53:fe";
const Mo = "198.51.100.1";
const qo = "bng-1.example.net";
const ar = "alex@fibre.example";
const Ul = 12060;
const Wd = ["192.0.2.53", "192.0.2.54"];
const hu = {
  router: 1513918951,
  server: 495235116
};
const Lr = "203.0.113.10";
const pm = q(h, 52344, Lr, 443);
const um = q(se, 40112, Lr, 443);
const _e = (e, t, s, n, o, a) => ({
  time: x(e),
  src: t === "router" ? _d : Gd,
  dst: s === "all" ? "Broadcast" : s === "router" ? _d : Gd,
  proto: n,
  info: o,
  len: "60 B",
  wire: {
    pppoe: a
  }
});
const rr = (e, ...t) => ({
  code: e,
  session: e === 101 ? Ul : 0,
  tags: t
});
const yt = (e, t) => ({
  code: 0,
  session: Ul,
  [e]: t
});
const Vd = [["mru", 1492], ["magic", hu.router]];
const Yd = [["mru", 1492], ["auth", "chap"], ["magic", hu.server]];
const fm = [["ip", "0.0.0.0"], ["dns1", "0.0.0.0"], ["dns2", "0.0.0.0"]];
const Ai = [["ip", se], ["dns1", Wd[0]], ["dns2", Wd[1]]];
const mm = {
  id: "pppoe",
  name: "PPPoE",
  title: "Broadband Logins",
  layer: 2,
  nodes: ["client", "router", "bng"],
  latency: {
    "client-router": 0.001,
    "router-bng": 0.004
  },
  labels: {
    router: ["Home Router", "No IP address"]
  },
  legend: [["slate", "Discovery"], ["violet", "PPP setup"], ["amber", "Data"]],
  overview: {
    full: "Point-to-Point Protocol over Ethernet",
    description: "Many DSL and fibre providers make the home router log in before it gets online. PPPoE is how: the router finds the provider’s access server and opens a session with it, then runs PPP inside, agreeing on the link’s settings, logging in with the username and password from the provider and receiving its public IP address. Every packet then carries an 8-byte PPPoE header.",
    facts: [["Layer", "Data Link (Layer 2)"], ["Discovery", "PADI, PADO, PADR, PADS"], ["Login", "CHAP or PAP"], ["Address", "From IPCP"], ["Overhead", "8 bytes (MTU 1,492)"], ["Defined In", "RFC 2516, RFC 1661"]]
  },
  outro: {
    title: "Logged in",
    desc: "Found, agreed, checked, addressed",
    text: "The router found the provider’s access server, got a session, agreed on the link’s settings, proved its password without sending it and was given its public address. Every packet now travels inside that session, until a PADT ends it. Press REPLAY to watch it again.",
    facts: [["Messages", "17 to get online"], ["Password", "Never sent"], ["Public IP", se], ["Overhead", "8 bytes per packet"]]
  },
  start: {
    nodes: ["client", "router"],
    frame: "local"
  },
  steps: [{
    title: "Anyone There?",
    desc: "The router looks for an access server",
    detail: "The home router is plugged into the provider’s fibre or DSL line. Before it can log in, it has to find the provider’s access server, so it broadcasts a PADI: “PPPoE Active Discovery Initiation”. An access server answers with a PADO, an offer that names it: bng-1.example.net.",
    facts: [["Asks", "PADI, to everyone"], ["Answer", "PADO, from the server"], ["Ethernet type", "0x8863 (discovery)"]],
    events: [{
      type: "show",
      nodes: ["bng"],
      frame: "line"
    }, l("router", "bng", "slate", "PADI", ["is there an access server?", "to ff:ff:ff:ff:ff:ff"], _e(0, "router", "all", "PPPoED", "Active Discovery Initiation (PADI)", rr(9, ["service", ""], ["host"]))), l("bng", "router", "slate", "PADO", [`AC-Name: ${qo}`, "and a cookie"], {
      ..._e(0.006, "bng", "router", "PPPoED", `Active Discovery Offer (PADO) AC-Name='${qo}'`, rr(7, ["ac", qo], ["service", ""], ["cookie"], ["host"])),
      len: "73 B"
    })]
  }, {
    title: "Pick a Server",
    desc: "A session number for the line",
    detail: "If several servers answered, the router picks one and asks it directly with a PADR, sending back the cookie it was given. The server replies with a PADS carrying a session ID, 0x2f1c. From now on every frame between the two of them carries that number.",
    facts: [["Request", "PADR"], ["Confirmed", "PADS"], ["Session ID", "0x2f1c"]],
    events: [l("router", "bng", "slate", "PADR", ["this server, please", "with its cookie"], _e(0.011, "router", "bng", "PPPoED", "Active Discovery Request (PADR)", rr(25, ["service", ""], ["host"], ["cookie"]))), l("bng", "router", "slate", "PADS", ["session ID 0x2f1c"], _e(0.017, "bng", "router", "PPPoED", "Active Discovery Session-confirmation (PADS)", rr(101, ["service", ""], ["host"]))), {
      type: "note",
      at: "router",
      text: "SESSION 0x2F1C",
      tone: "navy"
    }]
  }, {
    title: "Link Settings",
    desc: "LCP agrees on size and login",
    detail: "Now PPP runs inside the session, starting with LCP. Each side asks for its settings: packets of at most 1,492 bytes, since PPPoE’s 8 bytes have to fit in Ethernet’s 1,500, and a random magic number to spot loops. The server also asks for a CHAP login. Both agree.",
    facts: [["Largest packet", "1,492 bytes (MRU)"], ["Login", "CHAP with MD5"], ["Ethernet type", "0x8864 (session)"]],
    events: [l("router", "bng", "violet", "LCP REQUEST", ["MRU 1492", "magic number"], _e(0.022, "router", "bng", "PPP LCP", "Configuration Request", yt("lcp", {
      code: 1,
      id: 1,
      opts: Vd
    }))), l("bng", "router", "violet", "LCP ACK", [], _e(0.026, "bng", "router", "PPP LCP", "Configuration Ack", yt("lcp", {
      code: 2,
      id: 1,
      opts: Vd
    })), {
      quick: true
    }), l("bng", "router", "violet", "LCP REQUEST", ["MRU 1492, log in with CHAP", "magic number"], _e(0.027, "bng", "router", "PPP LCP", "Configuration Request", yt("lcp", {
      code: 1,
      id: 1,
      opts: Yd
    }))), l("router", "bng", "violet", "LCP ACK", [], _e(0.032, "router", "bng", "PPP LCP", "Configuration Ack", yt("lcp", {
      code: 2,
      id: 1,
      opts: Yd
    })), {
      quick: true
    })]
  }, {
    title: "Log In",
    desc: "A password check without the password",
    detail: "The server sends a random challenge. The router answers with its username, alex@fibre.example, and an MD5 hash of the challenge and its password, so the password itself never crosses the line. The server checks the answer with the provider’s RADIUS server, then says Success.",
    facts: [["Username", ar], ["Sent", "A hash, not the password"], ["Checked by", "The provider’s RADIUS"]],
    events: [l("bng", "router", "violet", "CHALLENGE", ["16 random bytes"], _e(0.037, "bng", "router", "PPP CHAP", `Challenge (NAME='${qo}')`, yt("chap", {
      code: 1,
      id: 1,
      name: qo
    }))), l("router", "bng", "violet", "RESPONSE", [ar, "MD5(id, password, challenge)"], {
      ..._e(0.042, "router", "bng", "PPP CHAP", `Response (NAME='${ar}')`, yt("chap", {
        code: 2,
        id: 1,
        name: ar
      })),
      len: "61 B"
    }), {
      type: "note",
      at: "bng",
      text: "CHECKED WITH RADIUS",
      tone: "navy"
    }, l("bng", "router", "violet", "SUCCESS", ["logged in"], _e(0.061, "bng", "router", "PPP CHAP", "Success (MESSAGE='Welcome')", yt("chap", {
      code: 3,
      id: 1,
      message: "Welcome"
    })))]
  }, {
    title: "Get an Address",
    desc: "IPCP hands out the public IP",
    detail: "The server first tells the router its own end, 198.51.100.1. The router asks for an address and DNS servers, offering 0.0.0.0: “anything”. The server says no and suggests 198.51.100.7 and two DNS servers. The router asks again with those, and the server agrees.",
    facts: [["Public IP", se], ["DNS", "192.0.2.53, 192.0.2.54"], ["Other end", Mo]],
    events: [l("bng", "router", "violet", "IPCP REQUEST", ["my end: 198.51.100.1"], _e(0.061, "bng", "router", "PPP IPCP", `Configuration Request (IP ${Mo})`, yt("ipcp", {
      code: 1,
      id: 1,
      own: true,
      opts: [["ip", Mo]]
    })), {
      quick: true
    }), l("router", "bng", "violet", "IPCP ACK", [], _e(0.065, "router", "bng", "PPP IPCP", `Configuration Ack (IP ${Mo})`, yt("ipcp", {
      code: 2,
      id: 1,
      own: true,
      opts: [["ip", Mo]]
    })), {
      quick: true
    }), l("router", "bng", "violet", "IPCP REQUEST", ["address? 0.0.0.0", "DNS? 0.0.0.0"], _e(0.066, "router", "bng", "PPP IPCP", "Configuration Request (IP 0.0.0.0)", yt("ipcp", {
      code: 1,
      id: 1,
      opts: fm
    }))), l("bng", "router", "violet", "IPCP NAK", ["use 198.51.100.7", "DNS 192.0.2.53, .54"], _e(0.071, "bng", "router", "PPP IPCP", `Configuration Nak (IP ${se})`, yt("ipcp", {
      code: 3,
      id: 1,
      opts: Ai
    }))), l("router", "bng", "violet", "IPCP REQUEST", ["198.51.100.7, please"], _e(0.076, "router", "bng", "PPP IPCP", `Configuration Request (IP ${se})`, yt("ipcp", {
      code: 1,
      id: 2,
      opts: Ai
    }))), l("bng", "router", "violet", "IPCP ACK", ["agreed"], _e(0.081, "bng", "router", "PPP IPCP", `Configuration Ack (IP ${se})`, yt("ipcp", {
      code: 2,
      id: 2,
      opts: Ai
    }))), {
      type: "label",
      at: "router",
      label: ["Home Router", se]
    }]
  }, {
    title: "Online",
    desc: "Every packet in an 8-byte wrapper",
    detail: "The laptop opens a website. The router swaps in its public address (NAT) and sends the packet inside the session: a 6-byte PPPoE header, then 2 bytes saying “IPv4”. It also lowers the MSS the laptop offered from 1460 to 1452, so the replies fit in 1,492 bytes.",
    facts: [["Wrapper", "6 + 2 bytes"], ["Largest packet", "1,492 bytes"], ["MSS", "1460 → 1452 (clamped)"]],
    events: [{
      type: "camera",
      frame: "access"
    }, l("client", "router", "amber", "SYN", ["to 203.0.113.10:443", "MSS 1460"], {
      time: x(1.204),
      src: h,
      dst: Lr,
      proto: "TCP",
      info: "52344 → 443 [SYN] MSS=1460",
      len: "66 B",
      wire: P(pm, h, "S")
    }), l("router", "bng", "amber", "SYN", ["in session 0x2f1c", "MSS now 1452"], {
      time: x(1.205),
      src: se,
      dst: Lr,
      proto: "TCP",
      info: "PPPoE 0x2f1c · 40112 → 443 [SYN] MSS=1452",
      len: "74 B",
      wire: {
        ...P(um, se, "S", undefined, {
          seq: 0,
          mss: 1452,
          mssNote: "Lowered from 1460 by the router, so packets back fit in the 1,492 bytes PPPoE leaves."
        }),
        ttl: 127,
        ttlNote: "The laptop sent it with 128; the router took 1 when it passed it on.",
        natOf: -1,
        alias: [`${se}:40112`, `${h}:52344`],
        pppoe: {
          code: 0,
          session: Ul,
          ip: true
        }
      }
    })]
  }]
};
const So = "203.0.113.50";
const Kl = "198.51.100.200";
const Bl = "Via: SIP/2.0/UDP 192.168.1.10:5060;rport;branch=z9hG4bK";
const To = "Via: SIP/2.0/UDP 192.168.1.10:5060;rport=5060;received=198.51.100.7;branch=z9hG4bK";
const ba = "Via: SIP/2.0/UDP 203.0.113.50;branch=z9hG4bK";
const Sn = "From: \"Alice\" <sip:alice@example.net>;tag=f1c2";
const _l = "To: <sip:bob@example.net>";
const Fr = "To: <sip:bob@example.net>;tag=b8e4";
const jt = "Call-ID: call-7c2e@192.168.1.10";
const Gl = "Record-Route: <sip:203.0.113.50;lr>";
const Ir = (e, t, s) => ["v=0", `o=${e} IN IP4 ${t}`, "s=-", `c=IN IP4 ${t}`, "t=0 0", `m=audio ${s} RTP/AVP 0 101`, "a=rtpmap:0 PCMU/8000", "a=rtpmap:101 telephone-event/8000"];
const Pt = (e, t = []) => [...e, ...(t.length ? ["Content-Type: application/sdp"] : []), `Content-Length: ${K(...t)}`, "", ...t];
const jd = {
  client: [h, 5060],
  relay: [So, 5060],
  peer: [Kl, 5060]
};
const Ge = (e, t, s, n, o) => {
  const [a, r] = jd[t];
  const [i, c] = jd[s];
  return {
    time: x(e),
    src: a,
    dst: i,
    proto: o.includes("v=0") ? "SIP/SDP" : "SIP",
    info: n,
    len: `${Math.max(60, 42 + K(...o))} B`,
    wire: {
      udp: {
        sport: r,
        dport: c,
        data: {
          text: o,
          name: "SIP"
        }
      }
    }
  };
};
const zd = {
  client: [h, 49170],
  toAlice: [So, 40000],
  toBob: [So, 40002],
  peer: [Kl, 49172]
};
const ir = (e, t, s, n, o) => {
  const [a, r] = zd[t];
  const [i, c] = zd[s];
  const {
    seq: d,
    ts: p,
    ssrc: u
  } = n;
  return {
    time: x(e),
    src: a,
    dst: i,
    proto: "RTP",
    info: `PT=ITU-T G.711 PCMU, SSRC=0x${u.toString(16).toUpperCase()}, Seq=${d + o}, Time=${p + o * 160}`,
    len: "214 B",
    wire: {
      udp: {
        sport: r,
        dport: c,
        data: {
          rtp: {
            codec: "pcmu",
            pt: 0,
            seq: d + o,
            ts: p + o * 160,
            ssrc: u,
            marker: o === 0,
            audio: 160
          }
        }
      }
    }
  };
};
const Qd = {
  seq: 11203,
  ts: 54720,
  ssrc: 983503556
};
const Xd = {
  seq: 30871,
  ts: 913600,
  ssrc: 2010179931
};
const Zd = (e, t) => Pt(["REGISTER sip:example.net SIP/2.0", `${Bl}-r${e}`, "Max-Forwards: 70", "From: <sip:alice@example.net>;tag=a73k", "To: <sip:alice@example.net>", "Call-ID: reg-5e1f@192.168.1.10", `CSeq: ${e} REGISTER`, "Contact: <sip:alice@192.168.1.10:5060>", ...(t ? ["Authorization: Digest username=\"alice\", realm=\"example.net\", nonce=\"7b2e91c4\", uri=\"sip:example.net\", response=\"4c1e7a9d02b35f68e1a9c47d0b2f6e13\", qop=auth, nc=00000001, cnonce=\"d3f0\""] : []), "Expires: 3600"]);
const Jd = (e, t, s) => Pt([`SIP/2.0 ${t}`, `${To}-r${e}`, "From: <sip:alice@example.net>;tag=a73k", "To: <sip:alice@example.net>;tag=s91d", "Call-ID: reg-5e1f@192.168.1.10", `CSeq: ${e} REGISTER`, ...s]);
const ym = Pt(["INVITE sip:bob@example.net SIP/2.0", `${Bl}-i1`, "Max-Forwards: 70", Sn, _l, jt, "CSeq: 1 INVITE", "Contact: <sip:alice@192.168.1.10:5060>"], Ir("alice 2890 2890", "192.168.1.10", 49170));
const wm = Pt(["SIP/2.0 100 Trying", `${To}-i1`, Sn, _l, jt, "CSeq: 1 INVITE"]);
const gm = Pt(["INVITE sip:bob@192.168.0.23:5060 SIP/2.0", Gl, `${ba}-p1`, `${To}-i1`, "Max-Forwards: 69", Sn, _l, jt, "CSeq: 1 INVITE", "Contact: <sip:alice@192.168.1.10:5060>"], Ir("alice 2890 2890", So, 40002));
const eh = (e, t) => Pt([`SIP/2.0 ${e}`, `${ba}-p1`, `${To}-i1`, Gl, Sn, Fr, jt, "CSeq: 1 INVITE", "Contact: <sip:bob@192.168.0.23:5060>"], t);
const th = (e, t) => Pt([`SIP/2.0 ${e}`, `${To}-i1`, Gl, Sn, Fr, jt, "CSeq: 1 INVITE", "Contact: <sip:bob@192.168.0.23:5060>"], t);
const Sm = Pt(["ACK sip:bob@192.168.0.23:5060 SIP/2.0", `${Bl}-a1`, "Route: <sip:203.0.113.50;lr>", "Max-Forwards: 70", Sn, Fr, jt, "CSeq: 1 ACK"]);
const Tm = Pt(["ACK sip:bob@192.168.0.23:5060 SIP/2.0", `${ba}-p2`, `${To}-a1`, "Max-Forwards: 69", Sn, Fr, jt, "CSeq: 1 ACK"]);
const Ur = "From: <sip:bob@example.net>;tag=b8e4";
const Kr = "To: \"Alice\" <sip:alice@example.net>;tag=f1c2";
const bm = Pt(["BYE sip:alice@192.168.1.10:5060 SIP/2.0", "Via: SIP/2.0/UDP 192.168.0.23:5060;rport;branch=z9hG4bK-b1", "Route: <sip:203.0.113.50;lr>", "Max-Forwards: 70", Ur, Kr, jt, "CSeq: 1 BYE"]);
const Wl = "Via: SIP/2.0/UDP 192.168.0.23:5060;rport=5060;received=198.51.100.200;branch=z9hG4bK-b1";
const vm = Pt(["BYE sip:alice@192.168.1.10:5060 SIP/2.0", `${ba}-p3`, Wl, "Max-Forwards: 69", Ur, Kr, jt, "CSeq: 1 BYE"]);
const km = Pt(["SIP/2.0 200 OK", `${ba}-p3`, Wl, Ur, Kr, jt, "CSeq: 1 BYE"]);
const Pm = Pt(["SIP/2.0 200 OK", Wl, Ur, Kr, jt, "CSeq: 1 BYE"]);
const Am = {
  id: "sip",
  name: "SIP",
  title: "Internet Phone Calls",
  layer: 7,
  nodes: ["client", "router", "internet", "relay", "remote", "peer"],
  lifelines: ["client", "relay", "peer"],
  latency: {
    "client-relay": 0.02,
    "relay-peer": 0.025
  },
  labels: {
    client: ["Alice", h],
    relay: ["SIP Server", So],
    remote: ["Bob’s Router", Kl],
    peer: ["Bob", "192.168.0.23"]
  },
  legend: [["amber", "Requests"], ["violet", "Responses"], ["green", "Voice (RTP)"]],
  overview: {
    full: "Session Initiation Protocol",
    description: "SIP sets up phone calls over the internet: office desk phones, phone apps and the providers behind them. A phone signs in with its provider’s SIP server. To call someone it sends an INVITE; the other phone rings and answers, and the two agree on how to send the voice, which then flows as RTP. The messages are plain text, a lot like HTTP.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "UDP or TCP 5060"], ["Call setup", "INVITE, 180, 200, ACK"], ["Voice", "RTP, described by SDP"], ["Codec here", "G.711, 64 kbit/s"], ["Defined In", "RFC 3261"]]
  },
  outro: {
    title: "Call ended",
    desc: "Signed in, rang, talked, hung up",
    text: "Alice’s phone signed in with a password it never sent, invited Bob’s phone through the SIP server, heard it ring, and talked over RTP until Bob hung up with a BYE. SIP only set the call up and took it down; the voice travelled as packets of its own. Press REPLAY to watch it again.",
    facts: [["Requests", "REGISTER, INVITE, ACK, BYE"], ["Voice", "50 packets a second each way"], ["Through", "The provider’s server"], ["Encrypted", "No (SIPS and SRTP add it)"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Sign In",
    desc: "The phone tells the server where it is",
    detail: "Alice’s phone, an app on her laptop, registers with her provider’s SIP server: alice@example.net can be reached here. The server answers 401 with a challenge, so the phone asks again with a hash made from the challenge and its password. 200 OK: registered for an hour.",
    facts: [["Port", "UDP 5060"], ["Login", "A hash, not the password"], ["Good for", "3600 s, then again"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "relay"],
      frame: "sipserver"
    }, l("client", "relay", "amber", "REGISTER", ["alice@example.net", "is here"], Ge(0, "client", "relay", "Request: REGISTER sip:example.net", Zd(1, false))), l("relay", "client", "violet", "401", ["Unauthorized", "with a challenge"], Ge(0.021, "relay", "client", "Status: 401 Unauthorized", Jd(1, "401 Unauthorized", ["WWW-Authenticate: Digest realm=\"example.net\", nonce=\"7b2e91c4\", qop=\"auth\", algorithm=MD5"]))), l("client", "relay", "amber", "REGISTER", ["again, with a hash"], Ge(0.042, "client", "relay", "Request: REGISTER sip:example.net", Zd(2, true))), l("relay", "client", "violet", "200 OK", ["registered"], Ge(0.063, "relay", "client", "Status: 200 OK (REGISTER)", Jd(2, "200 OK", ["Contact: <sip:alice@192.168.1.10:5060>;expires=3600"])))]
  }, {
    title: "Call Bob",
    desc: "An INVITE, passed on by the server",
    detail: "Alice calls bob@example.net. Her INVITE carries SDP: G.711 audio, sent to her phone. The server answers 100 Trying, finds where Bob’s phone registered and passes the INVITE on, with its own Via and Record-Route and its own address in the SDP: the voice will go through it.",
    facts: [["To", "sip:bob@example.net"], ["Offer (SDP)", "G.711, port 49170"], ["100 Trying", "Stops Alice resending"]],
    events: [{
      type: "show",
      nodes: ["remote", "peer"],
      frame: "sip"
    }, l("client", "relay", "amber", "INVITE", ["call bob@example.net", "SDP: G.711 audio"], Ge(2.5, "client", "relay", "Request: INVITE sip:bob@example.net", ym)), l("relay", "client", "violet", "100 TRYING", [], Ge(2.521, "relay", "client", "Status: 100 Trying", wm), {
      quick: true
    }), l("relay", "peer", "amber", "INVITE", ["passed on to Bob", "voice via the server"], Ge(2.521, "relay", "peer", "Request: INVITE sip:bob@192.168.0.23:5060", gm))]
  }, {
    title: "Ringing",
    desc: "The answer retraces the route",
    detail: "Bob’s phone starts ringing and says so: 180 Ringing. Responses follow the Via headers back the way the request came, so it goes to the server, which removes its own Via and passes it on to Alice. Her phone plays the ringing tone.",
    facts: [["Response", "180 Ringing"], ["Route back", "The Via headers, in reverse"], ["Alice hears", "The ringing tone"]],
    events: [l("peer", "relay", "violet", "180 RINGING", ["Bob’s phone rings"], Ge(2.56, "peer", "relay", "Status: 180 Ringing", eh("180 Ringing"))), l("relay", "client", "violet", "180 RINGING", ["to Alice"], Ge(2.586, "relay", "client", "Status: 180 Ringing", th("180 Ringing")))]
  }, {
    title: "Answered",
    desc: "200 OK, then ACK",
    detail: "Bob picks up. His 200 OK carries his SDP answer: G.711, sent to his phone. The server swaps in its own address again before passing it to Alice. Her phone confirms with an ACK, which the server passes to Bob. The call is set up.",
    facts: [["Answer (SDP)", "G.711, port 49172"], ["Confirmed by", "ACK"], ["Voice goes to", "The server, ports 40000, 40002"]],
    events: [l("peer", "relay", "violet", "200 OK", ["Bob answers", "SDP: G.711 audio"], Ge(6.32, "peer", "relay", "Status: 200 OK (INVITE)", eh("200 OK", Ir("bob 4410 4410", "192.168.0.23", 49172)))), l("relay", "client", "violet", "200 OK", ["answered", "voice via the server"], Ge(6.346, "relay", "client", "Status: 200 OK (INVITE)", th("200 OK", Ir("bob 4410 4410", So, 40000)))), l("client", "relay", "amber", "ACK", [], Ge(6.367, "client", "relay", "Request: ACK sip:bob@192.168.0.23:5060", Sm), {
      quick: true
    }), l("relay", "peer", "amber", "ACK", [], Ge(6.388, "relay", "peer", "Request: ACK sip:bob@192.168.0.23:5060", Tm), {
      quick: true
    })]
  }, {
    title: "Talking",
    desc: "Voice flows as RTP",
    detail: "Now the voice: every 20 ms each phone sends an RTP packet with 160 bytes of G.711 sound, a sequence number and a timestamp, over UDP. They go to the server, which passes them on to the other phone. SIP stays quiet while they talk.",
    facts: [["Every", "20 ms, 160 bytes of sound"], ["Carried by", "RTP over UDP"], ["SIP meanwhile", "Nothing to say"]],
    events: [l("client", "relay", "green", "VOICE", ["20 ms of Alice"], ir(6.42, "client", "toAlice", Qd, 0)), l("relay", "peer", "green", "VOICE", ["20 ms of Alice"], ir(6.441, "toBob", "peer", Qd, 0), {
      quick: true
    }), l("peer", "relay", "green", "VOICE", ["20 ms of Bob"], ir(6.47, "peer", "toBob", Xd, 0)), l("relay", "client", "green", "VOICE", ["20 ms of Bob"], ir(6.496, "toAlice", "client", Xd, 0), {
      quick: true
    })]
  }, {
    title: "Hang Up",
    desc: "BYE, and 200 OK",
    detail: "Bob hangs up: his phone sends BYE, routed through the server as the Record-Route asked, and Alice’s phone answers 200 OK. Both stop sending voice. The call took four kinds of request; the voice itself was never part of SIP.",
    facts: [["Request", "BYE"], ["Answer", "200 OK"], ["Then", "No more RTP"]],
    events: [l("peer", "relay", "amber", "BYE", ["Bob hangs up"], Ge(9.8, "peer", "relay", "Request: BYE sip:alice@192.168.1.10:5060", bm)), l("relay", "client", "amber", "BYE", ["to Alice"], Ge(9.826, "relay", "client", "Request: BYE sip:alice@192.168.1.10:5060", vm)), l("client", "relay", "violet", "200 OK", [], Ge(9.847, "client", "relay", "Status: 200 OK (BYE)", km), {
      quick: true
    }), l("relay", "peer", "violet", "200 OK", [], Ge(9.868, "relay", "peer", "Status: 200 OK (BYE)", Pm), {
      quick: true
    })]
  }]
};
const va = "192.168.1.64";
const Me = "rtsp://192.168.1.64:554/stream1";
const Em = q(h, 52510, va, 554);
const jn = "User-Agent: LibVLC/3.0.20 (LIVE555 Streaming Media v2016.11.28)";
const lr = e => `Authorization: Digest username="viewer", realm="IP Camera", nonce="3b8f2c61a4d0", uri="${e}", response="8d1f0c3e6a5b4927f1e0d2c3b4a59687"`;
const an = "1185d200";
const xm = "PLAY⁠";
const It = (e, t = []) => [...e, ...(t.length ? ["Content-Type: application/sdp", `Content-Length: ${K(...t)}`] : []), "", ...t];
const pu = (e, t, s, n) => ({
  time: x(e),
  src: t,
  dst: t === h ? va : h,
  proto: n.includes("v=0") ? "RTSP/SDP" : "RTSP",
  info: s,
  len: `${j(K(...n))} B`,
  wire: P(Em, t, "PA", {
    text: n,
    name: "RTSP"
  })
});
const zn = (e, t, s) => pu(e, h, t, s);
const Qn = (e, t, s) => pu(e, va, t, s);
const Cm = ["v=0", "o=- 1701864000 1 IN IP4 192.168.1.64", "s=Camera", "c=IN IP4 0.0.0.0", "t=0 0", "a=control:*", "m=video 0 RTP/AVP 96", "a=rtpmap:96 H264/90000", "a=fmtp:96 packetization-mode=1;profile-level-id=640028", "a=control:trackID=1"];
const Xn = {
  seq: 27493,
  ts: 3725434208,
  ssrc: 1511800443
};
const $m = (e, t, s) => ({
  time: x(e),
  src: va,
  dst: h,
  proto: "RTP",
  info: `PT=H.264 (96), SSRC=0x${Xn.ssrc.toString(16).toUpperCase()}, Seq=${Xn.seq + t}, Time=${Xn.ts}${t === 2 ? ", Mark" : ""}`,
  len: `${56 + s} B`,
  wire: {
    udp: {
      sport: 6970,
      dport: 50000,
      data: {
        rtp: {
          codec: "h264",
          pt: 96,
          seq: Xn.seq + t,
          ts: Xn.ts,
          ssrc: Xn.ssrc,
          marker: t === 2,
          start: t === 0,
          end: t === 2,
          video: s
        }
      }
    }
  }
});
const Lm = {
  id: "rtsp",
  name: "RTSP",
  title: "IP Camera Streams",
  layer: 7,
  nodes: ["client", "router", "cam"],
  latency: {
    "client-cam": 0.002
  },
  legend: [["green", "TCP"], ["amber", "Requests"], ["violet", "Replies"], ["blue", "Video (RTP)"]],
  overview: {
    full: "Real Time Streaming Protocol",
    description: "RTSP is how video players, recorders and security apps get live video from IP cameras. It works like a remote control: the player asks what the camera offers, sets up a stream, and says PLAY and later TEARDOWN, in text messages much like HTTP. The video itself doesn’t travel in RTSP: it flows separately as RTP, here over UDP.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "TCP 554"], ["Controls", "SETUP, PLAY, TEARDOWN"], ["Video", "RTP, described by SDP"], ["Codec here", "H.264"], ["Defined In", "RFC 2326 (2.0: RFC 7826)"]]
  },
  outro: {
    title: "Watched",
    desc: "Described, set up, played, stopped",
    text: "VLC asked the camera what it had, logged in with a hash of its password, set up one video track and pressed PLAY. The video came as RTP packets on ports of its own, a key frame in three pieces, until TEARDOWN ended the session. Press REPLAY to watch it again.",
    facts: [["Requests", "6 on one TCP connection"], ["Video", "RTP, UDP 6970 → 50000"], ["Key frame", "Split into 3 packets"], ["Session", `${an}, 60 s timeout`]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "What Can You Do?",
    desc: "OPTIONS over a TCP connection",
    detail: "VLC opens rtsp://192.168.1.64/stream1. It connects to the camera on TCP port 554 and starts with OPTIONS: which commands do you support? The camera lists them. As in HTTP, every request and reply is text; a CSeq header numbers them.",
    facts: [["Port", "TCP 554"], ["Asks", "OPTIONS"], ["Numbered by", "CSeq"]],
    events: [{
      type: "show",
      nodes: ["router", "cam"],
      frame: "camera"
    }, ...he({
      to: "cam",
      dst: va,
      sport: 52510,
      dport: 554,
      t: [0, 0.002, 0.004]
    }), l("client", "cam", "amber", "OPTIONS", ["what can you do?"], zn(0.004, `OPTIONS ${Me} RTSP/1.0`, It([`OPTIONS ${Me} RTSP/1.0`, "CSeq: 1", jn]))), l("cam", "client", "violet", "200 OK", ["DESCRIBE, SETUP, PLAY…"], Qn(0.007, "Reply: RTSP/1.0 200 OK", It(["RTSP/1.0 200 OK", "CSeq: 1", "Public: OPTIONS, DESCRIBE, SETUP, PLAY, PAUSE, TEARDOWN, GET_PARAMETER"])))]
  }, {
    title: "Describe the Stream",
    desc: "SDP says what the video is",
    detail: "DESCRIBE asks for the stream’s description. The camera wants a login first: 401, with a digest challenge. VLC asks again with a hash of the password, and the reply carries SDP: one H.264 video track, RTP payload type 96, with a 90 kHz clock.",
    facts: [["Login", "Digest: a hash"], ["Video", "H.264, payload type 96"], ["Track", "trackID=1"]],
    events: [l("client", "cam", "amber", "DESCRIBE", ["describe stream1"], zn(0.01, `DESCRIBE ${Me} RTSP/1.0`, It([`DESCRIBE ${Me} RTSP/1.0`, "CSeq: 2", jn, "Accept: application/sdp"]))), l("cam", "client", "violet", "401", ["log in first"], Qn(0.013, "Reply: RTSP/1.0 401 Unauthorized", It(["RTSP/1.0 401 Unauthorized", "CSeq: 2", "WWW-Authenticate: Digest realm=\"IP Camera\", nonce=\"3b8f2c61a4d0\""]))), l("client", "cam", "amber", "DESCRIBE", ["again, with a hash"], zn(0.016, `DESCRIBE ${Me} RTSP/1.0`, It([`DESCRIBE ${Me} RTSP/1.0`, "CSeq: 3", lr(Me), jn, "Accept: application/sdp"]))), l("cam", "client", "violet", "200 OK", ["SDP: H.264 video", "track 1"], Qn(0.02, "Reply: RTSP/1.0 200 OK, with session description", It(["RTSP/1.0 200 OK", "CSeq: 3", `Content-Base: ${Me}/`], Cm)))]
  }, {
    title: "Set Up",
    desc: "Agree on ports for the video",
    detail: "SETUP for trackID=1 says how to deliver it: RTP over UDP, to the laptop’s ports 50000 (video) and 50001 (RTCP reports). The camera agrees, picks its own ports, 6970 and 6971, and opens a session, 1185d200, that every later request names.",
    facts: [["Transport", "RTP over UDP"], ["Laptop ports", "50000, 50001"], ["Session", an]],
    events: [l("client", "cam", "amber", "SETUP", ["track 1, RTP over UDP", "to ports 50000-50001"], zn(0.023, `SETUP ${Me}/trackID=1 RTSP/1.0`, It([`SETUP ${Me}/trackID=1 RTSP/1.0`, "CSeq: 4", lr(`${Me}/`), jn, "Transport: RTP/AVP;unicast;client_port=50000-50001"]))), l("cam", "client", "violet", "200 OK", ["session 1185d200", "from ports 6970-6971"], Qn(0.026, "Reply: RTSP/1.0 200 OK", It(["RTSP/1.0 200 OK", "CSeq: 4", `Session: ${an};timeout=60`, "Transport: RTP/AVP;unicast;client_port=50000-50001;server_port=6970-6971;ssrc=5A1C3E7B"])))]
  }, {
    title: "Play",
    desc: "The remote control’s PLAY button",
    detail: "PLAY starts the stream from now (npt=0.000-). The reply tells VLC which RTP sequence number and timestamp come first, so it can line the video up. From here on, the video doesn’t travel in RTSP at all.",
    facts: [["Range", "From now"], ["First packet", "Seq 27493"], ["Video arrives", "On the UDP ports"]],
    events: [l("client", "cam", "amber", xm, ["play from now"], zn(0.029, `PLAY ${Me}/ RTSP/1.0`, It([`PLAY ${Me}/ RTSP/1.0`, "CSeq: 5", lr(`${Me}/`), jn, `Session: ${an}`, "Range: npt=0.000-"]))), l("cam", "client", "violet", "200 OK", ["playing"], Qn(0.032, "Reply: RTSP/1.0 200 OK", It(["RTSP/1.0 200 OK", "CSeq: 5", `Session: ${an}`, `RTP-Info: url=${Me}/trackID=1;seq=27493;rtptime=3725434208`])))]
  }, {
    title: "Video Arrives",
    desc: "A key frame in RTP packets",
    detail: "The camera sends a key frame, a whole picture, in three RTP packets: H.264 fragments marked first, middle and last, with the marker bit on the last. All three carry the same 90 kHz timestamp. Smaller frames holding only the changes follow, 25 a second.",
    facts: [["Packets", "3 for one key frame"], ["Timestamp", "Same for the whole frame"], ["Frames", "25 a second"]],
    events: [{
      type: "stream",
      from: "cam",
      to: "client",
      color: "blue",
      label: "VIDEO",
      locked: true,
      payload: ["a key frame in 3 packets", "UDP 6970 → 50000"],
      packets: [0, 1, 2].map(e => l("cam", "client", "blue", "VIDEO", [], $m(0.034 + e * 0.001, e, e === 2 ? 900 : 1398)))
    }]
  }, {
    title: "Stop",
    desc: "TEARDOWN ends the session",
    detail: "When the viewer closes the stream, VLC sends TEARDOWN with the session ID. The camera stops sending video and confirms. Had VLC simply vanished, the camera would stop anyway once 60 seconds passed without a word from it.",
    facts: [["Request", "TEARDOWN"], ["Session", "Ended"], ["Otherwise", "Timeout after 60 s"]],
    events: [l("client", "cam", "amber", "TEARDOWN", ["stop session 1185d200"], zn(12.4, `TEARDOWN ${Me}/ RTSP/1.0`, It([`TEARDOWN ${Me}/ RTSP/1.0`, "CSeq: 6", lr(`${Me}/`), jn, `Session: ${an}`]))), l("cam", "client", "violet", "200 OK", ["stopped"], Qn(12.403, "Reply: RTSP/1.0 200 OK", It(["RTSP/1.0 200 OK", "CSeq: 6", `Session: ${an}`])))]
  }]
};
const Zn = "192.168.1.30";
const Im = "203.0.113.80";
const G = "233.252.0.1";
const Ei = "224.0.0.1";
const sh = "224.0.0.2";
const Rm = "00:00:5e:00:53:01";
const Nm = "00:00:5e:00:53:fe";
const uu = e => `${e.toFixed(6)}s`;
const ha = e => `Seen going into the switch, port ${e}`;
const Dm = e => `Seen leaving the switch, port ${e}`;
const fu = (e, t) => ({
  copyOf: -e,
  at: Dm(t)
});
const Om = "Always 1: IGMP never goes past the first router.";
const br = {
  tos: 192,
  df: true
};
const ta = (e, t, s = {}) => ({
  igmp: {
    type: e,
    group: t,
    maxResp: e === 17 ? t === "0.0.0.0" ? 100 : 10 : 0
  },
  routerAlert: true,
  ttl: 1,
  ttlNote: Om,
  ...s
});
const Mm = {
  22: e => `Membership Report group ${e}`,
  23: e => `Leave Group ${e}`,
  17: e => e === "0.0.0.0" ? "Membership Query, general" : `Membership Query, specific for group ${e}`
};
const io = (e, t, s, n, o, a) => ({
  time: uu(e),
  src: t,
  dst: s,
  proto: "IGMPv2",
  info: Mm[n](o),
  len: "60 B",
  wire: a
});
const Ho = (e, t, s, n = {}) => io(e, t, G, 22, G, {
  ...ta(22, G, t === h ? {} : br),
  at: ha(s),
  ...n
});
const Jt = (e, t, s, n, o, a, r) => io(e, t, s, n, o, fu(a, r));
const Vl = (e, t, s) => ({
  time: uu(e),
  src: Im,
  dst: G,
  proto: "MPEG TS",
  info: "5000 → 1234 Len=1316, 7 TS packets (video PID 256)",
  len: "1358 B",
  wire: {
    udp: {
      sport: 5000,
      dport: 1234,
      data: {
        mpegts: {
          pid: 256,
          cc: t
        }
      }
    },
    df: false,
    ...s
  }
});
const nh = (e, t) => Vl(e, t, {
  ttl: 62,
  ttlNote: "Started at 64; 2 routers on the way each took 1.",
  link: {
    at: "Seen arriving on the router’s internet side",
    src: Nm,
    srcNote: "The provider’s router, passing the channel on."
  }
});
const oh = (e, t) => Vl(e, t, {
  ttl: 61,
  ttlNote: "Started at 64; 3 routers on the way each took 1.",
  natOf: -1,
  link: {
    at: ha(8),
    src: Rm,
    srcNote: "The router, passing the channel into the home."
  }
});
const xi = (e, t, s, n) => ({
  ...Vl(e, t, {}),
  wire: fu(s, n)
});
const qm = {
  id: "igmp",
  name: "IGMP",
  title: "Multicast TV",
  layer: 3,
  nodes: ["client", "switch", "stb", "router", "isp"],
  links: ["client-switch", "switch-stb", "switch-router", "router-isp"],
  lifelines: ["client", "switch", "stb", "router", "isp"],
  latency: {
    "client-switch": 0.000001,
    "switch-stb": 0.000001,
    "switch-router": 0.000001,
    "router-isp": 0.002
  },
  labels: {
    client: ["Client", h],
    isp: ["ISP Router", "TV channels"]
  },
  legend: [["amber", "Joins and leaves"], ["violet", "Queries"], ["blue", "Channel 1"]],
  overview: {
    full: "Internet Group Management Protocol",
    description: "Multicast sends one stream to a group address, and the network copies it only where it’s wanted: it’s how internet providers deliver live TV channels. IGMP is how a device tells its router which groups it wants. Switches listen in (IGMP snooping), so each stream reaches only the ports that asked for it.",
    facts: [["Layer", "Network (Layer 3)"], ["Carried in", "IP protocol 2"], ["Groups", "224.0.0.0 to 239.255.255.255"], ["Messages", "Report, Query, Leave"], ["Version here", "IGMPv2"], ["Defined In", "RFC 2236 (v3: RFC 3376)"]]
  },
  outro: {
    title: "Tuned In",
    desc: "Joined, copied, checked, left",
    text: "The TV box and then the laptop joined channel 1 with IGMP reports. The router joined once for the whole home, and the switch, listening in, copied the channel only to the ports that wanted it. Queries kept it flowing, and when the laptop left, the TV box’s answer kept it on. Press REPLAY to watch it again.",
    facts: [["Channel 1", G], ["Upstream", "One stream for the home"], ["Switch", "Copies to ports that joined"], ["Checks", "Every 125 s"]]
  },
  start: {
    nodes: ["client", "switch", "stb", "router"],
    frame: "tvbox"
  },
  steps: [{
    title: "Pick a Channel",
    desc: "The TV box joins a group",
    detail: "The viewer picks channel 1. Each channel is a multicast group, here 233.252.0.1, and the TV box sends an IGMP Membership Report to that address: I want this group. The switch listens in (IGMP snooping), notes port 2, and passes the report to the router alone.",
    facts: [["Channel 1", G], ["Message", "Membership Report"], ["Switch notes", "Port 2 wants it"]],
    events: [l("stb", "switch", "amber", "JOIN", [`${G}, please`], Ho(0, Zn, 2)), l("switch", "router", "amber", "JOIN", ["to the router port only"], Jt(0.000006, Zn, G, 22, G, 1, 8))]
  }, {
    title: "Ask the Provider",
    desc: "The router joins for the home",
    detail: "The router is an IGMP proxy: it joins the group on its internet side with a report of its own, from its public address, and the provider’s network starts sending channel 1 down the line. However many screens at home tune in, the router joins only once.",
    facts: [["Router role", "IGMP proxy"], ["Joins", "Once for the whole home"], ["From", se]],
    events: [{
      type: "show",
      nodes: ["isp"],
      frame: "tvlink"
    }, l("router", "isp", "amber", "JOIN", ["for the whole home"], io(0.0004, se, G, 22, G, ta(22, G, br)))]
  }, {
    title: "The Channel Flows",
    desc: "Sent only where it was asked for",
    detail: "The provider’s TV server sends channel 1 to 233.252.0.1: UDP datagrams holding seven 188-byte MPEG-TS packets of video and audio each. The router passes them in, and the switch sends them out of port 2 alone: only the TV box joined, so the laptop gets none.",
    facts: [["Datagram", "UDP, 1,316 bytes of TV"], ["Holds", "7 MPEG-TS packets"], ["Laptop gets", "Nothing"]],
    events: [l("isp", "router", "blue", "CHANNEL 1", [`to ${G}`, "MPEG-TS over UDP"], nh(0.0123, 4)), l("router", "switch", "blue", "CHANNEL 1", ["passed into the home"], oh(0.014306, 4)), l("switch", "stb", "blue", "CHANNEL 1", ["port 2 only"], xi(0.014318, 4, 1, 2))]
  }, {
    title: "A Second Screen",
    desc: "The laptop tunes in too",
    detail: "The laptop opens channel 1 in VLC and sends its own report. The switch adds port 1 and now makes two copies of every datagram. The router already gets the channel, so it asks the provider for nothing: one stream still comes down the line.",
    facts: [["Switch sends to", "Ports 1 and 2"], ["Upstream", "Still one stream"], ["Router asks", "Nothing new"]],
    events: [l("client", "switch", "amber", "JOIN", [`${G}, please`], Ho(4.2, h, 1)), l("switch", "router", "amber", "JOIN", ["to the router port only"], Jt(4.200006, h, G, 22, G, 1, 8)), l("isp", "router", "blue", "CHANNEL 1", ["the same one stream"], nh(4.2021, 9)), l("router", "switch", "blue", "CHANNEL 1", ["passed into the home"], oh(4.204106, 9)), {
      type: "stream",
      from: "switch",
      to: "stb",
      color: "blue",
      label: "CHANNEL 1",
      payload: ["copied to ports 1 and 2"],
      spacing: 0,
      packets: [l("switch", "client", "blue", "CHANNEL 1", ["copy for port 1"], xi(4.204118, 9, 1, 1)), l("switch", "stb", "blue", "CHANNEL 1", ["copy for port 2"], xi(4.204118, 9, 2, 2))]
    }]
  }, {
    title: "Still Watching?",
    desc: "The router checks regularly",
    detail: "Every 125 seconds the router sends a General Query to 224.0.0.1, every device: which groups do you still want? The switch passes it to every port. Each member answers at a random moment within 10 seconds, so the router and the switch keep the channel coming.",
    facts: [["Every", "125 seconds"], ["Sent to", "224.0.0.1, all devices"], ["Answer within", "10 seconds"]],
    events: [l("router", "switch", "violet", "QUERY", ["any groups wanted?"], io(125.6, ce, Ei, 17, "0.0.0.0", {
      ...ta(17, "0.0.0.0", br),
      at: ha(8)
    })), {
      type: "stream",
      from: "switch",
      to: "stb",
      color: "violet",
      label: "QUERY",
      payload: ["to every port"],
      spacing: 0,
      packets: [l("switch", "client", "violet", "QUERY", ["to port 1"], Jt(125.600006, ce, Ei, 17, "0.0.0.0", 1, 1)), l("switch", "stb", "violet", "QUERY", ["to port 2"], Jt(125.600006, ce, Ei, 17, "0.0.0.0", 2, 2))]
    }, l("stb", "switch", "amber", "REPORT", ["still watching"], Ho(128.93, Zn, 2)), l("switch", "router", "amber", "REPORT", ["to the router port only"], Jt(128.930006, Zn, G, 22, G, 1, 8)), l("client", "switch", "amber", "REPORT", ["still watching"], Ho(133.41, h, 1)), l("switch", "router", "amber", "REPORT", ["to the router port only"], Jt(133.410006, h, G, 22, G, 1, 8))]
  }, {
    title: "Leave",
    desc: "The laptop stops watching",
    detail: "Closing VLC sends a Leave Group to 224.0.0.2, all routers. Others may still watch, so the router asks about that group alone and waits 1 second. The TV box answers, so the channel stays; the switch just stops sending it to port 1.",
    facts: [["Leave sent to", "224.0.0.2, all routers"], ["Router asks", "About that group alone"], ["Channel", "Stays: the TV box answered"]],
    events: [l("client", "switch", "amber", "LEAVE", [`done with ${G}`], io(300.5, h, sh, 23, G, {
      ...ta(23, G),
      at: ha(1)
    })), l("switch", "router", "amber", "LEAVE", ["to the router port only"], Jt(300.500006, h, sh, 23, G, 1, 8)), l("router", "switch", "violet", "QUERY", [`anyone for ${G}?`], io(300.5004, ce, G, 17, G, {
      ...ta(17, G, br),
      at: ha(8)
    })), {
      type: "stream",
      from: "switch",
      to: "stb",
      color: "violet",
      label: "QUERY",
      payload: ["to the ports that joined"],
      spacing: 0,
      packets: [l("switch", "client", "violet", "QUERY", ["to port 1"], Jt(300.500406, ce, G, 17, G, 1, 1)), l("switch", "stb", "violet", "QUERY", ["to port 2"], Jt(300.500406, ce, G, 17, G, 2, 2))]
    }, l("stb", "switch", "amber", "REPORT", ["still watching"], Ho(300.83, Zn, 2)), l("switch", "router", "amber", "REPORT", ["to the router port only"], Jt(300.830006, Zn, G, 22, G, 1, 8))]
  }]
};
class R {
  constructor(t, s) {
    this.id = t;
    this.name = s;
    this.bytes = [];
    this.fields = [];
  }
  get length() {
    return this.bytes.length;
  }
  u8(t) {
    this.bytes.push(t & 255);
    return this;
  }
  u16(t) {
    this.bytes.push(t >>> 8 & 255, t & 255);
    return this;
  }
  u24(t) {
    this.bytes.push(t >>> 16 & 255, t >>> 8 & 255, t & 255);
    return this;
  }
  u32(t) {
    this.bytes.push(t >>> 24 & 255, t >>> 16 & 255, t >>> 8 & 255, t & 255);
    return this;
  }
  u16le(t) {
    this.bytes.push(t & 255, t >>> 8 & 255);
    return this;
  }
  u32le(t) {
    this.bytes.push(t & 255, t >>> 8 & 255, t >>> 16 & 255, t >>> 24 & 255);
    return this;
  }
  u64le(t) {
    return this.u32le(t % 4294967296).u32le(Math.floor(t / 4294967296));
  }
  u64(t) {
    return this.u32(Math.floor(t / 4294967296)).u32(t % 4294967296);
  }
  append(t) {
    const s = this.length;
    for (const n of t.bytes) {
      this.bytes.push(n);
    }
    for (const n of t.fields) {
      this.fields.push({
        ...n,
        from: n.from + s,
        to: n.to + s
      });
    }
    return this;
  }
  raw(t) {
    for (const s of t) {
      this.bytes.push(s);
    }
    return this;
  }
  ascii(t) {
    for (const s of new TextEncoder().encode(t)) {
      this.bytes.push(s);
    }
    return this;
  }
  unknown(t) {
    for (let s = 0; s < t; s++) {
      this.bytes.push(null);
    }
    return this;
  }
  field(t, s, n = () => {}, o = {}) {
    const a = this.length;
    n();
    this.fields.push({
      name: t,
      value: String(s),
      from: a,
      to: this.length,
      ...o
    });
    return this;
  }
}
const Ee = e => e.split(".").map(Number);
const ts = e => e.split(":").map(t => parseInt(t, 16));
function es(e) {
  const [t, s] = e.split("::");
  const n = t ? t.split(":") : [];
  const o = s !== undefined && s ? s.split(":") : [];
  return [...n, ...Array(8 - n.length - o.length).fill("0"), ...o].flatMap(r => [parseInt(r, 16) >> 8, parseInt(r, 16) & 255]);
}
const _ = (e, t = 4) => `0x${e.toString(16).padStart(t, "0")}`;
function pn(e) {
  let t = 0;
  for (let s = 0; s < e.length; s += 2) {
    const n = e[s];
    const o = s + 1 < e.length ? e[s + 1] : 0;
    if (n === null || o === null) {
      return null;
    }
    t += n << 8 | o;
  }
  while (t > 65535) {
    t = (t & 65535) + (t >>> 16);
  }
  return ~t & 65535;
}
function Rr(e) {
  const t = [];
  const s = [];
  const n = [];
  for (const o of e) {
    const a = t.length;
    n.push({
      id: o.id,
      name: o.name,
      from: a,
      to: a + o.length,
      summary: o.summary
    });
    for (const r of o.fields) {
      s.push({
        ...r,
        layer: o.id,
        from: r.from + a,
        to: r.to + a
      });
    }
    t.push(...o.bytes);
  }
  return {
    bytes: t,
    fields: s,
    layers: n
  };
}
const ah = {
  1: "Set Chunk Size",
  3: "Acknowledgement",
  5: "Window Acknowledgement Size",
  6: "Set Peer Bandwidth",
  8: "Audio Data",
  9: "Video Data",
  18: "AMF0 Data",
  20: "AMF0 Command"
};
function sa(e, t, s, n, o) {
  if (s === null) {
    return e.field(t, "null", () => e.u8(5), {
      depth: n,
      note: o
    });
  }
  if (typeof s == "boolean") {
    return e.field(t, s ? "true" : "false", () => e.u8(1).u8(s ? 1 : 0), {
      depth: n,
      note: o
    });
  }
  if (typeof s == "number") {
    const i = new DataView(new ArrayBuffer(8));
    i.setFloat64(0, s);
    return e.field(t, s.toLocaleString("en-US"), () => e.u8(0).raw(Array.from({
      length: 8
    }, (c, d) => i.getUint8(d))), {
      depth: n,
      note: o
    });
  }
  if (typeof s == "string") {
    return e.field(t, `"${s}"`, () => e.u8(2).u16(s.length).ascii(s), {
      depth: n,
      note: o
    });
  }
  const a = !!s.ecma;
  const r = Object.entries(a ? s.ecma : s);
  e.field(t, a ? `array of ${r.length}` : `object, ${r.length} properties`, () => a ? e.u8(8).u32(r.length) : e.u8(3), {
    depth: n,
    note: o
  });
  for (const [i, c] of r) {
    const d = e.length;
    e.u16(i.length).ascii(i);
    const p = e.fields.length;
    sa(e, i, c, n + 1);
    e.fields[p].from = d;
  }
  return e.field("End of object", "00 00 09", () => e.u16(0).u8(9), {
    depth: n + 1
  });
}
function Hm(e) {
  const t = new R("body", "");
  const s = e.type;
  if (s === 1) {
    t.field("Chunk size", `${e.size.toLocaleString("en-US")} bytes`, () => t.u32(e.size), {
      depth: 1,
      note: "From now on this side cuts messages into chunks of up to this size (128 until it says otherwise)."
    });
  }
  if (s === 3) {
    t.field("Received", `${e.size.toLocaleString("en-US")} bytes`, () => t.u32(e.size), {
      depth: 1,
      note: "How much has arrived so far: sent each time another window’s worth comes in."
    });
  }
  if (s === 5) {
    t.field("Window", `${e.size.toLocaleString("en-US")} bytes`, () => t.u32(e.size), {
      depth: 1,
      note: "The other side should hear back after every this many bytes it sends."
    });
  }
  if (s === 6) {
    t.field("Bandwidth, limit", `${e.size.toLocaleString("en-US")} bytes, dynamic`, () => t.u32(e.size).u8(2), {
      depth: 1,
      note: "How much the sender may have unacknowledged at once."
    });
  }
  if (s === 20) {
    sa(t, "Command", e.name, 1);
    sa(t, "Transaction ID", e.tx, 1, "Matches a reply to its request.");
    for (const [n, o, a] of e.args) {
      sa(t, n, o, 1, a);
    }
  }
  if (s === 18) {
    for (const [n, o, a] of e.args) {
      sa(t, n, o, 1, a);
    }
  }
  if (s === 9) {
    t.field("Frame, codec", e.key ? "0x17 (key frame, H.264)" : "0x27 (inter frame, H.264)", () => t.u8(e.key ? 23 : 39), {
      depth: 1
    });
    t.field("AVC packet type", e.config ? "0 (decoder settings)" : "1 (video)", () => t.u8(e.config ? 0 : 1), {
      depth: 1,
      note: e.config ? "The sequence header: the settings a decoder needs before the first frame." : "Compressed picture data."
    });
    t.field("Composition time", "0", () => t.u24(0), {
      depth: 1
    });
    t.field("Video", `${e.video.toLocaleString("en-US")} bytes`, () => t.unknown(e.video), {
      depth: 1,
      hidden: true,
      note: e.config ? "The H.264 profile, level and parameter sets." : "The key frame: a whole picture. Every 4,096 bytes a 1-byte chunk header continues it."
    });
  }
  if (s === 8) {
    t.field("Format", "0xaf (AAC)", () => t.u8(175), {
      depth: 1,
      note: "AAC; the other bits are fixed for AAC."
    });
    t.field("AAC packet type", e.config ? "0 (decoder settings)" : "1 (audio)", () => t.u8(e.config ? 0 : 1), {
      depth: 1,
      note: e.config ? "Sample rate and channels, for the decoder." : undefined
    });
    t.field("Audio", `${e.audio.toLocaleString("en-US")} bytes`, () => t.unknown(e.audio), {
      depth: 1,
      hidden: true
    });
  }
  return t;
}
const Fm = ["", "First", "Second", "Third", "Fourth", "Fifth"];
function Um(e) {
  const t = new R("rtmp", `RTMP handshake · ${e}`);
  const s = (o, a, r, i) => {
    t.field(o, a);
    t.field("Time", "0", () => t.u32(0), {
      depth: 1,
      note: r === "random" ? "A timestamp; zero is allowed." : "The timestamp from the block it echoes."
    });
    t.field(r === "random" ? "Zero" : "Time read", "0", () => t.u32(0), {
      depth: 1,
      example: r !== "random"
    });
    t.field(r === "random" ? "Random data" : "Echo", "1,528 bytes", () => t.unknown(1528), {
      depth: 1,
      hidden: true,
      note: i
    });
  };
  const n = o => t.field(o, "3", () => t.u8(3), {
    note: "RTMP version 3, the only one in use."
  });
  if (e === "C0+C1") {
    n("C0: version");
    s("C1", "1,536 bytes", "random", "Random bytes the server must send back.");
  }
  if (e === "S0+S1+S2") {
    n("S0: version");
    s("S1", "1,536 bytes", "random", "Random bytes the client must send back.");
    s("S2", "1,536 bytes: C1 back", "echo", "C1’s random bytes, sent back unchanged.");
  }
  if (e === "C2") {
    s("C2", "1,536 bytes: S1 back", "echo", "S1’s random bytes, sent back unchanged.");
  }
  return t;
}
function mu(e) {
  if (e.handshake) {
    return Um(e.handshake);
  }
  const t = new R("rtmp", e.messages.length > 1 ? `RTMP · ${e.messages.length} messages` : "RTMP");
  let s = e.chunk;
  e.messages.forEach((n, o) => {
    const a = Hm(n);
    const r = n.type === 20 ? `${n.name}()` : n.type === 18 ? `${n.args[0][1]}()` : ah[n.type];
    t.field(e.messages.length > 1 ? `${Fm[o + 1]} message` : "Message", r);
    t.field("Chunk header", `type 0, chunk stream ${n.csid}`, () => t.u8(n.csid), {
      depth: 1,
      note: "A full header follows: this chunk starts a message.",
      example: true
    });
    t.field("Timestamp", `${n.ts ?? 0} ms`, () => t.u24(n.ts ?? 0), {
      depth: 1
    });
    t.field("Message length", `${a.length.toLocaleString("en-US")} bytes`, () => t.u24(a.length), {
      depth: 1
    });
    t.field("Message type", `${n.type} (${ah[n.type]})`, () => t.u8(n.type), {
      depth: 1
    });
    t.field("Message stream", n.stream ?? 0, () => t.u32le(n.stream ?? 0), {
      depth: 1,
      note: n.stream ? "Stream 1, the one createStream made." : "Stream 0: the connection itself. (This number alone is little-endian.)"
    });
    const i = t.length;
    const c = (d, p) => d + Math.floor((p ? d - 1 : d) / s);
    for (let d = 0; d < a.length; d++) {
      if (d > 0 && d % s === 0) {
        if (n.type !== 8 && n.type !== 9) {
          throw new Error(`RTMP: ${r} crosses a chunk boundary`);
        }
        t.u8(n.csid | 192);
      }
      t.bytes.push(a.bytes[d]);
    }
    for (const d of a.fields) {
      t.fields.push({
        ...d,
        from: i + c(d.from),
        to: d.to > d.from ? i + c(d.to, true) : i + c(d.from)
      });
    }
    if (n.type === 1) {
      s = n.size;
    }
  });
  return t;
}
const Km = e => mu(e).length;
const ga = "203.0.113.10";
const rh = "rtmp://live.example.com/live";
const yu = "live_29481_xk3Qe7";
const Bm = q(h, 52630, ga, 1935);
const _m = ae + re + ie;
const wu = (e, t, s, n) => {
  const o = Km(n);
  const a = rt(o);
  return {
    time: x(e),
    src: t,
    dst: t === h ? ga : h,
    proto: "RTMP",
    info: a > 1 ? `${s}, ${a} segments` : s,
    len: a > 1 ? it(o + a * _m, a) : `${j(o)} B`,
    wire: P(Bm, t, "PA", {
      rtmp: n
    })
  };
};
const qs = (e, t, s) => wu(e, h, t, s);
const Fo = (e, t, s) => wu(e, ga, t, s);
const hs = ["Command object", null, "Nothing: AMF0 null."];
const cr = ["Stream key", yu, "Which channel this is. It works like a password, and here it travels unencrypted."];
const ih = (e, t) => ["Information", {
  level: "status",
  code: e,
  description: t
}];
const Gm = {
  id: "rtmp",
  name: "RTMP",
  title: "Live Streaming Upload",
  layer: 7,
  nodes: ["client", "router", "internet", "web"],
  latency: {
    "client-web": 0.017
  },
  labels: {
    web: ["Ingest Server", ga]
  },
  legend: [["green", "TCP"], ["slate", "RTMP handshake"], ["amber", "Commands"], ["violet", "Replies"], ["blue", "Video and audio"]],
  overview: {
    full: "Real-Time Messaging Protocol",
    description: "RTMP is how most streamers send live video to a platform: OBS and other apps push it to an ingest server, which turns it into streams for viewers. Made for Flash, it outlived Flash as the way to upload. Everything shares one TCP connection: commands, audio and video, cut into chunks.",
    facts: [["Layer", "Application (Layer 7)"], ["Port", "TCP 1935"], ["Carries", "H.264 video, AAC audio"], ["Commands", "Encoded in AMF0"], ["Secure version", "RTMPS, over TLS"], ["Defined In", "Adobe specification (2012)"]]
  },
  outro: {
    title: "Live",
    desc: "Connected, published, streamed",
    text: "OBS shook hands with the ingest server, connected to its live app, got stream 1 and published to it with the stream key. The video and audio then flowed in chunks over the same TCP connection until the streamer stopped. Press REPLAY to watch it again.",
    facts: [["Connection", "One TCP, port 1935"], ["Stream", "ID 1"], ["Chunks", "Up to 4,096 bytes"], ["Encryption", "None: RTMPS adds TLS"]]
  },
  start: {
    nodes: ["client"],
    frame: "client"
  },
  steps: [{
    title: "Handshake",
    desc: "TCP, then RTMP’s own",
    detail: "The streamer clicks Start Streaming. OBS connects to the ingest server on TCP port 1935, then RTMP has its own handshake: version 3 and 1,536 random bytes each way, which each side sends back. It shows both ends speak RTMP; it encrypts nothing.",
    facts: [["Port", "TCP 1935"], ["Version", "3"], ["Each side", "Sends 3,073 bytes"]],
    events: [{
      type: "show",
      nodes: ["router", "internet", "web"],
      frame: "path"
    }, ...he({
      to: "web",
      dst: ga,
      sport: 52630,
      dport: 1935,
      t: [0, 0.017, 0.034]
    }), l("client", "web", "slate", "C0+C1", ["version 3", "1,536 random bytes"], qs(0.034, "Handshake C0+C1", {
      handshake: "C0+C1"
    })), l("web", "client", "slate", "S0+S1+S2", ["version 3, its own bytes", "and C1 sent back"], Fo(0.052, "Handshake S0+S1+S2", {
      handshake: "S0+S1+S2"
    })), l("client", "web", "slate", "C2", ["S1 sent back"], qs(0.07, "Handshake C2", {
      handshake: "C2"
    }))]
  }, {
    title: "Connect",
    desc: "To the server’s live app",
    detail: "OBS raises its chunk size to 4,096 bytes and sends connect for the app called live, in AMF0, a compact binary format from Flash. The server sets its own window, bandwidth and chunk size, and answers _result: NetConnection.Connect.Success.",
    facts: [["App", "live"], ["Encoding", "AMF0"], ["Chunks", "Up to 4,096 bytes"]],
    events: [l("client", "web", "amber", "CONNECT", ["app: live", "chunk size 4,096"], qs(0.071, "Set Chunk Size 4096|connect('live')", {
      chunk: 128,
      messages: [{
        type: 1,
        csid: 2,
        size: 4096
      }, {
        type: 20,
        csid: 3,
        name: "connect",
        tx: 1,
        args: [["Command object", {
          app: "live",
          type: "nonprivate",
          flashVer: "FMLE/3.0 (compatible; FMSc/1.0)",
          swfUrl: rh,
          tcUrl: rh
        }, "Which app on the server, and the address OBS was given."]]
      }]
    })), l("web", "client", "violet", "_RESULT", ["Connect.Success", "window, bandwidth, chunks"], Fo(0.089, "Window Ack Size|Set Peer Bandwidth|Set Chunk Size|_result()", {
      chunk: 128,
      messages: [{
        type: 5,
        csid: 2,
        size: 5000000
      }, {
        type: 6,
        csid: 2,
        size: 5000000
      }, {
        type: 1,
        csid: 2,
        size: 4096
      }, {
        type: 20,
        csid: 3,
        name: "_result",
        tx: 1,
        args: [["Properties", {
          fmsVer: "FMS/3,0,1,123",
          capabilities: 31
        }], ["Information", {
          level: "status",
          code: "NetConnection.Connect.Success",
          description: "Connection succeeded.",
          objectEncoding: 0
        }]]
      }]
    }))]
  }, {
    title: "Make a Stream",
    desc: "createStream returns stream 1",
    detail: "Every message names a message stream; 0 is the connection itself. OBS releases and announces its stream key, then asks createStream for a stream to send on, all three commands in one packet. The server answers with stream ID 1.",
    facts: [["Commands", "3 in one packet"], ["Asks", "createStream"], ["Gets", "Stream ID 1"]],
    events: [l("client", "web", "amber", "CREATESTREAM", ["releaseStream, FCPublish", "createStream"], qs(0.107, "releaseStream()|FCPublish()|createStream()", {
      chunk: 4096,
      messages: [{
        type: 20,
        csid: 3,
        name: "releaseStream",
        tx: 2,
        args: [hs, cr]
      }, {
        type: 20,
        csid: 3,
        name: "FCPublish",
        tx: 3,
        args: [hs, cr]
      }, {
        type: 20,
        csid: 3,
        name: "createStream",
        tx: 4,
        args: [hs]
      }]
    })), l("web", "client", "violet", "_RESULT", ["stream ID 1"], Fo(0.125, "_result()", {
      chunk: 4096,
      messages: [{
        type: 20,
        csid: 3,
        name: "_result",
        tx: 4,
        args: [hs, ["Stream ID", 1, "The new stream: video and audio will go on it."]]
      }]
    }))]
  }, {
    title: "Publish",
    desc: "The stream key goes live",
    detail: "publish names the stream key, the secret that says whose channel this is. RTMP has no encryption, so the key crosses in plain text; platforms prefer RTMPS, the same over TLS. The server checks the key and answers NetStream.Publish.Start.",
    facts: [["Sends", "The stream key"], ["Encryption", "None (RTMPS adds TLS)"], ["Answer", "Publish.Start"]],
    events: [l("client", "web", "amber", "PUBLISH", ["on stream 1", "stream key, live"], qs(0.143, `publish('${yu}')`, {
      chunk: 4096,
      messages: [{
        type: 20,
        csid: 4,
        stream: 1,
        name: "publish",
        tx: 5,
        args: [hs, cr, ["Publishing type", "live", "Live: not recorded by this request."]]
      }]
    })), l("web", "client", "violet", "ONSTATUS", ["Publish.Start"], Fo(0.161, "onStatus('NetStream.Publish.Start')", {
      chunk: 4096,
      messages: [{
        type: 20,
        csid: 5,
        stream: 1,
        name: "onStatus",
        tx: 0,
        args: [hs, ih("NetStream.Publish.Start", "Start publishing")]
      }]
    }))]
  }, {
    title: "Video and Sound",
    desc: "Metadata, settings, then frames",
    detail: "OBS describes the stream: 1920×1080 at 30 frames a second, H.264 video, AAC audio. It sends the decoders’ settings, then a key frame, about 30 KB cut into 4,096-byte chunks. Frames follow non-stop, on the same TCP connection.",
    facts: [["Video", "H.264, 1920×1080, 30 fps"], ["Audio", "AAC, 48 kHz stereo"], ["Key frame", "30 KB in 8 chunks"]],
    events: [l("client", "web", "blue", "METADATA", ["1920×1080, 30 fps", "H.264 + AAC settings"], qs(0.179, "@setDataFrame()|Video Data|Audio Data", {
      chunk: 4096,
      messages: [{
        type: 18,
        csid: 4,
        stream: 1,
        args: [["Handler", "@setDataFrame"], ["Event", "onMetaData"], ["Metadata", {
          ecma: {
            duration: 0,
            fileSize: 0,
            width: 1920,
            height: 1080,
            videocodecid: 7,
            videodatarate: 6000,
            framerate: 30,
            audiocodecid: 10,
            audiodatarate: 160,
            audiosamplerate: 48000,
            audiosamplesize: 16,
            audiochannels: 2,
            stereo: true,
            encoder: "obs-output module (libobs version 30.2.3)"
          }
        }, "Codec IDs as in Flash video files: 7 is H.264, 10 is AAC."]]
      }, {
        type: 9,
        csid: 6,
        stream: 1,
        key: true,
        config: true,
        video: 40
      }, {
        type: 8,
        csid: 4,
        stream: 1,
        config: true,
        audio: 2
      }]
    })), l("client", "web", "blue", "KEY FRAME", ["30 KB of H.264", "8 chunks"], qs(0.18, "Video Data", {
      chunk: 4096,
      messages: [{
        type: 9,
        csid: 6,
        stream: 1,
        key: true,
        video: 30000
      }]
    }))]
  }, {
    title: "Stop Streaming",
    desc: "FCUnpublish and deleteStream",
    detail: "When the streamer clicks Stop Streaming, OBS sends FCUnpublish and deleteStream for stream 1. The server answers NetStream.Unpublish.Success and ends the broadcast for viewers. Then OBS closes the TCP connection.",
    facts: [["Commands", "FCUnpublish, deleteStream"], ["Answer", "Unpublish.Success"], ["Then", "TCP closes"]],
    events: [l("client", "web", "amber", "DELETESTREAM", ["FCUnpublish", "deleteStream 1"], qs(1834.62, "FCUnpublish()|deleteStream()", {
      chunk: 4096,
      messages: [{
        type: 20,
        csid: 3,
        name: "FCUnpublish",
        tx: 6,
        args: [hs, cr]
      }, {
        type: 20,
        csid: 3,
        name: "deleteStream",
        tx: 7,
        args: [hs, ["Stream ID", 1]]
      }]
    })), l("web", "client", "violet", "ONSTATUS", ["Unpublish.Success"], Fo(1834.638, "onStatus('NetStream.Unpublish.Success')", {
      chunk: 4096,
      messages: [{
        type: 20,
        csid: 5,
        stream: 1,
        name: "onStatus",
        tx: 0,
        args: [hs, ih("NetStream.Unpublish.Success", "Stop publishing")]
      }]
    }))]
  }]
};
const _s = {
  http: O0,
  https: M0,
  tcp: q0,
  udp: H0,
  ip: F0,
  dns: B0,
  dhcp: _0,
  icmp: V0,
  smtp: df,
  pop3: pf,
  imap: Tf,
  ftp: kf,
  ssh: Hf,
  tls: _f,
  websocket: Wf,
  wifi: Zf,
  wpa3: s1,
  portal: o1,
  proxy: i1,
  socks: l1,
  reverse: c1,
  wireguard: d1,
  ipsec: h1,
  quic: P1,
  ipv6: A1,
  ntp: x1,
  doh: N1,
  dnssec: B1,
  radius: Y1,
  smb: Q1,
  modbus: J1,
  bgp: tm,
  webrtc: rm,
  ethernet: hm,
  pppoe: mm,
  sip: Am,
  rtsp: Lm,
  igmp: qm,
  rtmp: Gm
};
const Ts = [{
  id: "http",
  name: "HTTP",
  full: "Hypertext Transfer Protocol",
  group: "application"
}, {
  id: "https",
  name: "HTTPS",
  full: "HTTP Secure",
  group: "security"
}, {
  id: "websocket",
  name: "WebSocket",
  full: "Two-way web messaging",
  group: "application"
}, {
  id: "webrtc",
  name: "WebRTC",
  full: "Browser video calls",
  group: "application"
}, {
  id: "sip",
  name: "SIP",
  full: "Internet phone calls",
  group: "application"
}, {
  id: "rtsp",
  name: "RTSP",
  full: "IP camera streams",
  group: "application"
}, {
  id: "rtmp",
  name: "RTMP",
  full: "Live streaming upload",
  group: "application"
}, {
  id: "quic",
  name: "QUIC",
  full: "HTTP/3 over UDP",
  group: "core"
}, {
  id: "tcp",
  name: "TCP",
  full: "Transmission Control Protocol",
  group: "core"
}, {
  id: "udp",
  name: "UDP",
  full: "User Datagram Protocol",
  group: "core"
}, {
  id: "ip",
  name: "IP",
  full: "Internet Protocol",
  group: "core"
}, {
  id: "bgp",
  name: "BGP",
  full: "Routing between networks",
  group: "core"
}, {
  id: "ipv6",
  name: "IPv6",
  full: "Address setup, neighbour discovery",
  group: "core"
}, {
  id: "dns",
  name: "DNS",
  full: "Domain Name System",
  group: "application"
}, {
  id: "doh",
  name: "DNS over HTTPS",
  full: "Private DNS lookups",
  group: "security"
}, {
  id: "dnssec",
  name: "DNSSEC",
  full: "Signed DNS answers",
  group: "security"
}, {
  id: "dhcp",
  name: "DHCP",
  full: "Dynamic Host Configuration",
  group: "application"
}, {
  id: "icmp",
  name: "ICMP",
  full: "Internet Control Message",
  group: "core"
}, {
  id: "igmp",
  name: "IGMP",
  full: "Multicast and TV channels",
  group: "core"
}, {
  id: "ntp",
  name: "NTP",
  full: "Network Time Protocol",
  group: "application"
}, {
  id: "ethernet",
  name: "Ethernet",
  full: "Frames and switches",
  group: "core"
}, {
  id: "pppoe",
  name: "PPPoE",
  full: "Broadband logins",
  group: "core"
}, {
  id: "wifi",
  name: "Wi-Fi",
  full: "Joining a network (WPA2)",
  group: "core"
}, {
  id: "wpa3",
  name: "WPA3",
  full: "Wi-Fi Protected Access 3",
  group: "security"
}, {
  id: "radius",
  name: "RADIUS",
  full: "802.1X Enterprise Wi-Fi",
  group: "security"
}, {
  id: "portal",
  name: "Captive Portal",
  full: "Hotel and café Wi-Fi logins",
  group: "application"
}, {
  id: "smtp",
  name: "SMTP",
  full: "Simple Mail Transfer Protocol",
  group: "application"
}, {
  id: "pop3",
  name: "POP3",
  full: "Post Office Protocol v3",
  group: "application"
}, {
  id: "imap",
  name: "IMAP",
  full: "Internet Message Access",
  group: "application"
}, {
  id: "ftp",
  name: "FTP",
  full: "File Transfer Protocol",
  group: "application"
}, {
  id: "smb",
  name: "SMB",
  full: "Windows file sharing",
  group: "application"
}, {
  id: "ssh",
  name: "SSH",
  full: "Secure Shell",
  group: "security"
}, {
  id: "tls",
  name: "TLS/SSL",
  full: "Transport Layer Security",
  group: "security"
}, {
  id: "proxy",
  name: "HTTP Proxy",
  full: "Forward proxy and CONNECT",
  group: "application"
}, {
  id: "socks",
  name: "SOCKS5",
  full: "Socket Secure proxy",
  group: "application"
}, {
  id: "reverse",
  name: "Reverse Proxy",
  full: "TLS offloading",
  group: "application"
}, {
  id: "wireguard",
  name: "WireGuard",
  full: "A modern VPN",
  group: "security"
}, {
  id: "ipsec",
  name: "IPsec",
  full: "IKEv2 and ESP",
  group: "security"
}, {
  id: "modbus",
  name: "Modbus",
  full: "Industrial control (OT)",
  group: "application"
}];
const Se = {
  menu: "<svg viewBox=\"0 0 18 14\" width=\"18\" height=\"14\" aria-hidden=\"true\"><path d=\"M1.5 2h15M1.5 7h15M1.5 12h15\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/></svg>",
  close: "<svg viewBox=\"0 0 14 14\" width=\"13\" height=\"13\" aria-hidden=\"true\"><path d=\"M2 2l10 10M12 2L2 12\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/></svg>",
  chevron: "<svg viewBox=\"0 0 10 16\" width=\"9\" height=\"14\" aria-hidden=\"true\"><path d=\"M2 2l6 6-6 6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
  check: "<svg viewBox=\"0 0 12 12\" width=\"11\" height=\"11\" aria-hidden=\"true\"><path d=\"M2.2 6.4l2.4 2.4 5.2-5.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
  reset: "<svg viewBox=\"0 0 18 18\" width=\"16\" height=\"16\" aria-hidden=\"true\"><path d=\"M15 9a6 6 0 1 1-1.9-4.4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\"/><path d=\"M14.6 1.6v4.2h-4.2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
  back: "<svg viewBox=\"0 0 12 12\" width=\"11\" height=\"11\" aria-hidden=\"true\"><path d=\"M7.5 2L3.5 6l4 4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
  search: "<svg viewBox=\"0 0 16 16\" width=\"15\" height=\"15\" aria-hidden=\"true\"><circle cx=\"7\" cy=\"7\" r=\"4.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"/><path d=\"M10.4 10.4 L14 14\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/></svg>",
  keyboard: "<svg viewBox=\"0 0 20 14\" width=\"19\" height=\"14\" aria-hidden=\"true\"><rect x=\"1\" y=\"1\" width=\"18\" height=\"12\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/><path d=\"M4.5 4.6h1.2 M8 4.6h1.2 M11.5 4.6h1.2 M15 4.6h.5 M4.5 7.4h1.2 M8 7.4h1.2 M11.5 7.4h1.2 M15 7.4h.5 M6 10.2h8\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\"/></svg>",
  list: "<svg viewBox=\"0 0 18 16\" width=\"17\" height=\"15\" aria-hidden=\"true\"><rect x=\"1\" y=\"1\" width=\"16\" height=\"14\" rx=\"1.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/><rect class=\"list-col\" x=\"1.8\" y=\"1.8\" width=\"4.6\" height=\"12.4\" fill=\"currentColor\"/><path d=\"M6.6 1.4 V14.6\" stroke=\"currentColor\" stroke-width=\"1.5\"/></svg>",
  layout: "<svg viewBox=\"0 0 18 16\" width=\"17\" height=\"15\" aria-hidden=\"true\"><rect x=\"1\" y=\"1\" width=\"16\" height=\"14\" rx=\"1.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/><path class=\"layout-split\" d=\"M12 1.4 V10 M1.4 10 H16.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/></svg>",
  expand: "<svg viewBox=\"0 0 16 16\" width=\"14\" height=\"14\" aria-hidden=\"true\"><path d=\"M2 6 V2 H6 M10 2 H14 V6 M14 10 V14 H10 M6 14 H2 V10\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
  collapse: "<svg viewBox=\"0 0 16 16\" width=\"14\" height=\"14\" aria-hidden=\"true\"><path d=\"M6 2 V6 H2 M14 6 H10 V2 M10 14 V10 H14 M2 10 H6 V14\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
  caret: "<svg viewBox=\"0 0 10 6\" width=\"10\" height=\"6\" aria-hidden=\"true\"><path d=\"M1 1l4 4 4-4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
  globe: "<svg viewBox=\"0 0 20 20\" width=\"17\" height=\"17\" aria-hidden=\"true\"><g fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\"><circle cx=\"10\" cy=\"10\" r=\"8\"/><ellipse cx=\"10\" cy=\"10\" rx=\"3.6\" ry=\"8\"/><path d=\"M2.4 7.2h15.2M2.4 12.8h15.2\"/></g></svg>",
  sun: "<svg viewBox=\"0 0 20 20\" width=\"16\" height=\"16\" aria-hidden=\"true\"><circle cx=\"10\" cy=\"10\" r=\"3.6\" fill=\"currentColor\"/><path d=\"M10 1.6v2.2M10 16.2v2.2M1.6 10h2.2M16.2 10h2.2M4.1 4.1l1.5 1.5M14.4 14.4l1.5 1.5M4.1 15.9l1.5-1.5M14.4 5.6l1.5-1.5\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/></svg>",
  moon: "<svg viewBox=\"0 0 20 20\" width=\"15\" height=\"15\" aria-hidden=\"true\"><path d=\"M16.5 12.6A7 7 0 0 1 7.4 3.5a7 7 0 1 0 9.1 9.1z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linejoin=\"round\"/></svg>"
};
const M = e => String(e).replace(/[&<>"]/g, t => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  "\"": "&quot;"
})[t]);
const gu = "protocol-explorer:progress:v1";
function Wm() {
  try {
    const e = JSON.parse(localStorage.getItem(gu));
    if (e && typeof e == "object") {
      return e;
    } else {
      return {};
    }
  } catch {
    return {};
  }
}
const Br = Wm();
function Vm() {
  try {
    localStorage.setItem(gu, JSON.stringify(Br));
  } catch {}
}
function Ym(e, t) {
  const s = Br[e.id] ??= {
    seen: [],
    done: false
  };
  let n = false;
  if (t.started && !t.done && !s.seen.includes(t.activeStep)) {
    s.seen.push(t.activeStep);
    n = true;
  }
  if (t.done && !s.done) {
    s.done = true;
    s.seen = e.steps.map((o, a) => a);
    n = true;
  }
  if (n) {
    Vm();
  }
  return n;
}
function jm(e) {
  const t = Br[e.id];
  if (t) {
    if (t.done) {
      return 1;
    } else {
      return Math.min(t.seen.length, e.steps.length - 1) / e.steps.length;
    }
  } else {
    return 0;
  }
}
function Nr(e) {
  const t = Br[e.id];
  if (t?.done) {
    return "done";
  } else if (t?.seen.length) {
    return "progress";
  } else {
    return "new";
  }
}
const Gs = "cubic-bezier(0.16, 1, 0.3, 1)";
const zm = "cubic-bezier(0.5, 0, 0.75, 0)";
const Qm = window.matchMedia("(prefers-reduced-motion: reduce)");
const Ne = () => Qm.matches;
const rn = new WeakMap();
function Su(e, t, {
  axis: s = "x",
  dir: n = 1,
  distance: o = 24,
  out: a = 160,
  inn: r = 300
} = {}) {
  if (Ne()) {
    return t();
  }
  const i = T => s === "x" ? `translateX(${T}px)` : `translateY(${T}px)`;
  const c = rn.get(e);
  if (c?.phase === "out") {
    c.update = t;
    c.dir = n;
    return;
  }
  const d = getComputedStyle(e);
  const p = {
    transform: d.transform,
    opacity: Number(d.opacity)
  };
  if (c?.phase === "in" && p.opacity < 0.5) {
    c.entering.cancel();
    t();
    c.entering = e.animate([p, {
      transform: "none",
      opacity: 1
    }], {
      duration: r * (1 - p.opacity),
      easing: Gs
    });
    c.entering.onfinish = () => rn.get(e) === c && rn.delete(e);
    return;
  }
  c?.entering.cancel();
  const u = {
    phase: "out",
    update: t,
    dir: n
  };
  rn.set(e, u);
  const y = e.animate([p, {
    transform: i(-o * n),
    opacity: 0
  }], {
    duration: a * p.opacity,
    easing: c ? "linear" : zm,
    fill: "forwards"
  });
  y.onfinish = () => {
    if (rn.get(e) === u) {
      u.update();
      u.phase = "in";
      u.entering = e.animate([{
        transform: i(o * u.dir),
        opacity: 0
      }, {
        transform: "none",
        opacity: 1
      }], {
        duration: r,
        easing: Gs
      });
      y.cancel();
      u.entering.onfinish = () => rn.get(e) === u && rn.delete(e);
    }
  };
}
const Xm = () => document.documentElement.dir === "rtl" ? -1 : 1;
const lo = (e, t, s = 1, n = 24) => Su(e, t, {
  axis: "x",
  dir: s * Xm(),
  distance: n
});
function Vt(e, t, s = 1, n) {
  if (e.dataset.text === t) {
    return;
  }
  const o = e.dataset.text === undefined;
  e.dataset.text = t;
  const a = () => {
    e.textContent = t;
    n?.(e);
  };
  if (o) {
    return a();
  }
  Su(e, a, {
    axis: "y",
    dir: s,
    distance: 10,
    out: 120,
    inn: 240
  });
}
function ho(e, t, {
  room: s = e.scrollHeight - e.clientHeight,
  least: n = 0
} = {}) {
  const o = e.scrollTop;
  const a = Math.max(0, Math.min(t, s)) - o;
  if (Math.abs(a) < 1) {
    return;
  }
  if (Ne()) {
    return e.scrollTop = o + a;
  }
  const r = Math.max(n, Math.min(650, 280 + Math.abs(a) * 0.8));
  const i = e._glide = {};
  if (!e._glideWatched) {
    e._glideWatched = true;
    const p = () => e._glide && (e._glide.stopped = true);
    e.addEventListener("wheel", p, {
      passive: true
    });
    e.addEventListener("touchstart", p, {
      passive: true
    });
  }
  let c;
  const d = p => {
    if (i.stopped || e._glide !== i) {
      return;
    }
    c ??= p;
    const u = Math.min(1, (p - c) / r);
    e.scrollTop = o + a * (u < 0.5 ? u ** 3 * 4 : 1 - (2 - u * 2) ** 3 / 2);
    if (u < 1) {
      requestAnimationFrame(d);
    }
  };
  requestAnimationFrame(d);
}
const Zm = "modulepreload";
const Jm = function (e) {
  return "/" + e;
};
const lh = {};
const Ce = function (t, s, n) {
  let o = Promise.resolve();
  if (s && s.length > 0) {
    let c = function (d) {
      return Promise.all(d.map(p => Promise.resolve(p).then(u => ({
        status: "fulfilled",
        value: u
      }), u => ({
        status: "rejected",
        reason: u
      }))));
    };
    document.getElementsByTagName("link");
    const r = document.querySelector("meta[property=csp-nonce]");
    const i = r?.nonce || r?.getAttribute("nonce");
    o = c(s.map(d => {
      d = Jm(d);
      if (d in lh) {
        return;
      }
      lh[d] = true;
      const p = d.endsWith(".css");
      const u = p ? "[rel=\"stylesheet\"]" : "";
      if (document.querySelector(`link[href="${d}"]${u}`)) {
        return;
      }
      const y = document.createElement("link");
      y.rel = p ? "stylesheet" : Zm;
      if (!p) {
        y.as = "script";
      }
      y.crossOrigin = "";
      y.href = d;
      if (i) {
        y.setAttribute("nonce", i);
      }
      document.head.appendChild(y);
      if (p) {
        return new Promise((T, m) => {
          y.addEventListener("load", T);
          y.addEventListener("error", () => m(new Error(`Unable to preload CSS for ${d}`)));
        });
      }
    }));
  }
  function a(r) {
    const i = new Event("vite:preloadError", {
      cancelable: true
    });
    i.payload = r;
    window.dispatchEvent(i);
    if (!i.defaultPrevented) {
      throw r;
    }
  }
  return o.then(r => {
    for (const i of r || []) {
      if (i.status === "rejected") {
        a(i.reason);
      }
    }
    return t().catch(a);
  });
};
const Tu = "protocol-explorer:lang";
const qt = [{
  code: "en",
  name: "English",
  short: "EN",
  html: "en"
}, {
  code: "es",
  name: "Español",
  short: "ES",
  html: "es",
  load: () => Ce(() => import("./es-CWfXW5jh.js"), __vite__mapDeps([0, 1]))
}, {
  code: "pt",
  name: "Português",
  short: "PT",
  html: "pt-BR",
  tag: "pt",
  load: () => Ce(() => import("./pt-1gauOvPm.js"), __vite__mapDeps([2, 1]))
}, {
  code: "fr",
  name: "Français",
  short: "FR",
  html: "fr",
  load: () => Ce(() => import("./fr-C5eMvhxr.js"), __vite__mapDeps([3, 1]))
}, {
  code: "it",
  name: "Italiano",
  short: "IT",
  html: "it",
  load: () => Ce(() => import("./it-C2pCPOTd.js"), __vite__mapDeps([4, 1]))
}, {
  code: "de",
  name: "Deutsch",
  short: "DE",
  html: "de",
  load: () => Ce(() => import("./de-CkTXFfkZ.js"), __vite__mapDeps([5, 1]))
}, {
  code: "nl",
  name: "Nederlands",
  short: "NL",
  html: "nl",
  load: () => Ce(() => import("./nl-iZ_6hecB.js"), __vite__mapDeps([6, 1]))
}, {
  code: "pl",
  name: "Polski",
  short: "PL",
  html: "pl",
  load: () => Ce(() => import("./pl-C7_zAHkL.js"), __vite__mapDeps([7, 1]))
}, {
  code: "tr",
  name: "Türkçe",
  short: "TR",
  html: "tr",
  load: () => Ce(() => import("./tr-Bud-ECdT.js"), __vite__mapDeps([8, 1]))
}, {
  code: "id",
  name: "Bahasa Indonesia",
  short: "ID",
  html: "id",
  load: () => Ce(() => import("./id-DSv3w2E0.js"), __vite__mapDeps([9, 1]))
}, {
  code: "vi",
  name: "Tiếng Việt",
  short: "VI",
  html: "vi",
  load: () => Ce(() => import("./vi-BtObyLa_.js"), __vite__mapDeps([10, 1]))
}, {
  code: "el",
  name: "Ελληνικά",
  short: "EL",
  html: "el",
  load: () => Ce(() => import("./el-C5kf_mfQ.js"), __vite__mapDeps([11, 1]))
}, {
  code: "uk",
  name: "Українська",
  short: "UA",
  html: "uk",
  load: () => Ce(() => import("./uk-CFZ4hBii.js"), __vite__mapDeps([12, 1]))
}, {
  code: "ru",
  name: "Русский",
  short: "RU",
  html: "ru",
  load: () => Ce(() => import("./ru-BEX_fK9x.js"), __vite__mapDeps([13, 1]))
}, {
  code: "zh",
  name: "简体中文",
  short: "ZH",
  badge: "简",
  html: "zh-CN",
  tag: "zh-Hans",
  load: () => Ce(() => import("./zh-AH-lIMHP.js"), [])
}, {
  code: "zh-TW",
  name: "繁體中文",
  short: "TW",
  badge: "繁",
  html: "zh-TW",
  tag: "zh-Hant",
  load: () => Ce(() => import("./zh-TW-CtKzzU9L.js"), [])
}, {
  code: "ja",
  name: "日本語",
  short: "JA",
  html: "ja",
  load: () => Ce(() => import("./ja-DIYXJF6J.js"), [])
}, {
  code: "ko",
  name: "한국어",
  short: "KO",
  html: "ko",
  load: () => Ce(() => import("./ko-DocaHqx7.js"), [])
}, {
  code: "hi",
  name: "हिन्दी",
  short: "HI",
  html: "hi",
  load: () => Ce(() => import("./hi-kacvLFRn.js"), __vite__mapDeps([14, 1]))
}, {
  code: "ar",
  name: "العربية",
  short: "AR",
  html: "ar",
  dir: "rtl",
  load: () => Ce(() => import("./ar-MCahGY6d.js"), __vite__mapDeps([15, 1]))
}, {
  code: "he",
  name: "עברית",
  short: "HE",
  html: "he",
  dir: "rtl",
  load: () => Ce(() => import("./he-BTJlyhmU.js"), __vite__mapDeps([16, 1]))
}];
let _r = "en";
let oo = null;
const bu = new Set();
const ey = (e, t) => t ? e.replace(/\{(\w+)\}/g, (s, n) => n in t ? t[n] : s) : e;
function S(e, t) {
  if (typeof e != "string" || !e) {
    return e;
  }
  let s = e;
  if (oo) {
    const n = oo.strings[e];
    if (n !== undefined) {
      s = n;
    } else {
      for (const [o, a] of oo.patterns) {
        if (o.test(e)) {
          s = e.replace(o, a);
          break;
        }
      }
    }
  }
  s = ey(s, t);
  if (oo?.post) {
    return oo.post(s);
  } else {
    return s;
  }
}
const Sa = () => _r;
const gn = () => qt.find(e => e.code === _r).dir === "rtl";
const po = e => gn() ? `⁦${e}⁩` : e;
const ty = /[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufefc]/;
const vu = e => gn() && !ty.test(e);
function as(e) {
  const t = qt.find(n => n.code === _r).html;
  const s = e.toLocaleUpperCase(t);
  if (t === "el") {
    return s.normalize("NFD").replace(/\u0301/g, "").normalize("NFC");
  } else {
    return s;
  }
}
const z = (e, t = false) => `data-t="${M(e)}"${t ? " data-t-upper" : ""}>${M(t ? as(S(e)) : S(e))}`;
const dr = e => `data-t-tip="${M(e)}" data-tip="${M(S(e))}"`;
function Yl(e, t) {
  e.dataset.tTip = t;
  e.dataset.tip = S(t);
}
function sy(e) {
  e.querySelectorAll("[data-t]").forEach(t => {
    const s = S(t.dataset.t);
    t.textContent = t.hasAttribute("data-t-upper") ? as(s) : s;
  });
  e.querySelectorAll("[data-t-title]").forEach(t => t.title = S(t.dataset.tTitle));
  e.querySelectorAll("[data-t-label]").forEach(t => t.setAttribute("aria-label", S(t.dataset.tLabel)));
  e.querySelectorAll("[data-t-tip]").forEach(t => t.dataset.tip = S(t.dataset.tTip));
  e.querySelectorAll("[data-t-placeholder]").forEach(t => t.placeholder = S(t.dataset.tPlaceholder));
}
async function ny(e) {
  const t = qt.find(a => a.code === e);
  if (!t?.load) {
    return null;
  }
  const {
    strings: s,
    patterns: n = [],
    post: o
  } = (await t.load()).default;
  return {
    strings: s,
    patterns: n,
    post: o
  };
}
let ch = 0;
async function ku(e, t = true) {
  const s = ++ch;
  const n = qt.some(r => r.code === e) ? e : "en";
  const o = await ny(n);
  if (s !== ch) {
    return;
  }
  oo = o;
  _r = n;
  const a = qt.find(r => r.code === n);
  document.documentElement.lang = a.html;
  document.documentElement.dir = a.dir ?? "ltr";
  if (t) {
    try {
      localStorage.setItem(Tu, n);
    } catch {}
  }
  bu.forEach(r => r(n));
}
const oy = e => bu.add(e);
function ay(e = navigator.languages?.length ? navigator.languages : [navigator.language]) {
  for (const t of e) {
    const s = String(t || "").toLowerCase();
    const [n] = s.split("-");
    if (n === "en") {
      return "en";
    }
    if (n === "zh") {
      if (/-(tw|hk|mo|hant)\b/.test(s)) {
        return "zh-TW";
      } else {
        return "zh";
      }
    }
    const o = {
      iw: "he",
      in: "id"
    }[n] ?? n;
    if (qt.some(a => a.code === o)) {
      return o;
    }
  }
  return "en";
}
async function ry() {
  let e = null;
  try {
    e = localStorage.getItem(Tu);
  } catch {}
  const t = e ?? ay();
  if (t && t !== "en") {
    await ku(t, false).catch(() => {});
  }
}
const iy = `
<svg class="logo-cube" viewBox="0 0 64 64" aria-hidden="true">
  <g fill="currentColor" stroke="var(--bg)" stroke-width="2.4" stroke-linejoin="round">
    <path d="M32 3 L58 16.5 L32 30 L6 16.5 Z" />
    <path d="M6 16.5 L32 30 L32 45.5 L6 32 Z" />
    <path d="M58 16.5 L32 30 L32 45.5 L58 32 Z" />
    <path d="M6 32 L32 45.5 L32 61 L6 47.5 Z" />
    <path d="M58 32 L32 45.5 L32 61 L58 47.5 Z" />
  </g>
</svg>`;
function ly() {
  const e = Ts.map((t, s) => `<span class="learning-seg"><i style="--i:${s}"></i></span>`).join("");
  return `
  <div class="learning">
    <div class="learning-head">
      <span class="learning-label" ${z("LEARNING PROGRESS")}</span>
      <span class="learning-value"></span>
    </div>
    <div class="learning-bars" role="img">${e}</div>
    <div class="learning-sub"><span class="learning-done"></span> / ${Ts.length} <span ${z("COMPLETE")}</span> <span class="dot">·</span> <span class="learning-active"></span> <span ${z("IN PROGRESS")}</span></div>
  </div>`;
}
function jl(e, t) {
  const s = Ts.map(a => ({
    name: a.name,
    value: jm(t[a.id]),
    status: Nr(t[a.id])
  })).sort((a, r) => r.value - a.value);
  const n = Math.round(s.reduce((a, r) => a + r.value, 0) / s.length * 100);
  const o = e.querySelector(".learning");
  o.querySelectorAll(".learning-seg").forEach((a, r) => {
    const i = s[r];
    a.classList.toggle("partial", i.value > 0 && i.value < 1);
    a.title = `${i.name}: ${Math.round(i.value * 100)}%`;
    a.firstElementChild.style.width = `${i.value * 100}%`;
  });
  o.querySelector(".learning-bars").setAttribute("aria-label", S("{pct}% complete", {
    pct: n
  }));
  Vt(o.querySelector(".learning-value"), `${n}%`);
  Vt(o.querySelector(".learning-done"), String(s.filter(a => a.status === "done").length));
  Vt(o.querySelector(".learning-active"), String(s.filter(a => a.status === "progress").length));
}
function cy() {
  return `
  <a class="credit" href="https://x.com/DilumSanjaya" target="_blank" rel="noopener noreferrer" data-t-title="Dilum Sanjaya on X" title="${S("Dilum Sanjaya on X")}">
    <span class="credit-label" ${z("DESIGNED BY")}</span>
    <span class="credit-name">
      <svg class="credit-x" viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="currentColor" d="M17.75 3h3.07l-6.71 7.67L22 21h-6.18l-4.84-6.33L5.44 21H2.37l7.18-8.2L2 3h6.33l4.38 5.79L17.75 3Zm-1.08 16.18h1.7L7.4 4.73H5.58l11.09 14.45Z"/></svg>
      DilumSanjaya
    </span>
  </a>`;
}
const ll = Math.ceil(qt.length / 2);
function Pu(e) {
  try {
    const t = qt.find(n => n.code === Sa()).html;
    const s = new Intl.DisplayNames([t, "en"], {
      type: "language",
      languageDisplay: "standard"
    }).of(e.tag ?? e.code);
    return s.charAt(0).toLocaleUpperCase(t) + s.slice(1);
  } catch {
    return "";
  }
}
function dy() {
  const e = qt.map(t => `<button type="button" role="menuitemradio" data-lang="${t.code}" aria-checked="${t.code === Sa()}">
      <span class="lang-badge" aria-hidden="true"><span class="lang-short" lang="${t.html}">${t.badge ?? t.short}</span>${Se.check}</span>
      <span class="lang-names"><span class="lang-native" lang="${t.html}">${t.name}</span><span class="lang-local">${M(Pu(t))}</span></span>
    </button>`).join("");
  return `
  <div class="lang">
    <button class="menu-btn" type="button" aria-haspopup="menu" aria-expanded="false" data-t-label="Language" aria-label="${S("Language")}" data-t-title="Language" title="${S("Language")}">
      ${Se.globe}<span class="lang-code">${qt.find(t => t.code === Sa()).short}</span>${Se.caret}
    </button>
    <div class="lang-menu" role="menu" hidden>
      <div class="lang-head" aria-hidden="true" ${z("Language")}</div>
      <div class="lang-grid" role="none" style="--rows: ${ll}">${e}</div>
    </div>
  </div>`;
}
function hy(e, t) {
  const s = e.querySelector(".lang");
  const n = s.querySelector(".menu-btn");
  const o = s.querySelector(".lang-menu");
  const a = () => [...o.querySelectorAll("[data-lang]")];
  function r(c, d = true) {
    if (c !== !o.hidden) {
      o.hidden = !c;
      n.setAttribute("aria-expanded", c);
      if (c) {
        if (d) {
          (a().find(p => p.getAttribute("aria-checked") === "true") ?? a()[0]).focus();
        }
        document.addEventListener("pointerdown", i, true);
      } else {
        document.removeEventListener("pointerdown", i, true);
      }
    }
  }
  const i = c => !s.contains(c.target) && r(false, false);
  n.addEventListener("click", () => r(o.hidden, true));
  o.addEventListener("click", async c => {
    const d = c.target.closest("[data-lang]");
    if (d && (r(false), n.focus(), d.dataset.lang !== Sa())) {
      s.classList.add("is-loading");
      try {
        await t(d.dataset.lang);
      } finally {
        s.classList.remove("is-loading");
      }
    }
  });
  s.addEventListener("keydown", c => {
    if (o.hidden) {
      return;
    }
    const d = a();
    const p = d.indexOf(document.activeElement);
    if (c.key === "ArrowDown" || c.key === "ArrowUp") {
      c.preventDefault();
      d[(p + (c.key === "ArrowDown" ? 1 : -1) + d.length) % d.length].focus();
    } else if (c.key === "ArrowRight" || c.key === "ArrowLeft") {
      c.preventDefault();
      const u = c.key === "ArrowRight" != (document.documentElement.dir === "rtl") ? ll : -ll;
      d[Math.min(d.length - 1, Math.max(0, p + u))].focus();
    } else if (c.key === "Home" || c.key === "End") {
      c.preventDefault();
      d[c.key === "Home" ? 0 : d.length - 1].focus();
    } else if (c.key === "Escape") {
      c.preventDefault();
      r(false);
      n.focus();
    } else if (c.key === "Tab") {
      r(false, false);
    }
  });
}
function py(e) {
  const t = Sa();
  e.querySelector(".lang-code").textContent = qt.find(s => s.code === t).short;
  e.querySelectorAll(".lang-menu [data-lang]").forEach(s => {
    s.setAttribute("aria-checked", s.dataset.lang === t);
    s.querySelector(".lang-local").textContent = Pu(qt.find(n => n.code === s.dataset.lang));
  });
}
function uy(e) {
  py(e);
  e.querySelectorAll(".osi-chips span").forEach((t, s) => t.title = S("Layer {n}: {name}", {
    n: s + 1,
    name: S(zl[s])
  }));
  delete e.dataset.lesson;
}
const zl = ["Physical", "Data Link", "Network", "Transport", "Session", "Presentation", "Application"];
function Gr(e) {
  Eu(e.querySelector(".topbar .now-step"));
  const t = e.querySelector(".brand-text h1");
  const s = e.querySelector(".brand-text p");
  if (!t?.offsetWidth || !s) {
    return;
  }
  s.style.letterSpacing = s.style.fontSize = "";
  const n = cl;
  const o = n(t);
  const a = n(s);
  if (a <= o) {
    return;
  }
  const r = getComputedStyle(s);
  const i = parseFloat(r.fontSize);
  const c = parseFloat(r.letterSpacing) / i;
  const d = 0.02;
  s.style.letterSpacing = `${d}em`;
  const p = n(s);
  if (p <= o) {
    s.style.letterSpacing = `${c - (a - o) / (a - p) * (c - d)}em`;
  } else {
    s.style.fontSize = `${i * o / p}px`;
  }
}
function fy() {
  return `
  <div class="now">
    <div class="now-label" ${z("NOW LEARNING")}</div>
    <div class="now-title"><span class="now-name"></span></div>
    <div class="now-progress">
      <span class="now-dots"></span>
      <span class="now-step"></span>
    </div>
  </div>`;
}
function my() {
  const e = zl.map((t, s) => `<span data-layer="${s + 1}" title="${S("Layer {n}: {name}", {
    n: s + 1,
    name: S(t)
  })}">${s + 1}</span>`).join("");
  return `
  <div class="osi">
    <div class="osi-head">
      <span class="osi-label" ${z("OSI LAYER")}</span>
      <span class="osi-name"></span>
    </div>
    <div class="osi-chips"><i class="osi-marker"></i>${e}</div>
  </div>`;
}
const Au = /Mac|iPhone|iPad|iPod/.test(navigator.platform || navigator.userAgent) ? "⌘" : "Ctrl";
function yy() {
  return `
  <div class="view-tools" role="group" data-t-label="View" aria-label="${S("View")}">
    <button class="tool-btn list-btn" type="button" aria-expanded="true" aria-controls="protocols" data-t-label="Protocol list" aria-label="${S("Protocol list")}" ${dr("Hide the protocol list (L)")}>${Se.list}</button>
    <button class="tool-btn focus-btn" type="button" aria-pressed="false" data-t-label="Diagram only" aria-label="${S("Diagram only")}" ${dr("Diagram only (D)")}>${Se.layout}</button>
    <button class="tool-btn fullscreen-btn" type="button" aria-pressed="false" data-t-label="Fullscreen" aria-label="${S("Fullscreen")}" ${dr("Fullscreen (F)")}>
      <span class="swap-icon">${Se.expand.replace("<svg", "<svg class=\"icon-expand\"")}${Se.collapse.replace("<svg", "<svg class=\"icon-collapse\"")}</span>
    </button>
    <button class="tool-btn keys-btn" type="button" aria-haspopup="dialog" data-t-label="Keyboard shortcuts" aria-label="${S("Keyboard shortcuts")}" ${dr("Keyboard shortcuts (?)")}>${Se.keyboard}</button>
  </div>`;
}
function wy() {
  return `
  <button class="search-btn" type="button" aria-haspopup="dialog" data-t-label="Search protocols" aria-label="${S("Search protocols")}">
    ${Se.search}<span class="search-text" ${z("Search protocols")}</span><kbd class="search-kbd">${Au} K</kbd>
  </button>`;
}
function gy() {
  return `
  <header class="topbar is-lean">
    <button class="drawer-btn" type="button" data-t-label="Protocols" aria-label="${S("Protocols")}" aria-expanded="false" aria-controls="protocols">${Se.menu}<span ${z("PROTOCOLS")}</span></button>
    <div class="brand">
      <div class="logo-frame">
        <span class="corner tl"></span><span class="corner tr"></span>
        <span class="corner bl"></span><span class="corner br"></span>
        ${iy}
      </div>
      <div class="brand-text">
        <h1>PROTOCOL <em>EXPLORER</em></h1>
        <p ${z("LEARN HOW THE INTERNET WORKS")}</p>
      </div>
    </div>

    <span class="topbar-sep"></span>
    ${fy()}
    <span class="topbar-sep"></span>
    ${my()}

    <div class="topbar-tools">
      ${wy()}
      ${yy()}
      <span class="topbar-sep"></span>
      ${ly()}
      <span class="topbar-sep"></span>
      ${cy()}
      <span class="topbar-sep"></span>
      ${dy()}
      <div class="theme-toggle" role="group" data-t-label="Theme" aria-label="${S("Theme")}">
        <button type="button" data-theme-choice="light" aria-pressed="false" data-t-label="Light mode" aria-label="${S("Light mode")}" data-t-title="Light mode" title="${S("Light mode")}">${Se.sun}</button>
        <button type="button" data-theme-choice="dark" aria-pressed="false" data-t-label="Dark mode" aria-label="${S("Dark mode")}" data-t-title="Dark mode" title="${S("Dark mode")}">${Se.moon}</button>
      </div>
    </div>
  </header>`;
}
function Sy(e, t) {
  const s = e.dataset.layer ? Number(e.dataset.layer) : null;
  e.dataset.lesson = t.id;
  e.dataset.layer = t.layer;
  Vt(e.querySelector(".now-name"), `${t.name} · ${as(S(t.title))}`);
  Vt(e.querySelector(".osi-name"), as(S(zl[t.layer - 1])), s && t.layer < s ? -1 : 1);
  const n = e.querySelector(".now-dots");
  if (n.children.length !== t.steps.length) {
    n.innerHTML = t.steps.map(() => "<i></i>").join("");
  }
  n.style.setProperty("--dots", t.steps.length);
  const o = e.querySelector(`.osi-chips [data-layer="${t.layer}"]`);
  e.querySelectorAll(".osi-chips span").forEach(a => a.classList.toggle("is-active", a === o));
  dh(e);
  if (s === null) {
    requestAnimationFrame(() => e.querySelector(".osi-marker").classList.add("is-ready"));
    new ResizeObserver(() => dh(e, false)).observe(e.querySelector(".osi-chips"));
  }
}
function dh(e, t = true) {
  const s = e.querySelector(".osi-chips .is-active");
  const n = e.querySelector(".osi-marker");
  if (!!s && !!s.offsetWidth) {
    if (!t) {
      n.style.transition = "none";
    }
    n.style.left = `${s.offsetLeft}px`;
    n.style.width = `${s.offsetWidth}px`;
    if (!t) {
      requestAnimationFrame(() => n.style.removeProperty("transition"));
    }
  }
}
function Ty(e, t, s) {
  if (e.dataset.lesson !== s.id) {
    Sy(e, s);
  }
  e.querySelectorAll(".now-dots i").forEach((a, r) => a.className = `is-${t.steps[r]}`);
  const n = s.steps[t.activeStep];
  const o = t.done ? S("LESSON COMPLETE") : t.started ? S("STEP {n}/{total} · {title}", {
    n: t.activeStep + 1,
    total: s.steps.length,
    title: as(S(n.title))
  }) : S("OVERVIEW · {n} STEPS", {
    n: s.steps.length
  });
  Vt(e.querySelector(".now-step"), o, t.started ? 1 : -1, Eu);
}
function Eu(e) {
  if (!e) {
    return;
  }
  e.style.letterSpacing = e.style.flexShrink = "";
  const t = e.getBoundingClientRect().width - 0.5;
  const s = cl(e);
  if (t <= 0 || s <= t) {
    return;
  }
  const n = getComputedStyle(e).letterSpacing;
  e.style.letterSpacing = "0px";
  const o = cl(e);
  e.style.letterSpacing = o >= t ? "0px" : `calc(${n} * ${(t - o) / (s - o)})`;
  if (o < t) {
    e.style.flexShrink = "0";
  }
}
const cl = e => {
  const t = document.createRange();
  t.selectNodeContents(e);
  return t.getBoundingClientRect().width;
};
const dl = "protocol-explorer:theme";
const by = window.matchMedia("(prefers-color-scheme: dark)");
const vy = {
  light: "#fdfdfe",
  dark: "#0b1020"
};
function hl(e, t) {
  let s = null;
  try {
    s = localStorage.getItem(dl);
  } catch {}
  if (s) {
    for (const n of document.querySelectorAll("meta[name=\"theme-color\"]")) {
      n.content = vy[t];
    }
  }
  e.querySelectorAll("[data-theme-choice]").forEach(n => {
    const o = n.dataset.themeChoice === t;
    n.classList.toggle("is-active", o);
    n.setAttribute("aria-pressed", o);
  });
}
function hh(e, t, s) {
  const n = document.documentElement;
  if (n.dataset.theme === t) {
    return hl(e, t);
  }
  const o = () => {
    n.dataset.theme = t;
    hl(e, t);
  };
  if (!s || !document.startViewTransition || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    return o();
  }
  const a = s.getBoundingClientRect();
  const r = a.left + a.width / 2;
  const i = a.top + a.height / 2;
  const c = Math.hypot(Math.max(r, innerWidth - r), Math.max(i, innerHeight - i));
  document.startViewTransition(o).ready.then(() => n.animate({
    clipPath: [`circle(0px at ${r}px ${i}px)`, `circle(${c}px at ${r}px ${i}px)`]
  }, {
    duration: 650,
    easing: "cubic-bezier(0.16, 1, 0.3, 1)",
    pseudoElement: "::view-transition-new(root)"
  }));
}
function ky(e) {
  hl(e, document.documentElement.dataset.theme);
  e.querySelector(".theme-toggle").addEventListener("click", t => {
    const s = t.target.closest("[data-theme-choice]");
    if (s) {
      try {
        localStorage.setItem(dl, s.dataset.themeChoice);
      } catch {}
      hh(e, s.dataset.themeChoice, s);
    }
  });
  by.addEventListener("change", t => {
    let s = null;
    try {
      s = localStorage.getItem(dl);
    } catch {}
    if (!s) {
      hh(e, t.matches ? "dark" : "light");
    }
  });
}
function Py(e) {
  e.querySelector(".theme-toggle [data-theme-choice]:not(.is-active)")?.click();
}
const xu = e => e.addEventListener("click", t => {
  if (t.target === e) {
    e.close();
  }
});
function Ay() {
  return `
  <dialog class="dialog shortcuts" aria-labelledby="shortcuts-title">
    <div class="dialog-head">
      <h2 class="dialog-title" id="shortcuts-title" ${z("KEYBOARD SHORTCUTS")}</h2>
      <button class="dialog-close" type="button" data-t-label="Close" aria-label="${S("Close")}">${Se.close}</button>
    </div>
    <div class="shortcuts-body" tabindex="-1" autofocus></div>
    <p class="dialog-foot"></p>
  </dialog>`;
}
const pa = e => `<kbd>${M(e)}</kbd>`;
function Ey(e) {
  const [t, s] = gn() ? ["←", "→"] : ["→", "←"];
  return [["Playback", [[[["Space"]], "Play or pause"], [[[t]], "Next step"], [[[s]], "Previous step"], [[["S"]], "One packet at a time"], [[["1"], ["9"]], "Go to step 1 to 9", "–"], [[["["], ["]"]], "Slower, faster"], [[["Esc"]], "Back to the overview"]]], ["View", [[[["V"]], "Network or sequence view"], [[["D"]], "Diagram only"], [[["L"]], "Show or hide the protocol list"], [[["F"]], "Fullscreen"], [[["T"]], "Light or dark theme"]]], ["Find", [[[[e, "K"], ["/"]], "Search protocols and steps"], [[["N"], ["P"]], "Next or previous protocol"], [[["?"]], "These shortcuts"]]], ["Packet inspector", [[[[s], [t]], "Previous or next packet"], [[["Esc"]], "Close it"]]]];
}
function xy(e) {
  return Ey(e).map(([t, s]) => `
      <section class="shortcut-group">
        <h3>${M(as(S(t)))}</h3>
        <dl>${s.map(([n, o, a = "/"]) => `<div><dt>${n.map(r => r.map(pa).join("<span class=\"kbd-plus\">+</span>")).join(`<span class="kbd-or">${a}</span>`)}</dt><dd>${M(S(o))}</dd></div>`).join("")}</dl>
      </section>`).join("");
}
function Cy(e, t) {
  xu(e);
  e.querySelector(".dialog-close").addEventListener("click", () => e.close());
  return {
    open() {
      e.querySelector(".shortcuts-body").innerHTML = xy(t);
      e.querySelector(".dialog-foot").innerHTML = M(S("Press {key} any time to see these again.")).replace("{key}", pa("?"));
      if (!e.open) {
        e.showModal();
      }
    },
    isOpen: () => e.open
  };
}
function $y() {
  return `
  <dialog class="dialog palette" data-t-label="Search protocols" aria-label="${S("Search protocols")}">
    <div class="palette-field">
      ${Se.search}
      <input class="palette-input" type="text" role="combobox" aria-expanded="true" aria-controls="palette-list" aria-autocomplete="list" autocomplete="off" spellcheck="false" data-t-placeholder="Search protocols and steps" placeholder="${S("Search protocols and steps")}">
      <kbd class="palette-esc">Esc</kbd>
    </div>
    <ul class="palette-list" id="palette-list" role="listbox"></ul>
    <p class="palette-empty" hidden ${z("Nothing matches.")}</p>
    <div class="palette-foot">
      <span>${pa("↑")}${pa("↓")} <span ${z("to move")}</span></span>
      <span>${pa("Enter")} <span ${z("to open")}</span></span>
    </div>
  </dialog>`;
}
const Cu = e => String(e).toLocaleLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
const Ly = {
  core: "CORE",
  application: "APPLICATION",
  security: "SECURITY"
};
function Iy(e, t) {
  const s = [];
  e.forEach((n, o) => {
    const a = t[n.id];
    if (!a) {
      return;
    }
    const r = i => [S(i), i];
    s.push({
      kind: "lesson",
      id: n.id,
      order: o,
      name: n.name,
      sub: S(n.full),
      tag: S(Ly[n.group]),
      fields: [[n.name, 12], [n.id, 8], ...r(n.full).map(i => [i, 5]), ...r(a.title).map(i => [i, 5])]
    });
    a.steps.forEach((i, c) => s.push({
      kind: "step",
      id: n.id,
      step: c,
      order: o,
      name: n.name,
      title: S(i.title),
      sub: S(i.desc),
      fields: [...r(i.title).map(d => [d, 4]), ...r(i.desc).map(d => [d, 2]), [n.name, 3]]
    }));
  });
  for (const n of s) {
    n.fields = n.fields.map(([o, a]) => [Cu(o), a]);
  }
  return s;
}
function Ry(e, t) {
  let s = 0;
  for (const n of t) {
    let o = 0;
    for (const [a, r] of e.fields) {
      const i = a.indexOf(n);
      if (i < 0) {
        continue;
      }
      const c = r * (i === 0 ? 3 : /[\s\-/(·.]/.test(a[i - 1]) ? 2 : 1);
      if (c > o) {
        o = c;
      }
    }
    if (!o) {
      return 0;
    }
    s += o;
  }
  return s + (e.kind === "lesson" ? 4 : 0);
}
function Ny(e, t, s) {
  const n = e.kind === "lesson" ? `<span class="pal-name">${M(e.name)}</span><span class="pal-sub">${M(e.sub)}</span><span class="pal-tag">${M(e.tag)}</span>` : `<span class="pal-name">${M(e.name)} <span class="pal-step">${M(S("STEP {n}", {
    n: e.step + 1
  }))}</span></span><span class="pal-sub"><b>${M(e.title)}</b> · ${M(e.sub)}</span>`;
  return `<li class="pal-option is-${e.kind}${t === s ? " is-active" : ""}" id="pal-${t}" role="option" aria-selected="${t === s}" data-index="${t}">${n}</li>`;
}
function Dy(e, {
  protocols: t,
  lessons: s,
  choose: n
}) {
  const o = e.querySelector(".palette-input");
  const a = e.querySelector(".palette-list");
  const r = e.querySelector(".palette-empty");
  let i = [];
  let c = [];
  let d = 0;
  function p() {
    const T = Cu(o.value).split(/\s+/).filter(Boolean);
    c = T.length ? i.map(m => ({
      e: m,
      s: Ry(m, T)
    })).filter(m => m.s > 0).sort((m, w) => w.s - m.s || m.e.order - w.e.order || (m.e.step ?? -1) - (w.e.step ?? -1)).slice(0, 40).map(m => m.e) : i.filter(m => m.kind === "lesson");
    d = 0;
    a.innerHTML = c.map((m, w) => Ny(m, w, d)).join("");
    r.hidden = c.length > 0;
    o.setAttribute("aria-activedescendant", c.length ? "pal-0" : "");
    a.scrollTop = 0;
  }
  function u(T, m = true) {
    if (c.length) {
      d = (T + c.length) % c.length;
      a.querySelectorAll(".pal-option").forEach(w => {
        const k = Number(w.dataset.index) === d;
        w.classList.toggle("is-active", k);
        w.setAttribute("aria-selected", k);
        if (k && m) {
          w.scrollIntoView({
            block: "nearest"
          });
        }
      });
      o.setAttribute("aria-activedescendant", `pal-${d}`);
    }
  }
  function y(T) {
    const m = c[T];
    if (m) {
      e.close();
      n(m.id, m.kind === "step" ? m.step : null);
    }
  }
  o.addEventListener("input", p);
  o.addEventListener("keydown", T => {
    if (T.key === "ArrowDown" || T.key === "ArrowUp") {
      T.preventDefault();
      u(d + (T.key === "ArrowDown" ? 1 : -1));
    } else if (T.key === "PageDown" || T.key === "PageUp") {
      T.preventDefault();
      u(Math.max(0, Math.min(c.length - 1, d + (T.key === "PageDown" ? 8 : -8))));
    } else if (T.key === "Enter") {
      T.preventDefault();
      y(d);
    }
  });
  a.addEventListener("pointermove", T => {
    const m = T.target.closest(".pal-option");
    if (m && Number(m.dataset.index) !== d) {
      u(Number(m.dataset.index), false);
    }
  });
  a.addEventListener("click", T => {
    const m = T.target.closest(".pal-option");
    if (m) {
      y(Number(m.dataset.index));
    }
  });
  xu(e);
  return {
    open() {
      i = Iy(t, s);
      o.value = "";
      p();
      if (!e.open) {
        e.showModal();
      }
      o.focus();
    },
    isOpen: () => e.open
  };
}
const Oy = [["all", "ALL"], ["core", "CORE"], ["application", "APPLICATION"], ["security", "SECURITY"]];
function My(e) {
  return `<div class="steps-wrap"><div class="steps-clip"><ol class="steps">${e.steps.map((s, n) => `
      <li class="step" data-step="${n}" style="--i:${n}">
        <button class="step-btn" type="button">
          <span class="step-num"><span>${n + 1}</span>${Se.check.replace("<path", "<path pathLength=\"1\"")}</span>
          <span class="step-text">
            <span class="step-title" ${z(s.title, true)}</span>
            <span class="step-desc" ${z(s.desc)}</span>
          </span>
        </button>
      </li>`).join("")}</ol></div></div>`;
}
function qy(e) {
  const t = Ts.map(n => {
    const o = e[n.id];
    return `
      <li class="proto ${o ? "has-lesson" : ""}" data-group="${n.group}" ${o ? `data-lesson="${n.id}"` : ""}>
        <button class="proto-row" type="button" aria-expanded="false">
          <span class="status-dot ${Nr(o)}" data-status="${Nr(o)}"></span>
          <span class="proto-text">
            <span class="proto-name">${n.name}</span>
            <span class="proto-full" ${z(n.full)}</span>
          </span>
          <span class="proto-chev">${Se.chevron}</span>
        </button>
        ${o ? My(o) : ""}
      </li>`;
  }).join("");
  const s = Oy.map(([n, o], a) => {
    const r = n === "all" ? Ts.length : Ts.filter(i => i.group === n).length;
    return `<button class="tab ${a === 0 ? "is-active" : ""}" type="button" role="tab" aria-selected="${a === 0}" data-group="${n}">
      <span ${z(o)}</span><span class="tab-count">${r}</span>
    </button>`;
  }).join("");
  return `
  <aside class="panel sidebar" id="protocols">
    <div class="panel-head">
      <h2 class="panel-title" ${z("INTERNET PROTOCOLS")}</h2>
      <button class="drawer-close" type="button" data-t-label="Close the protocol list" aria-label="${S("Close the protocol list")}" data-t-title="Close (Esc)" title="${S("Close (Esc)")}">${Se.close}</button>
    </div>
    <div class="tabs" role="tablist">${s}<span class="tab-indicator"></span></div>
    <ul class="proto-list">${t}</ul>
  </aside>`;
}
function na(e, t = true) {
  const s = e.querySelector(".tab.is-active");
  const n = e.querySelector(".tab-indicator");
  if (!t) {
    n.style.transition = "none";
  }
  n.style.left = `${s.offsetLeft}px`;
  n.style.width = `${s.offsetWidth}px`;
  if (!t) {
    n.offsetWidth;
    n.style.transition = "";
  }
}
function Wr(e) {
  const t = e.querySelector(".sidebar .tabs");
  if (!t?.offsetWidth) {
    return;
  }
  t.style.removeProperty("--tab-fit");
  let s = 1;
  for (let n = 0; n < 5 && t.scrollWidth > t.clientWidth + 0.5; n++) {
    s *= Math.max(0.85, (t.clientWidth - 1) / t.scrollWidth);
    t.style.setProperty("--tab-fit", s.toFixed(3));
  }
  na(e.querySelector(".sidebar"), false);
}
const Hy = "cubic-bezier(0.4, 0, 0.2, 1)";
const $u = e => e.getBoundingClientRect().height / e.offsetHeight || 1;
function Fy(e, t, {
  rect: s,
  opacity: n
}, o) {
  const a = e.getBoundingClientRect();
  const r = t.cloneNode(true);
  r.classList.add("proto-ghost");
  r.removeAttribute("data-lesson");
  r.dataset.ghostOf = t.querySelector(".proto-name").textContent;
  Object.assign(r.style, {
    top: `${(s.top - a.top) / o + e.scrollTop}px`,
    left: `${(s.left - a.left) / o}px`,
    width: `${t.offsetWidth}px`
  });
  e.appendChild(r);
  r.animate([{
    opacity: n
  }, {
    opacity: 0
  }], {
    duration: 60 + n * 110,
    easing: "ease-in",
    fill: "forwards"
  }).onfinish = () => r.remove();
}
function Uy(e, t) {
  const s = e.querySelector(".proto-list");
  const n = [...s.querySelectorAll(":scope > .proto:not(.proto-ghost)")];
  const o = $u(s);
  const a = Ne();
  const r = new Map();
  for (const p of n) {
    if (p.hidden) {
      continue;
    }
    const u = p.getBoundingClientRect();
    r.set(p, {
      rect: u,
      top: u.top,
      opacity: Number(getComputedStyle(p).opacity),
      moving: p.getAnimations().length > 0
    });
  }
  let i = 0;
  for (const p of n) {
    if (t !== "all" && p.dataset.group !== t && !p.hidden && !a) {
      Fy(s, p, r.get(p), o);
      i++;
    }
  }
  for (const p of n) {
    p.getAnimations().forEach(u => u.cancel());
    p.hidden = t !== "all" && p.dataset.group !== t;
  }
  if (a) {
    return;
  }
  const c = [];
  for (const p of n) {
    const u = r.get(p);
    if (p.hidden || !u) {
      continue;
    }
    const y = p.getBoundingClientRect();
    c.push([Math.min(u.top, y.top), Math.max(u.top, y.top) + y.height]);
  }
  let d = 0;
  for (const p of n) {
    if (p.hidden) {
      continue;
    }
    const u = r.get(p);
    if (u) {
      const y = (u.top - p.getBoundingClientRect().top) / o;
      if (Math.abs(y) < 0.5 && u.opacity >= 1) {
        continue;
      }
      p.animate([{
        transform: `translateY(${y}px)`,
        opacity: u.opacity
      }, {
        transform: "none",
        opacity: 1
      }], {
        duration: 360,
        delay: u.moving || !i ? 0 : 90,
        easing: Hy,
        fill: "backwards"
      });
    } else {
      const y = p.getBoundingClientRect();
      const T = c.some(([m, w]) => m < y.bottom - 4 && w > y.top + 4 && w - m > y.height + 8);
      p.animate([{
        opacity: 0,
        transform: "translateY(8px)"
      }, {
        opacity: 1,
        transform: "none"
      }], {
        duration: 300,
        delay: (T ? 250 : i ? 150 : 70) + d++ * 22,
        easing: Gs,
        fill: "backwards"
      });
    }
  }
}
function Ky(e, {
  onStep: t,
  onSelect: s
}) {
  na(e);
  const n = new ResizeObserver(() => na(e, false));
  e.querySelectorAll(".tabs, .tab").forEach(o => n.observe(o));
  document.fonts.ready.then(() => {
    na(e);
    e.querySelector(".tabs").classList.add("is-ready");
  });
  e.addEventListener("click", o => {
    const a = o.target.closest(".proto.is-open .step-btn");
    if (a) {
      t(Number(a.parentElement.dataset.step));
    }
    const r = o.target.closest(".proto.has-lesson > .proto-row");
    if (r) {
      s(r.parentElement.dataset.lesson);
    }
    const i = o.target.closest(".tab");
    if (i && !i.classList.contains("is-active")) {
      e.querySelectorAll(".tab").forEach(c => {
        c.classList.toggle("is-active", c === i);
        c.setAttribute("aria-selected", c === i);
      });
      na(e);
      Uy(e, i.dataset.group);
    }
  });
}
function By(e, t) {
  const s = !e.dataset.lesson;
  e.dataset.lesson = t;
  for (const o of e.querySelectorAll(".proto.has-lesson")) {
    const a = o.dataset.lesson === t;
    if (a !== o.classList.contains("is-open")) {
      if (a) {
        o.classList.add("instant");
        o.querySelectorAll(".step").forEach(r => {
          r.classList.remove("is-active", "is-done");
          r.style.removeProperty("--delay");
        });
        o.offsetWidth;
        o.classList.remove("instant");
      }
      o.classList.toggle("is-active", a);
      o.classList.toggle("is-open", a);
      o.querySelector(".proto-row").setAttribute("aria-expanded", a);
    }
  }
  const n = e.querySelector(`.proto[data-lesson="${t}"]`);
  clearTimeout(e._reveal);
  if (e._toTop === t) {
    Lu(e, n);
  } else if (!s) {
    e._reveal = setTimeout(() => e.dataset.lesson === t && Gy(e.querySelector(".proto-list"), n), 460);
  }
}
function _y(e, t) {
  const s = e.querySelector(`.proto[data-lesson="${t}"]`);
  if (s) {
    if (s.hidden) {
      e.querySelector(".tab[data-group=\"all\"]").click();
    }
    clearTimeout(e._reveal);
    if (e.dataset.lesson === t) {
      Lu(e, s);
    } else {
      e._toTop = t;
    }
  }
}
function Lu(e, t) {
  e._toTop = null;
  const s = e.querySelector(".proto-list");
  let n = t.offsetTop;
  let o = 0;
  for (const r of s.querySelectorAll(".proto.has-lesson")) {
    const i = r.querySelector(".steps-clip");
    if (r.hidden || !i) {
      continue;
    }
    const c = (r.classList.contains("is-open") ? i.scrollHeight : 0) - i.offsetHeight;
    o += c;
    if (t.compareDocumentPosition(r) & Node.DOCUMENT_POSITION_PRECEDING) {
      n += c;
    }
  }
  const a = s.scrollHeight + o - s.clientHeight;
  if (Ne()) {
    return requestAnimationFrame(() => s.scrollTop = Math.min(n, a));
  }
  ho(s, n, {
    room: a,
    least: 480
  });
}
function Gy(e, t) {
  const s = $u(e);
  const n = e.getBoundingClientRect();
  const o = t.getBoundingClientRect();
  const a = (o.top - n.top) / s + e.scrollTop;
  const r = o.height / s;
  const i = e.clientHeight;
  const c = 8;
  if (r + c * 2 > i || a < e.scrollTop + c) {
    ho(e, a - c);
  } else if (a + r > e.scrollTop + i - c) {
    ho(e, a + r - i + c);
  }
}
function Wy(e, t) {
  e.querySelectorAll(".proto[data-lesson]").forEach(s => {
    const n = s.querySelector(".status-dot");
    const o = Nr(t[s.dataset.lesson]);
    if (n.dataset.status !== o) {
      n.dataset.status = o;
      n.className = `status-dot ${o}`;
      if (!Ne()) {
        n.offsetWidth;
        n.classList.add("is-changed");
      }
    }
  });
}
function Vy(e, t, s) {
  if (e.dataset.lesson !== s.id) {
    By(e, s.id);
  }
  const n = [...e.querySelectorAll(`.proto[data-lesson="${s.id}"] .step`)];
  const o = n.filter((r, i) => t.steps[i] === "done" && !r.classList.contains("is-done"));
  const a = n.filter((r, i) => t.steps[i] !== "done" && r.classList.contains("is-done")).reverse();
  n.forEach(r => r.style.setProperty("--delay", "0ms"));
  o.forEach((r, i) => r.style.setProperty("--delay", `${i * 90}ms`));
  a.forEach((r, i) => r.style.setProperty("--delay", `${i * 50}ms`));
  n.forEach((r, i) => {
    if (t.steps[i] === "active" && !r.classList.contains("is-active")) {
      r.style.setProperty("--delay", `${o.length * 90}ms`);
    }
    r.classList.toggle("is-active", t.steps[i] === "active");
    r.classList.toggle("is-done", t.steps[i] === "done");
  });
}
const Yy = Math.cos(Math.PI / 6);
const jy = 0.5;
const ss = "var(--k-line-1b3fae)";
function Tn(e, t) {
  return (s, n, o = 0) => [e + (s - n) * Yy, t + (s + n) * jy - o];
}
const Iu = ([e, t]) => `${e.toFixed(2)},${t.toFixed(2)}`;
const ht = (e, t = "") => `<polygon points="${e.map(Iu).join(" ")}" ${t}/>`;
const Tt = (e, t = "") => `<polyline points="${e.map(Iu).join(" ")}" fill="none" ${t}/>`;
function Ws(e, t, s, n, o, a, r) {
  return {
    top: (i, c) => e(t + i, s + c, n + r),
    left: (i, c) => e(t + i, s + a, n + c),
    right: (i, c) => e(t + o, s + a - i, n + c)
  };
}
const V = (e, t, s, n, o, a = "") => ht([e(t, s), e(t + n, s), e(t + n, s + o), e(t, s + o)], a);
function mn(e, t, s, n, o = "") {
  const a = [];
  for (let r = 0; r < 28; r++) {
    const i = r / 28 * Math.PI * 2;
    a.push(e(t + n * Math.cos(i), s + n * Math.sin(i)));
  }
  return ht(a, o);
}
function pt(e, t, s, n, o, a, r, i = {}) {
  const {
    top: c = "var(--k-fill-f4f7fe)",
    left: d = "var(--k-fill-e5edfc)",
    right: p = "var(--k-fill-d0def8)",
    stroke: u = ss,
    sw: y = 1.7
  } = i;
  const T = `stroke="${u}" stroke-width="${y}" stroke-linejoin="round"`;
  return [ht([e(t, s, n + r), e(t + o, s, n + r), e(t + o, s + a, n + r), e(t, s + a, n + r)], `fill="${c}" ${T}`), ht([e(t, s + a, n), e(t + o, s + a, n), e(t + o, s + a, n + r), e(t, s + a, n + r)], `fill="${d}" ${T}`), ht([e(t + o, s + a, n), e(t + o, s, n), e(t + o, s, n + r), e(t + o, s + a, n + r)], `fill="${p}" ${T}`)].join("");
}
function zy(e, t, s, n, o, a, r) {
  let i = "";
  for (let c = a; c < n; c += a) {
    i += Tt([e(t + c, s), e(t + c, s + o)], r);
  }
  for (let c = a; c < o; c += a) {
    i += Tt([e(t, s + c), e(t + n, s + c)], r);
  }
  return i;
}
const ee = `stroke="${ss}"`;
const Wt = `${ee} stroke-width="1.3" stroke-linejoin="round"`;
const ns = {
  top: "url(#face-top)",
  left: "url(#face-left)",
  right: "url(#face-right)"
};
const bn = (e, t, s, n, o, a) => ht([e(t + n, s), e(t + n + a, s), e(t + n + a, s + o), e(t + n, s + o)], "class=\"iso-shadow\"");
function Jn(e, t, {
  antenna: s = true
} = {}) {
  const n = Tn(e, t);
  const o = 70;
  const a = 70;
  const r = 33;
  const i = Ws(n, 0, 0, 0, o, a, r);
  let c = bn(n, 0, 0, o, a, 34);
  c += pt(n, 0, 0, 0, o, a, r, {
    ...ns,
    sw: 2.2
  });
  const d = [[9, 7], [19.5, 5], [28, 7], [39, 5]];
  for (const [m, w] of d) {
    c += V(i.top, m, 30.5, w, 5, `fill="var(--k-fill-a9c0ee)" ${ee} stroke-width="1.5"`);
  }
  c += V(i.top, 30, 32, 3, 2, `fill="${ss}" stroke="none"`);
  const p = i.left;
  c += mn(p, 9.5, 17, 5, `fill="none" ${ee} stroke-width="2.6"`);
  c += V(p, 17, 13, 3.6, 8, `fill="${ss}" stroke="none"`);
  c += V(p, 15.5, 20, 6.6, 2, `fill="${ss}" stroke="none"`);
  c += V(p, 15.5, 11.5, 6.6, 2, `fill="${ss}" stroke="none"`);
  c += V(p, 30, 8, 13, 11, `fill="var(--k-fill-f4f7fe)" ${ee} stroke-width="2"`);
  const u = i.right;
  c += V(u, 9, 9, 52, 15, `fill="var(--k-fill-e8effd)" ${ee} stroke-width="2"`);
  c += V(u, 13, 12, 44, 9, `fill="var(--k-fill-c4d5f6)" ${Wt}`);
  for (let m = 0; m < 3; m++) {
    c += Tt([u(16, 14 + m * 2.6), u(54, 14 + m * 2.6)], "stroke=\"var(--k-line-8ea9e2)\" stroke-width=\"0.9\"");
  }
  if (!s) {
    return `<g class="device router">${c}</g>`;
  }
  const [y, T] = i.top(16, 8);
  c += `<ellipse cx="${y}" cy="${T}" rx="5.2" ry="2.8" fill="var(--k-fill-c9d8f6)" ${ee} stroke-width="1.5"/>`;
  c += `<path d="M${y - 3.2},${T} L${y - 1.4},${T - 40} L${y + 1.4},${T - 40} L${y + 3.2},${T} Z" fill="var(--k-fill-c9d8f6)" ${ee} stroke-width="1.6" stroke-linejoin="round"/>`;
  c += `<circle cx="${y}" cy="${T - 43.5}" r="4" fill="var(--k-fill-f4f7fe)" ${ee} stroke-width="1.8"/>`;
  return `<g class="device router">${c}</g>`;
}
function Qy(e, t) {
  const s = Tn(e, t);
  const n = 84;
  const o = 38;
  const a = 13;
  const r = Ws(s, 0, 0, 0, n, o, a);
  let i = bn(s, 0, 0, n, o, 24);
  i += pt(s, 0, 0, 0, n, o, a, {
    ...ns,
    sw: 2.1
  });
  const c = r.left;
  i += mn(c, 6, 6.5, 2.6, `fill="none" ${ee} stroke-width="1.6"`);
  for (let p = 0; p < 8; p++) {
    const u = 12.5 + p * 8.7;
    i += V(c, u, 2.6, 6.8, 7, `fill="var(--k-fill-f4f7fe)" ${ee} stroke-width="1.3"`);
    i += V(c, u + 1.7, 4, 3.4, 2.9, "fill=\"var(--k-fill-c4d5f6)\" stroke=\"none\"");
    i += V(r.top, u + 1.6, o - 5.4, 3.6, 2.4, `fill="var(--k-fill-a9c0ee)" ${ee} stroke-width="1"`);
  }
  i += V(r.top, 9, 7, n - 18, o - 17, "fill=\"none\" stroke=\"var(--k-line-8ea9e2)\" stroke-width=\"1\"");
  const d = r.right;
  for (let p = 0; p < 3; p++) {
    i += V(d, 7 + p * 8, 4, 4.2, 5.4, `fill="var(--k-fill-c4d5f6)" ${Wt}`);
  }
  return `<g class="device switch">${i}</g>`;
}
function Xy(e, t) {
  const s = Tn(e, t);
  let n = bn(s, 4, 4, 34, 34, 22);
  n += pt(s, 4, 4, 0, 34, 34, 5, {
    ...ns,
    sw: 1.9
  });
  n += pt(s, 17, 17, 5, 8, 8, 20, {
    ...ns,
    sw: 1.7
  });
  const o = 62;
  const a = 30;
  const r = 26;
  const i = 25;
  const c = Ws(s, -6, 6, i, o, a, r);
  n += pt(s, -6, 6, i, o, a, r, {
    ...ns,
    sw: 2.1
  });
  const d = c.left;
  n += mn(d, 13, 13, 9.5, `fill="var(--k-fill-f4f7fe)" ${ee} stroke-width="2"`);
  n += mn(d, 13, 13, 6, `fill="var(--k-fill-c4d5f6)" ${ee} stroke-width="1.5"`);
  n += mn(d, 13, 13, 2.4, `fill="${ss}" stroke="none"`);
  n += mn(d, 28, 19, 1.8, `fill="var(--k-fill-a9c0ee)" ${ee} stroke-width="1"`);
  for (let p = 0; p < 3; p++) {
    n += V(d, 36 + p * 7, 6, 3.5, 13, `fill="var(--k-fill-c4d5f6)" ${Wt}`);
  }
  n += pt(s, -12, 4, i + r, o + 8, a + 4, 3, {
    top: "var(--k-fill-f4f7fe)",
    left: "var(--k-fill-e5edfc)",
    right: "var(--k-fill-d0def8)",
    sw: 1.6
  });
  return `<g class="device camera">${n}</g>`;
}
function Zy(e, t) {
  const s = Tn(e, t);
  let n = bn(s, 0, 0, 80, 60, 26);
  n += pt(s, 30, 18, 0, 22, 14, 3, {
    ...ns,
    sw: 1.6
  });
  n += pt(s, 38, 22, 3, 6, 5, 9, {
    ...ns,
    sw: 1.5
  });
  const o = 82;
  const a = 6;
  const r = 52;
  const i = 12;
  const c = Ws(s, 0, 20, i, o, a, r);
  n += pt(s, 0, 20, i, o, a, r, {
    ...ns,
    sw: 2.1
  });
  const d = c.left;
  n += V(d, 4, 4, o - 8, r - 8, `fill="var(--k-fill-dce6fb)" ${ee} stroke-width="1.5"`);
  n += V(d, 10, 30, 20, 12, "fill=\"var(--k-fill-a9c0ec)\" stroke=\"none\"");
  for (let u = 0; u < 3; u++) {
    n += Tt([d(36, 38 - u * 6), d(70, 38 - u * 6)], "stroke=\"var(--k-line-a9c0ec)\" stroke-width=\"2.6\" stroke-linecap=\"round\"");
  }
  const p = Ws(s, 18, 40, 0, 46, 26, 9);
  n += pt(s, 18, 40, 0, 46, 26, 9, {
    ...ns,
    sw: 1.9
  });
  n += V(p.left, 5, 3, 14, 3.4, `fill="var(--k-fill-c4d5f6)" ${Wt}`);
  n += mn(p.left, 38, 4.6, 1.6, `fill="var(--k-fill-a9c0ee)" ${ee} stroke-width="1"`);
  return `<g class="device tv">${n}</g>`;
}
function eo(e, t) {
  const s = Tn(e, t);
  const n = 40.5;
  const o = 40.5;
  const a = 13.6;
  const r = 2.9;
  let i = bn(s, 0, 0, n, o, 30);
  i += pt(s, 1.5, 1.5, 0, n - 3, o - 3, a * 3 + r * 2, {
    top: "var(--k-fill-2f55c2)",
    left: "var(--k-fill-2f55c2)",
    right: "var(--k-fill-24479f)"
  });
  for (let c = 0; c < 3; c++) {
    const d = c * (a + r);
    const p = Ws(s, 0, 0, d, n, o, a);
    i += pt(s, 0, 0, d, n, o, a, {
      ...ns,
      sw: 1.9
    });
    if (c === 0) {
      i += V(p.left, 4, 3.8, 7, 5.6, `fill="var(--k-fill-5ed6ea)" ${Wt}`);
      i += V(p.left, 13, 3.8, 9, 5.6, `fill="var(--k-fill-d7e3fa)" ${Wt}`);
      i += V(p.left, 24, 3.8, 6, 5.6, `fill="var(--k-fill-5ed6ea)" ${Wt}`);
    } else {
      i += V(p.left, 4, 3.8, 27, 5.6, `fill="var(--k-fill-5ed6ea)" ${Wt}`);
      i += V(p.left, 4, 3.8, 9, 5.6, "fill=\"var(--k-fill-a6eef6)\" stroke=\"none\"");
    }
    i += V(p.right, 4, 3.8, 32, 5.6, `fill="var(--k-fill-9fbcf0)" ${Wt}`);
    if (c === 2) {
      i += V(p.top, 8.5, 8.5, 23.5, 23.5, `fill="var(--k-fill-dfe8fb)" ${ee} stroke-width="1.6"`);
      i += zy(p.top, 8.5, 8.5, 23.5, 23.5, 2.6, "stroke=\"var(--k-line-7d9be0)\" stroke-width=\"0.6\"");
    }
  }
  return `<g class="device dns">${i}</g>`;
}
function Ci(e, t) {
  const s = Tn(e, t);
  const n = 56.6;
  const o = 56.6;
  const a = 70;
  const r = Ws(s, 0, 0, 0, n, o, a);
  let i = bn(s, 0, 0, n, o, 40);
  i += pt(s, 0, 0, 0, n, o, a, {
    top: "url(#face-top)",
    left: "var(--k-fill-f4f8ff)",
    right: "url(#face-right)",
    sw: 2.3
  });
  i += V(r.top, 10, 10, 37, 37, `fill="var(--k-fill-c9d8f4)" ${ee} stroke-width="1.2"`);
  for (let u = 2.2; u < 37; u += 2.2) {
    i += Tt([r.top(10 + u, 10), r.top(10 + u, 47)], "stroke=\"var(--k-line-9db5e6)\" stroke-width=\"0.7\"");
  }
  const c = r.left;
  for (let u = 0; u < 3; u++) {
    const y = 6 + u * 20.5;
    i += V(c, 4.5, y, 47.5, 17, `fill="var(--k-fill-f5f8ff)" ${ee} stroke-width="2"`);
    i += V(c, 7.5, y + 3, 41.5, 11, `fill="var(--k-fill-e3ebfc)" ${Wt}`);
    const T = [[10, 5], [16, 3], [21, 3], [36, 3.4]];
    for (const [m, w] of T) {
      i += V(c, m, y + 5, w, 7, "fill=\"var(--k-fill-3d63c9)\" stroke=\"none\"");
    }
    i += V(c, 26, y + 6, 7, 5, "fill=\"var(--k-fill-a7bff0)\" stroke=\"none\"");
  }
  const d = r.right;
  const p = `fill="none" ${ee} stroke-width="1.9" stroke-linejoin="round" stroke-linecap="round"`;
  i += V(d, 8, 34, 40, 27, `fill="var(--k-fill-c7d8f7)" ${p}`);
  i += Tt([d(8, 52), d(30, 52), d(30, 46), d(48, 46)], p);
  i += Tt([d(14, 40), d(26, 40), d(26, 34)], p);
  i += Tt([d(36, 61), d(36, 54), d(44, 54)], p);
  i += V(d, 8, 9, 16, 15, `fill="var(--k-fill-c7d8f7)" ${p}`);
  i += V(d, 30, 9, 16, 15, `fill="var(--k-fill-c7d8f7)" ${p}`);
  i += Tt([d(30, 19), d(36, 19), d(36, 24)], p);
  i += `<circle cx="${d(47, 1)[0]}" cy="${d(47, 1)[1]}" r="2.6" fill="${ss}"/>`;
  return `<g class="device web">${i}</g>`;
}
function ph(e, t) {
  const s = Tn(e, t);
  const n = 56;
  const o = 86;
  const a = 5;
  const r = Ws(s, 0, 0, 0, n, o, a);
  let i = bn(s, -4, 0, n + 4, o, 30);
  i += ht([s(-4, o), s(n, o), s(n + 10, o + 8), s(-4, o + 8)], "class=\"iso-shadow\"");
  const c = 64;
  const d = 3;
  const p = 3;
  const u = 82;
  const y = A => (N, L) => s(A - d * L / c, p + u - N, a + L);
  const T = y(-7);
  const m = y(0);
  const w = (A, N, L, Q, ne) => [A(N, L), A(N + Q, L), A(N + Q, L + ne), A(N, L + ne)];
  i += ht(w(T, 0, 0, u, c), `fill="var(--k-fill-e2ebfc)" ${ee} stroke-width="2" stroke-linejoin="round"`);
  i += ht([T(0, 0), m(0, 0), m(0, c), T(0, c)], `fill="var(--k-fill-cddcf8)" ${ee} stroke-width="1.6" stroke-linejoin="round"`);
  i += ht([T(0, c), m(0, c), m(u, c), T(u, c)], `fill="var(--k-fill-cddcf8)" ${ee} stroke-width="1.6" stroke-linejoin="round"`);
  i += ht(w(m, 0, 0, u, c), `fill="var(--k-fill-f4f7fe)" ${ee} stroke-width="2" stroke-linejoin="round"`);
  i += ht(w(m, 4.5, 5, u - 9, c - 9.5), `fill="var(--k-fill-dce6fb)" ${ee} stroke-width="1.5" stroke-linejoin="round"`);
  i += ht(w(m, 4.5, c - 14, u - 9, 9.5), `fill="var(--k-fill-f2f6fe)" ${ee} stroke-width="1.2" stroke-linejoin="round"`);
  i += Tt([m(9, c - 9.3), m(24, c - 9.3)], "stroke=\"var(--k-line-9db5e8)\" stroke-width=\"2.2\" stroke-linecap=\"round\"");
  i += "<g class=\"screen-content\">";
  i += ht(w(m, 10, 13, 22, 24), "fill=\"var(--k-fill-a9c0ec)\" stroke=\"none\"");
  for (let A = 0; A < 4; A++) {
    i += Tt([m(38, 33 - A * 6), m(68, 33 - A * 6)], "stroke=\"var(--k-line-a9c0ec)\" stroke-width=\"3.2\" stroke-linecap=\"round\" pathLength=\"1\"");
  }
  i += "</g>";
  i += pt(s, 0, 0, 0, n, o, a, {
    top: "var(--k-fill-f5f8ff)",
    left: "var(--k-fill-dfe8fc)",
    right: "var(--k-fill-cddcf8)",
    sw: 2.1
  });
  const k = r.top;
  i += V(k, 6, 9, 27, 68, `fill="var(--k-fill-dce7fb)" ${ee} stroke-width="1.6"`);
  for (let A = 11.4; A < 33; A += 5.4) {
    i += Tt([k(A, 9), k(A, 77)], `stroke="${ss}" stroke-width="0.9"`);
  }
  for (let A = 13.85; A < 77; A += 4.85) {
    i += Tt([k(6, A), k(33, A)], `stroke="${ss}" stroke-width="0.9"`);
  }
  i += V(k, 38, 28, 13, 30, `fill="var(--k-fill-c3d4f5)" ${Wt}`);
  return `<g class="device laptop">${i}</g>`;
}
function Jy(e, t) {
  const s = [[-60, 10, 21], [-32, -16, 20], [-6, -36, 17], [22, -36, 26], [46, -16, 20], [58, 3, 22], [40, 22, 24], [-24, 24, 24], [8, 2, 32], [-20, 6, 26]];
  const n = (i, c = 0, d = 0) => s.map(([p, u, y]) => `<circle cx="${e + p + c}" cy="${t + u + d}" r="${y}" ${i}/>`).join("");
  const o = e + 20;
  const a = t;
  const r = 19.5;
  return `<g class="device cloud">
    <clipPath id="cloud-clip">${n("")}</clipPath>
    <ellipse cx="${e + 12}" cy="${t + 44}" rx="80" ry="10" class="iso-shadow round"/>
    ${n(`fill="var(--k-fill-fdfdff)" ${ee} stroke-width="4.6"`)}
    <g clip-path="url(#cloud-clip)">
      ${n("fill=\"var(--k-fill-e3eaf8)\"")}
      ${n("fill=\"var(--k-fill-fdfdff)\"", 3, -4)}
    </g>
    <g fill="none" ${ee} stroke-width="2.4" stroke-linecap="round">
      <circle cx="${o}" cy="${a}" r="${r}" fill="var(--k-fill-fdfdff)"/>
      <ellipse cx="${o}" cy="${a}" rx="8.5" ry="${r}"/>
      <line x1="${o}" y1="${a - r}" x2="${o}" y2="${a + r}"/>
      <path d="M${o - r},${a} H${o + r}"/>
      <path d="M${o - 16},${a - 10} Q${o},${a - 5} ${o + 16},${a - 10} M${o - 16},${a + 10} Q${o},${a + 15} ${o + 16},${a + 10}"/>
    </g>
  </g>`;
}
const ew = [45, 66, 810, 490];
const uh = [450, 311];
const fh = "x=\"-500\" y=\"-500\" width=\"1900\" height=\"1500\"";
const gs = {
  idle: "var(--k-line-bccae6)",
  navy: "#0b3aa8",
  blue: "#1f6fe8",
  green: "#12a56b",
  amber: "#f2ac0a",
  violet: "#7656e0",
  teal: "#0e95a3",
  slate: "#5d6f95"
};
function qe(e, t, [s, n], [o, a], r = 5.5) {
  const i = Math.hypot(o - s, a - n);
  const c = -(a - n) / i * r;
  const d = (o - s) / i * r;
  return {
    [`${e}>${t}`]: [s + c, n + d, o + c, a + d],
    [`${t}>${e}`]: [o - c, a - d, s - c, n - d]
  };
}
const oa = {
  "client>router": [262, 430, 371, 383],
  "router>client": [376, 355, 268, 403],
  "router>internet": [508.4, 357.1, 668.4, 434.8],
  "internet>router": [663.6, 444.6, 503.6, 366.9],
  "internet>dns": [690, 418, 690, 231],
  "dns>internet": [712, 229, 712, 404],
  "internet>web": [776, 418, 776, 254],
  "web>internet": [797, 264, 797, 438],
  ...qe("internet", "root", [799, 432], [928, 316]),
  ...qe("internet", "tld", [812, 457], [968, 440]),
  ...qe("internet", "auth", [796, 492], [925, 580]),
  ...qe("internet", "mx", [812, 455], [956, 395]),
  "internet>relay": [690, 418, 690, 231],
  "relay>internet": [712, 229, 712, 404],
  ...qe("web", "app", [868, 240], [936, 292]),
  ...qe("router", "lan", [398, 318], [356, 262]),
  ...qe("router", "isp", [492, 392], [548, 428]),
  ...qe("isp", "transit", [640, 418], [706, 374]),
  ...qe("transit", "hosting", [802, 374], [836, 410]),
  ...qe("hosting", "app", [924, 414], [950, 364]),
  ...qe("client", "switch", [247, 402], [271, 370]),
  ...qe("switch", "lan", [304, 314], [324, 266]),
  ...qe("switch", "router", [337, 366], [386, 389]),
  ...qe("router", "cam", [398, 318], [356, 262]),
  ...qe("switch", "stb", [304, 314], [324, 266]),
  ...qe("router", "bng", [492, 392], [653, 460]),
  ...qe("internet", "remote", [800, 440], [930, 394]),
  ...qe("remote", "peer", [1035, 388], [1095, 420])
};
const tw = {
  "client>dns": ["client>router", "router>internet", "internet>dns"],
  "dns>client": ["dns>internet", "internet>router", "router>client"],
  "client>web": ["client>router", "router>internet", "internet>web"],
  "web>client": ["web>internet", "internet>router", "router>client"],
  "dns>root": ["dns>internet", "internet>root"],
  "root>dns": ["root>internet", "internet>dns"],
  "dns>tld": ["dns>internet", "internet>tld"],
  "tld>dns": ["tld>internet", "internet>dns"],
  "dns>auth": ["dns>internet", "internet>auth"],
  "auth>dns": ["auth>internet", "internet>dns"],
  "client>router": ["client>router"],
  "router>client": ["router>client"],
  "client>internet": ["client>router", "router>internet"],
  "internet>client": ["internet>router", "router>client"],
  "router>web": ["router>internet", "internet>web"],
  "web>router": ["web>internet", "internet>router"],
  "web>dns": ["web>internet", "internet>dns"],
  "dns>web": ["dns>internet", "internet>web"],
  "web>mx": ["web>internet", "internet>mx"],
  "mx>web": ["mx>internet", "internet>web"],
  "client>relay": ["client>router", "router>internet", "internet>relay"],
  "relay>client": ["relay>internet", "internet>router", "router>client"],
  "relay>web": ["relay>internet", "internet>web"],
  "web>relay": ["web>internet", "internet>relay"],
  "web>app": ["web>app"],
  "app>web": ["app>web"],
  "client>lan": ["client>router", "router>lan"],
  "lan>client": ["lan>router", "router>client"],
  "router>lan": ["router>lan"],
  "lan>router": ["lan>router"],
  "client>switch": ["client>switch"],
  "switch>client": ["switch>client"],
  "switch>lan": ["switch>lan"],
  "lan>switch": ["lan>switch"],
  "switch>router": ["switch>router"],
  "router>switch": ["router>switch"],
  "router>isp": ["router>isp"],
  "isp>router": ["isp>router"],
  "router>bng": ["router>bng"],
  "bng>router": ["bng>router"],
  "client>cam": ["client>router", "router>cam"],
  "cam>client": ["cam>router", "router>client"],
  "switch>stb": ["switch>stb"],
  "stb>switch": ["stb>switch"],
  "isp>transit": ["isp>transit"],
  "transit>isp": ["transit>isp"],
  "hosting>transit": ["hosting>transit"],
  "transit>hosting": ["transit>hosting"],
  "client>app": ["client>router", "router>isp", "isp>transit", "transit>hosting", "hosting>app"],
  "app>client": ["app>hosting", "hosting>transit", "transit>isp", "isp>router", "router>client"],
  "client>peer": ["client>router", "router>internet", "internet>remote", "remote>peer"],
  "peer>client": ["peer>remote", "remote>internet", "internet>router", "router>client"],
  "peer>web": ["peer>remote", "remote>internet", "internet>web"],
  "web>peer": ["web>internet", "internet>remote", "remote>peer"],
  "peer>relay": ["peer>remote", "remote>internet", "internet>relay"],
  "relay>peer": ["relay>internet", "internet>remote", "remote>peer"]
};
const ye = {
  internet: ["Internet", ""],
  client: ["Client", "192.168.1.10"],
  router: ["Router", "192.168.1.1"],
  dns: ["DNS Resolver", "8.8.8.8"],
  web: ["Web Server", "203.0.113.10"],
  root: ["Root Server", "198.41.0.4"],
  tld: [".com TLD Server", "192.5.6.30"],
  auth: ["Authoritative Server", "198.51.100.53"],
  mx: ["Mail Server", "198.51.100.25"],
  relay: ["Proxy", "192.0.2.80"],
  app: ["App Server", "10.0.0.20"],
  lan: ["File Server", "192.168.1.20"],
  isp: ["ISP Router", "AS 64500"],
  transit: ["Transit Router", "AS 64510"],
  hosting: ["Hosting Router", "AS 64511"],
  remote: ["Their Router", "198.51.100.200"],
  peer: ["Their Laptop", "192.168.0.23"],
  switch: ["Switch", "8 ports"],
  bng: ["Access Server", "198.51.100.1"],
  cam: ["IP Camera", "192.168.1.64"],
  stb: ["TV Box", "192.168.1.30"]
};
const sw = {
  client: "Client",
  router: "Router",
  dns: "DNS Resolver",
  internet: "Internet",
  web: "Web Server",
  root: "Root Server",
  tld: ".com Server",
  auth: "Authoritative",
  mx: "Mail Server",
  relay: "Proxy",
  app: "App Server",
  lan: "Server",
  isp: "ISP Router",
  transit: "Transit",
  hosting: "Hosting",
  remote: "Their Router",
  peer: "Their Laptop",
  switch: "Switch",
  bng: "Access Server",
  cam: "Camera",
  stb: "TV Box"
};
const mh = [728, 460];
const yh = [701, 185];
const nw = [812, 203];
const ow = [960, 300];
const aw = [1005, 430];
const rw = [960, 575];
const iw = [1010, 380];
const lw = [985, 300];
const cw = [330, 215];
const dw = [595, 430];
const hw = [755, 330];
const pw = [880, 430];
const uw = [985, 330];
const wh = [1160, 430];
const fw = [262, 314];
const mw = [700, 462];
const yw = [330, 218];
const ww = [324, 191];
const $i = {
  client: [214, 446],
  dns: [701, 180],
  router: [440, 360],
  internet: [732, 458],
  web: [812, 206],
  root: [960, 296],
  tld: [1005, 426],
  auth: [960, 571],
  mx: [1010, 378],
  relay: [701, 180],
  app: [985, 303],
  lan: [330, 212],
  isp: [595, 451],
  transit: [755, 351],
  hosting: [880, 451],
  remote: [985, 351],
  peer: [1186, 430],
  switch: [282, 338],
  bng: [700, 483],
  cam: [332, 208],
  stb: [330, 200]
};
const gw = {
  client: {
    x: 205,
    y: 372,
    side: "top"
  },
  router: {
    x: 440,
    y: 290,
    side: "top"
  },
  web: {
    x: 758,
    y: 200,
    side: "left"
  },
  dns: {
    x: 662,
    y: 212,
    side: "left"
  },
  internet: {
    x: 732,
    y: 396,
    side: "top"
  },
  mx: {
    x: 955,
    y: 345,
    side: "left"
  },
  relay: {
    x: 662,
    y: 212,
    side: "left"
  },
  app: {
    x: 985,
    y: 226,
    side: "top"
  },
  lan: {
    x: 330,
    y: 160,
    side: "top"
  },
  isp: {
    x: 595,
    y: 396,
    side: "top"
  },
  transit: {
    x: 755,
    y: 262,
    side: "top"
  },
  hosting: {
    x: 880,
    y: 396,
    side: "top"
  },
  remote: {
    x: 985,
    y: 262,
    side: "top"
  },
  peer: {
    x: 1186,
    y: 350,
    side: "top"
  },
  switch: {
    x: 282,
    y: 300,
    side: "top"
  },
  bng: {
    x: 700,
    y: 427,
    side: "top"
  },
  cam: {
    x: 330,
    y: 158,
    side: "top"
  },
  stb: {
    x: 330,
    y: 132,
    side: "top"
  }
};
const gh = {
  client: ["client"],
  local: ["client", "router"],
  lookup: ["client", "router", "internet", "dns"],
  root: ["client", "router", "internet", "dns", "root"],
  tld: ["client", "router", "internet", "dns", "root", "tld"],
  path: ["client", "router", "internet", "web"],
  mailhost: ["client", "router", "internet", "dns", "web"],
  servers: ["internet", "dns", "web", "mx"],
  relay: ["client", "router", "internet", "relay"],
  backend: ["internet", "web", "app"],
  office: ["client", "router", "lan"],
  bgp: ["isp", "transit", "hosting", "app"],
  route: ["client", "router", "isp", "transit", "hosting", "app"],
  call: ["client", "router", "internet", "relay", "web", "remote", "peer"],
  switched: ["client", "switch", "lan", "router"],
  uplink: ["client", "switch", "lan", "router", "isp"],
  access: ["client", "router", "bng"],
  line: ["router", "bng"],
  camera: ["client", "router", "cam"],
  tvbox: ["client", "switch", "stb", "router"],
  tvlink: ["client", "switch", "stb", "router", "isp"],
  sipserver: ["client", "router", "internet", "relay"],
  sip: ["client", "router", "internet", "relay", "remote", "peer"],
  full: ["client", "switch", "router", "lan", "cam", "stb", "isp", "bng", "transit", "hosting", "dns", "relay", "internet", "web", "app", "root", "tld", "auth", "mx", "remote", "peer"]
};
const ke = (e, t, s, n, o = "start", a = "left-bottom") => `<g class="node-label" data-origin="${a}"><text class="node-name" x="${e}" y="${t}" text-anchor="${o}">${S(s)}</text>${n ? `<text class="node-ip" x="${e}" y="${t + 18}" text-anchor="${o}">${n}</text>` : ""}</g>`;
function Sw() {
  const e = t => `<marker id="head-${t}" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6.2" markerHeight="6.2" orient="auto-start-reverse">
       <path d="M0,0.6 L10,5 L0,9.4 Z" fill="${gs[t]}"/></marker>`;
  return `<defs>
    ${Object.keys(gs).map(e).join("")}
    <pattern id="iso-grid" width="62.354" height="36" patternUnits="userSpaceOnUse" x="9" y="4">
      <path d="M0,0 L62.354,36 M62.354,0 L0,36" stroke="var(--k-line-e4eaf5)" stroke-width="1"/>
    </pattern>
    <!-- the grid fades into the panel towards the edges -->
    <radialGradient id="grid-vignette" gradientUnits="userSpaceOnUse" cx="${uh[0]}" cy="${uh[1]}" r="560">
      <stop offset="0" stop-color="var(--k-fill-fefeff)" stop-opacity="0"/>
      <stop offset="0.6" stop-color="var(--k-fill-fefeff)" stop-opacity="0.4"/>
      <stop offset="1" stop-color="var(--k-fill-fefeff)" stop-opacity="1"/>
    </radialGradient>
    <!-- soft ground shadows, darkest against the device -->
    <linearGradient id="shadow-fade" x1="0" y1="0.25" x2="1" y2="0.75">
      <stop offset="0" stop-color="var(--k-shadow-8d9ab3)" stop-opacity="0.3"/>
      <stop offset="1" stop-color="var(--k-shadow-8d9ab3)" stop-opacity="0"/>
    </linearGradient>
    <radialGradient id="shadow-round">
      <stop offset="0" stop-color="var(--k-shadow-8d9ab3)" stop-opacity="0.26"/>
      <stop offset="1" stop-color="var(--k-shadow-8d9ab3)" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="face-top" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="var(--k-fill-f8fbff)"/><stop offset="1" stop-color="var(--k-fill-e6eefc)"/>
    </linearGradient>
    <linearGradient id="face-left" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="var(--k-fill-eff5ff)"/><stop offset="1" stop-color="var(--k-fill-dae5fb)"/>
    </linearGradient>
    <linearGradient id="face-right" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="var(--k-fill-e0eafc)"/><stop offset="1" stop-color="var(--k-fill-c7d7f6)"/>
    </linearGradient>
  </defs>`;
}
const Tw = `
  <g class="url-holder" transform="translate(60 334)"><g class="url-bar">
    <path d="M128 26 L140 58" class="url-leader"/>
    <rect class="url-box" width="168" height="26" rx="3"/>
    <g class="url-globe" transform="translate(9 6)">
      <circle cx="7" cy="7" r="6"/><ellipse cx="7" cy="7" rx="2.6" ry="6"/><path d="M1.4 5h11.2M1.4 9h11.2"/>
    </g>
    <g class="url-lock" transform="translate(10 5)">
      <path d="M3 7 V4.6 a3.5 3.5 0 0 1 7 0 V7"/><rect x="1" y="7" width="11" height="8" rx="1.6"/>
    </g>
    <text class="url-text" x="29" y="17.5"></text>
    <rect class="url-caret" x="29" y="6.5" width="1.6" height="13"/>
    <path class="url-check" d="M0 13.5 l3.5 3.5 l6.5 -7" pathLength="1"/>
  </g></g>`;
const Pe = (e, t) => `<g class="node" data-node="${e}">${t}</g>`;
function bw() {
  const e = Object.entries(oa).map(([t, s]) => {
    const [n, o, a, r] = s.map(i => i.toFixed(1));
    return `<path class="lane" data-lane="${t}" d="M${n},${o} L${a},${r}" marker-end="url(#head-idle)"/>`;
  }).join("");
  return `
  <svg class="network is-booting" viewBox="${ew.join(" ")}" preserveAspectRatio="xMidYMid meet" data-t-label="Network diagram" aria-label="${S("Network diagram")}">
    ${Sw()}
    <rect ${fh} fill="url(#iso-grid)"/>
    <rect ${fh} fill="url(#grid-vignette)"/>
    <g class="lanes">${e}</g>
    <g class="pulse-layer"></g>
    ${Pe("internet", Jy(...mh) + ke(mh[0] - 2, 524, ...ye.internet, "start", "center-top"))}
    ${Pe("client", ph(240, 446) + ke(73, 494, ...ye.client, "start", "right-top") + Tw)}
    ${Pe("dns", eo(...yh) + ke(654, 160, ...ye.dns, "end", "right-bottom"))}
    ${Pe("web", Ci(...nw) + ke(773, 106, ...ye.web))}
    ${Pe("root", eo(...ow) + ke(925, 228, ...ye.root))}
    ${Pe("tld", eo(...aw) + ke(970, 360, ...ye.tld))}
    ${Pe("auth", eo(...rw) + ke(925, 505, ...ye.auth))}
    ${Pe("mx", Ci(...iw) + ke(968, 286, ...ye.mx))}
    ${Pe("relay", eo(...yh) + ke(654, 160, ...ye.relay, "end", "right-bottom"))}
    ${Pe("app", Ci(...lw) + ke(1046, 316, ...ye.app, "start", "left-top"))}
    ${Pe("lan", eo(...cw) + ke(288, 192, ...ye.lan, "end", "right-bottom"))}
    ${Pe("isp", Jn(...dw, {
    antenna: false
  }) + ke(562, 517, ...ye.isp, "start", "left-top"))}
    ${Pe("transit", Jn(...hw, {
    antenna: false
  }) + ke(690, 288, ...ye.transit, "start", "left-bottom"))}
    ${Pe("hosting", Jn(...pw, {
    antenna: false
  }) + ke(847, 517, ...ye.hosting, "start", "left-top"))}
    ${Pe("switch", Qy(...fw) + ke(214, 300, ...ye.switch, "end", "right-bottom"))}
    ${Pe("bng", Jn(...mw, {
    antenna: false
  }) + ke(667, 549, ...ye.bng, "start", "left-top"))}
    ${Pe("cam", Xy(...yw) + ke(282, 186, ...ye.cam, "end", "right-bottom"))}
    ${Pe("stb", Zy(...ww) + ke(272, 170, ...ye.stb, "end", "right-bottom"))}
    ${Pe("peer", `<g transform="translate(${wh[0] * 2} 0) scale(-1 1)">${ph(...wh)}</g>${ke(1095, 525, ...ye.peer, "start", "left-top")}`)}
    <!-- drawn after the devices beside them, so their labels stay on top when labels grow on small panels -->
    ${Pe("router", Jn(440, 339) + ke(407, 426, ...ye.router, "start", "left-top"))}
    ${Pe("remote", Jn(...uw) + ke(1050, 330, ...ye.remote, "start", "left-top"))}
    <g class="packet-layer"></g>
    <g class="note-layer"></g>
  </svg>`;
}
const Bs = {
  draw: 620,
  quick: 320,
  stagger: 160,
  note: 700
};
const vw = ["client", "switch", "router", "lan", "cam", "stb", "isp", "bng", "transit", "hosting", "internet", "dns", "relay", "web", "app", "mx", "root", "tld", "auth", "remote", "peer"];
const kw = 3000;
const Pw = 0.25;
const Sh = 58;
const Aw = 18;
const Ew = 9;
const xw = 30;
const Th = 30;
const Cw = 22;
const bh = 30;
const $w = 30;
const Lw = 40;
const Li = e => Math.round(e * 1000000) / 1000000;
function Ru(e, t, s) {
  const n = e.latency?.[`${t}-${s}`] ?? e.latency?.[`${s}-${t}`];
  if (n === undefined) {
    throw new Error(`${e.id}: no delay between ${t} and ${s}`);
  }
  return n;
}
function Iw(e) {
  if (e >= 3600) {
    return `${+(e / 3600).toFixed(1)} h later`;
  } else if (e >= 60) {
    return `${+(e / 60).toFixed(1)} min later`;
  } else {
    return `${e < 10 ? e.toFixed(2) : e.toFixed(1)} s later`;
  }
}
function Rw(e) {
  const t = [];
  let s = 0;
  let n = 0;
  e.steps.forEach((w, k) => w.events.forEach(A => {
    if (A.type === "packet") {
      t.push({
        type: "packet",
        p: A,
        step: k,
        index: s++
      });
    }
    if (A.type === "stream") {
      A.packets.forEach(N => t.push({
        type: "packet",
        p: N,
        step: k,
        index: s++
      }));
    }
    if (A.type === "note") {
      t.push({
        type: "note",
        e: A,
        step: k,
        index: n++
      });
    }
  }));
  const o = new Set(t.flatMap(w => w.type === "packet" ? [w.p.from, w.p.to] : []));
  const a = (e.lifelines ?? vw).filter(w => o.has(w));
  const r = t.filter(w => w.type === "packet").map((w, k) => {
    const {
      p: A
    } = w;
    const N = Li(parseFloat(A.row.time));
    const L = Ru(e, A.from, A.to);
    return {
      ...w,
      k,
      sent: N,
      arrived: Li(N + L)
    };
  });
  const i = t.map((w, k) => ({
    it: w,
    i: k
  })).filter(({
    it: w
  }) => w.type === "note").map(({
    it: w,
    i: k
  }) => {
    const A = t.slice(0, k).findLast(O => O.type === "packet");
    const N = t.slice(k + 1).find(O => O.type === "packet");
    const L = A ? r.find(O => O.index === A.index).arrived : 0;
    const Q = N && N.step === w.step ? r.find(O => O.index === N.index).sent : -Infinity;
    const ne = a.includes(w.e.at) ? w.e.at : null;
    const be = A ? [A.p.from, A.p.to] : null;
    return {
      ...w,
      order: k,
      t: Math.max(L, Q),
      lane: ne,
      between: be
    };
  });
  const c = [...r.flatMap(w => [{
    t: w.sent,
    kind: 1,
    order: t.indexOf(t.find(k => k.type === "packet" && k.index === w.index)),
    pk: w,
    end: "sent"
  }, {
    t: w.arrived,
    kind: 0,
    order: w.k,
    pk: w,
    end: "arrived"
  }]), ...i.map(w => ({
    t: w.t,
    kind: 0.5,
    order: w.order,
    n: w
  }))].sort((w, k) => w.t - k.t || w.kind - k.kind || w.order - k.order);
  const d = [];
  const p = [];
  let u = $w;
  let y = null;
  let T = -Infinity;
  let m = -Infinity;
  for (const w of c) {
    if (y) {
      const A = Li(w.t - y.t);
      if (A > Pw) {
        p.push({
          y: u + Sh / 2,
          seconds: A
        });
        u += Sh;
      } else if (A > 0) {
        u += Math.max(Ew, A * kw);
      } else if (w.kind === y.kind && w.kind === 0) {
        u += Aw;
      }
    }
    if (w.kind === 1) {
      u = Math.max(u, T + xw, m + Cw);
    }
    const k = w.pk && w.end === "sent" ? w.pk.step : w.n ? w.n.step : null;
    if (k !== null && !d.some(A => A.step === k)) {
      u += bh / 2;
      d.push({
        step: k,
        y: u
      });
      u += bh / 2;
    }
    if (w.n) {
      u += Th / 2;
      w.n.y = u;
      m = u + 10;
      u += Th / 2;
    } else {
      w.pk[w.end === "sent" ? "ySent" : "yArrived"] = u;
    }
    if (w.kind === 1) {
      T = u;
    }
    y = w;
  }
  return {
    lifelines: a,
    packets: r,
    notes: i,
    steps: d,
    breaks: p,
    height: u + Lw
  };
}
let Dr = 1;
let uo = false;
const Uo = new Set();
function hr(e) {
  e.playbackRate = Dr;
  if (uo && e.playState === "running") {
    e.pause();
  }
  if (!uo && e.playState === "paused") {
    e.play();
  }
}
const yn = {
  get speed() {
    return Dr;
  },
  get paused() {
    return uo;
  },
  setSpeed(e) {
    Dr = e;
    Uo.forEach(hr);
  },
  pause() {
    uo = true;
    Uo.forEach(hr);
  },
  resume() {
    uo = false;
    Uo.forEach(hr);
  },
  track(e) {
    Uo.add(e);
    hr(e);
    const t = () => Uo.delete(e);
    e.addEventListener("finish", t);
    e.addEventListener("cancel", t);
    return e;
  }
};
function nt(e, t, s = () => {}) {
  return new Promise(n => {
    let o = null;
    let a = 0;
    const r = i => {
      if (t.cancelled) {
        return n();
      }
      if (o !== null && !uo) {
        a += (i - o) * Dr;
      }
      o = i;
      const c = typeof e == "function" ? e() : e;
      const d = c > 0 ? Math.max(0, Math.min(1, a / c)) : 1;
      s(d);
      if (d < 1) {
        requestAnimationFrame(r);
      } else {
        n();
      }
    };
    requestAnimationFrame(r);
  });
}
const ge = (e, t) => nt(e, t);
const Nw = "http://www.w3.org/2000/svg";
const vr = 78;
const vh = 30;
const Dw = 124;
const Ow = "M-3.2 -1 V-2.6 a3.2 3.2 0 0 1 6.4 0 V-1 M-4.4 -1 h8.8 v6.4 h-8.8 z";
function Mw() {
  return `
  <div class="sequence" data-t-label="Sequence diagram" aria-label="${S("Sequence diagram")}">
    <div class="seq-head"></div>
    <div class="seq-scroll"><svg class="seq-svg" xmlns="${Nw}"></svg></div>
  </div>`;
}
const Nu = (e, t, s) => s?.[t] ?? e.labels?.[t] ?? ye[t];
const Du = (e, t, s) => S(Nu(e, t, s)[0]);
function Ou(e, t, s, n) {
  const o = Nu(e, t, n)[1];
  if (o) {
    return S(o);
  } else {
    return s.packets.find(a => a.p.from === t)?.p.row.src ?? "";
  }
}
function qw(e, t, s) {
  const {
    p: n
  } = e;
  const o = t[n.from];
  const a = n.lost ? (t[n.from] + t[n.to]) / 2 : t[n.to];
  const [r, i] = [e.ySent, n.lost ? (e.ySent + e.yArrived) / 2 : e.yArrived];
  const c = Math.hypot(a - o, i - r);
  const [d, p] = [(a - o) / c, (i - r) / c];
  const u = n.lost ? 0 : 9;
  const [y, T] = [a - d * u, i - p * u];
  let m = Math.atan2(i - r, a - o) * 180 / Math.PI;
  if (m > 90) {
    m -= 180;
  }
  if (m < -90) {
    m += 180;
  }
  const w = n.row;
  const k = `${po(`#${e.index + 1} · ${w.time} · ${w.src} → ${w.dst} · ${w.proto}`)} · ${S(w.info)} · ${po(w.len)}`;
  const A = n.lost ? `<path class="seq-cross" d="M${a - 6},${i - 6} L${a + 6},${i + 6} M${a + 6},${i - 6} L${a - 6},${i + 6}"/>` : `<path class="seq-tip" d="M${a},${i} L${y - p * 4.5},${T + d * 4.5} L${y + p * 4.5},${T - d * 4.5} Z"/>`;
  return `
    <g class="seq-arrow c-${n.color}${n.lost ? " is-lost" : ""}" data-packet="${e.index}" data-len="${c.toFixed(1)}" data-geo="${[o, r, a, i, m.toFixed(2)].join(" ")}">
      <title>${M(k)}</title>
      <text class="seq-time" x="${vr - 14}" y="${r}">${M(w.time)}</text>
      <circle class="seq-dot" cx="${o}" cy="${r}" r="2.6"/>
      <line class="seq-line" x1="${o}" y1="${r}" x2="${y}" y2="${T}"/>
      ${A}
      <g class="seq-label">
        <rect class="seq-label-bg" y="-17" height="15" rx="2"/>
        ${n.locked ? `<path class="seq-lock" d="${Ow}"/>` : ""}
        <text class="seq-label-text" y="-6" text-anchor="middle">${M(S(n.label))}</text>
      </g>
    </g>`;
}
function Hw(e, t, s) {
  const n = e.lane;
  const o = n && s.indexOf(n) === s.length - 1 && s.length > 1;
  const a = n ? t[n] : e.between ? (t[e.between[0]] + t[e.between[1]]) / 2 : t[s[0]];
  const r = n ? o ? "left" : "right" : "center";
  return `
    <g class="seq-note tone-${e.e.tone ?? "navy"}" data-note="${e.index}" data-side="${r}" transform="translate(${a} ${e.y})">
      ${n ? "<circle class=\"seq-note-dot\" r=\"3.5\"/>" : ""}
      <rect class="seq-note-bg" y="-10" height="20" rx="2"/>
      <text class="seq-note-text" y="0.5">${M(S(e.e.text))}</text>
    </g>`;
}
function Fw(e, t) {
  const s = n => {
    let o = `M0 ${n}`;
    for (let a = 0; a < t; a += 12) {
      o += " q3 -3 6 0 q3 3 6 0";
    }
    return o;
  };
  return `
    <g class="seq-break" transform="translate(0 ${e.y})">
      <rect class="seq-break-band" x="0" y="-15" width="${t}" height="30"/>
      <path class="seq-wave" d="${s(-6)} ${s(6)}"/>
      <g transform="translate(${t / 2} 0)">
        <rect class="seq-break-bg" y="-10" height="20" rx="10"/>
        <text class="seq-break-text" y="0.5" text-anchor="middle">${M(S(Iw(e.seconds)))}</text>
      </g>
    </g>`;
}
function Uw(e, t) {
  for (const s of [e, t]) {
    for (let n = 0; n < s.length; n++) {
      const [o, a] = [s[n], s[(n + 1) % s.length]];
      const [r, i] = [a[1] - o[1], o[0] - a[0]];
      const c = u => u.map(([y, T]) => y * r + T * i);
      const [d, p] = [c(e), c(t)];
      if (Math.max(...d) <= Math.min(...p) || Math.max(...p) <= Math.min(...d)) {
        return false;
      }
    }
  }
  return true;
}
const kh = (e, t, s, n) => [[e, t], [s, t], [s, n], [e, n]];
function Kw(e) {
  const t = i => i.querySelector("text").getComputedTextLength();
  const s = [...e.querySelectorAll(".seq-note")].map(i => ({
    g: i,
    w: t(i)
  }));
  const n = [...e.querySelectorAll(".seq-arrow")].map(i => ({
    arrow: i,
    g: i.querySelector(".seq-label"),
    w: t(i.querySelector(".seq-label"))
  }));
  const o = [...e.querySelectorAll(".seq-break")].map(i => ({
    g: i,
    w: t(i)
  }));
  const a = [...e.querySelectorAll(".seq-step")].map(i => ({
    g: i,
    w: t(i)
  }));
  const r = [...e.querySelectorAll(".seq-cross")].map(i => {
    const [c, d] = i.getAttribute("d").match(/[-\d.]+/g).map(Number);
    return kh(c - 3, d - 3, c + 15, d + 15);
  });
  a.forEach(({
    g: i,
    w: c
  }) => i.querySelector("line").setAttribute("x1", 12 + c + 10));
  s.forEach(({
    g: i,
    w: c
  }) => {
    const d = i.querySelector("text");
    const p = i.querySelector("rect");
    const u = i.dataset.side;
    const y = u === "right" ? 10 : u === "left" ? -10 - c - 16 : -c / 2 - 8;
    p.setAttribute("x", y);
    p.setAttribute("width", c + 16);
    d.setAttribute("x", y + 8);
    const [T, m] = i.getAttribute("transform").match(/[-\d.]+/g).map(Number);
    r.push(kh(T + y, m - 10, T + y + c + 16, m + 10));
  });
  o.forEach(({
    g: i,
    w: c
  }) => {
    const d = i.querySelector(".seq-break-bg");
    d.setAttribute("x", -c / 2 - 10);
    d.setAttribute("width", c + 20);
  });
  n.sort((i, c) => c.w - i.w);
  n.forEach(({
    arrow: i,
    g: c,
    w: d
  }) => {
    const p = c.querySelector("text");
    const u = c.querySelector(".seq-lock");
    const y = u ? 14 : 0;
    p.setAttribute("x", y / 2);
    if (u) {
      u.setAttribute("transform", `translate(${-d / 2 - 4} -10)`);
    }
    const T = c.querySelector("rect");
    T.setAttribute("x", -d / 2 - 5 - y / 2);
    T.setAttribute("width", d + 10 + y);
    const [m, w, k, A, N] = i.dataset.geo.split(" ").map(Number);
    const L = d / 2 + 6 + y / 2;
    const [Q, ne] = [Math.cos(N * Math.PI / 180), Math.sin(N * Math.PI / 180)];
    const be = [[-L - 2, -21], [L + 2, -21], [L + 2, 3], [-L - 2, 3]].map(([B, J]) => [B * Q - J * ne, B * ne + J * Q]);
    const O = B => {
      const [J, lt] = [m + (k - m) * B, w + (A - w) * B];
      return {
        cx: J,
        cy: lt,
        box: be.map(([$, D]) => [J + $, lt + D])
      };
    };
    const Z = Math.hypot(k - m, A - w);
    const v = Math.min(0.45, (L + 8) / Z);
    const Ue = [0.5, 0.4, 0.6, 0.3, 0.7, 0.2, 0.8, 0.12, 0.88].filter(B => B >= v && B <= 1 - v).map(O);
    const De = B => r.filter(J => Uw(B.box, J)).length;
    const Ke = Ue.find(B => !De(B)) ?? [...Ue, O(0.5)].sort((B, J) => De(B) - De(J))[0];
    r.push(Ke.box);
    c.setAttribute("transform", `translate(${Ke.cx.toFixed(1)} ${Ke.cy.toFixed(1)}) rotate(${N})`);
  });
}
function Mu(e, t) {
  const s = e.querySelector(".seq-scroll");
  const n = e.querySelector(".seq-svg");
  const o = Rw(t);
  const a = Math.max(s.clientWidth, vr + vh + o.lifelines.length * Dw);
  const r = (a - vr - vh) / o.lifelines.length;
  const i = Object.fromEntries(o.lifelines.map((u, y) => [u, Math.round(vr + r * (y + 0.5))]));
  const c = e.querySelector(".seq-head");
  c.innerHTML = `<div class="seq-head-track" style="width:${a}px">${o.lifelines.map(u => `<span class="seq-who" data-id="${u}" style="left:${i[u]}px; max-width:${Math.floor(r - 10)}px"><b>${M(Du(t, u))}</b><i>${M(Ou(t, u, o))}</i></span>`).join("")}</div>`;
  pl(c);
  const d = o.lifelines.map(u => `<line class="seq-life" x1="${i[u]}" y1="0" x2="${i[u]}" y2="${o.height}"/>`).join("");
  const p = o.steps.map(u => `
    <g class="seq-step" data-step="${u.step}" transform="translate(0 ${u.y})">
      <line class="seq-step-line" x1="10" y1="0" x2="${a - 10}" y2="0"/>
      <text class="seq-step-text" x="12" y="0.5"><tspan class="seq-step-num">${S("STEP {n}", {
    n: u.step + 1
  })}</tspan> · ${M(as(S(t.steps[u.step].title)))}</text>
    </g>`).join("");
  n.setAttribute("viewBox", `0 0 ${a} ${o.height}`);
  n.setAttribute("width", a);
  n.setAttribute("height", o.height);
  n.innerHTML = d + o.breaks.map(u => Fw(u, a)).join("") + p + o.notes.map(u => Hw(u, i, o.lifelines)).join("") + [...o.packets.filter(u => !u.p.lost), ...o.packets.filter(u => u.p.lost)].map(u => qw(u, i)).join("");
  Kw(n);
  e._layout = o;
  e._lesson = t;
  e._width = s.clientWidth;
  e.dataset.lesson = t.id;
  s.scrollTop = 0;
  s.scrollLeft = 0;
  qu(e);
}
const pl = e => e.style.height = `${Math.max(46, ...[...e.querySelectorAll(".seq-who")].map(t => t.offsetHeight + 6))}px`;
const qu = e => {
  const t = e.querySelector(".seq-head-track");
  if (t) {
    t.style.transform = `translateX(${-e.querySelector(".seq-scroll").scrollLeft}px)`;
  }
};
function Hu(e) {
  if (!e._lesson || e.dataset.lesson !== e._want) {
    return;
  }
  const t = e.querySelector(".seq-scroll");
  const s = t.scrollTop;
  Mu(e, e._lesson);
  if (e._state) {
    Ql(e, e._state, e._lesson);
  }
  e.querySelector(".seq-svg").getAnimations({
    subtree: true
  }).forEach(n => n.finish());
  t.scrollTop = s;
}
function Bw(e) {
  const t = e.querySelector(".seq-scroll");
  t.addEventListener("scroll", () => qu(e), {
    passive: true
  });
  new ResizeObserver(() => Math.abs(t.clientWidth - e._width) >= 1 && Hu(e)).observe(t);
}
const Fu = e => Number(getComputedStyle(e).opacity);
function Ii(e, t, s) {
  const n = Fu(e);
  e.getAnimations({
    subtree: true
  }).forEach(c => c.cancel());
  e.classList.add("is-shown");
  if (Ne() || (t === "fade" || n > 0) && (e.animate([{
    opacity: n
  }, {
    opacity: 1
  }], {
    duration: (1 - n) * 260,
    delay: n > 0 ? 0 : s,
    easing: "ease-out",
    fill: "backwards"
  }), t === "fade" || n > 0.5)) {
    return;
  }
  const o = e.querySelector(".seq-line");
  const a = Number(e.dataset.len);
  const r = t === "quick" ? Bs.quick : Bs.draw;
  const i = (c, d, p) => yn.track(c.animate(d, {
    delay: s,
    fill: "backwards",
    ...p
  }));
  if (s) {
    i(e, [{
      opacity: 0
    }, {
      opacity: 1
    }], {
      duration: 1
    });
  }
  if (e.classList.contains("is-lost")) {
    i(o, [{
      opacity: 0
    }, {
      opacity: 1
    }], {
      duration: r,
      easing: "ease-out"
    });
  } else {
    i(o, [{
      strokeDasharray: `${a} ${a}`,
      strokeDashoffset: a
    }, {
      strokeDasharray: `${a} ${a}`,
      strokeDashoffset: 0
    }], {
      duration: r,
      easing: Gs
    });
  }
  i(e.querySelector(".seq-tip, .seq-cross"), [{
    opacity: 0
  }, {
    opacity: 1
  }], {
    duration: 160,
    delay: s + r * 0.7,
    easing: "ease-out"
  });
  i(e.querySelector(".seq-label"), [{
    opacity: 0
  }, {
    opacity: 1
  }], {
    duration: 240,
    delay: s + r * 0.3,
    easing: "ease-out"
  });
}
function Ph(e) {
  const t = Fu(e);
  e.getAnimations({
    subtree: true
  }).forEach(s => s.cancel());
  e.classList.remove("is-shown");
  if (!Ne() && t > 0) {
    e.animate([{
      opacity: t
    }, {
      opacity: 0
    }], {
      duration: t * 180,
      easing: t < 1 ? "linear" : "ease-in"
    });
  }
}
function Ql(e, t, s) {
  const n = e.querySelector(".seq-svg");
  const o = e._layout;
  const a = e.querySelector(".seq-head");
  a.querySelectorAll(".seq-who").forEach(m => {
    const [w, k] = [m.querySelector("b"), m.querySelector("i")];
    Vt(w, Du(s, m.dataset.id, t.labels), 1, () => pl(a));
    Vt(k, Ou(s, m.dataset.id, o, t.labels), 1, () => pl(a));
  });
  const r = [];
  let i = 0;
  n.querySelectorAll(".seq-arrow").forEach(m => {
    const w = Number(m.dataset.packet);
    const k = t.packets[w];
    const A = !t.started || k !== "future";
    const N = t.started && k === "current";
    if (A && !m.classList.contains("is-shown")) {
      r.push({
        g: m,
        current: N,
        y: o.packets[w].yArrived
      });
    }
    if (!A && m.classList.contains("is-shown")) {
      Ph(m);
    }
    m.classList.toggle("is-current", N);
  });
  const c = r.length && r.every(m => m.current);
  r.forEach((m, w) => {
    const k = o.packets.find(A => A.index === Number(m.g.dataset.packet))?.p.quick;
    if (c) {
      Ii(m.g, k ? "quick" : "draw", w * Bs.stagger);
    } else {
      Ii(m.g, "fade", Math.min(i++ * 14, 420));
    }
  });
  n.querySelectorAll(".seq-note").forEach(m => {
    const w = !t.started || t.notes[Number(m.dataset.note)] !== "future";
    if (w && !m.classList.contains("is-shown")) {
      Ii(m, "fade", 0);
      r.push({
        g: m,
        y: o.notes[Number(m.dataset.note)].y
      });
    }
    if (!w && m.classList.contains("is-shown")) {
      Ph(m);
    }
  });
  n.querySelectorAll(".seq-step").forEach(m => m.classList.toggle("is-active", t.started && !t.done && Number(m.dataset.step) === t.activeStep));
  const d = e.querySelector(".seq-scroll");
  if (!t.started) {
    return r.length && ho(d, 0);
  }
  const u = [...n.querySelectorAll(".seq-arrow.is-shown, .seq-note.is-shown")].map(m => m.dataset.packet !== undefined ? o.packets[Number(m.dataset.packet)].yArrived : o.notes[Number(m.dataset.note)].y);
  const y = u.length ? Math.max(...u) : 0;
  const T = d.clientHeight;
  if (y > d.scrollTop + T - 44) {
    ho(d, y - T * 0.62);
  } else if (y < d.scrollTop + 30) {
    ho(d, y - T * 0.4);
  }
}
function _w(e, t, s) {
  const n = [e.querySelector(".seq-scroll"), e.querySelector(".seq-head")];
  e._want = t.id;
  e._state = s;
  const o = () => {
    if (e._want === t.id) {
      n.forEach(a => a.getAnimations().forEach(r => r.cancel()));
      Mu(e, t);
      Ql(e, e._state, t);
      if (!Ne()) {
        n.forEach(a => a.animate([{
          opacity: 0
        }, {
          opacity: 1
        }], {
          duration: 260,
          easing: "ease-out"
        }));
      }
    }
  };
  if (!e.dataset.lesson || Ne()) {
    return o();
  }
  n.forEach(a => {
    const r = Number(getComputedStyle(a).opacity);
    a.getAnimations().forEach(i => i.cancel());
    a.animate([{
      opacity: r
    }, {
      opacity: 0
    }], {
      duration: r * 160,
      easing: r < 1 ? "linear" : "ease-in",
      fill: "forwards"
    });
  });
  setTimeout(o, 170);
}
function Gw(e, t, s) {
  e._state = t;
  if (e._want !== s.id) {
    return _w(e, s, t);
  }
  if (e.dataset.lesson === s.id) {
    Ql(e, t, s);
  }
}
const Vr = e => e.steps.flatMap(t => t.events).flatMap(t => t.type === "packet" ? [t] : t.type === "stream" ? t.packets : []);
const Uu = "192.168.1.10";
const Or = "192.168.1.1";
const Ah = "198.51.100.7";
const Xl = "198.51.100.1";
const Zl = "8.8.8.8";
const pe = {
  laptop: "00:00:5e:00:53:10",
  lan: "00:00:5e:00:53:01",
  wan: "00:00:5e:00:53:02",
  server: "00:00:5e:00:53:20",
  isp: "00:00:5e:00:53:fe",
  all: "ff:ff:ff:ff:ff:ff"
};
const Ww = "10.8.0.2";
const Vw = "198.51.100.200";
const Ri = {
  [Uu]: [pe.laptop, "The laptop’s network card.", "The laptop."],
  "0.0.0.0": [pe.laptop, "The laptop’s network card.", "The laptop."],
  [Or]: [pe.lan, "The router’s side facing the home network.", "The router itself."],
  "192.168.1.2": [pe.lan, "The access point’s wired port.", "The access point."],
  "192.168.1.20": [pe.server, "The server’s network card.", "The server. It is on the same network, so the frame goes straight to it, not through the router."],
  "192.168.1.30": ["00:00:5e:00:53:30", "The TV box’s network port.", "The TV box."],
  "192.168.1.64": ["00:00:5e:00:53:64", "The camera’s network port.", "The camera. It is on the same network, so the frame goes straight to it, not through the router."]
};
const Eh = e => /^2(2[4-9]|3\d)\./.test(e);
const Yw = e => {
  const [, t, s, n] = Ee(e);
  return ["01", "00", "5e", t & 127, s, n].map(o => typeof o == "number" ? o.toString(16).padStart(2, "0") : o).join(":");
};
const to = e => e.startsWith("192.168.1.") || e === "0.0.0.0" || e === "255.255.255.255";
const aa = e => e === Uu || e === "0.0.0.0" || e === Ww;
const pr = e => aa(e) || e === Zl ? 128 : e === Xl ? 255 : 64;
const Ni = e => e === Or ? 0 : e === Xl ? 1 : e === Zl ? 10 : 12;
const xh = 1460;
function kr(e) {
  let t = 2166136261;
  for (const s of e) {
    t = Math.imul(t ^ s.charCodeAt(0), 16777619);
  }
  return t >>> 0;
}
const jw = `\r
`;
const Ku = e => JSON.stringify(e).slice(1, -1);
function Ch(e, t, s) {
  const n = new R(e, t);
  s.forEach((o, a) => n.field(a ? "" : "Text", `${Ku(o)}␍␊`, () => n.ascii(o + jw), {
    mono: true
  }));
  return n;
}
function $h(e, t) {
  const s = zw(e, t);
  if (!t.take) {
    return s;
  }
  const [n, o] = t.take;
  const a = new R(s.id, `${s.name} · bytes ${n + 1}–${o} of ${s.length.toLocaleString("en-US")}`);
  a.bytes = s.bytes.slice(n, o);
  a.fields = s.fields.filter(r => r.from === r.to ? r.from >= n && r.from <= o : r.to > n && r.from < o).map(r => ({
    ...r,
    from: Math.max(0, r.from - n),
    to: Math.min(o, r.to) - n
  }));
  return a;
}
function zw(e, t) {
  if (t.ascii !== undefined) {
    const s = new R("app", t.name ?? Fi(e));
    s.field("Data", `"${t.ascii}" (${t.ascii.length} bytes)`, () => s.ascii(t.ascii), {
      mono: true,
      note: t.note
    });
    return s;
  }
  if (t.text) {
    const s = Ch("app", t.name ?? Fi(e), t.text);
    if (t.body) {
      s.field("Body", `"${t.body}" (${t.body.length} bytes)`, () => s.ascii(t.body), {
        mono: true
      });
    }
    return s;
  }
  if (t.http) {
    const s = Ch("app", "HTTP", t.http.lines);
    if (t.http.body) {
      s.field("Body", `${t.http.body.toLocaleString("en-US")} bytes: ${t.http.what}`, () => s.unknown(t.http.body), {
        hidden: true,
        note: "The page itself; its contents are not part of the lesson."
      });
    }
    return s;
  }
  if (t.opaque !== undefined) {
    const s = new R("app", t.name ?? Fi(e));
    s.field("Data", `${t.opaque.toLocaleString("en-US")} bytes: ${t.what}`, () => s.unknown(t.opaque), {
      hidden: true,
      note: t.note
    });
    return s;
  }
  if (t.tls) {
    return Rg(t.tls);
  }
  if (t.ssh) {
    return Ng(t.ssh);
  }
  if (t.dns) {
    return Og(t.dns);
  }
  if (t.dhcp) {
    return qg(t.dhcp);
  }
  if (t.rtp) {
    return Hg(t.rtp);
  }
  if (t.mpegts) {
    return Fg(t.mpegts);
  }
  if (t.rtmp) {
    return mu(t.rtmp);
  }
  if (t.ws) {
    return Sg(t.ws);
  }
  if (t.socks) {
    return Tg(t.socks);
  }
  if (t.wg) {
    return bg(t.wg);
  }
  if (t.ike) {
    return vg(t.ike);
  }
  if (t.esp) {
    return kg(t.esp);
  }
  if (t.quic) {
    return Xw(t.quic);
  }
  if (t.ntp) {
    return eg(t.ntp);
  }
  if (t.radius) {
    return og(t.radius);
  }
  if (t.smb) {
    return lg(t.smb);
  }
  if (t.modbus) {
    return hg(t.modbus);
  }
  if (t.bgp) {
    return ug(t.bgp);
  }
  if (t.stun) {
    return fg(t.stun);
  }
  if (t.dtls) {
    return mg(t.dtls);
  }
  if (t.srtp) {
    return yg(t.srtp);
  }
  throw new Error(`unknown payload for ${e.info}`);
}
const Lh = {
  initial: [192, "Initial"],
  handshake: [224, "Handshake"]
};
const Qw = {
  initial: "Encrypted with keys anyone can work out from the connection ID, so it stops accidents, not eavesdroppers: the Client Hello inside can be read on the way.",
  handshake: "Encrypted with keys from the key exchange so far.",
  "1rtt": "Encrypted with the session keys."
};
function Xw(e) {
  const t = e.packets.map(n => n.type === "1rtt" ? "1-RTT" : Lh[n.type][1]);
  const s = new R("quic", e.packets.length === 1 ? `QUIC · ${t[0]}` : `QUIC · ${t.join(" + ")}`);
  e.packets.forEach((n, o) => {
    const a = n.type !== "1rtt";
    const r = a ? 6 + n.dcid.length + 1 + n.scid.length + (n.type === "initial" ? 1 : 0) + 2 + 1 : 1 + n.dcid.length + 1;
    s.field(`${t[o]} packet`, `${r + n.sealed} bytes`, () => {}, {
      heading: true
    });
    s.field("Header type", a ? `long header, ${t[o]}` : "short header", () => s.u8(a ? Lh[n.type][0] | 3 : 82), {
      depth: 1,
      example: true,
      note: "The top bits say what kind of packet this is; the last bits are disguised (header protection)."
    });
    if (a) {
      s.field("Version", "1", () => s.u32(1), {
        depth: 1
      });
      s.field("Destination connection ID", fo(n.dcid), () => s.u8(n.dcid.length).raw(n.dcid), {
        depth: 1,
        example: true,
        note: "Which connection this belongs to. Each side picks its own ID; the other writes it here."
      });
      s.field("Source connection ID", fo(n.scid), () => s.u8(n.scid.length).raw(n.scid), {
        depth: 1,
        example: true
      });
      if (n.type === "initial") {
        s.field("Token length", "0", () => s.u8(0), {
          depth: 1,
          note: "No token: the server hasn’t asked this client to prove its address first."
        });
      }
      s.field("Length", `${n.sealed + 1} bytes`, () => s.u16(n.sealed + 1 | 16384), {
        depth: 1,
        note: "The packet number and payload. Whatever follows is another packet in the same datagram."
      });
    } else {
      s.field("Destination connection ID", fo(n.dcid), () => s.raw(n.dcid), {
        depth: 1,
        example: true,
        note: "Only the receiver’s ID, and no length: it knows how long its own IDs are. It stays the same if the laptop changes network."
      });
    }
    s.field("Packet number", `${n.pn} (disguised)`, () => s.unknown(1), {
      depth: 1,
      hidden: true,
      note: "Hidden by header protection, so nobody on the way can read or change it."
    });
    s.field("Encrypted payload", `${n.sealed} bytes`, () => s.unknown(n.sealed), {
      depth: 1,
      hidden: true,
      note: Qw[n.type]
    });
    Ot(s, n.inner, 2);
  });
  return s;
}
const Zw = 2208988800;
const Jw = e => {
  const t = Math.floor(e);
  return `${new Date(t * 1000).toISOString().slice(11, 19)}${(e - t).toFixed(6).slice(1)} UTC`;
};
function eg(e) {
  const t = new R("ntp", `NTP · ${e.server ? "server" : "client"}`);
  const s = (a, r, i) => t.field(a, r ? Jw(r) : "0", () => {
    const c = Math.floor(r ?? 0);
    t.u32(r ? c + Zw : 0).u32(r ? Math.round((r - c) * 4294967296) : 0);
  }, {
    note: i
  });
  const n = (a, r, i) => t.field(a, r ? `${(r * 1000).toFixed(1)} ms` : "0", () => t.u32(Math.round(r * 65536)), {
    note: i,
    example: !!r
  });
  const o = e.version ?? 4;
  t.field("Leap, version, mode", `0, ${o}, ${e.server ? "4 (server)" : "3 (client)"}`, () => t.u8(o << 3 | (e.server ? 4 : 3)), {
    note: e.server ? "Mode 4: an answer from a server." : "Mode 3: a client asking for the time."
  });
  t.field("Stratum", e.server ? "2" : "0 (not set)", () => t.u8(e.server ? 2 : 0), {
    note: e.server ? "Two steps from a reference clock: it follows a stratum 1 server, which has its own GPS or atomic clock." : undefined
  });
  t.field("Poll", "64 s", () => t.u8(6), {
    note: "How often the client means to ask (2 to the power 6 seconds). It grows as the clock settles."
  });
  t.field("Precision", "2^-23 s (0.12 µs)", () => t.u8(233), {
    note: "How finely this clock can be read.",
    example: true
  });
  n("Root delay", e.server ? 0.0089 : 0, e.server ? "Round-trip time from this server to the reference clock." : undefined);
  n("Root dispersion", e.server ? 0.0213 : 0, e.server ? "How far off this server could be, at most." : undefined);
  t.field("Reference ID", e.server ? "192.0.2.123 (its own time source)" : "0", () => t.raw(e.server ? Ee("192.0.2.123") : [0, 0, 0, 0]), {
    example: !!e.server
  });
  s("Reference time", e.reference, e.server ? "When this server last set its own clock." : undefined);
  s("Origin time", e.origin, e.server ? "T1, copied from the request: the client can match the answer to its question." : undefined);
  s("Receive time", e.receive, e.server ? "T2: when the request arrived, by the server’s clock." : undefined);
  s("Transmit time", e.transmit, e.server ? "T3: when this answer left." : "T1: when the request left, by the laptop’s own (wrong) clock.");
  return t;
}
const fo = e => e.map(t => t.toString(16).padStart(2, "0")).join(" ");
const Ot = (e, t, s = 1) => t.forEach((n, o) => e.field(o ? "" : "Inside", n, () => {}, {
  depth: s,
  inside: true
}));
const Di = {
  1: "Request",
  2: "Response",
  3: "Success",
  4: "Failure"
};
const Ih = {
  1: "Identity",
  13: "EAP-TLS"
};
function Bu(e) {
  const t = new R("eap", `EAP · ${e.code > 2 ? Di[e.code] : `${Di[e.code]}, ${Ih[e.type]}`}`);
  const s = e.tls;
  const n = e.code > 2 ? 4 : 5 + (e.identity?.length ?? 0) + (s ? 1 + (s.length ? 4 + s.length : 0) : 0);
  t.field("Code", `${e.code} (${Di[e.code]})`, () => t.u8(e.code), {
    note: e.code === 3 ? "The RADIUS server accepted the login." : undefined
  });
  t.field("Identifier", e.id, () => t.u8(e.id), {
    note: "A response carries the same number as the request it answers.",
    example: true
  });
  t.field("Length", `${n} bytes`, () => t.u16(n));
  if (e.code > 2) {
    return t;
  }
  t.field("Type", `${e.type} (${Ih[e.type]})`, () => t.u8(e.type), {
    note: e.type === 1 ? e.code === 1 ? "Who are you?" : undefined : "A TLS handshake, carried inside EAP."
  });
  if (e.identity) {
    t.field("Identity", e.identity, () => t.ascii(e.identity), {
      mono: true,
      note: "Who is logging in. The realm after the @ tells the RADIUS server (or the servers that pass requests on) where the account lives."
    });
  }
  if (s) {
    const o = s.start ? 32 : s.length ? 128 : 0;
    t.field("Flags", s.start ? "0x20 (start)" : s.length ? "0x80 (length included)" : "0x00 (no data)", () => t.u8(o), {
      note: s.start ? "Start: the server is ready for the laptop’s Client Hello." : s.length ? undefined : "Nothing to send: an empty answer that keeps the conversation going."
    });
    if (s.length) {
      t.field("TLS length", `${s.length} bytes`, () => t.u32(s.length), {
        note: "Longer TLS messages are split into pieces of about 1,000 bytes, each one acknowledged."
      });
      t.field("TLS records", `${s.length} bytes`, () => t.unknown(s.length), {
        hidden: true,
        note: s.note
      });
      Ot(t, s.what);
    }
  }
  return t;
}
const Rh = {
  1: "Access-Request",
  2: "Access-Accept",
  3: "Access-Reject",
  11: "Access-Challenge"
};
const tg = {
  1: "Should this device be let in?",
  2: "Yes: let it in.",
  11: "Not yet: here is the next message for the device."
};
const sg = {
  "User-Name": 1,
  "NAS-IP-Address": 4,
  "Service-Type": 6,
  "Framed-MTU": 12,
  State: 24,
  "Called-Station-Id": 30,
  "Calling-Station-Id": 31,
  "NAS-Port-Type": 61,
  "Tunnel-Type": 64,
  "Tunnel-Medium-Type": 65,
  "EAP-Message": 79,
  "Message-Authenticator": 80,
  "Tunnel-Private-Group-Id": 81
};
const ur = {
  "Service-Type": {
    2: "Framed"
  },
  "NAS-Port-Type": {
    19: "Wireless, IEEE 802.11"
  },
  "Tunnel-Type": {
    13: "VLAN"
  },
  "Tunnel-Medium-Type": {
    6: "IEEE 802"
  }
};
const ng = {
  "User-Name": "The identity the laptop gave.",
  "NAS-IP-Address": "The access point asking.",
  "Called-Station-Id": "The access point’s MAC address and the network’s name.",
  "Calling-Station-Id": "The laptop’s MAC address.",
  "Framed-MTU": "Keep each EAP message small enough for one frame.",
  State: "The server’s bookmark for this login: the access point sends it back with the next request.",
  "Message-Authenticator": "An HMAC-MD5 of the whole packet, keyed with the shared secret. Every packet that carries EAP must have one; since the Blast-RADIUS attack of 2024, it goes first.",
  "Tunnel-Private-Group-Id": "Put this device on VLAN 20, the staff network."
};
const Nh = {
  "MS-MPPE-Recv-Key": [17, "The first 32 bytes of the key material that both ends of the TLS handshake worked out. The access point uses it as the PMK, the starting key for the 4-way handshake."],
  "MS-MPPE-Send-Key": [16, "The next 32 bytes of the key material. Wi-Fi doesn’t need them."]
};
function og(e) {
  const t = new R("radius", "");
  for (const [o, a] of e.attrs) {
    ag(t, o, a);
  }
  const s = new R("radius", `RADIUS · ${Rh[e.code]}`);
  const n = 20 + t.length;
  s.field("Code", `${e.code} (${Rh[e.code]})`, () => s.u8(e.code), {
    note: tg[e.code]
  });
  s.field("Identifier", e.id, () => s.u8(e.id), {
    note: "A reply carries the number of the request it answers.",
    example: true
  });
  s.field("Length", `${n} bytes`, () => s.u16(n));
  s.field("Authenticator", "16 bytes", () => s.unknown(16), {
    hidden: true,
    note: e.code === 1 ? "Random, new in every request." : "A hash of this reply, the request’s authenticator and the shared secret: only the real server could have made it."
  });
  s.field("Attributes", `${t.length} bytes`, () => {}, {
    heading: true
  });
  return s.append(t);
}
function ag(e, t, s) {
  const n = sg[t] ?? 26;
  const o = {
    depth: 1,
    note: ng[t]
  };
  if (t === "EAP-Message") {
    const a = Bu(s);
    const r = Math.ceil(a.length / 253);
    for (let i = 0, c = 0; i < a.length; i += 253, c++) {
      const d = Math.min(a.length, i + 253);
      e.field(c ? "EAP-Message, continued" : "EAP-Message", `type 79, ${d - i + 2} bytes`, () => e.u8(79).u8(d - i + 2), {
        depth: 1,
        note: c ? undefined : r > 1 ? `The EAP packet (${a.length.toLocaleString("en-US")} bytes), split over ${r} attributes of up to 253 bytes.` : "The EAP packet, passed on unchanged."
      });
      const p = e.length;
      e.raw(a.bytes.slice(i, d));
      const u = d === a.length;
      for (const y of a.fields) {
        const T = y.from === y.to;
        if (T ? y.from < i || y.from > d || y.from === d && !u : y.to <= i || y.from >= d) {
          continue;
        }
        const m = Math.max(y.from, i);
        const w = Math.min(y.to, d);
        const k = !T && (y.from < i || y.to > d);
        e.fields.push({
          ...y,
          name: k && y.from < i ? `${y.name}, continued` : y.name,
          value: k ? y.from >= i ? `${w - m} of ${y.to - y.from} bytes` : `${w - m} more bytes` : y.value,
          from: p + m - i,
          to: p + w - i,
          depth: (y.depth ?? 0) + 2
        });
      }
    }
  } else if (Nh[t]) {
    const [a, r] = Nh[t];
    e.field(t, "Microsoft (311), type " + a, () => e.u8(26).u8(58).u32(311).u8(a).u8(52), {
      depth: 1,
      note: r
    });
    e.field("Salt, encrypted key", "50 bytes", () => e.unknown(50), {
      depth: 2,
      hidden: true,
      note: "Encrypted with the shared secret, so only the access point can read the key."
    });
  } else if (t === "NAS-IP-Address") {
    e.field(t, s, () => e.u8(n).u8(6).raw(Ee(s)), o);
  } else if (t === "State" || t === "Message-Authenticator") {
    e.field(t, "16 bytes", () => e.u8(n).u8(18).unknown(16), {
      ...o,
      hidden: true
    });
  } else if (t === "Tunnel-Type" || t === "Tunnel-Medium-Type") {
    e.field(t, `${s} (${ur[t][s]})`, () => e.u8(n).u8(6).u8(0).u24(s), o);
  } else if (ur[t] || t === "Framed-MTU") {
    e.field(t, ur[t] ? `${s} (${ur[t][s]})` : `${s} bytes`, () => e.u8(n).u8(6).u32(s), o);
  } else {
    e.field(t, `"${s}"`, () => e.u8(n).u8(s.length + 2).ascii(s), {
      ...o,
      mono: true,
      example: t.endsWith("Station-Id")
    });
  }
}
const Oi = {
  0: "NEGOTIATE",
  1: "SESSION_SETUP",
  3: "TREE_CONNECT",
  5: "CREATE",
  6: "CLOSE",
  8: "READ"
};
const rg = {
  0: "STATUS_SUCCESS",
  3221225494: "STATUS_MORE_PROCESSING_REQUIRED"
};
const Mi = [514, 528, 768, 770, 785];
const Dh = [93, 58, 0, 0, 0, 0, 0, 0, 145, 44, 126, 11, 0, 0, 0, 0];
const ig = [Date.UTC(2026, 9, 12, 14, 3, 27), Date.UTC(2026, 10, 7, 9, 12, 5), Date.UTC(2026, 10, 2, 16, 48, 51), Date.UTC(2026, 10, 2, 16, 48, 51)];
const Oh = e => (e / 1000 + 11644473600) * 10000000;
const Mh = (e, t) => {
  for (const s of t) {
    e.u16le(s.charCodeAt(0));
  }
  return e;
};
function lg(e) {
  const t = !!e.resp;
  const s = new R("smb", `SMB2 · ${Oi[e.cmd]} ${t ? "response" : "request"}`);
  const n = new R("smb", "");
  cg(n, e);
  const o = 64 + n.length;
  const a = {
    depth: 1
  };
  s.field("Length", `${o.toLocaleString("en-US")} bytes`, () => s.u8(0).u24(o), {
    note: "On port 445 every SMB message starts with its length, a leftover from NetBIOS."
  });
  s.field("Header", "64 bytes", () => {}, {
    heading: true
  });
  s.field("Protocol", "0xFE \"SMB\" (SMB2 or 3)", () => s.raw([254, 83, 77, 66]), {
    ...a,
    note: "SMB1 messages started 0xFF \"SMB\". SMB1 is switched off in Windows today."
  });
  s.field("Header size", "64", () => s.u16le(64), a);
  s.field("Credit charge", e.charge ?? 1, () => s.u16le(e.charge ?? 1), {
    ...a,
    note: e.charge > 1 ? "A big read costs one credit per 64 KB." : undefined
  });
  s.field(t ? "Status" : "Channel sequence", t ? `${_(e.status ?? 0, 8)} (${rg[e.status ?? 0]})` : "0", () => s.u32le(t ? e.status ?? 0 : 0), {
    ...a,
    note: e.status ? "Not an error: the login needs another round." : undefined
  });
  s.field("Command", `${e.cmd} (${Oi[e.cmd]})`, () => s.u16le(e.cmd), a);
  s.field(t ? "Credits granted" : "Credits asked for", e.credits, () => s.u16le(e.credits), {
    ...a,
    example: true,
    note: t ? undefined : "Credits limit how many requests the laptop may have waiting at once. The server hands them out."
  });
  const r = (t ? 1 : 0) | (e.signed ? 8 : 0);
  s.field("Flags", `${_(r, 8)}${r ? ` (${[t && "response", e.signed && "signed"].filter(Boolean).join(", ")})` : ""}`, () => s.u32le(r), a);
  s.field("Next command", "0 (none chained)", () => s.u32le(0), a);
  s.field("Message ID", e.mid, () => s.u64le(e.mid), {
    ...a,
    note: t ? undefined : "Counts up with each request; the response carries the same number."
  });
  s.field("Reserved", "0x0000feff", () => s.u32le(65279), {
    ...a,
    example: true
  });
  s.field("Tree ID", e.tree ? _(e.tree, 8) : "0 (no share yet)", () => s.u32le(e.tree ?? 0), {
    ...a,
    example: !!e.tree,
    note: e.tree && e.cmd === 3 ? "The number for this share; later requests carry it." : undefined
  });
  s.field("Session ID", e.session ? _(e.session, 16) : "0 (not logged in yet)", () => s.u64le(e.session ?? 0), {
    ...a,
    example: !!e.session,
    note: e.session && e.cmd === 1 && t && e.status ? "The server’s number for this login, from now on in every message." : undefined
  });
  s.field("Signature", e.signed ? "16 bytes" : "zeros (not signed)", () => e.signed ? s.unknown(16) : s.raw(Array(16).fill(0)), {
    ...a,
    hidden: !!e.signed,
    note: e.signed ? "AES-GMAC over the whole message, with a key from the login: a changed or forged message would be caught." : undefined
  });
  s.field(`${Oi[e.cmd]} ${t ? "response" : "request"}`, `${n.length.toLocaleString("en-US")} bytes`, () => {}, {
    heading: true
  });
  return s.append(n);
}
function cg(e, t) {
  const s = {
    depth: 1
  };
  const n = (c, d, p, u = {}) => e.field(c, d, p, {
    ...s,
    ...u
  });
  const o = c => n("Structure size", c, () => e.u16le(c));
  const a = (c, d, p) => {
    n("Security buffer", `offset ${c}, ${d} bytes`, () => e.u16le(c).u16le(d));
    return () => {
      n("Security blob", `${d} bytes`, () => e.unknown(d), {
        hidden: true,
        example: true,
        note: "GSS-API and SPNEGO wrapping, around NTLMSSP."
      });
      Ot(e, p, 2);
    };
  };
  const r = () => n("File ID", fo(Dh.slice(0, 4)) + " …", () => e.raw(Dh), {
    example: true,
    note: "The handle for the open file: reads and the close name it."
  });
  const i = () => n("Times", "created, accessed, written, changed", () => ig.forEach(c => e.u64le(Oh(c))), {
    example: true,
    note: "Windows FILETIME: 100-nanosecond steps since 1601."
  });
  if (t.cmd === 0 && !t.resp) {
    o(36);
    n("Dialect count", Mi.length, () => e.u16le(Mi.length));
    n("Security mode", "0x0002 (signing required)", () => e.u16le(2), {
      note: "Recent versions of Windows 11 require signing by default."
    });
    n("Reserved", "0", () => e.u16le(0));
    n("Capabilities", "0x0000007f", () => e.u32le(127), {
      example: true,
      note: "DFS, leases, large reads and writes, multichannel, persistent handles, directory leases, encryption."
    });
    n("Client GUID", "16 bytes", () => e.unknown(16), {
      hidden: true,
      example: true,
      note: "A random ID for this computer."
    });
    n("Negotiate contexts", "at offset 112, 4 of them", () => e.u32le(112).u16le(4).u16le(0));
    n("Dialects", "2.0.2, 2.1, 3.0, 3.0.2, 3.1.1", () => Mi.forEach(c => e.u16le(c)), {
      note: "Every version the laptop speaks. The server picks the newest it also knows."
    });
    n("Padding", "2 bytes", () => e.u16le(0));
    n("Contexts", "102 bytes", () => e.unknown(102), {
      hidden: true,
      example: true,
      note: "SMB 3.1.1 extras, each in its own small block."
    });
    Ot(e, ["Pre-authentication integrity: SHA-512, and a 32-byte random salt", "Encryption: AES-128-GCM, AES-128-CCM, AES-256-GCM, AES-256-CCM", "Signing: AES-GMAC, AES-CMAC, HMAC-SHA256", "The server’s name: nas"], 2);
  } else if (t.cmd === 0) {
    o(65);
    n("Security mode", "0x0001 (signing enabled)", () => e.u16le(1));
    n("Dialect", "0x0311 (SMB 3.1.1)", () => e.u16le(785), {
      note: "The newest version both sides speak."
    });
    n("Context count", "3", () => e.u16le(3));
    n("Server GUID", "16 bytes", () => e.unknown(16), {
      hidden: true,
      example: true
    });
    n("Capabilities", "0x00000006", () => e.u32le(6), {
      example: true,
      note: "Leases, large reads and writes."
    });
    n("Largest read, write", "8 MB each", () => e.u32le(8388608).u32le(8388608).u32le(8388608), {
      example: true,
      note: "The most data one request may carry: transactions, reads and writes."
    });
    n("System time", "7 Nov 2026, 09:41:00", () => e.u64le(Oh(Date.UTC(2026, 10, 7, 9, 41))).u64le(0), {
      example: true
    });
    const c = a(128, 74, ["The login methods the server accepts: NTLMSSP"]);
    n("Context offset", "208", () => e.u32le(208));
    c();
    n("Padding", "6 bytes", () => e.raw([0, 0, 0, 0, 0, 0]));
    n("Contexts", "76 bytes", () => e.unknown(76), {
      hidden: true,
      example: true
    });
    Ot(e, ["Pre-authentication integrity: SHA-512, and the server’s own salt", "Encryption: AES-128-GCM", "Signing: AES-GMAC"], 2);
  } else if (t.cmd === 1 && !t.resp) {
    o(25);
    n("Flags", "0", () => e.u8(0));
    n("Security mode", "0x02 (signing required)", () => e.u8(2));
    n("Capabilities", "0x00000001 (DFS)", () => e.u32le(1));
    n("Channel", "0", () => e.u32le(0));
    const c = a(88, t.blob[0], t.blob[1]);
    n("Previous session", "0", () => e.u64le(0));
    c();
  } else if (t.cmd === 1) {
    o(9);
    n("Session flags", "0", () => e.u16le(0));
    if (t.blob === "done") {
      n("Security buffer", "offset 72, 9 bytes", () => e.u16le(72).u16le(9));
      n("Security blob", "SPNEGO: accept-completed", () => e.raw([161, 7, 48, 5, 160, 3, 10, 1, 0]), {
        note: "The login is complete."
      });
    } else {
      a(72, t.blob[0], t.blob[1])();
    }
  } else if (t.cmd === 3 && !t.resp) {
    o(9);
    n("Flags", "0", () => e.u16le(0));
    n("Path", `offset 72, ${t.path.length * 2} bytes`, () => e.u16le(72).u16le(t.path.length * 2));
    n("Share", t.path, () => Mh(e, t.path), {
      mono: true,
      note: "Server and share name, in UTF-16."
    });
  } else if (t.cmd === 3) {
    o(16);
    n("Share type", "1 (disk)", () => e.u8(1).u8(0));
    n("Share flags", "0x00000000", () => e.u32le(0), {
      note: "Encryption not required for this share; signing still protects every message."
    });
    n("Capabilities", "0", () => e.u32le(0));
    n("Access", "0x001f01ff (full control)", () => e.u32le(2032127), {
      note: "What this user may do in the share."
    });
  } else if (t.cmd === 5 && !t.resp) {
    o(57);
    n("Oplock, impersonation", "none, 2 (impersonation)", () => e.u8(0).u8(0).u32le(2));
    n("Reserved", "16 zero bytes", () => e.raw(Array(16).fill(0)));
    n("Desired access", "0x00120089 (read)", () => e.u32le(1179785), {
      note: "Read the data, its attributes and its permissions."
    });
    n("File attributes", "0", () => e.u32le(0));
    n("Share access", "0x00000001 (read)", () => e.u32le(1), {
      note: "Others may read the file while it is open, but not change it."
    });
    n("Disposition", "1 (open, fail if missing)", () => e.u32le(1));
    n("Options", "0x00000040 (a file, not a folder)", () => e.u32le(64));
    n("Name", `offset 120, ${t.name.length * 2} bytes`, () => e.u16le(120).u16le(t.name.length * 2));
    n("Create contexts", "none", () => e.u32le(0).u32le(0));
    n("File name", t.name, () => Mh(e, t.name), {
      mono: true,
      note: "Relative to the share."
    });
  } else if (t.cmd === 5) {
    o(89);
    n("Oplock, flags", "none, 0", () => e.u8(0).u8(0));
    n("Action", "1 (opened)", () => e.u32le(1));
    i();
    n("Allocation size", `${Math.ceil(t.size / 4096) * 4096} bytes`, () => e.u64le(Math.ceil(t.size / 4096) * 4096));
    n("File size", `${t.size.toLocaleString("en-US")} bytes`, () => e.u64le(t.size));
    n("Attributes", "0x00000020 (archive)", () => e.u32le(32).u32le(0));
    r();
    n("Create contexts", "none", () => e.u32le(0).u32le(0));
  } else if (t.cmd === 8 && !t.resp) {
    o(49);
    n("Padding, flags", "0x50, 0", () => e.u8(80).u8(0), {
      note: "Where the server should put the data in its answer: 80 bytes in, right after the headers."
    });
    n("Length", `${t.length.toLocaleString("en-US")} bytes`, () => e.u32le(t.length), {
      note: "The whole file in one request."
    });
    n("Offset", "0", () => e.u64le(0));
    r();
    n("Minimum, channel, remaining", "0, 0, 0", () => e.u32le(0).u32le(0).u32le(0));
    n("Channel info", "none", () => e.u16le(0).u16le(0).u8(0));
  } else if (t.cmd === 8) {
    o(17);
    n("Data offset", "80", () => e.u8(80).u8(0));
    n("Data length", `${t.length.toLocaleString("en-US")} bytes`, () => e.u32le(t.length));
    n("Remaining, flags", "0, 0", () => e.u32le(0).u32le(0));
    n("Data", `${t.length.toLocaleString("en-US")} bytes`, () => e.unknown(t.length), {
      hidden: true,
      note: "The file itself; its contents are not part of the lesson."
    });
  } else if (t.cmd === 6 && !t.resp) {
    o(24);
    n("Flags", "0", () => e.u16le(0).u32le(0));
    r();
  } else if (t.cmd === 6) {
    o(60);
    n("Flags", "0", () => e.u16le(0).u32le(0), {
      note: "The laptop didn’t ask for the file’s details, so the rest is zeros."
    });
    n("Times, sizes, attributes", "52 zero bytes", () => e.raw(Array(52).fill(0)));
  }
}
const qh = {
  3: "Read Holding Registers",
  5: "Write Single Coil",
  6: "Write Single Register"
};
const dg = {
  2: "Illegal Data Address"
};
function hg(e) {
  const t = e.exception ? e.fn | 128 : e.fn;
  const s = e.exception ? 1 : e.fn === 3 && e.resp ? 1 + e.registers.length * 2 : 4;
  const n = new R("modbus", `Modbus/TCP · ${e.exception ? "exception" : `${qh[e.fn]}${e.resp ? ", answer" : ""}`}`);
  n.field("Transaction ID", e.tid, () => n.u16(e.tid), {
    note: e.resp ? "The same number as the request." : "Picked by the client; the answer carries the same number.",
    example: true
  });
  n.field("Protocol ID", "0 (Modbus)", () => n.u16(0));
  n.field("Length", `${2 + s} bytes`, () => n.u16(2 + s), {
    note: "The unit ID and everything after it."
  });
  n.field("Unit ID", "1", () => n.u8(1), {
    note: "Which device. It matters when a gateway passes requests on to devices on a serial line."
  });
  n.field("Function code", e.exception ? `${t} (${e.fn} + 128: an exception)` : `${t} (${qh[e.fn]})`, () => n.u8(t), {
    note: e.exception ? "The top bit set: the request failed." : undefined
  });
  if (e.exception) {
    n.field("Exception code", `${e.exception} (${dg[e.exception]})`, () => n.u8(e.exception), {
      note: "There is no register at that address."
    });
  } else if (e.fn === 3 && !e.resp) {
    n.field("Starting address", `${e.address} (register 4${String(e.address + 1).padStart(4, "0")})`, () => n.u16(e.address), {
      note: "Modbus counts from 0, though manuals often number the same register 40001 and up."
    });
    n.field("Quantity", `${e.count} registers`, () => n.u16(e.count));
  } else if (e.fn === 3) {
    n.field("Byte count", `${e.registers.length * 2}`, () => n.u8(e.registers.length * 2));
    e.registers.forEach(([o, a], r) => n.field(`Register ${e.address + r}`, `${o} (${a})`, () => n.u16(o), {
      depth: 1,
      note: r ? undefined : "Plain 16-bit numbers. What each one means is written in the PLC’s documentation, not in the message."
    }));
  } else {
    n.field(e.fn === 5 ? "Coil address" : "Register address", `${e.address} (${e.what})`, () => n.u16(e.address));
    n.field("Value", e.fn === 5 ? e.value ? "0xFF00 (on)" : "0x0000 (off)" : `${e.value} (${e.meaning})`, () => n.u16(e.fn === 5 ? e.value ? 65280 : 0 : e.value), {
      note: e.resp ? "The answer repeats the request: done." : e.fn === 5 ? "A coil is a single on/off output. 0xFF00 switches it on." : undefined
    });
  }
  return n;
}
const Hh = {
  1: "OPEN",
  2: "UPDATE",
  3: "NOTIFICATION",
  4: "KEEPALIVE"
};
const pg = {
  1: "The first message on a session: who this router is and what it supports.",
  2: "Routes: paths to new addresses, and ones taken back.",
  4: "Only the header: “still here”. Sent when there’s nothing else to say, every third of the hold time."
};
const qi = e => {
  const [t, s] = e.split("/");
  return [+s, ...Ee(t).slice(0, Math.ceil(s / 8))];
};
function ug(e) {
  const t = new R("bgp", "");
  if (e.type === 1) {
    const n = {
      depth: 1
    };
    t.field("Version", "4", () => t.u8(4));
    t.field("My AS", e.as, () => t.u16(e.as), {
      note: "This router’s network. (A 4-byte AS number goes in the capability below, with 23456 here.)"
    });
    t.field("Hold time", `${e.hold} s`, () => t.u16(e.hold), {
      note: "If nothing at all arrives for this long, the session is dropped. Both sides use the lower offer."
    });
    t.field("BGP identifier", e.id, () => t.raw(Ee(e.id)), {
      note: "The router’s ID, usually one of its addresses."
    });
    t.field("Optional parameters", "16 bytes", () => t.u8(16));
    t.field("Capabilities", "parameter 2, 14 bytes", () => t.u8(2).u8(14), {
      note: "What this router can do beyond the basics."
    });
    t.field("Multiprotocol", "IPv4 unicast", () => t.u8(1).u8(4).u16(1).u8(0).u8(1), {
      ...n,
      note: "Which kinds of routes it will exchange on this session."
    });
    t.field("Route refresh", "yes", () => t.u8(2).u8(0), {
      ...n,
      note: "It can ask the other side to send all its routes again."
    });
    t.field("4-byte AS numbers", `yes, AS ${e.as}`, () => t.u8(65).u8(4).u32(e.as), {
      ...n,
      note: "2-byte AS numbers ran short, so newer ones are 4 bytes long."
    });
  } else if (e.type === 2) {
    const n = (e.withdraw ?? []).flatMap(qi);
    t.field("Withdrawn routes", n.length ? `${n.length} bytes` : "0 bytes", () => t.u16(n.length));
    for (const a of e.withdraw ?? []) {
      t.field("Withdrawn", a, () => t.raw(qi(a)), {
        depth: 1,
        note: "These addresses can no longer be reached through this router."
      });
    }
    const o = new R("bgp", "");
    if (e.path) {
      const a = {
        depth: 1
      };
      o.field("ORIGIN", "0 (IGP: from inside the network that announced it)", () => o.u8(64).u8(1).u8(1).u8(0), a);
      o.field("AS_PATH", e.path.join(" "), () => {
        o.u8(64).u8(2).u8(2 + e.path.length * 4).u8(2).u8(e.path.length);
        e.path.forEach(r => o.u32(r));
      }, {
        ...a,
        note: "Every network the route has passed through, the latest first. Other things being equal, the shorter path wins; a router that finds its own number here drops the route, so routes can’t loop."
      });
      o.field("NEXT_HOP", e.next, () => o.u8(64).u8(3).u8(4).raw(Ee(e.next)), {
        ...a,
        note: "Send packets for these addresses to this router."
      });
    }
    t.field("Path attributes", `${o.length} bytes`, () => t.u16(o.length));
    t.append(o);
    for (const a of e.nlri ?? []) {
      t.field("Reachable", a, () => t.raw(qi(a)), {
        note: "The addresses this route leads to: a prefix, here 256 addresses."
      });
    }
  }
  const s = new R("bgp", `BGP · ${Hh[e.type]}${e.withdraw ? " (withdrawal)" : ""}`);
  s.field("Marker", "16 bytes of 0xFF", () => s.raw(Array(16).fill(255)), {
    note: "All ones: where a message starts."
  });
  s.field("Length", `${19 + t.length} bytes`, () => s.u16(19 + t.length));
  s.field("Type", `${e.type} (${Hh[e.type]})`, () => s.u8(e.type), {
    note: pg[e.type]
  });
  return s.append(t);
}
const Fh = {
  1: "Binding Request",
  257: "Binding Success Response"
};
const Uh = 554869826;
function fg(e) {
  const t = new R("stun", "");
  const s = (o, a, r, i, c, d = {}) => t.field(a, r, () => {
    t.u16(o).u16(i);
    c();
    for (let p = i; p % 4; p++) {
      t.u8(0);
    }
  }, {
    depth: 1,
    ...d
  });
  for (const [o, a] of e.attrs ?? []) {
    if (o === "XOR-MAPPED-ADDRESS") {
      const [r, i] = a.split(":");
      s(32, o, a, 8, () => t.u8(0).u8(1).u16(i ^ 8466).raw(Ee(r).map((c, d) => c ^ Uh >>> 24 - d * 8 & 255)), {
        note: e.peer ? "Where the check came from, as the other laptop saw it: the home router’s public address and port." : "Where the request came from, as the server saw it: the home router’s public address, and the port its NAT picked for this conversation."
      });
    } else if (o === "USERNAME") {
      s(6, o, `"${a}"`, a.length, () => t.ascii(a), {
        mono: true,
        example: true,
        note: "The ICE user names from the offer and the answer, the other side’s first: proves the check belongs to this call."
      });
    } else if (o === "PRIORITY") {
      s(36, o, a, 4, () => t.u32(a), {
        example: true,
        note: "The priority a new candidate found by this check would get."
      });
    } else if (o === "ICE-CONTROLLING") {
      s(32810, o, "8 random bytes", 8, () => t.unknown(8), {
        hidden: true,
        note: "This side, the caller, makes the final choice of path. The random number settles a tie."
      });
    } else if (o === "USE-CANDIDATE") {
      s(37, o, "empty", 0, () => {}, {
        note: "Use this pair of addresses for the call."
      });
    } else if (o === "MESSAGE-INTEGRITY") {
      s(8, o, "20 bytes", 20, () => t.unknown(20), {
        hidden: true,
        note: "HMAC-SHA1 of the message, keyed with an ICE password swapped through the signalling server, so a stranger can’t fake a check or its answer."
      });
    } else if (o === "FINGERPRINT") {
      s(32808, o, "4 bytes", 4, () => t.unknown(4), {
        hidden: true,
        note: "A CRC-32 of the message: marks it clearly as STUN."
      });
    }
  }
  const n = new R("stun", `STUN · ${Fh[e.type]}`);
  n.field("Message type", `${_(e.type)} (${Fh[e.type]})`, () => n.u16(e.type));
  n.field("Length", `${t.length} bytes`, () => n.u16(t.length), {
    note: "The attributes; the 20-byte header isn’t counted."
  });
  n.field("Magic cookie", "0x2112a442", () => n.u32(Uh), {
    note: "Always this value: tells STUN apart from the other traffic on the same port."
  });
  n.field("Transaction ID", `${fo(e.tid.slice(0, 4))} …`, () => n.raw(e.tid), {
    example: true,
    note: "Random; the response carries the same ID."
  });
  if (t.length) {
    n.field("Attributes", `${t.length} bytes`, () => {}, {
      heading: true
    });
  }
  return n.append(t);
}
const Kh = {
  1: "Client Hello",
  2: "Server Hello",
  11: "Certificate",
  12: "Server Key Exchange",
  13: "Certificate Request",
  14: "Server Hello Done",
  15: "Certificate Verify",
  16: "Client Key Exchange"
};
function mg(e) {
  const t = new R("dtls", `DTLS · ${e.name}`);
  for (const s of e.records) {
    const n = s.ccs ? 1 : s.sealed ?? 12 + s.body;
    const o = s.ccs ? "Change Cipher Spec" : s.sealed ? "Finished (encrypted)" : Kh[s.msg];
    const a = {
      depth: 1
    };
    t.field(o, `record, ${13 + n} bytes`, () => {}, {
      heading: true
    });
    t.field("Content type", s.ccs ? "20 (change cipher spec)" : "22 (handshake)", () => t.u8(s.ccs ? 20 : 22), a);
    t.field("Version", "0xfefd (DTLS 1.2)", () => t.u16(65277), a);
    t.field("Epoch", s.epoch, () => t.u16(s.epoch), {
      ...a,
      note: s.epoch ? "Epoch 1: protected with the keys just agreed." : undefined
    });
    t.field("Sequence number", s.seq, () => t.u16(0).u32(s.seq), {
      ...a,
      note: "Counts this side’s records, so repeats and stale ones can be spotted."
    });
    t.field("Length", `${n} bytes`, () => t.u16(n), a);
    if (s.ccs) {
      t.field("Change cipher spec", "1", () => t.u8(1), {
        ...a,
        note: "From the next record on, this side encrypts."
      });
    } else if (s.sealed) {
      t.field("Encrypted", `${s.sealed} bytes`, () => t.unknown(s.sealed), {
        ...a,
        hidden: true,
        note: "An 8-byte nonce, the Finished message and a 16-byte tag (AES-128-GCM)."
      });
      Ot(t, ["Finished: a check value over the whole handshake"], 2);
    } else {
      t.field("Handshake type", `${s.msg} (${Kh[s.msg]})`, () => t.u8(s.msg), a);
      t.field("Message length", `${s.body} bytes`, () => t.u24(s.body), a);
      t.field("Message sequence", s.mseq, () => t.u16(s.mseq), {
        ...a,
        note: s.mseq === 0 ? "Handshake messages are numbered, so they can be put back in order." : undefined
      });
      t.field("Fragment", `offset 0, ${s.body} bytes (all of it)`, () => t.u24(0).u24(s.body), a);
      if (s.body) {
        t.field("Message", `${s.body} bytes`, () => t.unknown(s.body), {
          ...a,
          hidden: true,
          example: true
        });
        if (s.what) {
          Ot(t, s.what, 2);
        }
      }
    }
  }
  return t;
}
function yg(e) {
  const t = new R("srtp", `SRTP · ${e.video ? "video" : "audio"}`);
  t.field("Version etc.", "2, no padding, extension, no CSRCs", () => t.u8(144), {
    note: "X set: a header extension follows the fixed header."
  });
  t.field("Marker, payload type", `${e.marker ? 1 : 0}, ${e.pt} (${e.video ? "VP8" : "Opus"}, as agreed in the SDP)`, () => t.u8((e.marker ? 128 : 0) | e.pt), {
    example: true,
    note: e.marker ? "Marker set: the last packet of a video frame." : undefined
  });
  t.field("Sequence number", e.seq, () => t.u16(e.seq), {
    example: true,
    note: "One more for each packet, so a lost or late one shows."
  });
  t.field("Timestamp", e.ts, () => t.u32(e.ts), {
    example: true,
    note: e.video ? "Video clock, 90,000 ticks a second: +3,000 per frame at 30 frames a second." : "Audio clock, 48,000 ticks a second: +960 per 20 ms."
  });
  t.field("SSRC", _(e.ssrc, 8), () => t.u32(e.ssrc), {
    example: true,
    note: "Which stream this is; announced in the SDP."
  });
  t.field("Header extension", "0xbede, 2 words", () => t.u16(48862).u16(2), {
    note: "One-byte elements: an ID (from the SDP’s a=extmap lines) and a length."
  });
  if (e.video) {
    t.field("Absolute send time", "id 2, 3 bytes", () => t.u8(34).u24(e.sent), {
      depth: 1,
      example: true,
      note: "When the packet was sent, so the receiver can tell when the network is filling up."
    });
  } else {
    t.field("Audio level", `id 1: −${e.level} dBov, voice`, () => t.u8(16).u8(e.level | 128), {
      depth: 1,
      note: "How loud this packet is, so a group call can show who is talking without decrypting."
    });
  }
  t.field("Transport sequence", `id 3: ${e.tw}`, () => t.u8(49).u16(e.tw), {
    depth: 1,
    example: true,
    note: "Numbers every packet of the call; the receiver reports what arrived when, for congestion control."
  });
  t.field("Padding", e.video ? "1 byte" : "3 bytes", () => t.raw(e.video ? [0] : [0, 0, 0]), {
    depth: 1
  });
  t.field("Encrypted media", `${e.media} bytes`, () => t.unknown(e.media), {
    hidden: true,
    note: e.video ? "Part of a VP8 video frame, encrypted with keys from the DTLS handshake (AES-128-GCM)." : "20 ms of Opus audio, encrypted with keys from the DTLS handshake (AES-128-GCM)."
  });
  t.field("Authentication tag", "16 bytes", () => t.unknown(16), {
    hidden: true,
    note: "Proves the packet came from the other side unchanged; the header is covered too."
  });
  return t;
}
const wg = {
  1: "text",
  2: "binary",
  8: "close",
  9: "ping",
  10: "pong"
};
const gg = {
  1000: "normal closure",
  1001: "going away"
};
function Sg(e) {
  const t = wg[e.op];
  const s = new R("ws", `WebSocket · ${t}`);
  const n = e.code !== undefined ? [e.code >> 8, e.code & 255] : [...new TextEncoder().encode(e.text ?? "")];
  if (n.length > 125) {
    throw new Error("WebSocket: payloads over 125 bytes need an extended length");
  }
  const o = e.mask ? n.map((a, r) => a ^ e.mask[r % 4]) : n;
  s.field("FIN, opcode", `1, ${e.op} (${t})`, () => s.u8(e.op | 128), {
    note: "FIN 1: this frame is a whole message. The opcode says what it carries."
  });
  s.field("Mask, length", `${e.mask ? "masked" : "not masked"}, ${n.length} byte${n.length === 1 ? "" : "s"}`, () => s.u8((e.mask ? 128 : 0) | n.length), {
    note: e.mask ? "Everything a browser sends is masked." : "A server never masks what it sends."
  });
  if (e.mask) {
    s.field("Masking key", fo(e.mask), () => s.raw(e.mask), {
      note: "Chosen at random for every frame.",
      example: true
    });
  }
  if (n.length) {
    s.field(e.code !== undefined ? "Status code" : "Payload", e.code !== undefined ? `${e.code} (${gg[e.code]})` : `"${e.text}" (${n.length} bytes)`, () => s.raw(o), {
      mono: e.code === undefined,
      note: e.mask ? "Each byte XORed with the masking key in turn; the server XORs it back." : undefined
    });
  }
  return s;
}
const Bh = {
  0: "no login",
  2: "user name and password"
};
function Tg(e) {
  const t = new R("socks", `SOCKS5 · ${e.name}`);
  t.field("Version", "5", () => t.u8(5));
  if (e.methods) {
    t.field("Methods offered", e.methods.length, () => t.u8(e.methods.length));
    for (const s of e.methods) {
      t.field("Method", `${s} (${Bh[s]})`, () => t.u8(s), {
        depth: 1
      });
    }
  } else if (e.method !== undefined) {
    t.field("Method chosen", `${e.method} (${Bh[e.method]})`, () => t.u8(e.method));
  } else {
    if (e.reply) {
      t.field("Reply", "0 (succeeded)", () => t.u8(0));
    } else {
      t.field("Command", "1 (CONNECT)", () => t.u8(1), {
        note: "Open a TCP connection on my behalf."
      });
    }
    t.field("Reserved", "0", () => t.u8(0));
    if (e.host) {
      t.field("Address type", "3 (domain name)", () => t.u8(3));
      t.field("Address", e.host, () => t.u8(e.host.length).ascii(e.host), {
        mono: true,
        note: "The proxy looks the name up itself, so the laptop needs no DNS lookup of its own."
      });
    } else {
      t.field("Address type", "1 (IPv4)", () => t.u8(1));
      t.field("Address", e.ip, () => t.raw(Ee(e.ip)), {
        note: e.reply ? "The address the proxy connects from." : undefined
      });
    }
    t.field("Port", e.port, () => t.u16(e.port), {
      example: !!e.reply
    });
  }
  return t;
}
const _h = {
  1: "handshake initiation",
  2: "handshake response",
  4: "transport data"
};
function bg(e) {
  const t = new R("wg", `WireGuard · ${_h[e.type]}`);
  const s = (n, o, a) => t.field(n, `${o} bytes`, () => t.unknown(o), {
    hidden: true,
    note: a
  });
  t.field("Message type", `${e.type} (${_h[e.type]})`, () => t.u8(e.type));
  t.field("Reserved", "0", () => t.raw([0, 0, 0]));
  if (e.type === 1 || e.type === 2) {
    t.field("Sender index", _(e.sender, 8), () => t.u32le(e.sender), {
      note: "A number this side picked for the session; the other side puts it in every packet it sends back.",
      example: true
    });
  }
  if (e.type === 2 || e.type === 4) {
    t.field("Receiver index", _(e.receiver, 8), () => t.u32le(e.receiver), {
      note: "The other side’s index: which session this packet belongs to.",
      example: true
    });
  }
  if (e.type === 1) {
    s("Ephemeral key", 32, "A new public key, made just for this handshake.");
    s("Encrypted static key", 48, "The laptop’s long-term public key (32 bytes) and a 16-byte tag, encrypted: only the server learns who is calling.");
    s("Encrypted timestamp", 28, "The time (12 bytes) and a tag, encrypted. An old initiation sent again is refused.");
  } else if (e.type === 2) {
    s("Ephemeral key", 32, "The server’s new public key for this handshake.");
    s("Encrypted nothing", 16, "Only a tag: it proves the server holds its private key.");
  } else {
    t.field("Counter", e.counter, () => t.u64le(e.counter), {
      note: "Counts up with every packet; one seen before is thrown away."
    });
    s("Encrypted packet", e.sealed, e.inner ? "The whole inner packet, padded to a multiple of 16 bytes, then a 16-byte tag." : "Nothing but the 16-byte tag: an empty packet that keeps the tunnel open.");
    if (e.inner) {
      Ot(t, e.inner);
    }
  }
  if (e.type !== 4) {
    s("MAC 1", 16, "Keyed with the server’s public key: without it, the server doesn’t answer at all.");
    t.field("MAC 2", "zeros", () => t.raw(Array(16).fill(0)), {
      note: "Used only when the server is busy and asks for a cookie first."
    });
  }
  return t;
}
const Gh = {
  34: "IKE_SA_INIT",
  35: "IKE_AUTH"
};
const Hi = {
  33: "SA",
  34: "KE",
  35: "IDi",
  36: "IDr",
  40: "Nonce",
  41: "Notify",
  46: "Encrypted"
};
function vg(e) {
  const t = new R("ike", `IKEv2 · ${Gh[e.exchange]} ${e.response ? "response" : "request"}`);
  if (e.nonEsp) {
    t.field("Non-ESP marker", "0x00000000", () => t.u32(0), {
      note: "Four zero bytes: an IKE message, not an ESP packet (they share port 4500)."
    });
  }
  const s = new R("x", "");
  const n = [];
  if (e.exchange === 34) {
    n.push([33, 40, 34, () => s.field("Proposal", "IKE: AES-GCM-256, PRF HMAC-SHA-256, Curve25519", () => {
      s.u8(0).u8(0).u16(36).u8(1).u8(1).u8(0).u8(3);
      s.raw([3, 0, 0, 12, 1, 0, 0, 20, 128, 14, 1, 0]);
      s.raw([3, 0, 0, 8, 2, 0, 0, 5]);
      s.raw([0, 0, 0, 8, 4, 0, 0, 31]);
    }, {
      depth: 1,
      note: e.response ? "The one the server chose from the laptop’s offer." : "What the laptop offers; a real client often offers several."
    })]);
    n.push([34, 40, 40, () => {
      s.field("DH group", "31 (Curve25519)", () => s.u16(31).u16(0), {
        depth: 1
      });
      s.field("Key data", "32 bytes", () => s.unknown(32), {
        depth: 1,
        hidden: true,
        note: "This side’s public key. From the two, both work out the same secret."
      });
    }]);
    n.push([40, 36, 41, () => s.field("Nonce", "32 random bytes", () => s.unknown(32), {
      depth: 1,
      hidden: true
    })]);
    for (const [a, r, i] of [[16388, "NAT_DETECTION_SOURCE_IP", 41], [16389, "NAT_DETECTION_DESTINATION_IP", 0]]) {
      n.push([41, 28, i, () => {
        s.field("Notify", `${a} (${r})`, () => s.u8(0).u8(0).u16(a), {
          depth: 1
        });
        s.field("Hash", "20 bytes", () => s.unknown(20), {
          depth: 1,
          hidden: true,
          note: i ? "A hash of the SPIs and the address and port this side sent from. If what arrives doesn’t match, a NAT changed it on the way." : "The same for the address and port it sent to."
        });
      }]);
    }
  } else {
    n.push([46, e.sealed + 28, e.first, () => {
      s.field("IV", "8 bytes", () => s.unknown(8), {
        depth: 1,
        hidden: true
      });
      s.field("Encrypted payloads", `${e.sealed} bytes`, () => s.unknown(e.sealed), {
        depth: 1,
        hidden: true,
        note: "Everything else in this message, encrypted with the keys from IKE_SA_INIT."
      });
      Ot(s, e.inner, 2);
      s.field("Integrity check", "16 bytes", () => s.unknown(16), {
        depth: 1,
        hidden: true
      });
    }]);
  }
  const o = 28 + n.reduce((a, [, r]) => a + r, 0);
  t.field("Initiator SPI", _(e.spiI, 16), () => t.u64(e.spiI), {
    note: "Picked by the laptop: which IKE session this is.",
    example: true
  });
  t.field("Responder SPI", e.spiR ? _(e.spiR, 16) : "0 (not known yet)", () => t.u64(e.spiR ?? 0), {
    example: !!e.spiR
  });
  t.field("Next payload", `${n[0][0]} (${Hi[n[0][0]]})`, () => t.u8(n[0][0]));
  t.field("Version", "2.0", () => t.u8(32));
  t.field("Exchange type", `${e.exchange} (${Gh[e.exchange]})`, () => t.u8(e.exchange));
  t.field("Flags", e.response ? "0x20 (response)" : "0x08 (initiator)", () => t.u8(e.response ? 32 : 8));
  t.field("Message ID", e.exchange === 34 ? 0 : 1, () => t.u32(e.exchange === 34 ? 0 : 1), {
    note: "Each request and its response share a number; the next exchange counts up."
  });
  t.field("Length", `${o} bytes`, () => t.u32(o));
  for (const [a, r, i, c] of n) {
    s.field(`${Hi[a]} payload`, `${r} bytes`, () => {}, {
      heading: true
    });
    s.field("Next payload, length", `${i ? `${i} (${Hi[i]})` : "0 (none)"}, ${r} bytes`, () => s.u8(i).u8(0).u16(r), {
      depth: 1
    });
    c();
  }
  return t.append(s);
}
function kg(e) {
  const t = new R("esp", "ESP");
  t.field("SPI", _(e.spi, 8), () => t.u32(e.spi), {
    note: "Which tunnel (security association) this belongs to; the receiving side chose it during IKE_AUTH.",
    example: true
  });
  t.field("Sequence number", e.seq, () => t.u32(e.seq), {
    note: "Counts up with every packet; one seen before is thrown away."
  });
  t.field("IV", "8 bytes", () => t.unknown(8), {
    hidden: true,
    note: "Different for every packet."
  });
  t.field("Encrypted data", `${e.sealed} bytes`, () => t.unknown(e.sealed), {
    hidden: true,
    note: "The whole inner packet, then padding, the pad length and the next header (4: an IPv4 packet)."
  });
  Ot(t, e.inner);
  t.field("Integrity check", "16 bytes", () => t.unknown(16), {
    hidden: true,
    note: "Shows any change to the packet."
  });
  return t;
}
const ul = {
  9: "PADI",
  7: "PADO",
  25: "PADR",
  101: "PADS",
  167: "PADT",
  0: "Session"
};
const Pg = {
  9: "Active Discovery Initiation: is there an access server out there?",
  7: "Active Discovery Offer: an access server answers.",
  25: "Active Discovery Request: the router picks this server.",
  101: "Active Discovery Session-confirmation: here is the session ID.",
  167: "Active Discovery Terminate: the session is over.",
  0: "Session data: one PPP packet."
};
const Ag = {
  service: [257, "Service-Name", "The service the router wants; empty means any."],
  ac: [258, "AC-Name", "The access server’s name."],
  host: [259, "Host-Uniq", "A value the router made up. Answers carry it back, so the router can match them to its request."],
  cookie: [260, "AC-Cookie", "A value the server will recognise when the router asks for it again, so floods of fake requests cost it nothing."]
};
const _u = (e, t) => {
  const s = [];
  for (let n = 0; n < t; n += 4) {
    const o = kr(`${e} ${n}`);
    s.push(o >>> 24, o >>> 16 & 255, o >>> 8 & 255, o & 255);
  }
  return s.slice(0, t);
};
function fl(e, t, s) {
  const n = new R("pppoe", s);
  n.field("Version, type", "1, 1", () => n.u8(17));
  n.field("Code", `${_(e.code, 2)} (${ul[e.code]})`, () => n.u8(e.code), {
    note: Pg[e.code]
  });
  n.field("Session ID", e.session ? _(e.session) : "0 (none yet)", () => n.u16(e.session ?? 0), {
    note: e.session ? "Given by the server in its PADS; every frame of the session carries it." : undefined,
    example: !!e.session
  });
  n.field("Length", `${t} bytes`, () => n.u16(t), {
    note: "What follows this header."
  });
  return n;
}
function Eg(e) {
  const t = new R("tags", "");
  for (const [n, o] of e.tags) {
    const [a, r, i] = Ag[n];
    t.field(r, "", () => {}, {
      heading: true,
      note: i
    });
    if (n === "host" || n === "cookie") {
      const c = _u(`${n} pppoe`, n === "host" ? 4 : 16);
      t.field("Type, length", `${_(a)}, ${c.length}`, () => t.u16(a).u16(c.length), {
        depth: 1
      });
      t.field("Value", c.map(d => d.toString(16).padStart(2, "0")).join(""), () => t.raw(c), {
        depth: 1,
        example: true,
        mono: true
      });
    } else {
      t.field("Type, length", `${_(a)}, ${o.length}`, () => t.u16(a).u16(o.length), {
        depth: 1
      });
      if (o) {
        t.field("Value", `"${o}"`, () => t.ascii(o), {
          depth: 1,
          mono: true
        });
      } else {
        t.field("Value", "empty", () => {}, {
          depth: 1
        });
      }
    }
  }
  const s = fl(e, t.length, `PPPoE ${ul[e.code]} · ${6 + t.length} bytes`);
  s.summary = `${ul[e.code]}, ${e.tags.length} tags`;
  return s.append(t);
}
const xg = {
  lcp: [49185, "LCP", "Link Control Protocol: the link’s settings."],
  chap: [49699, "CHAP", "Challenge Handshake Authentication Protocol: the login."],
  ipcp: [32801, "IPCP", "IP Control Protocol: the IP address and DNS servers."],
  ip: [33, "IPv4", "An IPv4 packet follows."]
};
const Cg = {
  1: ["Configure-Request", "The settings this side wants."],
  2: ["Configure-Ack", "Every setting accepted, exactly as asked."],
  3: ["Configure-Nak", "Not these values: here are ones that would be accepted."],
  9: ["Echo-Request", "Is the other side still there?"],
  10: ["Echo-Reply", "Still here."]
};
const $g = {
  1: ["Challenge", "A random value for the router to prove its password with."],
  2: ["Response", "The proof, and who is logging in."],
  3: ["Success", "The login worked."]
};
function Lg(e, t, [s, n]) {
  if (s === "mru") {
    e.field("Maximum-Receive-Unit", `${n} bytes`, () => e.u8(1).u8(4).u16(n), {
      depth: 1,
      note: "The largest packet this side will take: 1,500 bytes of Ethernet minus PPPoE’s 8."
    });
  }
  if (s === "auth") {
    e.field("Authentication-Protocol", "CHAP with MD5", () => e.u8(3).u8(5).u16(49699).u8(5), {
      depth: 1,
      note: "How the server wants the router to log in."
    });
  }
  if (s === "magic") {
    e.field("Magic-Number", _(n, 8), () => e.u8(5).u8(6).u32(n), {
      depth: 1,
      example: true,
      note: "Random. Seeing its own number come back would mean the line loops back on itself."
    });
  }
  if (s === "ip") {
    e.field("IP-Address", n, () => e.u8(3).u8(6).raw(Ee(n)), {
      depth: 1,
      note: n === "0.0.0.0" ? "Zero: “please give me an address”." : t === "own" ? "The address of the server’s end of the link." : "The address for the router."
    });
  }
  if (s === "dns1") {
    e.field("Primary-DNS-Address", n, () => e.u8(129).u8(6).raw(Ee(n)), {
      depth: 1,
      note: n === "0.0.0.0" ? "Zero: “which DNS server should I use?”" : undefined
    });
  }
  if (s === "dns2") {
    e.field("Secondary-DNS-Address", n, () => e.u8(131).u8(6).raw(Ee(n)), {
      depth: 1
    });
  }
}
function Wh(e) {
  const t = e.lcp ? "lcp" : e.chap ? "chap" : e.ipcp ? "ipcp" : "ip";
  const [s, n, o] = xg[t];
  const a = new R("ppp", "");
  a.field("Protocol", `${_(s)} (${n})`, () => a.u16(s), {
    note: o
  });
  if (t === "ip") {
    a.name = "PPP · 2 bytes";
    return a;
  }
  const r = e[t];
  const i = new R("body", "");
  let c;
  if (t === "chap") {
    const [d, p] = $g[r.code];
    c = d;
    i.field("Code", `${r.code} (${d})`, () => i.u8(r.code), {
      note: p
    });
    i.field("Identifier", r.id, () => i.u8(r.id), {
      note: r.code === 1 ? "The response must carry the same number." : "The number of the challenge this answers."
    });
    const u = i.length;
    i.field("Length", "", () => i.u16(0));
    if (r.code === 1 || r.code === 2) {
      const y = _u(`chap ${r.code} ${r.id}`, 16);
      i.field("Value size", "16 bytes", () => i.u8(16));
      i.field("Value", y.map(T => T.toString(16).padStart(2, "0")).join(""), () => i.raw(y), {
        example: true,
        mono: true,
        note: r.code === 1 ? "Random, new for every login." : "MD5 of the identifier, the password and the challenge: it proves the password without sending it."
      });
      i.field("Name", `"${r.name}"`, () => i.ascii(r.name), {
        mono: true,
        note: r.code === 1 ? "The server’s name." : "The username the provider gave."
      });
    } else if (r.message) {
      i.field("Message", `"${r.message}"`, () => i.ascii(r.message), {
        mono: true,
        note: "Text for people to read; any words will do."
      });
    }
    i.bytes[u] = i.length >> 8;
    i.bytes[u + 1] = i.length & 255;
    i.fields.find(y => y.name === "Length").value = `${i.length} bytes`;
  } else {
    const [d, p] = Cg[r.code];
    c = d;
    i.field("Code", `${r.code} (${d})`, () => i.u8(r.code), {
      note: p
    });
    i.field("Identifier", r.id, () => i.u8(r.id), {
      note: r.code === 1 || r.code === 9 ? "The answer carries the same number." : "The number of the request this answers."
    });
    const u = (r.opts ?? []).reduce((T, [m]) => T + {
      mru: 4,
      auth: 5,
      magic: 6,
      ip: 6,
      dns1: 6,
      dns2: 6
    }[m], 0);
    const y = 4 + u + (r.magic !== undefined ? 4 : 0);
    i.field("Length", `${y} bytes`, () => i.u16(y));
    if (r.magic !== undefined) {
      i.field("Magic-Number", _(r.magic, 8), () => i.u32(r.magic), {
        example: true
      });
    }
    if (r.opts?.length) {
      i.field("Options", `${u} bytes`, () => {}, {
        heading: true
      });
      for (const T of r.opts) {
        Lg(i, r.own ? "own" : "peer", T);
      }
    }
  }
  a.append(i);
  a.name = `PPP ${n} ${c} · ${a.length} bytes`;
  a.summary = `${n} ${c}`;
  return a;
}
const Fi = e => e.proto.replace(" (TLS)", "").replace("-DATA", " data");
const Ig = {
  handshake: [22, "Handshake"],
  ccs: [20, "Change Cipher Spec"],
  appdata: [23, "Application Data"],
  alert: [21, "Alert"]
};
function Rg(e, t) {
  const s = new R("tls", `TLS 1.3 · ${e.length} record${e.length > 1 ? "s" : ""}`);
  for (const n of e) {
    const [o, a] = Ig[n.type];
    const r = n.length;
    s.field("Record", `${a}, ${r.toLocaleString("en-US")} byte${r === 1 ? "" : "s"}`, () => {}, {
      heading: true
    });
    s.field("Content type", `${o} (${a})`, () => s.u8(o), {
      depth: 1,
      note: n.inner ? "Every encrypted record says Application Data on the outside; the real type is inside." : undefined
    });
    s.field("Version", n.legacy ? "0x0301 (TLS 1.0)" : "0x0303 (TLS 1.2)", () => s.u16(n.legacy ? 769 : 771), {
      depth: 1,
      note: n.legacy ? "A Client Hello’s record says TLS 1.0 so old middleboxes let it through; the real versions are offered inside." : "TLS 1.3 records say 1.2 on the outside, for compatibility."
    });
    s.field("Length", r.toLocaleString("en-US"), () => s.u16(r), {
      depth: 1
    });
    if (n.type === "ccs") {
      s.field("Change cipher spec", "1", () => s.u8(1), {
        depth: 1,
        note: "Has no job in TLS 1.3; sent so middleboxes see a familiar handshake."
      });
    } else if (n.hello) {
      const i = n.hello;
      s.field("Handshake type", `${i.type} (${i.name})`, () => s.u8(i.type), {
        depth: 1
      });
      s.field("Length", (r - 4).toLocaleString("en-US"), () => s.u24(r - 4), {
        depth: 1
      });
      s.field("Contents", `${(r - 4).toLocaleString("en-US")} bytes`, () => s.unknown(r - 4), {
        depth: 1,
        hidden: true,
        note: i.note
      });
      for (const [c, d] of i.fields) {
        s.field(c, d, () => {}, {
          depth: 2
        });
      }
    } else {
      s.field("Encrypted data", `${r.toLocaleString("en-US")} bytes`, () => s.unknown(r), {
        depth: 1,
        hidden: true,
        note: "Ciphertext, ending in a 16-byte tag that shows any change. Only the two ends can read it."
      });
      if (n.inner) {
        s.field("Inside", n.inner.what, () => {}, {
          depth: 2,
          inside: true
        });
        for (const i of n.inner.text ?? []) {
          s.field("", `${Ku(i)}␍␊`, () => {}, {
            depth: 3,
            inside: true,
            mono: true
          });
        }
      }
    }
  }
  return s;
}
function Ng(e) {
  const t = new R("ssh", "SSH");
  if (e.sealed) {
    t.name = "SSH · encrypted packet";
    t.field("Encrypted packet", `${e.sealed} bytes`, () => t.unknown(e.sealed), {
      hidden: true,
      note: "With chacha20-poly1305 even the length is encrypted; a 16-byte tag at the end shows any change."
    });
    t.field("Inside", e.inside, () => {}, {
      depth: 1,
      inside: true
    });
    return t;
  }
  const s = new R("x", "");
  const n = (r, i, c = 1) => s.field(r, i.length > 60 ? `${i.slice(0, 57)}…` : i, () => s.u32(i.length).ascii(i), {
    depth: c,
    mono: true
  });
  if (e.msg === "kexinit") {
    s.field("Message", "20 (KEXINIT)", () => s.u8(20));
    s.field("Cookie", "16 random bytes", () => s.unknown(16), {
      depth: 1,
      hidden: true
    });
    const r = [["Key exchange", e.kex], ["Host keys", e.hostkeys], ["Ciphers, out", e.ciphers], ["Ciphers, in", e.ciphers], ["MACs, out", e.macs], ["MACs, in", e.macs], ["Compression, out", e.compression], ["Compression, in", e.compression], ["Languages, out", []], ["Languages, in", []]];
    for (const [i, c] of r) {
      n(i, c.join(","));
    }
    s.field("First packet follows", "0", () => s.u8(0), {
      depth: 1
    });
    s.field("Reserved", "0", () => s.u32(0), {
      depth: 1
    });
  } else if (e.msg === "ecdh_init") {
    s.field("Message", "30 (KEX_ECDH_INIT)", () => s.u8(30));
    s.field("Public keys", `${e.q} bytes (sntrup761 1,158 + X25519 32)`, () => s.u32(e.q).unknown(e.q), {
      depth: 1,
      hidden: true
    });
  } else if (e.msg === "ecdh_reply") {
    s.field("Message", "31 (KEX_ECDH_REPLY)", () => s.u8(31));
    s.field("Host key", `${e.ks} bytes: ssh-ed25519 public key`, () => s.u32(e.ks).unknown(e.ks), {
      depth: 1,
      hidden: true
    });
    s.field("Server’s half", `${e.q} bytes (sntrup761 ciphertext 1,039 + X25519 32)`, () => s.u32(e.q).unknown(e.q), {
      depth: 1,
      hidden: true
    });
    s.field("Signature", `${e.sig} bytes: ssh-ed25519 signature over the exchange`, () => s.u32(e.sig).unknown(e.sig), {
      depth: 1,
      hidden: true
    });
  } else if (e.msg === "newkeys") {
    s.field("Message", "21 (NEWKEYS)", () => s.u8(21), {
      note: "From the next packet on, this side encrypts."
    });
  }
  let o = 8 - (5 + s.length) % 8;
  if (o < 4) {
    o += 8;
  }
  t.field("Packet length", 1 + s.length + o, () => t.u32(1 + s.length + o), {
    note: "Bytes after this field."
  });
  t.field("Padding length", o, () => t.u8(o), {
    note: "Random padding brings the packet to a multiple of 8 bytes."
  });
  const a = t.length;
  t.raw(s.bytes);
  for (const r of s.fields) {
    t.fields.push({
      ...r,
      from: r.from + a,
      to: r.to + a
    });
  }
  t.field("Padding", `${o} random bytes`, () => t.unknown(o), {
    hidden: true
  });
  return t;
}
const Dg = {
  RRSIG: "A signature over the records above it, made with the zone’s private key.",
  DNSKEY: "One of the zone’s public keys; whoever checks a signature needs it.",
  DS: "A hash of the child zone’s key-signing key, kept and signed by the parent zone."
};
const Ui = {
  A: 1,
  NS: 2,
  MX: 15,
  AAAA: 28,
  OPT: 41,
  DS: 43,
  RRSIG: 46,
  DNSKEY: 48
};
function Og(e) {
  const t = new R("dns", "DNS");
  const s = new Map();
  const n = m => {
    const w = m.split(".");
    for (let k = 0; k < w.length; k++) {
      const A = w.slice(k).join(".");
      if (s.has(A)) {
        return t.u16(s.get(A) | 49152);
      }
      if (t.length < 16383) {
        s.set(A, t.length);
      }
      t.u8(w[k].length).ascii(w[k]);
    }
    t.u8(0);
  };
  const o = m => {
    for (const w of m.split(".")) {
      t.u8(w.length).ascii(w);
    }
    t.u8(0);
  };
  const a = (e.response ? 32768 : 0) | (e.aa ? 1024 : 0) | (e.rd ? 256 : 0) | (e.ra ? 128 : 0) | (e.ad ? 32 : 0);
  const r = [e.response ? "response" : "query", e.aa && "AA (authoritative)", e.rd && "RD (recursion desired)", e.ra && "RA (recursion available)", e.ad && "AD (authenticated data)"].filter(Boolean);
  const i = m => m ?? [];
  const c = i(e.ar).length + (e.edns ? 1 : 0);
  t.field("Transaction ID", _(e.id), () => t.u16(e.id), {
    note: "Picked at random; the answer must carry the same one.",
    example: true
  });
  t.field("Flags", `${_(a)}: ${r.join(", ")}`, () => t.u16(a));
  t.field("Questions", 1, () => t.u16(1));
  t.field("Answers", i(e.an).length, () => t.u16(i(e.an).length));
  t.field("Authority records", i(e.ns).length, () => t.u16(i(e.ns).length));
  t.field("Additional records", c, () => t.u16(c));
  const [d, p] = e.q;
  t.field("Question", `${d}, type ${p}, class IN`, () => {
    n(d);
    t.u16(Ui[p]).u16(1);
  });
  const u = m => new Date(m * 1000).toISOString().slice(0, 10);
  const y = {
    MX: m => `${m[0]} ${m[1]}`,
    DNSKEY: m => `${m.flags} (${m.flags === 257 ? "key-signing key" : "zone-signing key"} ${m.tag}), ECDSA P-256`,
    DS: m => `key ${m.tag}, SHA-256 digest`,
    RRSIG: m => `${m.covered}, signed by ${m.signer} key ${m.tag}, valid ${u(m.inception)} to ${u(m.expiration)}`
  };
  const T = (m, [w, k, A, N]) => {
    const L = y[k] ? y[k](N) : N;
    t.field(m, `${w} ${k} ${L} (TTL ${A.toLocaleString("en-US")} s)`, () => {
      n(w);
      t.u16(Ui[k]).u16(1).u32(A);
      const Q = t.length;
      t.u16(0);
      if (k === "A") {
        t.raw(Ee(N));
      } else if (k === "AAAA") {
        t.raw(es(N));
      } else if (k === "NS") {
        n(N);
      } else if (k === "MX") {
        t.u16(N[0]);
        n(N[1]);
      } else if (k === "DNSKEY") {
        t.u16(N.flags).u8(3).u8(13).unknown(64);
      } else if (k === "DS") {
        t.u16(N.tag).u8(13).u8(2).unknown(32);
      } else if (k === "RRSIG") {
        t.u16(Ui[N.covered]).u8(13).u8(N.labels).u32(N.ttl).u32(N.expiration).u32(N.inception).u16(N.tag);
        o(N.signer);
        t.unknown(64);
      }
      const ne = t.length - Q - 2;
      t.bytes[Q] = ne >> 8;
      t.bytes[Q + 1] = ne & 255;
    }, {
      example: e.exampleTtl && m === "Answer",
      note: Dg[k]
    });
  };
  i(e.an).forEach(m => T("Answer", m));
  i(e.ns).forEach(m => T("Authority", m));
  i(e.ar).forEach(m => T("Additional", m));
  if (e.edns) {
    t.field("EDNS", `UDP size ${e.edns.size}, DNSSEC OK = ${e.edns.do ? 1 : 0}`, () => t.u8(0).u16(41).u16(e.edns.size).u32(e.edns.do ? 32768 : 0).u16(0), {
      note: e.edns.do ? "Says how big a UDP answer can be, and DNSSEC OK: send the signatures too." : "Says how big a UDP answer can be. DNSSEC signatures are not asked for here, to keep the lesson short; a validating resolver like 8.8.8.8 does ask for them."
    });
  }
  return t;
}
const Vh = ["", "Discover", "Offer", "Request", "Decline", "ACK", "NAK", "Release", "Inform"];
const Mg = {
  1: ["Subnet mask", "ip"],
  3: ["Router", "ip"],
  6: ["DNS server", "ip"],
  12: ["Host name", "text"],
  28: ["Broadcast address", "ip"],
  50: ["Requested address", "ip"],
  51: ["Lease time", "secs"],
  53: ["Message type", "type"],
  54: ["Server identifier", "ip"],
  55: ["Parameters wanted", "list"],
  58: ["Renewal time (T1)", "secs"],
  59: ["Rebinding time (T2)", "secs"],
  60: ["Vendor class", "text"],
  61: ["Client identifier", "mac"],
  81: ["Client FQDN", "fqdn"]
};
function qg(e) {
  const t = new R("dhcp", `DHCP ${Vh[e.options.find(([n]) => n === 53)[1]]}`);
  const s = (n, o, a) => t.field(n, o, () => t.raw(Ee(o)), {
    note: a
  });
  t.field("Message", e.op === 1 ? "1 (request, from a client)" : "2 (reply, from a server)", () => t.u8(e.op));
  t.field("Hardware", "Ethernet, 6-byte addresses", () => t.u8(1).u8(6));
  t.field("Hops", "0", () => t.u8(0));
  t.field("Transaction ID", _(e.xid, 8), () => t.u32(e.xid), {
    note: "Chosen by the client; every reply repeats it."
  });
  t.field("Seconds", "0", () => t.u16(0));
  t.field("Flags", "0x0000 (unicast replies are fine)", () => t.u16(0), {
    note: "Broadcast flag off: the server may send straight to the client’s MAC address."
  });
  s("Client address", e.ciaddr ?? "0.0.0.0", "Filled in only when the client already has an address (renewing).");
  s("Your address", e.yiaddr ?? "0.0.0.0", "The address the server is giving out.");
  s("Next server", e.siaddr ?? "0.0.0.0");
  s("Relay agent", "0.0.0.0");
  t.field("Client MAC", pe.laptop, () => t.raw(ts(pe.laptop)).raw(Array(10).fill(0)), {
    example: true
  });
  t.field("Server name, boot file", "empty", () => t.raw(Array(192).fill(0)));
  t.field("Magic cookie", "99.130.83.99 (DHCP)", () => t.raw([99, 130, 83, 99]), {
    note: "Marks the options that follow as DHCP."
  });
  for (const [n, o] of e.options) {
    const [a, r] = Mg[n];
    const i = r === "type" ? `${o} (${Vh[o]})` : r === "secs" ? `${o.toLocaleString("en-US")} s (${o / 3600} h)` : r === "list" ? o.join(", ") : r === "mac" ? `01 ${pe.laptop}` : o;
    t.field(`Option ${n}`, `${a}: ${i}`, () => {
      t.u8(n);
      if (r === "ip") {
        t.u8(4).raw(Ee(o));
      } else if (r === "type") {
        t.u8(1).u8(o);
      } else if (r === "secs") {
        t.u8(4).u32(o);
      } else if (r === "text") {
        t.u8(o.length).ascii(o);
      } else if (r === "list") {
        t.u8(o.length).raw(o);
      } else if (r === "mac") {
        t.u8(7).u8(1).raw(ts(pe.laptop));
      } else if (r === "fqdn") {
        t.u8(3 + o.length).u8(0).u8(0).u8(0).ascii(o);
      }
    }, {
      example: ["text", "list", "fqdn"].includes(r)
    });
  }
  t.field("End", "255", () => t.u8(255));
  if (t.length < 300) {
    const n = 300 - t.length;
    t.field("Padding", `${n} zero bytes, up to the 300-byte minimum`, () => t.raw(Array(n).fill(0)));
  }
  return t;
}
function Hg(e) {
  const t = e.codec ?? "opus";
  const s = t === "h264";
  const n = new R("rtp", s ? "RTP + video" : "RTP + audio");
  const o = {
    opus: `${e.pt} (Opus, agreed when the call was set up)`,
    pcmu: `${e.pt} (PCMU: G.711 μ-law, the classic phone codec)`,
    h264: `${e.pt} (H.264, as the camera’s description said)`
  };
  const a = {
    opus: "Audio clock at 48,000 per second: +960 per 20 ms frame.",
    pcmu: "Audio clock at 8,000 per second: +160 per 20 ms of sound.",
    h264: "Video clock at 90,000 per second; every packet of one frame has the same value."
  };
  n.field("Version etc.", "2, no padding, no extension, no CSRCs", () => n.u8(128));
  n.field("Marker, payload type", `${e.marker ? 1 : 0}, ${o[t]}`, () => n.u8((e.marker ? 128 : 0) | e.pt), {
    example: true,
    note: s ? e.marker ? "Marker set: the last packet of a frame." : "Marker clear: more of this frame follows." : undefined
  });
  n.field("Sequence number", e.seq, () => n.u16(e.seq), {
    note: "Counts up by one per packet, so the app can spot a missing or late one.",
    example: true
  });
  n.field("Timestamp", e.ts, () => n.u32(e.ts), {
    note: a[t],
    example: true
  });
  n.field("SSRC", _(e.ssrc, 8), () => n.u32(e.ssrc), {
    note: s ? "Identifies this video stream." : "Identifies this audio stream.",
    example: true
  });
  if (t === "opus") {
    n.field("Audio", `${e.audio} bytes of Opus audio (20 ms)`, () => n.unknown(e.audio), {
      hidden: true
    });
  }
  if (t === "pcmu") {
    n.field("Audio", `${e.audio} bytes of G.711 audio (20 ms, one byte per sample)`, () => n.unknown(e.audio), {
      hidden: true
    });
  }
  if (s) {
    n.field("FU indicator", "0x7c (fragment of a frame)", () => n.u8(124), {
      note: "Fragmentation unit: one piece of a frame too big for one packet."
    });
    const r = (e.start ? 128 : 0) | (e.end ? 64 : 0) | 5;
    n.field("FU header", `${_(r, 2)} (${e.start ? "first piece" : e.end ? "last piece" : "middle piece"} of a key frame)`, () => n.u8(r), {
      note: "Type 5: a key frame (IDR), a whole picture the decoder can start from."
    });
    n.field("Video", `${e.video} bytes of the key frame`, () => n.unknown(e.video), {
      hidden: true
    });
  }
  return n;
}
function Fg(e) {
  const t = new R("mpegts", "MPEG-TS · 7 packets");
  t.field("Sync byte", "0x47", () => t.u8(71), {
    note: "Every transport stream packet starts with 0x47, so the receiver can find where packets begin."
  });
  t.field("Flags, PID", `${_(e.pid, 4)} (PID ${e.pid}: video)`, () => t.u16(e.pid), {
    note: "Which stream the packet belongs to: the channel’s video, its audio, or the tables that list them.",
    example: true
  });
  t.field("Payload, counter", `${_(e.cc | 16, 2)} (payload only, counter ${e.cc})`, () => t.u8(e.cc | 16), {
    note: "Counts 0 to 15 for each PID, so a lost packet shows up as a gap.",
    example: true
  });
  t.field("Video", "184 bytes of the channel’s video", () => t.unknown(184), {
    hidden: true
  });
  t.field("More packets", "6 × 188 bytes: video and audio", () => t.unknown(1128), {
    hidden: true,
    note: "Six more transport stream packets, each with its own 4-byte header."
  });
  return t;
}
const Ko = pe.lan;
const Yh = [0, 15, 172, 4];
const Ug = {
  1: "802.1X (logins checked by a RADIUS server)",
  2: "PSK (a shared password)",
  8: "SAE (WPA3)"
};
const Kg = {
  "assoc-req": [0, "Association Request"],
  "assoc-resp": [16, "Association Response"],
  "probe-req": [64, "Probe Request"],
  "probe-resp": [80, "Probe Response"],
  beacon: [128, "Beacon"],
  auth: [176, "Authentication"]
};
const Bg = [140, 18, 152, 36, 176, 72, 96, 108];
function ml(e, t) {
  const s = t === 8 ? 192 : 0;
  e.field("RSN", `WPA${t === 8 ? 3 : 2}: CCMP, ${t === 8 ? "SAE" : t === 1 ? "802.1X" : "PSK"}`, () => {}, {
    heading: true,
    note: "Robust Security Network: how this network is protected."
  });
  e.field("Element ID, length", "48, 20 bytes", () => e.u8(48).u8(20), {
    depth: 1
  });
  e.field("Version", "1", () => e.u16le(1), {
    depth: 1
  });
  e.field("Group cipher", "CCMP (AES)", () => e.raw(Yh), {
    depth: 1,
    note: "Encrypts broadcasts, which every device on the network can read."
  });
  e.field("Pairwise cipher", "1: CCMP (AES)", () => e.u16le(1).raw(Yh), {
    depth: 1,
    note: "Encrypts each device’s own traffic, with keys only it and the access point have."
  });
  e.field("Key management", `1: ${Ug[t]}`, () => e.u16le(1).raw([0, 15, 172, t]), {
    depth: 1
  });
  e.field("Capabilities", s ? "0x00c0: management frame protection required" : "0x0000", () => e.u16le(s), {
    depth: 1,
    note: s ? "Disconnect messages and other management frames are signed, so they can’t be forged." : undefined
  });
}
function _g(e, t) {
  const s = new R("mgmt", t);
  const n = () => s.field("SSID", `"${e.ssid}"`, () => s.u8(0).u8(e.ssid.length).ascii(e.ssid), {
    mono: true,
    note: "The network’s name."
  });
  const o = () => s.field("Supported rates", "6, 9, 12, 18, 24, 36, 48, 54 Mbit/s", () => s.u8(1).u8(8).raw(Bg), {
    note: "Only the oldest, slowest rates; the fast ones are in the elements that follow."
  });
  const a = i => s.field("More elements", `${e.other} bytes`, () => s.unknown(e.other), {
    hidden: true,
    note: i
  });
  const r = i => s.field("Capabilities", "0x0011: access point network, encrypted", () => s.u16le(17), {
    note: "Privacy bit set: joining takes a key.",
    example: i
  });
  if (e.kind === "beacon" || e.kind === "probe-resp") {
    s.field("Timestamp", `${e.ts.toLocaleString("en-US")} µs`, () => s.u64le(e.ts), {
      note: "The access point’s clock; devices on the network keep theirs in step with it.",
      example: true
    });
    s.field("Beacon interval", "100 TU (102.4 ms)", () => s.u16le(100), {
      note: "A beacon goes out about ten times a second."
    });
    r(false);
    n();
    o();
    if (e.kind === "beacon") {
      s.field("TIM", "DTIM count 0, period 1", () => s.raw([5, 4, 0, 1, 0, 0]), {
        note: "Tells sleeping devices whether frames are waiting for them."
      });
    }
    ml(s, e.akm);
    a("Wi-Fi 4, 5 and 6 capabilities and settings (HT, VHT, HE: channel 36, 80 MHz wide), and vendor extras.");
  } else if (e.kind === "probe-req") {
    s.field("SSID", "empty (any network)", () => s.u8(0).u8(0), {
      note: "Any access point may answer. (Devices used to ask for every network they had joined by name, telling anyone listening where they had been.)"
    });
    o();
    a("What the laptop’s radio can do: Wi-Fi 4, 5 and 6 capabilities, and vendor extras.");
  } else if (e.kind === "auth") {
    const i = e.alg === 3;
    s.name = i ? `Authentication · SAE ${e.sae}` : "Authentication · Open System";
    s.field("Algorithm", i ? "3 (SAE)" : "0 (Open System)", () => s.u16le(e.alg), {
      note: i ? "Simultaneous Authentication of Equals: WPA3’s password exchange." : "Open: anyone may get this far. The password is checked later, in the 4-way handshake."
    });
    s.field("Transaction", i ? `${e.trans} (${e.sae})` : `${e.trans}`, () => s.u16le(e.trans));
    s.field("Status", "0 (success)", () => s.u16le(0));
    if (i && e.sae === "Commit") {
      s.field("Group", "19 (256-bit elliptic curve)", () => s.u16le(19));
      s.field("Scalar", "32 bytes", () => s.unknown(32), {
        hidden: true,
        note: "Worked out from a random secret and the password."
      });
      s.field("Element", "64 bytes", () => s.unknown(64), {
        hidden: true,
        note: "A point on the curve, also tied to the password. Recording the scalar and element doesn’t let anyone test password guesses afterwards."
      });
    } else if (i) {
      s.field("Send-confirm", "1", () => s.u16le(1));
      s.field("Confirm", "32 bytes", () => s.unknown(32), {
        hidden: true,
        note: "Proves this side worked out the same key, without giving it away."
      });
    }
  } else if (e.kind === "assoc-req") {
    r(true);
    s.field("Listen interval", "10 beacons", () => s.u16le(10), {
      note: "How often the laptop wakes to check for waiting frames when saving power.",
      example: true
    });
    n();
    o();
    ml(s, e.akm);
    a("What the laptop’s radio can do (Wi-Fi 4, 5 and 6), and vendor extras.");
  } else if (e.kind === "assoc-resp") {
    r(false);
    s.field("Status", "0 (success)", () => s.u16le(0));
    s.field("Association ID", "1", () => s.u16le(49153), {
      note: "The laptop’s number at this access point (the top two bits are always set).",
      example: true
    });
    o();
    a("The settings the access point uses (Wi-Fi 4, 5 and 6), and vendor extras.");
  }
  return s;
}
function Gg(e) {
  const t = new R("llc", "LLC/SNAP · 8 bytes");
  t.field("LLC", "AA AA 03 (SNAP)", () => t.raw([170, 170, 3]));
  t.field("Organization", "00 00 00", () => t.raw([0, 0, 0]));
  t.field("Type", "0x888e (802.1X authentication)", () => t.u16(34958), {
    note: "What follows: plays the part an Ethernet type field does on a cable."
  });
  if (e.eap) {
    const p = Bu(e.eap);
    const u = new R("eapol", "EAPOL · 4 bytes");
    u.field("Version", e.from === "ap" ? "2" : "1", () => u.u8(e.from === "ap" ? 2 : 1), {
      example: true
    });
    u.field("Type", "0 (EAP packet)", () => u.u8(0), {
      note: "Carries an EAP message. The access point copies it into a RADIUS packet for the server, and back."
    });
    u.field("Length", `${p.length} bytes`, () => u.u16(p.length));
    return [t, u, p];
  }
  const s = e.msg;
  const n = s === 1 || s === 3;
  const a = (e.sae ? 0 : 2) | 8 | (s === 3 ? 64 : 0) | (n ? 128 : 0) | (s > 1 ? 256 : 0) | (s > 2 ? 512 : 0) | (s === 3 ? 4096 : 0);
  const r = ["pairwise", s === 3 && "install", n && "ACK", s > 1 && "MIC", s > 2 && "secure", s === 3 && "key data encrypted"].filter(Boolean);
  const i = s === 2 ? 22 : s === 3 ? e.keyData : 0;
  const c = 95 + i;
  const d = new R("eapol", `EAPOL-Key · message ${s} of 4`);
  d.field("Version", n ? "2" : "1", () => d.u8(n ? 2 : 1), {
    example: true
  });
  d.field("Type", "3 (Key)", () => d.u8(3));
  d.field("Length", `${c} bytes`, () => d.u16(c));
  d.field("Descriptor type", "2 (RSN)", () => d.u8(2));
  d.field("Key information", `${_(a)}: ${r.join(", ")}`, () => d.u16(a), {
    note: ["", "ACK: the laptop must answer.", "MIC: this message carries a check value.", "Install: start using the keys. The group key comes encrypted.", "Secure: the keys are in place."][s]
  });
  d.field("Key length", n ? "16 bytes" : "0", () => d.u16(n ? 16 : 0), {
    note: n ? "The pairwise key is 16 bytes (AES-128)." : undefined
  });
  d.field("Replay counter", s < 3 ? 1 : 2, () => d.u64(s < 3 ? 1 : 2), {
    note: "Counts up with each message from the access point; an old one sent again is ignored."
  });
  if (s === 4) {
    d.field("Nonce", "zeros", () => d.raw(Array(32).fill(0)));
  } else {
    d.field(n ? "ANonce" : "SNonce", "32 random bytes", () => d.unknown(32), {
      hidden: true,
      note: n ? "A random number from the access point." : "A random number from the laptop. From both numbers, both MAC addresses and the key that comes from the password, each side works out the same session keys."
    });
  }
  d.field("Key IV", "zeros", () => d.raw(Array(16).fill(0)));
  d.field("Key RSC", "zeros", () => d.raw(Array(8).fill(0)), {
    note: s === 3 ? "Where the group key’s packet numbers start." : undefined
  });
  d.field("Reserved", "zeros", () => d.raw(Array(8).fill(0)));
  if (s === 1) {
    d.field("MIC", "zeros", () => d.raw(Array(16).fill(0)), {
      note: "No keys yet, so nothing to check with."
    });
  } else {
    d.field("MIC", "16 bytes", () => d.unknown(16), {
      hidden: true,
      note: "Worked out with the new keys: it proves the sender knows the password, and that the message wasn’t changed."
    });
  }
  d.field("Key data length", `${i} bytes`, () => d.u16(i));
  if (s === 2) {
    ml(d, e.akm ?? (e.sae ? 8 : 2));
  }
  if (s === 3) {
    d.field("Key data", `${i} bytes`, () => d.unknown(i), {
      hidden: true,
      note: "Encrypted with a key from the handshake."
    });
    Ot(d, ["The access point’s RSN element", "GTK: the group key, for broadcasts", ...(e.sae ? ["IGTK: the key that signs broadcast management frames"] : [])]);
  }
  return [t, d];
}
function Wg(e, t) {
  const s = t.from === "sta";
  const n = Kg[t.kind];
  const [o, a] = n ?? [136, "QoS Data"];
  const r = t.kind === "beacon" || t.kind === "probe-req" ? pe.all : s ? Ko : pe.laptop;
  const i = s ? pe.laptop : Ko;
  const c = t.kind === "data";
  const d = n ? 0 : (s ? 1 : 2) | (c ? 64 : 0);
  const p = new R("wlan", "");
  p.field("Frame type", `${n ? "Management" : "Data"}, ${a}`, () => p.u8(o));
  p.field("Flags", d ? `${_(d, 2)} (${[c && "protected", s ? "to the access point" : "from the access point"].filter(Boolean).join(", ")})` : "0x00", () => p.u8(d), {
    note: c ? "Protected: what follows the header is encrypted." : undefined
  });
  p.field("Duration", `${t.duration ?? 0} µs`, () => p.u16le(t.duration ?? 0), {
    note: t.duration ? "How long the channel stays booked for this exchange; other devices wait." : "Nobody acknowledges a broadcast, so nothing is booked.",
    example: !!t.duration
  });
  const u = (T, m, w) => p.field(T, m, () => p.raw(ts(m)), {
    note: w,
    example: m !== pe.all
  });
  u("Receiver", r, r === pe.all ? "Broadcast: every device in range listens." : "The radio this frame is for.");
  u("Transmitter", i, s ? "The laptop’s Wi-Fi card." : "The access point.");
  if (n) {
    u("BSSID", Ko, "The access point’s own address: which network this is about.");
  } else if (s) {
    u("Destination", t.dst ?? Ko, t.dst === pe.all ? "Where the access point should pass it on to: everyone on the network." : "The access point itself.");
  } else {
    u("Source", Ko, "Sent by the access point itself.");
  }
  p.field("Sequence number", t.seq, () => p.u16le(t.seq << 4), {
    note: "Lets the receiver spot a repeat when a frame is sent again.",
    example: true
  });
  if (!n) {
    p.field("QoS control", `TID ${t.tid ?? 7}`, () => p.u16le(t.tid ?? 7), {
      note: t.tid === undefined ? "Priority 7, the highest: the handshake goes first." : undefined,
      example: true
    });
  }
  p.name = `802.11 · ${p.length} bytes`;
  p.summary = `${i} → ${r}`;
  const y = [p];
  if (n) {
    y.push(_g(t, a));
  } else if (t.kind === "eapol") {
    y.push(...Gg(t));
  } else {
    const T = new R("ccmp", "CCMP · encrypted");
    T.field("CCMP header", `packet number ${t.pn}, key 0`, () => T.raw([t.pn & 255, t.pn >> 8 & 255, 0, 32, 0, 0, 0, 0]), {
      note: "Counts up with every frame; one seen before is thrown away."
    });
    T.field("Encrypted data", `${t.sealed} bytes`, () => T.unknown(t.sealed), {
      hidden: true
    });
    Ot(T, t.inner);
    T.field("MIC", "8 bytes", () => T.unknown(8), {
      hidden: true,
      note: "Shows any change to the frame."
    });
    y.push(T);
  }
  return {
    index: e,
    at: "Seen over the air, on Wi-Fi channel 36",
    ...Rr(y),
    wifi: true,
    segments: 1,
    tcp: null,
    messageLength: null
  };
}
const jh = {
  133: "Router Solicitation",
  134: "Router Advertisement",
  135: "Neighbor Solicitation",
  136: "Neighbor Advertisement"
};
const Vg = {
  "::": "Unspecified: the laptop has no address it may use yet.",
  "ff02::1": "Every device on this network.",
  "ff02::2": "Every router on this network."
};
const zh = e => Vg[e] ?? (e.startsWith("ff02::1:ff") ? "Solicited-node multicast: only devices whose address ends in the same 24 bits are listening." : e.startsWith("fe80:") ? "A link-local address: usable only on this network." : undefined);
function Yg(e, t) {
  if (t.mac) {
    e.field(t.type === 1 ? "Source link-layer address" : "Target link-layer address", t.mac, () => e.u8(t.type).u8(1).raw(ts(t.mac)), {
      note: t.type === 1 ? "The sender’s MAC address, so nobody has to ask for it." : "The answer: the MAC address that goes with the target.",
      example: true
    });
  } else if (t.type === 3) {
    e.field("Prefix", `${t.prefix}/64, valid ${t.valid.toLocaleString("en-US")} s, preferred ${t.preferred.toLocaleString("en-US")} s`, () => e.u8(3).u8(4).u8(64).u8(192).u32(t.valid).u32(t.preferred).u32(0).raw(es(t.prefix)), {
      note: "Flags L and A: addresses in this prefix are on this network, and devices may make their own (SLAAC)."
    });
  } else if (t.type === 5) {
    e.field("MTU", `${t.mtu} bytes`, () => e.u8(5).u8(1).u16(0).u32(t.mtu), {
      note: "The largest packet this network carries."
    });
  } else if (t.type === 25) {
    e.field("DNS server", `${t.dns}, for ${t.lifetime.toLocaleString("en-US")} s`, () => e.u8(25).u8(3).u16(0).u32(t.lifetime).raw(es(t.dns)), {
      note: "Recursive DNS server: which resolver to ask, so no DHCP is needed for that either."
    });
  }
}
function jg(e, t) {
  const s = t.dst.startsWith("ff");
  const n = s ? `33:33:${es(t.dst).slice(12).map(p => p.toString(16).padStart(2, "0")).join(":")}` : t.ethDst;
  const o = new R("eth", "Ethernet II · 14 bytes");
  o.summary = `${t.ethSrc} → ${n}`;
  o.field("Destination", n, () => o.raw(ts(n)), {
    note: s ? "A multicast MAC address: 33:33, then the last four bytes of the IPv6 address." : "The device this frame is for.",
    example: !s
  });
  o.field("Source", t.ethSrc, () => o.raw(ts(t.ethSrc)), {
    note: "The sender’s network card.",
    example: true
  });
  o.field("Type", "0x86dd (IPv6)", () => o.u16(34525), {
    note: "What the frame carries."
  });
  const a = t.icmp;
  const r = new R("icmp6", `ICMPv6 · ${jh[a.type]}`);
  r.field("Type", `${a.type} (${jh[a.type]})`, () => r.u8(a.type));
  r.field("Code", "0", () => r.u8(0));
  const i = r.length;
  r.field("Checksum", "", () => r.u16(0), {
    note: "Covers the message and both IPv6 addresses."
  });
  if (a.type === 133) {
    r.field("Reserved", "0", () => r.u32(0));
  }
  if (a.type === 134) {
    r.field("Hop limit", "64", () => r.u8(64), {
      note: "The hop limit devices here should put on their packets."
    });
    r.field("Flags", "0x00: M 0, O 0", () => r.u8(0), {
      note: "M: take addresses from DHCPv6. O: take other settings from DHCPv6. Both off: this advertisement has everything."
    });
    r.field("Router lifetime", "1,800 s", () => r.u16(1800), {
      note: "How long the laptop may use this router as its way out."
    });
    r.field("Reachable time", "0 (not set)", () => r.u32(0));
    r.field("Retransmit timer", "0 (not set)", () => r.u32(0));
  }
  if (a.type === 135) {
    r.field("Reserved", "0", () => r.u32(0));
    r.field("Target", a.target, () => r.raw(es(a.target)), {
      note: a.dad ? "The address the laptop wants to use. If anyone answers, it’s taken." : "Whose MAC address is wanted."
    });
  }
  if (a.type === 136) {
    r.field("Flags", "0x60000000: solicited, override", () => r.u32(1610612736), {
      note: "Solicited: this answers a question. Override: replace any older entry for this address."
    });
    r.field("Target", a.target, () => r.raw(es(a.target)));
  }
  for (const p of a.options ?? []) {
    Yg(r, p);
  }
  const c = new R("ip6", "IPv6 · 40 bytes");
  c.summary = `${t.src} → ${t.dst}`;
  c.field("Version, class, flow", "6, 0, 0", () => c.u32(1610612736), {
    note: "IPv6, ordinary traffic, no flow label."
  });
  c.field("Payload length", `${r.length} bytes`, () => c.u16(r.length), {
    note: "What follows this 40-byte header."
  });
  c.field("Next header", "58 (ICMPv6)", () => c.u8(58));
  c.field("Hop limit", "255", () => c.u8(255), {
    note: "Neighbour discovery must arrive with 255, proof that no router passed it on: it came from this network."
  });
  c.field("Source", t.src, () => c.raw(es(t.src)), {
    note: zh(t.src)
  });
  c.field("Destination", t.dst, () => c.raw(es(t.dst)), {
    note: zh(t.dst)
  });
  const d = pn([...es(t.src), ...es(t.dst), 0, 0, r.length >> 8, r.length & 255, 0, 0, 0, 58, ...r.bytes]);
  r.bytes[i] = d >> 8;
  r.bytes[i + 1] = d & 255;
  r.fields.find(p => p.name === "Checksum").value = _(d);
  return {
    index: e,
    at: "Seen on the laptop’s home network",
    ...Rr([o, c, r]),
    ipLength: 40 + r.length,
    segments: 1,
    tcp: null,
    messageLength: null
  };
}
const zg = [["F", 1, "FIN"], ["S", 2, "SYN"], ["R", 4, "RST"], ["P", 8, "PSH"], ["A", 16, "ACK"]];
function Qg(e) {
  const t = zg.filter(([s]) => e.includes(s));
  return {
    bits: t.reduce((s, [, n]) => s | n, 0),
    names: t.map(([,, s]) => s).join(", ")
  };
}
const Qh = (e, t, s, n) => [...Ee(e), ...Ee(t), 0, s, n >> 8, n & 255];
class Xg {
  constructor(t) {
    this.lesson = t;
    this.alias = new Map();
    this.ids = new Map();
    this.conns = new Map();
    this.pending = [];
    this.remote = new Map();
    this.built = [];
  }
  ipId(t) {
    if (!this.ids.has(t)) {
      this.ids.set(t, kr(`id ${t}`) & 65535);
    }
    const s = this.ids.get(t);
    this.ids.set(t, s + 1 & 65535);
    return s;
  }
  endpointMac(t, s) {
    if (!this.remote.has(t)) {
      this.remote.set(t, this.remote.size);
    }
    const n = this.remote.get(t);
    return `00:00:5e:00:53:${(s ? 128 + n : 64 + n).toString(16)}`;
  }
  link(t) {
    const {
      src: s,
      dst: n
    } = t;
    if (to(s) || to(n)) {
      const o = n === "255.255.255.255" || n === "Broadcast";
      const a = Ri[s] ?? Ri[Or];
      const r = Ri[n];
      return {
        at: this.lesson.seenOn ?? "Seen on the laptop’s home network",
        src: a[0],
        dst: o ? pe.all : r ? r[0] : pe.lan,
        srcNote: a[1],
        dstNote: o ? "Broadcast: every device on the network receives it." : r ? r[2] : "The router: anything beyond the home network goes to it first."
      };
    }
    if (s === Ah) {
      return {
        at: "Seen as it leaves the router’s internet side",
        src: pe.wan,
        dst: pe.isp,
        srcNote: "The router’s internet-facing port.",
        dstNote: "The internet provider’s router, the next hop."
      };
    } else if (s === Vw) {
      return {
        at: "Seen as it leaves their router’s internet side",
        src: this.endpointMac(s),
        dst: this.endpointMac(s, true),
        srcNote: "Their router’s internet-facing port.",
        dstNote: "Their internet provider’s router, the next hop."
      };
    } else {
      return {
        at: `Seen as it leaves ${s}`,
        src: this.endpointMac(s),
        dst: this.endpointMac(s, true),
        srcNote: "The sender’s network card.",
        dstNote: "The sender’s next router; each hop puts the packet in a new frame."
      };
    }
  }
  ttl(t, s) {
    if (s.ttl !== undefined) {
      return s.ttl;
    } else if (to(t.dst) && !to(t.src)) {
      return pr(t.src) - Ni(t.src);
    } else {
      return pr(t.src);
    }
  }
  conn(t, s) {
    const n = u => this.alias.get(u) ?? u;
    const o = n(`${t.src}:${s.sport}`);
    const a = n(`${t.dst}:${s.dport}`);
    const r = [o, a].sort().join(" ");
    if (!this.conns.has(r)) {
      this.conns.set(r, {
        key: r,
        ends: {},
        ts: false
      });
    }
    const i = this.conns.get(r);
    const c = !i.ends[o];
    for (const [u, y] of [[o, o.split(":")[0]], [a, a.split(":")[0]]]) {
      i.ends[u] ??= {
        ip: y,
        isn: kr(`isn ${r} ${u}`),
        next: 0,
        got: 0,
        ooo: [],
        tsBase: kr(`ts ${u}`) % 4000000000,
        peerTs: 0,
        win: aa(y) ? [1026, 8] : [501, 7]
      };
    }
    const d = i.ends[o];
    const p = i.ends[a];
    if (c && s.opened) {
      const [u, y] = s.opened.bytes;
      d.next = p.got = u;
      p.next = d.got = y;
      i.ts = !!s.opened.ts;
      if (i.ts) {
        [d.peerTs, p.peerTs] = [p.tsBase, d.tsBase];
      }
    }
    return {
      c: i,
      me: d,
      peer: p,
      meKey: o,
      peerKey: a
    };
  }
  deliver(t) {
    this.pending = this.pending.filter(s => {
      if (s.at > t + 1e-9) {
        return true;
      }
      const n = s.to;
      if (s.seq === n.got) {
        n.got += s.len;
        n.ooo.sort((o, a) => o[0] - a[0]);
        while (n.ooo.length && n.ooo[0][0] <= n.got) {
          n.got = Math.max(n.got, n.ooo.shift()[1]);
        }
      } else if (s.seq > n.got) {
        n.ooo.push([s.seq, s.seq + s.len]);
      }
      if (s.tsval) {
        n.peerTs = s.tsval;
      }
      return false;
    });
  }
  tcp(t, s, n, o, a, r) {
    const {
      c: i,
      me: c,
      peer: d
    } = this.conn(t, s);
    const {
      bits: p,
      names: u
    } = Qg(s.flags);
    const y = p & 2;
    const T = p & 1;
    const m = p & 16;
    const w = n ? n.length : 0;
    const k = aa(c.ip);
    if (y && !m) {
      i.ts = !k;
    }
    const A = [];
    const N = Math.round(o * 1000);
    const L = c.tsBase + N >>> 0;
    const Q = s.mss ?? 1460;
    if (y && !m && k) {
      A.push(["MSS", Q], ["NOP"], ["WS", 8], ["NOP"], ["NOP"], ["SACKP"]);
    } else if (y && !m) {
      A.push(["MSS", Q], ["SACKP"], ["TS", L, 0], ["NOP"], ["WS", 7]);
    } else if (y) {
      A.push(...(i.ts ? [["MSS", 1460], ["SACKP"], ["TS", L, c.peerTs], ["NOP"], ["WS", 7]] : [["MSS", 1460], ["NOP"], ["NOP"], ["SACKP"], ["NOP"], ["WS", 7]]));
    } else if (i.ts) {
      A.push(["NOP"], ["NOP"], ["TS", L, c.peerTs]);
    }
    if (s.sack) {
      const ue = d && c.ooo.map(([H, Le]) => [H, Le]);
      A.push(["NOP"], ["NOP"], ["SACK", ue]);
    }
    const ne = i.ts ? xh - 12 : xh;
    const be = Math.min(w, ne);
    const O = s.seq ?? c.next;
    const Z = m ? s.ack ?? c.got : 0;
    if (s.seq === undefined) {
      c.next += w + (y ? 1 : 0) + (T ? 1 : 0);
    }
    if (!a.lost) {
      this.pending.push({
        at: o + Ru(this.lesson, a.from, a.to),
        to: d,
        seq: O,
        len: w + (y ? 1 : 0) + (T ? 1 : 0),
        tsval: i.ts ? L : 0
      });
    }
    const v = new R("tcp", "");
    const Ue = A.reduce((ue, [H, Le]) => ue + {
      NOP: 1,
      MSS: 4,
      WS: 3,
      SACKP: 2,
      TS: 10,
      SACK: 2 + (H === "SACK" ? Le.length : 0) * 8
    }[H], 0);
    const De = 20 + Ue;
    v.summary = `${s.sport} → ${s.dport}, ${u}`;
    v.name = `TCP · ${De} bytes`;
    v.field("Source port", s.sport, () => v.u16(s.sport), {
      note: k ? t.src === Ah ? "The router’s NAT swapped in its own port for the laptop’s." : "Picked by the laptop’s system for this connection." : undefined
    });
    v.field("Destination port", s.dport, () => v.u16(s.dport));
    v.field("Sequence number", y ? "0 (relative)" : `${O} (relative)`, () => v.u32(c.isn + O >>> 0), {
      note: y ? "This side’s starting number. Shown as 0; the real one is random." : "Position of this segment’s first byte, counted from this side’s SYN."
    });
    v.field("Real sequence number", c.isn + O >>> 0, () => {}, {
      depth: 1,
      example: true
    });
    v.field("Acknowledgment", m ? `${Z} (relative)` : "0 (not used yet)", () => v.u32(m ? d.isn + Z >>> 0 : 0), {
      note: m ? "The next byte this side expects: everything before it has arrived." : "A first SYN has nothing to acknowledge."
    });
    v.field("Header length", `${De} bytes`, () => v.u8(De / 4 << 4), {
      note: Ue ? `20 bytes, plus ${Ue} of options.` : undefined
    });
    v.field("Flags", `${_(p, 3)} (${u})`, () => v.u8(p));
    const Ke = c.win[1];
    const B = y ? m && i.ts ? 65160 : 64240 : c.win[0];
    v.field("Window", y ? `${B}` : `${B} (× ${2 ** Ke} = ${(B * 2 ** Ke).toLocaleString("en-US")} bytes)`, () => v.u16(B), {
      note: "How much more data this side can take right now.",
      example: true
    });
    const J = v.length;
    v.field("Checksum", "", () => v.u16(0), {
      note: "Covers the header, the data and the IP addresses, so damage is caught."
    });
    v.field("Urgent pointer", "0", () => v.u16(0));
    if (A.length) {
      v.field("Options", `${Ue} bytes`, () => {}, {
        heading: true
      });
      for (const [ue, H, Le] of A) {
        if (ue === "NOP") {
          v.field("No-op", "1", () => v.u8(1), {
            depth: 1,
            note: "Spacing, so the next option lines up."
          });
        }
        if (ue === "MSS") {
          v.field("Maximum segment size", `${H} bytes`, () => v.u8(2).u8(4).u16(H), {
            depth: 1,
            note: s.mssNote ?? "The most data this side wants in one segment."
          });
        }
        if (ue === "WS") {
          v.field("Window scale", `× ${2 ** H}`, () => v.u8(3).u8(3).u8(H), {
            depth: 1,
            note: "Window values are multiplied by this, so windows can be larger than 64 KB."
          });
        }
        if (ue === "SACKP") {
          v.field("SACK permitted", "yes", () => v.u8(4).u8(2), {
            depth: 1,
            note: "This side understands selective acknowledgements."
          });
        }
        if (ue === "TS") {
          v.field("Timestamps", `value ${H}, echo ${Le}`, () => v.u8(8).u8(10).u32(H).u32(Le), {
            depth: 1,
            note: "Used to measure round trips; both sides offered them.",
            example: true
          });
        }
        if (ue === "SACK") {
          v.field("SACK", H.map(([Be, At]) => `has ${Be}–${At - 1}`).join(", "), () => {
            v.u8(5).u8(2 + H.length * 8);
            for (const [Be, At] of H) {
              v.u32(d.isn + Be >>> 0).u32(d.isn + At >>> 0);
            }
          }, {
            depth: 1,
            note: "Bytes that arrived after the gap, so only the gap needs resending."
          });
        }
      }
    }
    const lt = n ? n.bytes.slice(0, be) : [];
    const $ = pn([...Qh(t.src, t.dst, 6, De + be), ...v.bytes, ...lt]);
    const D = v.fields.find(ue => ue.name === "Checksum");
    if ($ === null) {
      v.bytes[J] = v.bytes[J + 1] = null;
      D.value = "covers bytes not shown here";
      D.hidden = true;
    } else {
      v.bytes[J] = $ >> 8;
      v.bytes[J + 1] = $ & 255;
      D.value = _($);
    }
    return {
      header: v,
      first: be,
      segments: Math.max(1, r ?? Math.ceil(w / ne)),
      mss: ne,
      seq: O,
      ack: Z,
      hlen: De
    };
  }
  frame(t, s, n) {
    const o = t.row;
    const a = o.wire;
    if (!a) {
      return null;
    }
    if (a.copyOf !== undefined) {
      const L = this.built[s + a.copyOf];
      return this.built[s] = {
        ...L,
        index: s,
        at: a.at ?? L.at
      };
    }
    if (a.wifi) {
      return this.built[s] = Wg(s, a.wifi);
    }
    if (a.ipv6) {
      return this.built[s] = jg(s, a.ipv6);
    }
    const r = parseFloat(o.time);
    this.deliver(r);
    if (a.alias) {
      this.alias.set(a.alias[0], a.alias[1]);
    }
    const i = a.pppoe && !a.pppoe.ip;
    const c = i ? {
      at: this.lesson.seenOn ?? "Seen on the router’s line to the provider",
      src: o.src,
      dst: o.dst === "Broadcast" ? pe.all : o.dst,
      srcNote: o.src === pe.wan ? "The router’s internet-facing port." : "The access server’s port.",
      dstNote: o.dst === "Broadcast" ? "Broadcast: everything on the line receives it." : o.dst === pe.wan ? "The router’s internet-facing port." : "The access server that answered."
    } : a.arp ? {
      at: "Seen on the laptop’s home network",
      src: o.src,
      dst: o.dst === "Broadcast" ? pe.all : o.dst,
      srcNote: "The sender’s network card.",
      dstNote: o.dst === "Broadcast" ? "Broadcast: every device on the network receives it." : "Straight back to the device that asked."
    } : this.link(o);
    if (a.link) {
      Object.assign(c, a.link);
    }
    if (Eh(o.dst)) {
      c.dst = Yw(o.dst);
      c.dstNote = "Multicast: 01:00:5e, then the last 23 bits of the group address. Network cards listen for the groups their system has joined.";
    }
    const d = [];
    const p = new R("eth", "Ethernet II · 14 bytes");
    p.summary = `${c.src} → ${c.dst}`;
    p.field("Destination", c.dst, () => p.raw(ts(c.dst)), {
      note: c.dstNote,
      example: c.dst !== pe.all
    });
    p.field("Source", c.src, () => p.raw(ts(c.src)), {
      note: c.srcNote,
      example: true
    });
    const [u, y] = a.arp ? [2054, "ARP"] : a.pppoe ? a.pppoe.code ? [34915, "PPPoE discovery"] : [34916, "PPPoE session"] : [2048, "IPv4"];
    p.field("Type", `${_(u)} (${y})`, () => p.u16(u), {
      note: "What the frame carries."
    });
    d.push(p);
    let T = 1;
    let m = null;
    let w;
    if (a.arp) {
      const L = new R("arp", `ARP ${a.arp.op === 1 ? "request" : "reply"} · 28 bytes`);
      L.field("Hardware type", "1 (Ethernet)", () => L.u16(1));
      L.field("Protocol type", "0x0800 (IPv4)", () => L.u16(2048));
      L.field("Address sizes", "6 (MAC), 4 (IPv4)", () => L.u8(6).u8(4));
      L.field("Operation", a.arp.op === 1 ? "1 (request: who has …?)" : "2 (reply: … is at …)", () => L.u16(a.arp.op));
      L.field("Sender MAC", a.arp.sender[0], () => L.raw(ts(a.arp.sender[0])), {
        example: true
      });
      L.field("Sender IP", a.arp.sender[1], () => L.raw(Ee(a.arp.sender[1])));
      L.field("Target MAC", a.arp.target[0], () => L.raw(ts(a.arp.target[0])), {
        note: a.arp.op === 1 ? "All zeros: this is what the request wants to find out." : undefined,
        example: a.arp.op === 2
      });
      L.field("Target IP", a.arp.target[1], () => L.raw(Ee(a.arp.target[1])));
      d.push(L);
    } else if (i) {
      if (a.pppoe.code) {
        d.push(Eg(a.pppoe));
      } else {
        const L = Wh(a.pppoe);
        d.push(fl(a.pppoe, L.length, "PPPoE · 6 bytes"), L);
      }
    } else {
      const L = a.tcp ? 6 : a.udp ? 17 : a.igmp ? 2 : 1;
      const Q = [];
      let ne;
      if (a.tcp) {
        const $ = a.tcp.data ? $h(o, a.tcp.data) : null;
        m = this.tcp(o, a.tcp, $, r, t, a.tcp.segments);
        T = m.segments;
        ne = m.header;
        Q.push(ne);
        if ($) {
          $.full = $.length;
          if (m.first < $.length) {
            $.bytes = $.bytes.slice(0, m.first);
            $.cut = true;
          }
          Q.push($);
        }
      } else if (a.udp) {
        const $ = $h(o, a.udp.data);
        const D = new R("udp", "UDP · 8 bytes");
        const ue = 8 + $.length;
        D.summary = `${a.udp.sport} → ${a.udp.dport}`;
        D.field("Source port", a.udp.sport, () => D.u16(a.udp.sport));
        D.field("Destination port", a.udp.dport, () => D.u16(a.udp.dport));
        D.field("Length", `${ue} bytes`, () => D.u16(ue), {
          note: "UDP header and data. That is all of UDP: no numbering, no acknowledgements."
        });
        const H = pn([...Qh(o.src, o.dst, 17, ue), ...D.bytes, 0, 0, ...$.bytes]);
        if (a.udp.noChecksum) {
          D.field("Checksum", "0 (not used)", () => D.u16(0), {
            note: "ESP checks its own contents, so ESP carried in UDP leaves this at zero."
          });
        } else {
          D.field("Checksum", H === null ? "covers bytes not shown here" : _(H || 65535), () => H === null ? D.unknown(2) : D.u16(H || 65535), {
            note: "Covers the header, the data and the IP addresses.",
            hidden: H === null
          });
        }
        Q.push(D, $);
      } else if (a.igmp) {
        const $ = a.igmp;
        const D = {
          17: "Membership Query",
          22: "Membership Report",
          23: "Leave Group"
        };
        const ue = {
          17: $.group === "0.0.0.0" ? "The router asks: which groups does anyone here still want?" : "The router asks: does anyone still want this group?",
          22: "This device wants the group’s traffic.",
          23: "This device no longer wants the group."
        };
        const H = new R("igmp", `IGMPv2 · ${D[$.type]}`);
        H.summary = `${D[$.type]}${$.group !== "0.0.0.0" ? ` ${$.group}` : ""}`;
        H.field("Type", `${_($.type, 2)} (${D[$.type]})`, () => H.u8($.type), {
          note: ue[$.type]
        });
        H.field("Max response time", $.type === 17 ? `${$.maxResp / 10} s` : "0", () => H.u8($.type === 17 ? $.maxResp : 0), {
          note: $.type === 17 ? "Members answer at a random moment within this time, so their answers don’t all arrive at once." : "Only queries use it."
        });
        const Le = H.length;
        H.field("Checksum", "", () => H.u16(0), {
          note: "Covers the IGMP message."
        });
        H.field("Group address", $.group, () => H.raw(Ee($.group)), {
          note: $.group === "0.0.0.0" ? "Zero in a general query: every group." : "The multicast group: one TV channel."
        });
        const Be = pn(H.bytes);
        H.bytes[Le] = Be >> 8;
        H.bytes[Le + 1] = Be & 255;
        H.fields.find(At => At.name === "Checksum").value = _(Be);
        Q.push(H);
      } else if (a.icmp) {
        const $ = a.icmp;
        const D = new R("icmp", "");
        const ue = {
          "8,0": "Echo request",
          "0,0": "Echo reply",
          "11,0": "Time exceeded (TTL reached 0)",
          "3,3": "Destination unreachable (port unreachable)"
        };
        D.field("Type", `${$.type}`, () => D.u8($.type), {
          note: ue[`${$.type},${$.code}`]
        });
        D.field("Code", `${$.code}`, () => D.u8($.code));
        const H = D.length;
        D.field("Checksum", "", () => D.u16(0), {
          note: "Covers the whole ICMP message."
        });
        if ($.type === 8 || $.type === 0) {
          D.field("Identifier", _($.id), () => D.u16($.id), {
            note: "Matches replies to this ping program."
          });
          D.field("Sequence number", $.seq, () => D.u16($.seq), {
            note: "Windows counts up across every ping it sends."
          });
          D.field("Data", `"${$.data}" (${$.data.length} bytes)`, () => D.ascii($.data), {
            note: $.type === 8 ? "Windows ping’s filler: the alphabet, a to w, then again." : "Sent back exactly as it came.",
            mono: true
          });
        } else {
          D.field("Unused", "0", () => D.u32(0));
          const Be = this.built[s + $.quote];
          const At = 14;
          const vo = Be.bytes.slice(At, At + (Be.ipLength ?? Be.bytes.length - At));
          const Et = vo.slice(0, $.quoteBytes === 8 ? 28 : vo.length);
          Et[8] = $.ttl;
          Et[10] = Et[11] = 0;
          const Ys = pn(Et.slice(0, 20));
          Et[10] = Ys >> 8;
          Et[11] = Ys & 255;
          D.field("Original packet", $.quoteBytes === 8 ? "its IP header and first 8 bytes (28 bytes)" : `all ${Et.length} bytes of it`, () => D.raw(Et), {
            note: `The packet that caused this, as the reporting device received it (TTL ${$.ttl}), so the sender can tell which packet it was.`
          });
          D.field("Its source, destination", `${o.dst} → ${n[s + $.quote].row.dst}`, () => {}, {
            depth: 1
          });
        }
        const Le = pn(D.bytes);
        D.bytes[H] = Le >> 8;
        D.bytes[H + 1] = Le & 255;
        D.fields.find(Be => Be.name === "Checksum").value = _(Le);
        D.name = `ICMP · ${ue[`${$.type},${$.code}`]}`;
        Q.push(D);
      }
      const be = Q.reduce(($, D) => $ + D.length, 0);
      const O = a.routerAlert ? 24 : 20;
      const Z = O + be;
      const v = new R("ip", `IPv4 · ${O} bytes`);
      const Ue = this.ttl(o, a);
      const De = a.tcp ? true : a.df ?? (!aa(o.src) && !!a.udp && o.src !== Zl && o.src !== Or);
      const Ke = a.natOf !== undefined ? this.built[s + a.natOf].ipId : this.ipId(o.src);
      const B = a.ttlNote ?? (aa(o.src) ? `Windows starts at 128.${Ue !== 128 ? ` Set to ${Ue} on purpose here.` : ""}` : to(o.dst) && !to(o.src) ? `Started at ${pr(o.src)}; ${Ni(o.src)} router${Ni(o.src) === 1 ? "" : "s"} on the way each took 1.` : `As sent: this system starts at ${pr(o.src)}.`);
      v.summary = `${o.src} → ${o.dst}`;
      v.field("Version, header length", `4, ${O} bytes`, () => v.u8(O / 4 | 64), {
        note: a.routerAlert ? "IPv4, with one 4-byte option." : "IPv4, with no options."
      });
      if (a.tos) {
        v.field("DSCP, ECN", `${a.tos >> 2} (network control), 0`, () => v.u8(a.tos), {
          note: "Marked as network control, so it is sent ahead of ordinary traffic."
        });
      } else {
        v.field("DSCP, ECN", "0, 0", () => v.u8(0), {
          note: "Priority and congestion marks; 0 means ordinary traffic."
        });
      }
      v.field("Total length", `${Z} bytes`, () => v.u16(Z), {
        note: "This header and everything inside it."
      });
      v.field("Identification", _(Ke), () => v.u16(Ke), {
        note: "Lets the receiver reassemble the pieces if the packet gets split.",
        example: true
      });
      v.field("Flags", De ? "DF (don’t fragment)" : "none", () => v.u16(De ? 16384 : 0), {
        note: De ? "Routers must not split it; if it’s too big they report back instead." : "Routers may split it if a link is too small.",
        example: !a.tcp
      });
      v.field("Time to live", Ue, () => v.u8(Ue), {
        note: B,
        example: o.src === Xl
      });
      v.field("Protocol", {
        6: "6 (TCP)",
        17: "17 (UDP)",
        2: "2 (IGMP)",
        1: "1 (ICMP)"
      }[L], () => v.u8(L));
      const J = v.length;
      v.field("Header checksum", "", () => v.u16(0), {
        note: "Covers this header only; every router recomputes it after lowering the TTL."
      });
      v.field("Source", o.src, () => v.raw(Ee(o.src)));
      v.field("Destination", o.dst, () => v.raw(Ee(o.dst)), Eh(o.dst) ? {
        note: "A multicast group address."
      } : undefined);
      if (a.routerAlert) {
        v.field("Router Alert option", "0x94040000", () => v.u32(2483290112), {
          note: "Asks every router on the way to look inside, though the packet isn’t addressed to it."
        });
      }
      const lt = pn(v.bytes);
      v.bytes[J] = lt >> 8;
      v.bytes[J + 1] = lt & 255;
      v.fields.find($ => $.name === "Header checksum").value = _(lt);
      if (a.pppoe) {
        d.push(fl(a.pppoe, 2 + Z, "PPPoE · 6 bytes"), Wh(a.pppoe));
      }
      d.push(v, ...Q);
      w = Ke;
    }
    const k = Rr(d);
    const A = a.arp || i ? undefined : k.bytes.length - 14 - (a.pppoe ? 8 : 0);
    if (k.bytes.length < 60) {
      const L = new R("pad", `Ethernet padding · ${60 - k.bytes.length} bytes`);
      const Q = 60 - k.bytes.length;
      L.field("Padding", `${Q} zero bytes`, () => L.raw(Array(Q).fill(0)), {
        note: "Ethernet frames are at least 60 bytes (64 with the checksum the card adds), so short ones are padded."
      });
      const ne = Rr([L]);
      k.layers.push({
        ...ne.layers[0],
        from: k.bytes.length,
        to: 60
      });
      for (const be of ne.fields) {
        k.fields.push({
          ...be,
          from: be.from + k.bytes.length,
          to: be.to + k.bytes.length
        });
      }
      k.bytes.push(...ne.bytes);
    }
    const N = {
      index: s,
      at: a.at ?? c.at,
      ...k,
      ipLength: A,
      ipId: w,
      segments: T,
      tcp: m && {
        seq: m.seq,
        ack: m.ack,
        hlen: m.hlen,
        mss: m.mss
      },
      messageLength: (() => {
        const L = d.find(Q => Q.full !== undefined);
        if (L) {
          return L.full;
        } else {
          return null;
        }
      })()
    };
    this.built[s] = N;
    return N;
  }
}
const Ki = new WeakMap();
function Gu(e) {
  if (!Ki.has(e)) {
    const t = new Xg(e);
    const s = Vr(e);
    Ki.set(e, s.map((n, o) => t.frame(n, o, s)));
  }
  return Ki.get(e);
}
const Zg = {
  eth: "slate",
  wlan: "slate",
  arp: "amber",
  ip: "blue",
  tcp: "green",
  udp: "green",
  icmp: "amber",
  tls: "teal",
  pad: "grey",
  llc: "grey",
  eapol: "amber",
  ccmp: "teal",
  wg: "teal",
  esp: "teal",
  ike: "amber",
  quic: "teal",
  ip6: "blue",
  icmp6: "amber",
  eap: "amber",
  radius: "violet",
  smb: "violet",
  modbus: "violet",
  bgp: "violet",
  stun: "amber",
  dtls: "teal",
  srtp: "teal",
  pppoe: "slate",
  ppp: "violet",
  igmp: "amber"
};
const Jl = e => Zg[e] ?? "violet";
const Jg = {
  eth: "Ethernet",
  wlan: "802.11",
  arp: "ARP",
  ip: "IPv4",
  tcp: "TCP",
  udp: "UDP",
  icmp: "ICMP",
  pad: "Padding",
  tls: "TLS",
  llc: "LLC",
  eapol: "EAPOL",
  ccmp: "CCMP",
  mgmt: "Body",
  wg: "WireGuard",
  esp: "ESP",
  ike: "IKEv2",
  ws: "WebSocket",
  socks: "SOCKS5",
  quic: "QUIC",
  ip6: "IPv6",
  icmp6: "ICMPv6",
  ntp: "NTP",
  eap: "EAP",
  radius: "RADIUS",
  smb: "SMB2",
  modbus: "Modbus",
  bgp: "BGP",
  stun: "STUN",
  dtls: "DTLS",
  srtp: "SRTP",
  pppoe: "PPPoE",
  ppp: "PPP"
};
function eS() {
  return `
  <div class="inspector" hidden data-t-label="Packet inspector" aria-label="${S("Packet inspector")}">
    <div class="ins-head">
      <span class="ins-badge step-badge"></span>
      <div class="ins-title"><b></b><span></span></div>
      <div class="ins-nav">
        <button type="button" data-ins="prev" data-t-label="Previous packet" aria-label="${S("Previous packet")}" data-t-title="Previous packet (←)" title="${S("Previous packet (←)")}">‹</button>
        <button type="button" data-ins="next" data-t-label="Next packet" aria-label="${S("Next packet")}" data-t-title="Next packet (→)" title="${S("Next packet (→)")}">›</button>
        <button type="button" data-ins="close" data-t-label="Close" aria-label="${S("Close")}" data-t-title="Close (Esc)" title="${S("Close (Esc)")}">✕</button>
      </div>
    </div>
    <div class="ins-where"></div>
    <div class="ins-bar"></div>
    <div class="ins-body">
      <div class="ins-tree"></div>
      <div class="ins-hex"></div>
    </div>
    <div class="ins-foot"><span><i class="eg" ${z("E.G.")}</i> <span ${z("an example value: it differs in every real capture")}</span></span><span><b>··</b> <span ${z("bytes the lesson can’t show: encrypted, random, or a file’s contents")}</span></span></div>
  </div>`;
}
function tS(e, t) {
  const s = e.to > e.from ? ` data-from="${e.from}" data-to="${e.to}"` : "";
  return `
    <div class="ins-field ${[`d${e.depth ?? 0}`, e.heading && "is-heading", e.hidden && "is-hidden", e.inside && "is-inside", e.mono && "is-mono"].filter(Boolean).join(" ")}" data-field="${t}"${s}>
      <span class="ins-name">${M(S(e.name))}</span>
      <span class="ins-value">${M(S(e.value))}${e.example ? ` <i class="eg">${S("E.G.")}</i>` : ""}</span>
      ${e.note ? `<p class="ins-note">${M(S(e.note))}</p>` : ""}
    </div>`;
}
function sS(e) {
  return e.layers.map(t => {
    const s = e.fields.map((o, a) => [o, a]).filter(([o]) => o.layer === t.id);
    const n = t.to - t.from;
    return `
      <section class="ins-layer c-${Jl(t.id)}" data-layer="${t.id}">
        <h4><span>${M(S(t.name))}</span>${t.summary ? `<em>${M(S(t.summary))}</em>` : ""}</h4>
        ${s.map(([o, a]) => tS(o, a)).join("")}
        
      </section>`;
  }).join("");
}
function nS(e) {
  const t = n => e.layers.find(o => n >= o.from && n < o.to)?.id ?? "pad";
  const s = [];
  for (let n = 0; n < e.bytes.length; n += 16) {
    const o = e.bytes.slice(n, n + 16);
    const a = o.map((i, c) => `<span class="hx c-${Jl(t(n + c))}${i === null ? " is-unknown" : ""}" data-i="${n + c}">${i === null ? "··" : i.toString(16).padStart(2, "0")}</span>`).join("");
    const r = o.map((i, c) => `<span class="as${i === null ? " is-unknown" : ""}" data-i="${n + c}">${i === null ? "·" : i >= 32 && i < 127 ? M(String.fromCharCode(i)) : "."}</span>`).join("");
    s.push(`<div class="hx-row"><span class="hx-at">${n.toString(16).padStart(4, "0")}</span><span class="hx-bytes">${a}</span><span class="hx-text">${r}</span></div>`);
  }
  return `<div class="hx-head">${S("BYTES")} <span>${S("{n} in this frame", {
    n: e.bytes.length
  })}</span></div>${s.join("")}`;
}
function oS(e) {
  const t = e.bytes.length;
  return e.layers.map(s => {
    const n = s.to - s.from;
    return `<span class="ins-seg c-${Jl(s.id)}" data-layer="${s.id}" style="flex:${Math.max(n, t * 0.045)}" title="${M(S(s.name))}"><b>${M(S(Jg[s.id] ?? s.name.split(" ·")[0]))}</b><i>${n}</i></span>`;
  }).join("");
}
function aS(e, t, s) {
  Wu(e, t, s);
  Vu(e, t, s);
}
function Wu(e, t, s) {
  const n = Gu(t)[s];
  const o = Vr(t)[s];
  const a = o.row;
  e.dataset.index = s;
  const r = e.querySelector(".ins-badge");
  r.className = `ins-badge step-badge ${o.color}`;
  r.textContent = s + 1;
  e.querySelector(".ins-title b").textContent = S(o.label);
  e.querySelector(".ins-title span").textContent = po(`${a.time} · ${a.src} → ${a.dst} · ${a.proto} · ${a.len}`);
  const i = [S(n.at)];
  if (n.segments > 1) {
    i.push(S("This row stands for {n} TCP segments carrying a {size}-byte message; the first segment is shown", {
      n: n.segments,
      size: n.messageLength.toLocaleString("en-US")
    }));
  }
  if (o.lost) {
    i.push(S("This packet was lost on the way"));
  }
  e.querySelector(".ins-where").textContent = i.join(" · ");
  e.querySelector(".ins-bar").innerHTML = oS(n);
}
function Vu(e, t, s) {
  const n = Gu(t)[s];
  e.querySelector(".ins-tree").innerHTML = sS(n);
  e.querySelector(".ins-hex").innerHTML = nS(n);
  e.querySelector(".ins-tree").scrollTop = 0;
  e.querySelector(".ins-hex").scrollTop = 0;
  e._frame = n;
}
function fr(e, t, s, n) {
  e.querySelectorAll(".is-lit").forEach(o => o.classList.remove("is-lit"));
  if (t !== undefined) {
    for (let o = t; o < s; o++) {
      e.querySelectorAll(`[data-i="${o}"]`).forEach(a => a.classList.add("is-lit"));
    }
    n?.classList.add("is-lit");
  }
}
function rS(e, t) {
  e.addEventListener("click", s => {
    const n = s.target.closest("[data-ins]");
    if (n) {
      t[n.dataset.ins]();
    }
    const o = s.target.closest(".ins-seg");
    if (o) {
      e.querySelector(`.ins-layer[data-layer="${o.dataset.layer}"]`)?.scrollIntoView({
        block: "start",
        behavior: Ne() ? "auto" : "smooth"
      });
    }
  });
  e.addEventListener("mouseover", s => {
    const n = s.target.closest(".ins-field[data-from]");
    if (n) {
      return fr(e, Number(n.dataset.from), Number(n.dataset.to), n);
    }
    const o = s.target.closest("[data-i]");
    if (o && e._frame) {
      const a = Number(o.dataset.i);
      const r = e._frame.fields.map((p, u) => [p, u]).filter(([p]) => a >= p.from && a < p.to).sort((p, u) => p[0].to - p[0].from - (u[0].to - u[0].from));
      if (!r.length) {
        return fr(e, a, a + 1);
      }
      const [i, c] = r[0];
      const d = e.querySelector(`.ins-field[data-field="${c}"]`);
      fr(e, i.from, i.to, d);
      d?.scrollIntoView({
        block: "nearest"
      });
    }
  });
  e.addEventListener("mouseleave", () => fr(e));
}
function iS(e, {
  visible: t,
  onChange: s
}) {
  let n = null;
  const o = () => !e.hidden && !e.classList.contains("is-closing");
  function a(c, d) {
    n = c;
    const p = o();
    e.getAnimations().forEach(u => u.cancel());
    e.classList.remove("is-closing");
    e.hidden = false;
    aS(e, c, d);
    if (!p && !Ne()) {
      e.animate([{
        opacity: 0,
        transform: "translateY(26px)"
      }, {
        opacity: 1,
        transform: "none"
      }], {
        duration: 320,
        easing: Gs
      });
    }
    s(d);
  }
  function r() {
    if (!e.hidden) {
      s(null);
      if (Ne()) {
        return e.hidden = true;
      }
      e.classList.add("is-closing");
      e.getAnimations().forEach(c => c.cancel());
      e.animate([{
        opacity: 1,
        transform: "none"
      }, {
        opacity: 0,
        transform: "translateY(18px)"
      }], {
        duration: 200,
        easing: "ease-in"
      }).onfinish = () => {
        if (e.classList.contains("is-closing")) {
          e.classList.remove("is-closing");
          e.hidden = true;
        }
      };
    }
  }
  function i(c) {
    if (!o()) {
      return;
    }
    const d = t();
    const p = d.indexOf(Number(e.dataset.index));
    const u = d[p + c];
    if (u !== undefined) {
      e.dataset.index = u;
      Wu(e, n, u);
      lo(e.querySelector(".ins-body"), () => e.dataset.index === String(u) && Vu(e, n, u), c, 14);
      s(u);
    }
  }
  rS(e, {
    prev: () => i(-1),
    next: () => i(1),
    close: r
  });
  return {
    open: a,
    close: r,
    step: i,
    isOpen: o,
    index: () => o() ? Number(e.dataset.index) : null
  };
}
const ua = [0.5, 1, 1.5, 2];
function Yu() {
  const e = ua.map(t => `<button type="button" role="menuitemradio" data-speed="${t}" aria-checked="${t === 1}"><span class="speed-check">${Se.check}</span><span>${t}×</span></button>`).join("");
  return `
    <div class="speed-box">
      <button class="btn speed" type="button" aria-haspopup="menu" aria-expanded="false" data-t-title="Playback speed" title="${S("Playback speed")}">
        <span class="speed-label">1×</span>${Se.caret}
      </button>
      <div class="speed-menu" role="menu" data-t-label="Playback speed" aria-label="${S("Playback speed")}" hidden>
        <div class="speed-head" ${z("Playback speed")}</div>
        ${e}
      </div>
    </div>
    <button class="btn icon" type="button" data-action="prev" data-t-title="Previous step (←)" title="${S("Previous step (←)")}" data-t-label="Previous step" aria-label="${S("Previous step")}">
      <svg viewBox="0 0 12 12" width="12" height="12" aria-hidden="true"><path d="M7.8 1.8 L3.6 6 L7.8 10.2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
    <button class="btn primary toggle" type="button" data-action="toggle" data-t-title="Play / pause (Space)" title="${S("Play / pause (Space)")}">
      <span class="toggle-icon">
        <svg class="icon-playpause" viewBox="0 0 12 14" width="12" height="14" aria-hidden="true"><path class="pp-a"/><path class="pp-b"/></svg>
        ${Se.reset.replace("<svg", "<svg class=\"icon-replay\"")}
      </span>
      <span class="toggle-label"></span>
    </button>
    <button class="btn" type="button" data-action="step" data-t-title="One packet at a time (S)" title="${S("One packet at a time (S)")}"><span ${z("STEP")}</span></button>
    <button class="btn" type="button" data-action="reset" data-t-title="Back to the overview (Esc)" title="${S("Back to the overview (Esc)")}" data-t-label="Reset" aria-label="${S("Reset")}">${Se.reset}<span class="btn-text" ${z("RESET")}</span></button>`;
}
function ju(e, t) {
  const s = e.querySelector(".toggle");
  new ResizeObserver(() => Xu(s)).observe(s);
  e.addEventListener("click", n => {
    const o = n.target.closest("[data-action]");
    if (o && !o.disabled && e.contains(o)) {
      t[o.dataset.action]();
    }
  });
  lS(e.querySelector(".speed-box"), n => t.speed(n));
}
function lS(e, t) {
  const s = e.querySelector(".speed");
  const n = e.querySelector(".speed-menu");
  const o = () => [...n.querySelectorAll("[data-speed]")];
  const a = i => !e.contains(i.target) && r(false);
  function r(i, c = true) {
    if (i !== !n.hidden) {
      n.hidden = !i;
      s.setAttribute("aria-expanded", i);
      e.classList.toggle("is-open", i);
      if (i) {
        if (c) {
          (o().find(d => d.getAttribute("aria-checked") === "true") ?? o()[0]).focus();
        }
        document.addEventListener("pointerdown", a, true);
      } else {
        document.removeEventListener("pointerdown", a, true);
      }
    }
  }
  s.addEventListener("click", () => r(n.hidden));
  n.addEventListener("click", i => {
    const c = i.target.closest("[data-speed]");
    if (c) {
      t(Number(c.dataset.speed));
      r(false);
      s.focus();
    }
  });
  e.addEventListener("keydown", i => {
    if (n.hidden) {
      return;
    }
    const c = o();
    const d = c.indexOf(document.activeElement);
    if (i.key === "ArrowDown" || i.key === "ArrowUp") {
      i.preventDefault();
      c[(d + (i.key === "ArrowDown" ? 1 : -1) + c.length) % c.length].focus();
    } else if (i.key === "Home" || i.key === "End") {
      i.preventDefault();
      c[i.key === "Home" ? 0 : c.length - 1].focus();
    } else if (i.key === "Escape") {
      i.preventDefault();
      r(false);
      s.focus();
    } else if (i.key === "Tab") {
      r(false, false);
    }
  });
}
function zu(e, t) {
  const s = e.querySelector(".toggle");
  s.classList.toggle("is-playing", t.playing);
  s.classList.toggle("is-done", t.done && !t.playing);
  Vt(s.querySelector(".toggle-label"), S(t.playing ? "PAUSE" : t.done ? "REPLAY" : "PLAY"));
  e.querySelector("[data-action=\"step\"]").disabled = t.done;
  e.querySelector("[data-action=\"prev\"]").disabled = !t.started;
}
function Qu(e, t) {
  Vt(e.querySelector(".speed-label"), `${t}×`);
  e.querySelectorAll(".speed-menu [data-speed]").forEach(s => s.setAttribute("aria-checked", Number(s.dataset.speed) === t));
}
function ka(e) {
  const t = e.querySelector(".toggle-label");
  const s = t.textContent;
  t.style.minWidth = "";
  const n = Math.max(...["PLAY", "PAUSE", "REPLAY"].map(r => {
    t.textContent = S(r);
    return t.scrollWidth;
  }));
  t.textContent = s;
  if (!n) {
    return;
  }
  t.style.minWidth = `${n}px`;
  const o = e.querySelector(".toggle");
  const a = getComputedStyle(o);
  o._need = n + 16 + parseFloat(a.columnGap || 12) + parseFloat(a.paddingLeft) + parseFloat(a.paddingRight) + 2;
  Xu(o);
}
const Xu = e => e.classList.toggle("is-iconic", getComputedStyle(e).containerType === "inline-size" && e.clientWidth < (e._need ?? 0));
const cS = [["network", "NETWORK", "<svg viewBox=\"0 0 16 16\" width=\"14\" height=\"14\" aria-hidden=\"true\"><path d=\"M8 1.8 L14 5 L8 8.2 L2 5 Z M2 8.4 L8 11.6 L14 8.4 M2 11.6 L8 14.8 L14 11.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linejoin=\"round\"/></svg>"], ["sequence", "SEQUENCE", "<svg viewBox=\"0 0 16 16\" width=\"14\" height=\"14\" aria-hidden=\"true\"><path d=\"M3 1.5 V14.5 M13 1.5 V14.5\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-dasharray=\"2 2\"/><path d=\"M3 4.5 L12 6.5 M12 6.5 L9.6 7.4 M12 6.5 L10.2 4.6 M13 9.5 L4 11.5 M4 11.5 L5.8 9.6 M4 11.5 L6.4 12.4\" stroke=\"currentColor\" stroke-width=\"1.5\" fill=\"none\" stroke-linecap=\"round\"/></svg>"]];
function dS() {
  const e = cS.map(([t, s, n], o) => `<button type="button" role="tab" data-view="${t}" aria-selected="${o === 0}" class="${o === 0 ? "is-active" : ""}">${n}<span ${z(s)}</span></button>`).join("");
  return `
  <section class="panel simulation">
    ${bw()}
    ${Mw()}
    <div class="view-switch" role="tablist" data-t-label="View" aria-label="${S("View")}" data-t-title="Switch view (V)" title="${S("Switch view (V)")}">${e}<i class="view-indicator"></i></div>
    <div class="stage-controls" role="group" data-t-label="Playback" aria-label="${S("Playback")}">${Yu()}</div>
    ${eS()}
  </section>`;
}
const Zu = "protocol-explorer:view";
const hS = () => {
  try {
    return localStorage.getItem(Zu);
  } catch {
    return null;
  }
};
function pS(e, t = () => {}) {
  const s = e.querySelector(".view-indicator");
  function n(r, i = true) {
    e.classList.toggle("is-sequence", r === "sequence");
    e.querySelectorAll(".view-switch button").forEach(c => {
      const d = c.dataset.view === r;
      c.classList.toggle("is-active", d);
      c.setAttribute("aria-selected", d);
      if (d) {
        s.style.left = `${c.offsetLeft}px`;
        s.style.width = `${c.offsetWidth}px`;
      }
    });
    t(r);
    if (i) {
      try {
        localStorage.setItem(Zu, r);
      } catch {}
    }
  }
  e.querySelector(".view-switch").addEventListener("click", r => {
    const i = r.target.closest("button");
    if (i) {
      n(i.dataset.view);
    }
  });
  n(hS() === "sequence" ? "sequence" : "network", false);
  requestAnimationFrame(() => s.classList.add("is-ready"));
  const o = () => {
    const r = e.querySelector(".view-switch button.is-active");
    s.style.transition = "none";
    s.style.left = `${r.offsetLeft}px`;
    s.style.width = `${r.offsetWidth}px`;
    s.offsetWidth;
    s.style.transition = "";
  };
  const a = new ResizeObserver(o);
  e.querySelectorAll(".view-switch button").forEach(r => a.observe(r));
  return {
    toggle: () => n(e.classList.contains("is-sequence") ? "network" : "sequence"),
    view: () => e.classList.contains("is-sequence") ? "sequence" : "network"
  };
}
const Xh = (e, t) => S(e.labels?.[t]?.[0] ?? sw[t]);
const uS = "<svg class=\"pill-lock\" viewBox=\"0 0 12 14\" width=\"10\" height=\"12\" aria-hidden=\"true\"><path d=\"M3 6.5 V4.5 a3 3 0 0 1 6 0 V6.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/><rect x=\"1.5\" y=\"6.5\" width=\"9\" height=\"6.5\" rx=\"1.3\" fill=\"currentColor\"/></svg>";
const Ju = e => e.map(([t, s]) => `<div><dt>${M(as(S(t)))}</dt><dd>${M(S(s))}</dd></div>`).join("");
function fS() {
  return `
  <section class="panel overview">
    <div class="panel-head bar">
      <h2 class="panel-title sm"></h2>
      <button class="back-btn" type="button" hidden>${Se.back}<span ${z("OVERVIEW")}</span></button>
    </div>

    <div class="overview-stage">
      <div class="overview-body" data-view="overview">
        <div class="overview-name">
          <h3></h3>
          <span class="badge"><i></i><span ${z("ACTIVE")}</span></span>
        </div>
        <p class="overview-full"></p>
        <p class="overview-desc"></p>
        <dl class="facts overview-facts"></dl>
      </div>

      <div class="overview-body explain" data-view="step" hidden aria-live="polite">
        <div class="explain-label"></div>
        <h3 class="explain-title"></h3>
        <p class="explain-sub"></p>
        <p class="explain-text"></p>
        <div class="explain-packet">
          <div class="explain-packet-clip">
            <div class="explain-packet-card">
              <div class="explain-packet-inner">
                <div class="explain-packet-head"><b></b><span></span></div>
                <div class="explain-payload"></div>
                <div class="explain-meta"></div>
              </div>
            </div>
          </div>
        </div>
        <dl class="facts explain-facts"></dl>
      </div>
    </div>
  </section>`;
}
function mS(e, t) {
  e.querySelector(".back-btn").addEventListener("click", t);
}
function yS(e, t, s) {
  const n = t.steps[e.activeStep];
  const o = Vr(t);
  const a = e.event;
  const r = e.started && !e.done && (a?.type === "packet" || a?.type === "stream") && a.step === e.activeStep;
  const i = r ? o.indexOf(a.type === "stream" ? a.packets[0] : o.find(c => c.row === a.row)) + 1 : 0;
  return {
    lesson: t,
    order: s,
    view: e.started ? "step" : "overview",
    title: S(e.started ? e.done ? "LESSON SUMMARY" : "STEP DETAILS" : "PROTOCOL OVERVIEW"),
    rank: e.started ? e.done ? t.steps.length : e.activeStep : -1,
    content: e.done ? {
      label: S("LESSON COMPLETE"),
      ...t.outro,
      done: true
    } : {
      label: S("STEP {n} OF {total}", {
        n: e.activeStep + 1,
        total: t.steps.length
      }),
      title: n.title,
      desc: n.desc,
      text: n.detail,
      facts: n.facts
    },
    packet: r ? {
      number: i,
      count: a.type === "stream" ? a.packets.length : 1,
      total: o.length,
      event: a
    } : null
  };
}
function wS(e, t) {
  const s = e.querySelector("[data-view=\"overview\"]");
  s.querySelector("h3").textContent = t.name;
  s.querySelector(".overview-full").textContent = S(t.overview.full);
  s.querySelector(".overview-desc").textContent = S(t.overview.description);
  s.querySelector(".overview-facts").innerHTML = Ju(t.overview.facts);
}
function gS(e, t) {
  const s = e.querySelector(".explain");
  s.classList.toggle("is-done", !!t.done);
  s.querySelector(".explain-label").textContent = t.label;
  s.querySelector(".explain-title").textContent = as(S(t.title));
  s.querySelector(".explain-sub").textContent = S(t.desc);
  s.querySelector(".explain-text").textContent = S(t.text);
  s.querySelector(".explain-facts").innerHTML = Ju(t.facts ?? []);
  s.scrollTop = 0;
}
function ec(e, t, s) {
  if (!t) {
    return;
  }
  const n = e.querySelector(".explain-packet");
  const {
    event: o,
    number: a,
    count: r,
    total: i
  } = t;
  n.dataset.color = o.color;
  n.querySelector("b").innerHTML = (o.locked ? uS : "") + M(S(o.label));
  const c = o.type === "stream" ? [...new Set(o.packets.map(d => d.to))] : [o.to];
  n.querySelector("span").textContent = as(`${Xh(s, o.from)} ${gn() ? "←" : "→"} ${c.map(d => Xh(s, d)).join(" + ")}`);
  n.querySelector(".explain-payload").textContent = o.payload.map(d => S(d)).join(`
`);
  if (o.type === "stream") {
    const d = o.packets.filter(T => T.lost).length;
    const p = o.packets.map(T => T.row.len);
    const u = p.every(T => T === p[0]) ? `${r} × ${p[0]}` : p.every(T => T.endsWith(" B")) ? `${p.map(T => T.slice(0, -2)).join(" + ")} B` : p.join(" + ");
    const y = d ? ` · ${S(d === 1 ? "1 LOST" : "{n} LOST", {
      n: d
    })}` : o.locked ? ` · ${S("ENCRYPTED")}` : "";
    n.querySelector(".explain-meta").textContent = `${S("PACKETS {from}–{to} OF {total}", {
      from: a,
      to: a + r - 1,
      total: i
    })} · ${po(u)}${y}`;
  } else {
    const d = o.lost ? ` · ${S("LOST ON THE WAY")}` : o.locked ? ` · ${S("ENCRYPTED")}` : "";
    n.querySelector(".explain-meta").textContent = `${S("PACKET {n} OF {total}", {
      n: a,
      total: i
    })} · ${po(o.row.proto)} · ${po(o.row.len)}${d}`;
  }
}
function e0(e, t) {
  const s = e.querySelector(".explain-packet");
  const n = s.offsetHeight;
  s.getAnimations().forEach(a => a.cancel());
  t();
  const o = s.offsetHeight;
  if (n !== o && !Ne()) {
    s.animate([{
      height: `${n}px`
    }, {
      height: `${o}px`
    }], {
      duration: 420,
      easing: Gs
    });
  }
}
const SS = (e, t) => t.packet && e0(e, () => ec(e, t.packet, t.lesson));
function mr(e, t) {
  wS(e, t.lesson);
  e.querySelector("[data-view=\"overview\"]").hidden = t.view !== "overview";
  e.querySelector("[data-view=\"step\"]").hidden = t.view !== "step";
  gS(e, t.content);
  ec(e, t.packet, t.lesson);
  e.querySelector(".explain-packet").classList.toggle("is-open", !!t.packet);
}
function TS(e, t) {
  const s = e.querySelector(".back-btn");
  if (s.hidden === t) {
    s.hidden = !t;
    if (t && !Ne()) {
      s.animate([{
        transform: `translateX(${gn() ? -14 : 14}px)`,
        opacity: 0
      }, {
        transform: "none",
        opacity: 1
      }], {
        duration: 320,
        easing: Gs
      });
    }
  }
}
function bS(e) {
  e._shown = null;
}
function vS(e, t, s, n = 0) {
  const o = yS(t, s, n);
  const a = e._shown;
  e._latest = o;
  const r = () => e._latest;
  Vt(e.querySelector(".panel-title"), o.title, !a || o.rank >= a.rank ? 1 : -1);
  TS(e, o.view === "step");
  if (!a) {
    mr(e, o);
  } else if (o.lesson !== a.lesson) {
    lo(e.querySelector(".overview-stage"), () => mr(e, r()), o.order > a.order ? 1 : -1, 32);
  } else if (o.view !== a.view) {
    lo(e.querySelector(".overview-stage"), () => mr(e, r()), o.view === "step" ? 1 : -1, 32);
  } else if (o.view === "step" && o.rank !== a.rank) {
    lo(e.querySelector(".explain"), () => mr(e, r()), o.rank > a.rank ? 1 : -1);
  } else if (o.view === "step" && o.packet?.number !== a.packet?.number) {
    const i = e.querySelector(".explain-packet");
    const c = ["client", "dns"].includes(o.packet?.event.to) && o.packet?.event.from !== "client";
    if (o.packet && a.packet) {
      lo(i.querySelector(".explain-packet-inner"), () => SS(e, r()), c ? 1 : -1, 18);
    } else {
      e0(e, () => {
        if (o.packet) {
          ec(e, o.packet, o.lesson);
        }
        i.classList.toggle("is-open", !!o.packet);
      });
    }
  }
  e._shown = o;
}
const kS = e => vu(S(e)) ? " dir=\"ltr\" class=\"is-ltr\"" : "";
function PS(e) {
  return Vr(e).map(({
    color: t,
    row: s,
    lost: n
  }, o) => `
      <tr data-packet="${o}" class="${n ? "is-lost" : ""}" tabindex="0" hidden>
        <td><span class="step-badge ${t}">${o + 1}</span></td>
        <td><bdi dir="ltr">${M(s.time)}</bdi></td>
        <td title="${M(s.src)}"><bdi dir="ltr">${M(s.src)}</bdi></td>
        <td title="${M(s.dst)}"><bdi dir="ltr">${M(s.dst)}</bdi></td>
        <td><bdi dir="ltr">${M(s.proto)}</bdi></td>
        <td title="${M(S(s.info))}"${kS(s.info)}><span ${z(s.info)}</span>${n ? `<span class="lost-chip" ${z("LOST")}</span>` : ""}</td>
        <td><bdi dir="ltr">${M(s.len)}</bdi></td>
      </tr>`).join("");
}
function AS() {
  return `
  <section class="panel packets">
    <div class="panel-head bar">
      <h2 class="panel-title sm" ${z("PACKET FLOW")}</h2>
      <div class="packet-legend" data-t-label="Colour key" aria-label="${S("Colour key")}"></div>
      <div class="packet-actions">${Yu()}</div>
    </div>
    <div class="packet-scroll">
      <table class="packet-table">
        <colgroup>
          <col style="width:56px"><col style="width:106px"><col style="width:146px"><col style="width:150px">
          <col style="width:112px"><col><col style="width:74px">
        </colgroup>
        <thead>
          <tr>${["NO.", "TIME", "SOURCE", "DESTINATION", "PROTOCOL", "INFO", "SIZE"].map(e => `<th ${z(e)}</th>`).join("")}</tr>
        </thead>
        <tbody class="packet-empty-body"><tr class="packet-empty" hidden><td colspan="7" ${z("No packets on the wire yet.")}</td></tr></tbody>
        <tbody class="packet-rows"></tbody>
      </table>
    </div>
  </section>`;
}
function ES(e, t) {
  ju(e.querySelector(".packet-actions"), t);
  e.addEventListener("click", s => {
    const n = s.target.closest("tr[data-packet]");
    if (n && !n.hidden) {
      t.inspect(Number(n.dataset.packet));
    }
  });
  e.addEventListener("keydown", s => {
    const n = s.key === "Enter" && s.target.closest("tr[data-packet]");
    if (n && !n.hidden) {
      t.inspect(Number(n.dataset.packet));
    }
  });
}
const t0 = e => e.hidden ? 0 : Number(getComputedStyle(e).opacity);
function Zh(e, t = 0) {
  const s = t0(e);
  e.dataset.shown = "1";
  e.getAnimations().forEach(n => n.cancel());
  e.hidden = false;
  if (!Ne() && s !== 1) {
    e.animate([{
      opacity: s,
      transform: `translateY(${(1 - s) * 10}px)`
    }, {
      opacity: 1,
      transform: "none"
    }], {
      duration: 360,
      delay: s > 0 ? 0 : t,
      easing: Gs,
      fill: "backwards"
    });
  }
}
function yl(e) {
  const t = t0(e);
  const s = e.hidden ? "none" : getComputedStyle(e).transform;
  e.dataset.shown = "0";
  e.getAnimations().forEach(o => o.cancel());
  if (Ne() || t === 0) {
    return e.hidden = true;
  }
  const n = e.animate([{
    opacity: t,
    transform: s
  }, {
    opacity: 0,
    transform: s
  }], {
    duration: t * 180,
    fill: "forwards"
  });
  n.onfinish = () => {
    if (e.dataset.shown === "0") {
      e.hidden = true;
    }
    n.cancel();
  };
}
const wl = e => (e.legend ?? []).map(([t, s]) => t ? `<span class="legend-item"><i class="legend-dot step-badge ${t}"></i>${M(S(s))}</span>` : `<span class="legend-note">${M(S(s))}</span>`).join("");
function xS(e, t) {
  const s = e.querySelector(".packet-rows");
  const n = e.querySelector(".packet-legend");
  const o = !e.dataset.lesson;
  e.dataset.lesson = t.id;
  if (o) {
    n.innerHTML = wl(t);
  } else {
    lo(n, () => n.innerHTML = wl(t), 1, 16);
  }
  const a = [...s.children].filter(i => !i.hidden);
  const r = () => {
    if (e.dataset.lesson === t.id) {
      s.innerHTML = PS(t);
      s.dataset.lesson = t.id;
      e.querySelector(".packet-scroll").scrollTop = 0;
      if (e._latest) {
        s0(e, e._latest);
      }
    }
  };
  if (!a.length || Ne()) {
    return r();
  }
  a.forEach(yl);
  setTimeout(r, 200);
}
function s0(e, t) {
  if (e.querySelector(".packet-rows").dataset.lesson !== e.dataset.lesson) {
    return;
  }
  const s = [...e.querySelectorAll("tr[data-packet]")];
  const n = s.map((c, d) => !t.started || t.packets[d] !== "future");
  const o = s.filter((c, d) => n[d] && c.dataset.shown !== "1");
  const a = s.filter((c, d) => !n[d] && c.dataset.shown === "1");
  a.forEach(yl);
  o.forEach((c, d) => Zh(c, (a.length ? 200 : 0) + (o.length > 1 ? d * 35 : 0)));
  s.forEach((c, d) => c.classList.toggle("is-current", t.started && t.packets[d] === "current"));
  if (t.started && o.length === 1) {
    const c = e.querySelector(".packet-scroll");
    requestAnimationFrame(() => c.scrollTo({
      top: c.scrollHeight,
      behavior: "smooth"
    }));
  }
  if (!t.started && o.length) {
    e.querySelector(".packet-scroll").scrollTo({
      top: 0,
      behavior: "smooth"
    });
  }
  const r = e.querySelector(".packet-empty");
  const i = t.started && !n.some(Boolean);
  if (i && r.dataset.shown !== "1") {
    Zh(r, a.length ? 220 : 0);
  }
  if (!i && r.dataset.shown === "1") {
    yl(r);
  }
}
function CS(e, t, s) {
  e._latest = t;
  if (e.dataset.lesson !== s.id) {
    xS(e, s);
  } else {
    s0(e, t);
  }
  zu(e.querySelector(".packet-actions"), t);
}
function $S(e, t) {
  e.querySelector(".packet-legend").innerHTML = wl(t);
  tc(e);
  e.querySelectorAll("tr[data-packet] td[title]").forEach(s => {
    const n = s.querySelector("[data-t]");
    if (!n) {
      return;
    }
    const o = S(n.dataset.t);
    s.title = o;
    const a = vu(o);
    s.classList.toggle("is-ltr", a);
    if (a) {
      s.dir = "ltr";
    } else {
      s.removeAttribute("dir");
    }
  });
}
const tc = e => ka(e.querySelector(".packet-actions"));
const LS = (e, t) => Qu(e.querySelector(".packet-actions"), t);
const IS = "http://www.w3.org/2000/svg";
const Jh = 0.21;
const RS = 140;
const NS = 55;
const Bi = 1100;
const yr = 14;
const DS = 470;
const ep = ["client"];
const tp = [10, 20, 30];
const OS = 1500;
const MS = 700;
const qS = 1.8;
const HS = [140, 58];
const sp = [60, 334];
const FS = /[\u1100-\u115f\u2e80-\u303e\u3041-\u33ff\u3400-\u4dbf\u4e00-\u9fff\ua960-\ua97f\uac00-\ud7a3\uf900-\ufaff\ufe30-\ufe4f\uff00-\uff60\uffe0-\uffe6]/;
const _i = e => [...e].reduce((t, s) => t + (FS.test(s) ? 2 : US.test(s) ? 0 : 1), 0);
const US = /[\u200e\u200f\u2066-\u2069]/;
const KS = /[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufefc]/;
const Gi = (e, t, s = 0) => Math.max(t, e.getComputedTextLength() + s);
const BS = e => e < 0.5 ? e * 4 * e * e : 1 - (e * -2 + 2) ** 3 / 2;
const wr = e => 1 + (e - 1) ** 3 * 2.2 + (e - 1) ** 2 * 1.2;
const np = e => 1 - (1 - e) ** 3;
const Bo = e => e * e * e;
function He(e, t, s) {
  const n = document.createElementNS(IS, e);
  for (const [o, a] of Object.entries(t)) {
    n.setAttribute(o, a);
  }
  s?.appendChild(n);
  return n;
}
const gr = ([e, t, s, n], o) => ({
  x: e + (s - e) * o,
  y: t + (n - t) * o
});
const op = ([e, t, s, n]) => Math.hypot(s - e, n - t);
function _S(e) {
  const t = Object.fromEntries([...e.querySelectorAll(".lane")].map(f => [f.dataset.lane, f]));
  const s = Object.fromEntries([...e.querySelectorAll(".node")].map(f => [f.dataset.node, f]));
  const n = e.querySelector(".packet-layer");
  const o = e.querySelector(".pulse-layer");
  const a = e.querySelector(".note-layer");
  const r = e.querySelector(".url-bar");
  const i = r.querySelector(".url-box");
  const c = r.querySelector(".url-text");
  const d = r.querySelector(".url-caret");
  const p = r.querySelector(".url-check");
  const u = [...e.querySelectorAll("[data-node=client] .screen-content > *")];
  const y = new Set();
  const T = new Set();
  let m = Object.keys(s);
  let w = null;
  let k = true;
  let A = false;
  let N = "full";
  let L = e.getAttribute("viewBox").split(" ").map(Number);
  const Q = [...e.querySelectorAll(".node-label")];
  const ne = e.querySelector(".url-holder");
  let be = 1;
  let O = 1;
  function Z(f) {
    f.removeAttribute("transform");
    f.querySelector(".label-plate")?.remove();
    if (be === 1) {
      return;
    }
    const g = f.getBBox();
    f.prepend(He("rect", {
      class: "label-plate",
      x: (g.x - 4).toFixed(1),
      y: (g.y - 1).toFixed(1),
      width: (g.width + 8).toFixed(1),
      height: (g.height + 2).toFixed(1),
      rx: 3
    }));
    const [b, C] = f.dataset.origin.split("-");
    const I = b === "left" ? g.x : b === "right" ? g.x + g.width : g.x + g.width / 2;
    const E = C === "top" ? g.y : g.y + g.height;
    f.setAttribute("transform", `translate(${I.toFixed(1)} ${E.toFixed(1)}) scale(${be.toFixed(3)}) translate(${(-I).toFixed(1)} ${(-E).toFixed(1)})`);
  }
  function v() {
    const f = e.getBoundingClientRect().width;
    const g = f ? Math.min(qS, Math.max(1, MS / f)) : 1;
    if (Math.abs(g - be) < 0.01) {
      return;
    }
    be = g;
    O = 1 + (g - 1) * 0.6;
    e.classList.toggle("is-scaled", g > 1);
    Q.forEach(Z);
    const [b, C] = HS;
    ne.setAttribute("transform", `translate(${sp[0] + b} ${sp[1] + C}) scale(${O.toFixed(3)}) translate(${-b} ${-C})`);
  }
  function Ue(f) {
    const g = f.getBBox();
    const b = f.transform?.baseVal.consolidate()?.matrix;
    if (!b) {
      return g;
    }
    const [C, I] = [b.a * g.x + b.e, b.a * (g.x + g.width) + b.e];
    const [E, F] = [b.d * g.y + b.f, b.d * (g.y + g.height) + b.f];
    return {
      x: Math.min(C, I),
      y: Math.min(E, F),
      width: Math.abs(I - C),
      height: Math.abs(F - E)
    };
  }
  function De(f, g) {
    if (g) {
      return s[f].getBBox();
    }
    const b = [...s[f].children].filter(E => !E.classList.contains("url-holder")).map(Ue);
    const C = Math.min(...b.map(E => E.x));
    const I = Math.min(...b.map(E => E.y));
    return {
      x: C,
      y: I,
      width: Math.max(...b.map(E => E.x + E.width)) - C,
      height: Math.max(...b.map(E => E.y + E.height)) - I
    };
  }
  function Ke(f) {
    N = f;
    r.classList.toggle("is-away", !ep.includes(f));
  }
  let B = 0;
  const J = e.closest(".simulation")?.querySelector(".view-switch");
  function lt(f) {
    const b = gh[f].filter(U => m.includes(U)).map(U => De(U, ep.includes(f)));
    const C = Math.min(...b.map(U => U.x)) - yr;
    const I = Math.min(...b.map(U => U.y)) - yr;
    const E = Math.max(...b.map(U => U.x + U.width)) + yr - C;
    const F = Math.max(...b.map(U => U.y + U.height)) + yr - I;
    const le = e.getBoundingClientRect();
    const {
      width: me,
      height: ve
    } = le;
    const Ie = U => {
      const xt = Math.max(ve - B - U, ve / 2);
      const oe = Math.min(me / E, xt / F, me / DS);
      return {
        s: oe,
        x: C + E / 2 - me / oe / 2,
        y: I + F / 2 - (U + xt / 2) / oe
      };
    };
    let Y = Ie(0);
    const Qe = J?.offsetParent ? J.getBoundingClientRect() : null;
    if (Qe) {
      const U = {
        left: Qe.left - le.left - 4,
        right: Qe.right - le.left + 4,
        top: Qe.top - le.top - 4,
        bottom: Qe.bottom - le.top + 4
      };
      const xt = oe => (oe.x - Y.x) * Y.s < U.right && (oe.x + oe.width - Y.x) * Y.s > U.left && (oe.y - Y.y) * Y.s < U.bottom && (oe.y + oe.height - Y.y) * Y.s > U.top;
      if (b.some(xt)) {
        Y = Ie(U.bottom + 4);
      }
    }
    return [Y.x, Y.y, me / Y.s, ve / Y.s];
  }
  function $(f) {
    L = f;
    e.setAttribute("viewBox", f.map(g => g.toFixed(2)).join(" "));
  }
  let D = {
    cancelled: false
  };
  async function ue(f, g, b) {
    D.cancelled = true;
    const C = D = {
      cancelled: false
    };
    const I = L;
    await nt(g, {
      get cancelled() {
        return b.cancelled || C.cancelled;
      }
    }, E => {
      const F = BS(E);
      $(I.map((le, me) => le + (f[me] - le) * F));
    });
  }
  function H(f, g) {
    Ke(f);
    return ue(lt(f), Bi, g);
  }
  function Le() {
    D.cancelled = true;
    v();
    $(lt(N));
  }
  new ResizeObserver(Le).observe(e);
  function Be(f, g) {
    const b = s[f];
    if (g) {
      y.add(f);
    } else {
      y.delete(f);
    }
    b.style.opacity = g ? 1 : 0;
    b.removeAttribute("transform");
  }
  async function At(f, g, {
    delay: b = 0,
    ring: C = true
  } = {}) {
    const I = s[f];
    y.add(f);
    I.style.opacity = 0;
    if (b) {
      await ge(b, g);
    }
    await nt(650, g, E => {
      I.setAttribute("transform", `translate(0 ${((1 - wr(E)) * -46).toFixed(2)})`);
      I.style.opacity = Math.min(1, E * 2.4);
    });
    if (!g.cancelled) {
      I.removeAttribute("transform");
      if (C) {
        Xr(f, "navy", g);
      }
    }
  }
  async function vo(f, g, b = 0) {
    const C = s[f];
    y.delete(f);
    C.style.opacity = 1;
    if (b) {
      await ge(b, g);
    }
    await nt(380, g, I => {
      C.setAttribute("transform", `translate(0 ${(Bo(I) * -30).toFixed(2)})`);
      C.style.opacity = 1 - I;
    });
    if (!g.cancelled) {
      C.removeAttribute("transform");
      C.style.opacity = 0;
    }
  }
  function Et(f, g) {
    const b = s[f];
    nt(340, g, C => {
      if (C < 1) {
        b.setAttribute("transform", `translate(0 ${(Math.sin(Math.PI * C) * -5).toFixed(2)})`);
      } else {
        b.removeAttribute("transform");
      }
    });
  }
  function Ys(f, g) {
    const [b, C] = oa[f];
    const I = gr(oa[f], g);
    t[f].setAttribute("d", `M${b},${C} L${I.x.toFixed(1)},${I.y.toFixed(1)}`);
    t[f].style.visibility = g > 0.01 ? "" : "hidden";
  }
  async function dc(f, g, b, C = 0) {
    Ys(f, g ? 0 : 1);
    if (C) {
      await ge(C, b);
    }
    await nt(g ? 520 : 300, b, I => Ys(f, g ? np(I) : 1 - Bo(I)));
  }
  function ko(f, g = 0) {
    for (const b of Object.keys(t)) {
      const [C, I] = b.split(">");
      const E = y.has(C) && y.has(I) && (!w || w.has(`${C}-${I}`) || w.has(`${I}-${C}`));
      const F = E !== T.has(b);
      if (E) {
        T.add(b);
      } else {
        T.delete(b);
      }
      if (f) {
        if (F) {
          dc(b, E, f, g);
        }
      } else {
        Ys(b, E ? 1 : 0);
      }
    }
  }
  function Pa(f) {
    k = f;
    u.forEach(g => {
      g.style.opacity = f ? 1 : 0;
      g.style.strokeDasharray = g.tagName === "polyline" ? 1 : "";
      g.style.strokeDashoffset = g.tagName === "polyline" ? f ? 0 : 1 : "";
    });
  }
  async function zr(f, g, b = 0) {
    Pa(!f);
    k = f;
    if (b) {
      await ge(b, g);
    }
    const C = f ? u : [...u].reverse();
    for (const I of C) {
      if (g.cancelled) {
        return;
      }
      const E = I.tagName === "polyline";
      I.style.opacity = 1;
      await nt(f ? 240 : 110, g, F => {
        const le = f ? np(F) : 1 - F;
        if (E) {
          I.style.strokeDashoffset = 1 - le;
        } else {
          I.style.opacity = le;
        }
      });
      if (!f) {
        I.style.opacity = 0;
      }
    }
  }
  async function v0(f, g, b) {
    const C = H(g, b);
    await ge(Bi * 0.45, b);
    for (const [I, E] of f.entries()) {
      if (b.cancelled) {
        return;
      }
      const F = At(E, b);
      if (I === f.length - 1) {
        await F;
      } else {
        await ge(200, b);
      }
    }
    if (!b.cancelled) {
      ko(b);
      await C;
      await ge(300, b);
    }
  }
  async function k0({
    nodes: f,
    frame: g
  }, b) {
    Po(Zr);
    const C = Object.keys(s).filter(I => y.has(I) && !f.includes(I));
    C.forEach(I => y.delete(I));
    ko(b);
    zr(false, b);
    C.forEach((I, E) => vo(I, b, 120 + E * 70));
    await ge(250, b);
    await H(g, b);
    await ge(250, b);
  }
  async function P0({
    at: f,
    text: g,
    tone: b = "navy"
  }, C) {
    const {
      x: I,
      y: E,
      side: F
    } = gw[f] ?? {
      x: $i[f][0],
      y: $i[f][1],
      side: "top"
    };
    const le = S(g);
    const me = He("g", {
      transform: `translate(${I} ${E}) scale(${O.toFixed(3)})`
    }, a);
    const ve = He("g", {
      class: `note ${b}`
    }, me);
    const Ie = He("text", {
      class: "note-text",
      "dominant-baseline": "central"
    }, ve);
    Ie.textContent = le;
    const Y = Gi(Ie, _i(le) * 7.4, 3) + 30;
    const [Qe, U] = F === "left" ? [-Y - 9, -13] : [-Y / 2, -38];
    const xt = F === "left" ? `M${Qe},${U} h${Y} v8 l8,5 l-8,5 v8 h${-Y} z` : `M${Qe},${U} h${Y} v26 h${-Y / 2 + 7} l-7,8 l-7,-8 h${-Y / 2 + 7} z`;
    Ie.setAttribute("x", Qe + 23);
    Ie.setAttribute("y", U + 13);
    ve.insertBefore(He("circle", {
      class: "note-dot",
      cx: Qe + 13,
      cy: U + 13,
      r: 3.5
    }), Ie);
    ve.insertBefore(He("path", {
      class: "note-box",
      d: xt
    }), ve.firstChild);
    Et(f, C);
    await nt(320, C, oe => ve.setAttribute("transform", `scale(${wr(oe).toFixed(3)})`));
    await ge(OS, C);
    await nt(200, C, oe => {
      ve.setAttribute("transform", `scale(${(1 - Bo(oe) * 0.3).toFixed(3)})`);
      ve.style.opacity = 1 - oe;
    });
    me.remove();
  }
  function Qr(f, g) {
    const b = t[f];
    b.classList.toggle("is-active", !!g);
    b.style.stroke = g ? gs[g] : "";
    b.setAttribute("marker-end", `url(#head-${g || "idle"})`);
  }
  const Pn = {};
  function A0(f, g) {
    Pn[f] = (Pn[f] ?? 0) + 1;
    Qr(f, g);
  }
  function hc(f) {
    Pn[f] = Math.max(0, (Pn[f] ?? 0) - 1);
    if (!Pn[f]) {
      Qr(f);
    }
  }
  async function Xr(f, g, b) {
    const [C, I] = $i[f];
    const E = He("circle", {
      cx: C,
      cy: I,
      fill: "none",
      stroke: gs[g],
      "stroke-width": 2
    }, o);
    await nt(700, b, F => {
      E.setAttribute("r", 14 + F * 46);
      E.setAttribute("opacity", (1 - F) * 0.6);
    });
    E.remove();
  }
  function E0(f, g, b = [], C = false) {
    const I = S(g);
    const E = b.map(te => S(te));
    const F = tp.map((te, Ze) => He("circle", {
      r: 3.6 - Ze,
      fill: gs[f],
      opacity: 0.45 - Ze * 0.12
    }, n));
    const le = He("g", {
      class: "packet"
    }, n);
    He("circle", {
      r: 13,
      fill: gs[f],
      opacity: 0.18
    }, le);
    He("circle", {
      r: 6,
      fill: gs[f],
      stroke: "var(--panel)",
      "stroke-width": 2
    }, le);
    const me = 15;
    const ve = C ? 14 : 0;
    const Ie = E.length ? E.length * me + 9 : 0;
    const Y = He("g", {
      class: `packet-tag ${f}`,
      transform: `translate(0 -16) scale(${O.toFixed(3)})`
    }, le);
    const Qe = E.map((te, Ze) => {
      const zt = He("text", {
        y: -Ie + 6 + Ze * me,
        "dominant-baseline": "hanging",
        class: "packet-field"
      }, Y);
      zt.textContent = te;
      return zt;
    });
    const U = He("text", {
      "text-anchor": "middle",
      "dominant-baseline": "central",
      x: ve / 2,
      y: -Ie - 10.5,
      class: "packet-label"
    }, Y);
    U.textContent = I;
    const xt = Gi(U, _i(I) * 7.6);
    const oe = Math.max(xt + 16 + ve, ...Qe.map((te, Ze) => Gi(te, _i(E[Ze]) * 6.2) + 16));
    Qe.forEach((te, Ze) => {
      const zt = KS.test(E[Ze]);
      te.setAttribute("x", zt ? oe / 2 - 8 : -oe / 2 + 8);
      if (zt) {
        te.setAttribute("text-anchor", "end");
      }
    });
    Y.insertBefore(He("rect", {
      x: -oe / 2,
      y: -Ie - 22,
      width: oe,
      height: 22,
      rx: 3,
      fill: gs[f]
    }), U);
    if (Ie) {
      Y.insertBefore(He("rect", {
        x: -oe / 2,
        y: -Ie - 4,
        width: oe,
        height: Ie + 4,
        rx: 3,
        class: "packet-body",
        stroke: gs[f]
      }), Y.firstChild);
    }
    if (C) {
      const te = -xt / 2 - 4;
      He("path", {
        class: "packet-lock",
        d: `M${te - 6},${-Ie - 10} v-2.4 a3,3 0 0 1 6,0 v2.4 M${te - 7.5},${-Ie - 10} h9 v6.5 h-9 z`
      }, Y);
    }
    return {
      g: le,
      trail: F
    };
  }
  const Aa = (f, g, b = 1) => f.setAttribute("transform", `translate(${g.x.toFixed(1)} ${g.y.toFixed(1)}) scale(${b.toFixed(3)})`);
  async function pc({
    from: f,
    to: g,
    color: b,
    label: C,
    payload: I,
    locked: E,
    lost: F,
    quick: le
  }, me) {
    const ve = tw[`${f}>${g}`];
    const Ie = le ? Jh * 2.4 : Jh;
    const Y = F ? ve.findIndex(te => te.includes("internet")) : -1;
    const Qe = ve.filter((te, Ze) => Y < 0 || Ze <= Y);
    Qe.forEach(te => A0(te, b));
    const U = E0(b, C, I, E);
    const xt = gr(oa[ve[0]], 0);
    await nt(le ? 140 : 220, me, te => Aa(U.g, xt, wr(te)));
    let oe = xt;
    for (const [te, Ze] of ve.entries()) {
      if (me.cancelled) {
        return;
      }
      const zt = oa[Ze];
      const ei = te === Y ? 0.55 : 1;
      await nt(op(zt) * ei / Ie, me, yc => {
        oe = gr(zt, yc * ei);
        Aa(U.g, oe);
        U.trail.forEach((wc, I0) => {
          const gc = gr(zt, Math.max(0, yc * ei - tp[I0] / op(zt)));
          wc.setAttribute("cx", gc.x);
          wc.setAttribute("cy", gc.y);
        });
      });
      if (me.cancelled) {
        return;
      }
      if (te === Y) {
        return C0(U, oe, Qe, me);
      }
      Et(Ze.split(">")[1], me);
      if (te < ve.length - 1) {
        await ge(le ? 40 : RS, me);
      }
    }
    Xr(g, b, me);
    await nt(180, me, te => {
      Aa(U.g, oe, 1 - Bo(te));
      U.trail.forEach(Ze => Ze.setAttribute("opacity", (1 - te) * 0.3));
    });
    U.g.remove();
    U.trail.forEach(te => te.remove());
    ve.forEach(hc);
    await ge(150, me);
  }
  async function x0({
    packets: f,
    spacing: g = 480
  }, b) {
    const C = [];
    for (const [I, E] of f.entries()) {
      if (b.cancelled) {
        return;
      }
      C.push(pc(E, b));
      if (I < f.length - 1) {
        await ge(g, b);
      }
    }
    await Promise.all(C);
  }
  async function C0(f, g, b, C) {
    const I = He("path", {
      class: "drop-cross",
      d: "M-6,-6 L6,6 M6,-6 L-6,6",
      transform: `translate(${g.x} ${g.y})`
    }, n);
    await nt(520, C, E => {
      Aa(f.g, {
        x: g.x,
        y: g.y + Bo(E) * 26
      }, 1 - E * 0.4);
      f.g.style.opacity = 1 - E;
      f.trail.forEach(F => F.setAttribute("opacity", (1 - E) * 0.3));
      I.setAttribute("transform", `translate(${g.x} ${g.y}) scale(${wr(Math.min(1, E * 2)).toFixed(3)})`);
    });
    f.g.remove();
    f.trail.forEach(E => E.remove());
    b.forEach(hc);
    await ge(500, C);
    await nt(250, C, E => I.style.opacity = 1 - E);
    I.remove();
  }
  let Zr = {};
  let Jr = {};
  function Po(f) {
    Jr = f;
    for (const [g, b] of Object.entries(s)) {
      const C = (f[g] ?? ye[g]).map(F => S(F));
      const I = [b.querySelector(".node-name"), b.querySelector(".node-ip")];
      const E = b.querySelector(".node-label");
      I.forEach((F, le) => {
        if (!!F && F.textContent !== C[le]) {
          F.textContent = C[le];
          Z(E);
          if (y.has(g) && b.style.opacity !== "0") {
            F.animate([{
              opacity: 0
            }, {
              opacity: 1
            }], {
              duration: 260
            });
          }
        }
      });
    }
  }
  const uc = ({
    at: f,
    label: g
  }) => Po({
    ...Jr,
    [f]: g
  });
  function fc(f, g) {
    r.classList.toggle("is-secure", !!g);
    c.textContent = f;
    const b = c.getComputedTextLength();
    i.setAttribute("width", (b + 58).toFixed(1));
    p.setAttribute("transform", `translate(${(b + 38).toFixed(1)} 0)`);
  }
  async function $0(f, g, b) {
    fc(f, g);
    c.textContent = "";
    d.setAttribute("x", 29);
    r.classList.add("is-visible", "is-typing");
    await ge(400, b);
    for (let C = 1; C <= f.length; C++) {
      if (b.cancelled) {
        return;
      }
      c.textContent = f.slice(0, C);
      d.setAttribute("x", 30 + c.getComputedTextLength());
      await ge(NS, b);
    }
    if (!b.cancelled) {
      r.classList.remove("is-typing");
      Et("client", b);
      await ge(500, b);
    }
  }
  async function L0(f) {
    await ge(200, f);
    await zr(true, f);
    if (!f.cancelled) {
      r.classList.add("is-loaded");
      Xr("client", "green", f);
      await ge(500, f);
    }
  }
  function mc() {
    r.classList.remove("is-visible", "is-typing", "is-loaded");
    c.textContent = "";
  }
  Object.keys(t).forEach(f => Ys(f, 0));
  return {
    run(f, g) {
      if (f.type === "packet") {
        return pc(f, g);
      } else if (f.type === "stream") {
        return x0(f, g);
      } else if (f.type === "type-url") {
        return $0(f.text, f.secure, g);
      } else if (f.type === "focus") {
        return k0(f, g);
      } else if (f.type === "show") {
        return v0(f.nodes, f.frame, g);
      } else if (f.type === "camera") {
        return H(f.frame, g);
      } else if (f.type === "render") {
        return L0(g);
      } else if (f.type === "note") {
        return P0(f, g);
      } else if (f.type === "label") {
        uc(f);
        return ge(400, g);
      } else {
        return Promise.resolve();
      }
    },
    retext() {
      Po(Jr);
    },
    setInset(f) {
      if (f !== B) {
        B = f;
        Le();
      }
    },
    overview(f, g = {}, b = null) {
      m = f;
      w = b && new Set(b);
      Zr = g;
      Po(g);
      Object.keys(s).forEach(C => Be(C, m.includes(C)));
      ko();
      mc();
      Pa(true);
      Ke("full");
      Le();
    },
    apply(f) {
      if (f.type === "focus") {
        Po(Zr);
        Object.keys(s).forEach(g => Be(g, f.nodes.includes(g)));
        ko();
        mc();
        Pa(false);
        Ke(f.frame);
        Le();
      }
      if (f.type === "type-url") {
        fc(f.text, f.secure);
        r.classList.add("is-visible");
      }
      if (f.type === "show") {
        f.nodes.forEach(g => Be(g, true));
        ko();
      }
      if (f.type === "show" || f.type === "camera") {
        Ke(f.frame);
        Le();
      }
      if (f.type === "render") {
        Pa(true);
        r.classList.add("is-loaded");
      }
      if (f.type === "label") {
        uc(f);
      }
    },
    snapshot() {
      return {
        view: L,
        visible: new Set(y),
        lanes: new Set(T),
        page: k,
        fresh: !A
      };
    },
    morph(f, g) {
      A = true;
      e.classList.remove("is-booting");
      const b = gh.full.filter(E => y.has(E) && !f.visible.has(E));
      const C = [...f.visible].filter(E => !y.has(E));
      if (!f.fresh) {
        const E = L;
        $(f.view);
        ue(E, Bi * 0.8, g);
      }
      C.forEach((E, F) => vo(E, g, F * 60));
      b.forEach((E, F) => At(E, g, {
        delay: (f.fresh ? 150 : 250) + F * 110,
        ring: false
      }));
      const I = b.length ? 500 + b.length * 110 : 0;
      for (const E of Object.keys(t)) {
        const F = T.has(E);
        if (F !== f.lanes.has(E)) {
          dc(E, F, g, F ? I : 0);
        }
      }
      if (k !== f.page) {
        zr(k, g, k ? I + 200 : 0);
      }
    },
    clear() {
      for (const f of [...n.children, ...a.children]) {
        f.animate([{
          opacity: 1
        }, {
          opacity: 0
        }], {
          duration: 160
        }).onfinish = () => f.remove();
      }
      o.replaceChildren();
      Object.keys(t).forEach(f => {
        Pn[f] = 0;
        Qr(f);
      });
    }
  };
}
const GS = {
  network: {
    event: 450,
    step: 1100,
    quick: 120
  },
  sequence: {
    event: 260,
    step: 650,
    quick: 80
  }
};
function WS(e) {
  if (e.type === "packet") {
    if (e.quick) {
      return Bs.quick;
    } else {
      return Bs.draw;
    }
  } else if (e.type === "stream") {
    return (e.packets.length - 1) * Bs.stagger + Bs.draw;
  } else if (e.type === "note") {
    return Bs.note;
  } else {
    return 0;
  }
}
function VS(e, t, s, {
  mode: n = "network"
} = {}) {
  const o = [{
    type: "focus",
    ...e.start,
    step: 0
  }, ...e.steps.flatMap((O, Z) => O.events.map(v => ({
    ...v,
    step: Z
  })))];
  const a = e.steps.map((O, Z) => o.findLastIndex(v => v.step === Z));
  let r = 0;
  let i = -1;
  let c = false;
  let d = {
    cancelled: false
  };
  let p = null;
  let u = n;
  function y() {
    const O = r >= o.length && i === -1;
    const Z = r > 0 || i !== -1;
    const v = i !== -1 ? i : r - 1;
    const Ue = v >= 0 ? o[v].step : 0;
    const De = B => B.type === "packet" || B.type === "stream";
    const Ke = v >= 0 && De(o[v]) ? v : -1;
    return {
      playing: c,
      running: i !== -1,
      started: Z,
      done: O,
      activeStep: Ue,
      event: v >= 0 ? o[v] : null,
      steps: e.steps.map((B, J) => J === Ue && Z && !O ? "active" : a[J] < r ? "done" : "todo"),
      packets: o.flatMap((B, J) => {
        if (!De(B)) {
          return [];
        }
        const lt = J === Ke ? "current" : J < r ? "past" : "future";
        if (B.type === "stream") {
          return B.packets.map(() => lt);
        } else {
          return [lt];
        }
      }),
      labels: Object.fromEntries(o.slice(0, v + 1).flatMap(B => B.type === "label" ? [[B.at, B.label]] : [])),
      notes: o.flatMap((B, J) => B.type === "note" ? [J < r || J === i ? "past" : "future"] : [])
    };
  }
  let T = false;
  let m = false;
  function w() {
    if (!T) {
      T = true;
      queueMicrotask(() => {
        T = false;
        if (!m) {
          s(y());
        }
      });
    }
  }
  function k() {
    const O = t.snapshot();
    if (r === 0) {
      t.overview(e.nodes, e.labels, e.links);
    } else {
      o.slice(0, r).forEach(Z => t.apply(Z));
    }
    t.morph(O, d);
  }
  function A(O) {
    const Z = o[O + 1];
    const v = GS[u];
    if (Z.step !== o[O].step) {
      return v.step;
    } else if (Z.quick && o[O].quick) {
      return v.quick;
    } else {
      return v.event;
    }
  }
  async function N() {
    if (i !== -1) {
      return;
    }
    if (r >= o.length) {
      c = false;
      w();
      return;
    }
    const O = r;
    const Z = d;
    i = O;
    w();
    if (u === "sequence") {
      t.apply(o[O]);
      await ge(WS(o[O]), Z);
    } else {
      await t.run(o[O], Z);
    }
    if (Z !== d || (Z.finish && (d = {
      cancelled: false
    }, t.clear(), t.apply(o[O])), i = -1, r = O + 1, r >= o.length && (c = false), w(), !c)) {
      return;
    }
    const v = p = {
      cancelled: false
    };
    await ge(() => A(O), v);
    if (p === v) {
      p = null;
    }
    if (!v.cancelled && c) {
      N();
    }
  }
  function L() {
    d.cancelled = true;
    d = {
      cancelled: false
    };
    if (p) {
      p.cancelled = true;
    }
    p = null;
    i = -1;
    t.clear();
    yn.resume();
  }
  function Q() {
    L();
    c = false;
    r = 0;
    k();
    w();
  }
  function ne() {
    if (r >= o.length && i === -1) {
      Q();
    }
    c = true;
    yn.resume();
    w();
    if (i === -1 && !p) {
      N();
    }
  }
  function be() {
    c = false;
    yn.pause();
    w();
  }
  return {
    reset: Q,
    dispose() {
      L();
      c = false;
      m = true;
    },
    toggle: () => c ? be() : ne(),
    pause: be,
    play: ne,
    step() {
      c = false;
      if (p) {
        p.cancelled = true;
      }
      p = null;
      yn.resume();
      w();
      if (i === -1) {
        N();
      }
    },
    setMode(O) {
      if (O !== u) {
        u = O;
        if (O === "sequence" && i !== -1) {
          d.finish = true;
          d.cancelled = true;
        }
      }
    },
    jump(O) {
      L();
      r = o.findIndex(Z => Z.step === O);
      k();
      ne();
    }
  };
}
await ry();
const we = document.querySelector("#app");
we.innerHTML = `
  <div class="shell">
    ${gy()}
    <main class="workspace">
      ${qy(_s)}
      ${dS()}
      ${fS()}
      ${AS()}
    </main>
    <div class="scrim" aria-hidden="true"></div>
    ${Ay()}
    ${$y()}
  </div>
`;
const YS = [{
  name: "wide",
  min: 1440,
  canvas: 1672
}, {
  name: "medium",
  min: 1100,
  canvas: 1180
}, {
  name: "tablet",
  min: 900,
  canvas: 900
}, {
  name: "narrow",
  min: 640,
  canvas: 640
}, {
  name: "phone",
  min: 0,
  canvas: 380
}];
const at = document.documentElement;
const ze = we.querySelector(".shell");
let ap = null;
function sc() {
  const e = at.clientWidth;
  const t = YS.find(a => e >= a.min);
  const s = t.name !== ap;
  ap = t.name;
  if (s) {
    at.classList.add("is-relaid");
  }
  const n = t.name === "wide" ? e / t.canvas : Math.min(1, e / t.canvas);
  const o = !["wide", "medium"].includes(t.name);
  at.dataset.layout = t.name;
  at.classList.toggle("is-stacked", o);
  at.classList.toggle("is-single", t.name === "narrow" || t.name === "phone");
  if (o) {
    wn.inert = !vn();
  } else {
    Vs(false);
  }
  ze.style.zoom = n;
  ze.style.width = `${e / n}px`;
  ze.style.height = o ? "" : `${window.innerHeight / n}px`;
  ze.style.minHeight = o ? `${window.innerHeight / n}px` : "";
  Gr(we);
  Wr(we);
  nc?.();
  if (s) {
    at.offsetWidth;
    at.classList.remove("is-relaid");
  }
}
let nc = null;
const gl = we.querySelector(".drawer-btn");
const wn = we.querySelector(".sidebar");
const vn = () => ze.classList.contains("is-drawer-open");
function Vs(e) {
  const t = at.classList.contains("is-stacked");
  ze.classList.toggle("is-drawer-open", e);
  at.classList.toggle("is-locked", e);
  gl.setAttribute("aria-expanded", e);
  wn.inert = t && !e;
  if (e) {
    wn.querySelector(".drawer-close").focus({
      preventScroll: true
    });
  } else if (t && wn.contains(document.activeElement)) {
    gl.focus({
      preventScroll: true
    });
  }
}
gl.addEventListener("click", () => Vs(!vn()));
wn.querySelector(".drawer-close").addEventListener("click", () => Vs(false));
we.querySelector(".scrim").addEventListener("click", () => Vs(false));
sc();
window.addEventListener("resize", sc);
window.addEventListener("orientationchange", sc);
const Xe = we.querySelector(".topbar");
const Yr = we.querySelector(".sidebar");
const oc = we.querySelector(".overview");
const os = we.querySelector(".packets");
const ac = we.querySelector(".simulation");
const jr = we.querySelector(".sequence");
let vt = null;
let Te = null;
let bt = null;
const n0 = pS(ac, e => Te?.setMode(e));
const o0 = () => [...os.querySelectorAll("tr[data-packet]")].filter(e => !e.hidden && e.dataset.shown === "1").map(e => Number(e.dataset.packet));
const kt = iS(ac.querySelector(".inspector"), {
  visible: o0,
  onChange: e => {
    for (const o of we.querySelectorAll(".is-inspected")) {
      o.classList.remove("is-inspected");
    }
    at.classList.toggle("is-inspecting", e !== null);
    if (e === null) {
      return;
    }
    we.querySelectorAll(`tr[data-packet="${e}"], .seq-arrow[data-packet="${e}"]`).forEach(o => o.classList.add("is-inspected"));
    const t = os.querySelector(`tr[data-packet="${e}"]`);
    const s = os.querySelector(".packet-scroll");
    const n = os.querySelector("thead").offsetHeight;
    if (t.offsetTop < s.scrollTop + n) {
      s.scrollTo({
        top: t.offsetTop - n,
        behavior: "smooth"
      });
    } else if (t.offsetTop + t.offsetHeight > s.scrollTop + s.clientHeight) {
      s.scrollTo({
        top: t.offsetTop + t.offsetHeight - s.clientHeight,
        behavior: "smooth"
      });
    }
  }
});
const a0 = e => {
  if (bt?.playing || bt?.running) {
    Te.pause();
  }
  kt.open(vt, e);
};
jr.addEventListener("click", e => {
  const t = e.target.closest(".seq-arrow.is-shown");
  if (t) {
    a0(Number(t.dataset.packet));
  }
});
Bw(jr);
const rc = _S(we.querySelector(".network"));
const kn = ac.querySelector(".stage-controls");
jl(Xe, _s);
ky(Xe);
function r0(e, t = vt) {
  Ty(Xe, e, t);
  Vy(Yr, e, t);
  vS(oc, e, t, Ts.findIndex(n => n.id === t.id));
  CS(os, e, t);
  zu(kn, e);
  const s = kt.index();
  if (s !== null && !o0().includes(s)) {
    kt.close();
  }
  Gw(jr, e, t);
}
function ic(e) {
  if (vt?.id === e) {
    return Te.reset();
  }
  kt.close();
  Te?.dispose();
  vt = _s[e];
  const t = vt;
  Te = VS(t, rc, s => {
    bt = s;
    if (Ym(t, s)) {
      jl(Xe, _s);
      Wy(Yr, _s);
    }
    r0(s, t);
  }, {
    mode: n0.view()
  });
  Te.reset();
}
function rp() {
  sy(we);
  uy(Xe);
  Gr(Xe);
  Wr(we);
  jl(Xe, _s);
  if (vt) {
    bS(oc);
    $S(os, vt);
    ka(kn);
    rc.retext();
    Hu(jr);
    if (kt.isOpen()) {
      kt.open(vt, kt.index());
    }
    if (bt) {
      r0(bt);
    }
  }
}
oy(() => {
  if (!document.startViewTransition || Ne()) {
    return rp();
  }
  at.classList.add("is-retexting");
  document.startViewTransition(rp).finished.finally(() => at.classList.remove("is-retexting"));
});
hy(Xe, e => ku(e));
const ip = () => vn() && setTimeout(() => Vs(false), 220);
Ky(Yr, {
  onStep: e => {
    Te.jump(e);
    ip();
  },
  onSelect: e => {
    ic(e);
    ip();
  }
});
mS(oc, () => Te.reset());
const i0 = "protocol-explorer:speed";
function lc(e, t = true) {
  yn.setSpeed(e);
  LS(os, e);
  Qu(kn, e);
  if (t) {
    try {
      localStorage.setItem(i0, e);
    } catch {}
  }
}
try {
  const e = Number(localStorage.getItem(i0));
  if (ua.includes(e)) {
    lc(e, false);
  }
} catch {}
const l0 = (e, t) => {
  try {
    localStorage.setItem(e, t ? "1" : "0");
  } catch {}
};
const c0 = e => {
  try {
    return localStorage.getItem(e);
  } catch {
    return null;
  }
};
const bo = () => at.classList.contains("is-stacked");
const jS = ze.querySelector(".workspace");
function d0(e, t = true) {
  if (t && !Ne() && !bo()) {
    return e();
  }
  ze.classList.add("is-instant");
  e();
  jS.offsetWidth;
  ze.classList.remove("is-instant");
}
const h0 = "protocol-explorer:list";
const Sl = Xe.querySelector(".list-btn");
function p0(e, {
  save: t = true,
  animate: s = true
} = {}) {
  if (e !== !ze.classList.contains("is-list-hidden")) {
    d0(() => {
      ze.classList.toggle("is-list-hidden", !e);
      Sl.setAttribute("aria-expanded", e);
      Yl(Sl, e ? "Hide the protocol list (L)" : "Show the protocol list (L)");
      if (!bo()) {
        wn.inert = !e;
      }
    }, s);
    if (t) {
      l0(h0, e);
    }
  }
}
const u0 = () => bo() ? Vs(!vn()) : p0(ze.classList.contains("is-list-hidden"));
Sl.addEventListener("click", u0);
const f0 = "protocol-explorer:focus";
const Tl = Xe.querySelector(".focus-btn");
const zS = () => ze.classList.contains("is-focus") && !bo();
const QS = 64;
function m0(e, {
  save: t = true,
  animate: s = true
} = {}) {
  if (e !== ze.classList.contains("is-focus")) {
    d0(() => {
      ze.classList.toggle("is-focus", e);
      Tl.setAttribute("aria-pressed", e);
      Yl(Tl, e ? "Show all panels (D)" : "Diagram only (D)");
      nc();
      if (e) {
        ka(kn);
      }
    }, s);
    if (t) {
      l0(f0, e);
    }
  }
}
const y0 = () => !bo() && m0(!ze.classList.contains("is-focus"));
Tl.addEventListener("click", y0);
const bl = Xe.querySelector(".fullscreen-btn");
at.classList.toggle("can-fullscreen", !!document.fullscreenEnabled);
function w0() {
  if (document.fullscreenEnabled) {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      at.requestFullscreen().catch(() => {});
    }
  }
}
bl.addEventListener("click", w0);
document.addEventListener("fullscreenchange", () => {
  const e = !!document.fullscreenElement;
  bl.setAttribute("aria-pressed", e);
  Yl(bl, e ? "Exit fullscreen (F)" : "Fullscreen (F)");
});
nc = () => {
  rc.setInset(zS() ? QS : 0);
  wn.inert = bo() ? !vn() : ze.classList.contains("is-list-hidden");
};
if (c0(h0) === "0") {
  p0(false, {
    save: false,
    animate: false
  });
}
if (c0(f0) === "1") {
  m0(true, {
    save: false,
    animate: false
  });
}
const g0 = Cy(we.querySelector(".shortcuts"), Au);
Xe.querySelector(".keys-btn").addEventListener("click", () => g0.open());
function S0(e, t = null) {
  if (vt?.id !== e || t === null) {
    ic(e);
  }
  if (t !== null) {
    Te.jump(t);
  }
  if (vn()) {
    Vs(false);
  }
}
function XS(e, t = null) {
  _y(Yr, e);
  S0(e, t);
}
const cc = Dy(we.querySelector(".palette"), {
  protocols: Ts,
  lessons: _s,
  choose: XS
});
Xe.querySelector(".search-btn").addEventListener("click", () => cc.open());
function lp(e) {
  const t = Ts.filter(n => _s[n.id]).map(n => n.id);
  const s = t.indexOf(vt?.id);
  S0(t[(s + e + t.length) % t.length]);
}
document.fonts.ready.then(() => {
  tc(os);
  ka(kn);
  Gr(Xe);
  Wr(we);
});
document.fonts.addEventListener("loadingdone", () => {
  tc(os);
  ka(kn);
  Gr(Xe);
  Wr(we);
});
const T0 = {
  toggle: () => Te.toggle(),
  step: () => Te.step(),
  reset: () => Te.reset(),
  prev: () => b0(),
  speed: e => lc(e)
};
ES(os, {
  ...T0,
  inspect: a0
});
ju(kn, T0);
function ZS() {
  if (!bt?.started) {
    return Te.jump(0);
  }
  if (bt.activeStep < vt.steps.length - 1) {
    Te.jump(bt.activeStep + 1);
  }
}
function b0() {
  if (bt?.started) {
    if (bt.done) {
      return Te.jump(vt.steps.length - 1);
    }
    if (bt.activeStep > 0) {
      Te.jump(bt.activeStep - 1);
    } else {
      Te.reset();
    }
  }
}
const cp = () => kt.isOpen() ? kt.step(1) : ZS();
const dp = () => kt.isOpen() ? kt.step(-1) : b0();
const hp = e => lc(ua[Math.max(0, Math.min(ua.length - 1, ua.indexOf(yn.speed) + e))]);
const vl = {
  " ": () => Te.toggle(),
  ArrowRight: () => gn() ? dp() : cp(),
  ArrowLeft: () => gn() ? cp() : dp(),
  Escape: () => vn() ? Vs(false) : kt.isOpen() ? kt.close() : Te.reset(),
  s: () => !bt?.done && Te.step(),
  "[": () => hp(-1),
  "]": () => hp(1),
  v: () => n0.toggle(),
  d: y0,
  l: u0,
  f: w0,
  t: () => Py(Xe),
  n: () => lp(1),
  p: () => lp(-1),
  "/": () => cc.open(),
  "?": () => g0.open()
};
for (let e = 1; e <= 9; e++) {
  vl[e] = () => e <= vt.steps.length && Te.jump(e - 1);
}
const JS = e => e instanceof Element && e.closest("input, textarea, select, [contenteditable=\"true\"], .lang-menu, .speed-menu");
const e2 = () => !!we.querySelector("dialog[open]");
for (const e of ["keydown", "keyup"]) {
  window.addEventListener(e, t => {
    if (!Te || e2()) {
      return;
    }
    if ((t.ctrlKey || t.metaKey) && !t.altKey && t.key.toLowerCase() === "k") {
      t.preventDefault();
      if (e === "keydown") {
        cc.open();
      }
      return;
    }
    const s = vl[t.key.length === 1 && t.key !== " " ? t.key.toLowerCase() : t.key] ?? vl[t.key];
    if (!!s && !t.ctrlKey && !t.metaKey && !t.altKey && !JS(t.target)) {
      t.preventDefault();
      if (e === "keydown" && !t.repeat) {
        s();
      }
    }
  });
}
document.fonts.ready.then(() => ic("http"));
